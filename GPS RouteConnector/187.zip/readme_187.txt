R187:
Made plugin proof to callback id changes