R186:
Fixed array manipulation crashes