R185:
Fixed crashes