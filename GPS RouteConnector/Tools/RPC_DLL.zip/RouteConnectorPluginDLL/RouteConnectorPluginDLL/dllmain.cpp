
#define WIN32_LEAN_AND_MEAN   

#include <windows.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iterator>
#include <queue>
#include <cstring>
#include <limits>
#include <fstream>
#include <stack>
#include <set>
#include <string>

typedef int cell;
typedef unsigned int ucell;
      
#define FUNCTION __stdcall 

#include "Graph.h"
#include "dllmain.h"
#include "functions.h"
#include "exports.h"

BOOL APIENTRY DllMain( HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{

	return TRUE;
}

BOOL FUNCTION LOAD_SYSTEM()
{
	for(int i = 0; i < MAX_NODES; ++i)
	{
		xNode[i].Exists = false;
		xNode[i].AddedToGraph = false;
		xNode[i].NodeID = NULL;
		for(int j = 0; j < MAX_CONNECTIONS; ++j)
		{
			xNode[i].CW[j].ID = (-1);
		}
	}
	ReadNodeData("GPS.dat");
	return TRUE;
}

