using namespace std;

#define MAX_NODES (32768)
#define MAX_CONNECTIONS (5)

#define BOTH (0)
#define One_To_Two (1)

bool constructed = false;

float FUNCTION GetConnectedNodeDistance(int NodeID,int ConnectID);
float FUNCTION GetDistanceBetweenPoints(int NodeID1,int NodeID2);

int FUNCTION IsNodeAddedToGraph(int NodeID);
int FUNCTION AddNotAddedNodeToGraph(int NodeID);
int FUNCTION AddNode(float X,float Y, float Z, int AddToGraph);
int FUNCTION AddNodeEx(int i,float X,float Y, float Z, int AddToGraph);
int FUNCTION GetNextEmptyNodeID();
int FUNCTION ConnectNodes(int NodeOne, int NodeTwo, int AddToGraph,int direction);
int FUNCTION NearestNodeFromPoint(float X, float Y, float Z, float MaxDist, int ignorenode);
int FUNCTION ReadNodeData(char * file);
int FUNCTION WriteNodeData(char * file);
int FUNCTION GetConnectedNodes(int NodeID);
int FUNCTION GetNodeDirectionToConnect(int NodeID, int ConnectID);
int FUNCTION GetConnectedNodeID(int NodeID,int ConnectID);
void FUNCTION constructGaph();
int FUNCTION DisconnectAllConnectionsFromNode(int Node);
int FUNCTION DisconnectNodeFromNode(int Node_One,int Node_Two);
int FUNCTION RemoveNode(int Node);
int FUNCTION RemoveWholeNodePath(int NodeID);
int FUNCTION NodeExists(int NodeID);
int FUNCTION GetNodeDirectionToConnect(int NodeID, int ConnectID);
int FUNCTION SetNodeDirectionToConnect(int NodeID, int ConnectID,int Direction);
int GPSdatVersion = 0;
int FUNCTION RemoveWholeNodePath(int NodeID);
int FUNCTION CalculatePath(int Start, int End, int * Array, int &cost, int &size);

char buffer[2048];
//
Graph* dgraph;
vector <cell>tbcway;

struct ConnectInfo
{
	int ID;
	float Distance;
	int connect_direction;
};

struct NodesInfo
{
	bool Exists;
	float xPOS;
	float yPOS;
	float zPOS;
	bool AddedToGraph;
	Node* NodeID;
	ConnectInfo CW[MAX_CONNECTIONS];
};

struct RM
{
	int ID;
	bool closed;
	RM(int ID_,bool closed_)
	{
		ID = ID_;
		closed = closed_;
	}
};

bool FUNCTION inList(int ID, std::vector<RM>* pList);

vector			<RM>							RemoveNodes;
NodesInfo		xNode[MAX_NODES];