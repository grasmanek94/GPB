
int FUNCTION GetGPSdatVersion()
{
	return GPSdatVersion;
}


int FUNCTION GetPluginVersion()
{
	return 181;
}

int FUNCTION GetNodePos(int NodeID, float &X, float &Y, float &Z )
{
	if(NodeID < 0 || NodeID > (MAX_NODES-1))
		return 0;
	if(xNode[NodeID].Exists == false)
		return -1;
	X = xNode[NodeID].xPOS;
	Y = xNode[NodeID].yPOS;
	Z = xNode[NodeID].zPOS;
	return 1;
}

float FUNCTION GetangleBetweenNodes( int NodeID_1, int NodeID_2, int NodeID_3 )
{
	if(NodeID_1 < 0 || NodeID_1 > (MAX_NODES-1))
		return 0.0f;
	if(NodeID_2 < 0 || NodeID_2 > (MAX_NODES-1))
		return 0.0f;
	if(NodeID_3 < 0 || NodeID_3 > (MAX_NODES-1))
		return 0.0f;

    double c = sqrt(((xNode[NodeID_2].xPOS - xNode[NodeID_1].xPOS) * (xNode[NodeID_2].xPOS - xNode[NodeID_1].xPOS)) + ((xNode[NodeID_2].yPOS - xNode[NodeID_1].yPOS) * (xNode[NodeID_2].yPOS - xNode[NodeID_1].yPOS)));
    double b = sqrt(((xNode[NodeID_2].xPOS - xNode[NodeID_3].xPOS) * (xNode[NodeID_2].xPOS - xNode[NodeID_3].xPOS)) + ((xNode[NodeID_2].yPOS - xNode[NodeID_3].yPOS) * (xNode[NodeID_2].yPOS - xNode[NodeID_3].yPOS)));
    double a = sqrt(((xNode[NodeID_1].xPOS - xNode[NodeID_3].xPOS) * (xNode[NodeID_1].xPOS - xNode[NodeID_3].xPOS)) + ((xNode[NodeID_1].yPOS - xNode[NodeID_3].yPOS) * (xNode[NodeID_1].yPOS - xNode[NodeID_3].yPOS)));
    float C = (float)(acos(((a*a) - ((b*b) + (c*c))) / (-2.0 * b * c)) * 57.295779513082320876798154814105);

	return C;
}

int FUNCTION CalculatePath(int Start, int End, int * Array, int &cost, int &size)
{
	dgraph->findPath_r(xNode[Start].NodeID ,xNode[End].NodeID,tbcway,cost);	
	dgraph->reset();
	std::move(tbcway.begin(), tbcway.end(), Array);
	size = tbcway.size();
	tbcway.clear();
	return 1;
}