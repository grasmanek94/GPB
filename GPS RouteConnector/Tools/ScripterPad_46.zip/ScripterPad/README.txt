Scripter Pad Revision 46


Requirements:
	.NET: Compiled for these .NET FRAMEWORKS:
		-2.0
		-3.0
		-3.5
		-4.0 Client Profile
	RAM:
		-At least (MINIMUM!) 512 MB of FREE RAM
	CPU:
		-Any CPU should do, multicore CPU's won't affect performance, only one core is used,
		-Recommended speed: 1.5 GHz
		-If you have a multicore processor set affinity to a processor that is not the first, so it will load everything fast


Usage:
	Fire up the program,
	you should see something like this:
	
	[img]http://img528.imageshack.us/img528/5057/mainform.png[/img]

Explaination:
	1) This is the list of all nodes on the whole map
	2) when you click a node id in list 1, in list 2 you will see to which nodes the node in list 1 is connected
	3) this will draw a square grid (750x750) on the map
	4) refreshes the bitmap, however I think you never would be forced to use that, included for "just in case"
	5) displays the node X and Y pos, all node positions are 0 because there is no heightmap implemented , IX and IY are the pixel positions
	6) The status bar of current action fro bittons 10,12 and 13
	7) The main map window, you can scroll by holding your right mous button and moving the mouse around
	8) This is the mini panel where all thhe map magic comes from,
	   When you have selected "Place Node, then when you click with the left mouse button on the map, a ndoe will be placed.
	   When you have placed a few nodes, select "Connect Nodes", then click nearby any node you want to connect,
	   In "Node Selected : xx" you will see the first ndoe you selected, with Deselect button you can deselect it.
	   When you have selected one node, click nearby an second node to connect it, THERE IS NO UDNO ACTION SO BE CAREFULL,
	   If you want to undo it, you will need to save to a file and edit the file manually with notepad or any other text editor, but be carefull, this can corrupt the file and make it unreadable to the program!
	   GX and GY are for when you have the grid drawn, they let you know which grid square you clicked.
	9) This shows additional information for selected nodes in List1 and List2
	10) This saves an image file (BMP) of the current map you created with all nodes and connections, what you see is what you get, note that this file is up to 80 MB big, you will have to re-save it yourself to make the size smaller.
	11) this is the output filename for your preview image
	12) 
	    -Load Connections > Loads all connections from the given <filename|GPS.dat|>, please load all points FIRST,
	    -Save Connections > Saves all current made and loaded connections to the specifies filename
	13)
	    -Draw Numbers > When checked the program will create numbers near all points.
	    -Load Points > See Load Connections, the difference is that it loads points, not connections.
	    -Save Points > See Save connections, the difference is that it saves points, not connections.

Noted:
	The output files can easily be edited with any text editor.
	The image file called "map.jpg" MUST be there where the EXE is.