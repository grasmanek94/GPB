#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
#include<windows.h>

#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#ifdef OS_WINDOWS
	void Thread::BackgroundCalculator( void *unused )
#else
	void *Thread::BackgroundCalculator( void *unused )
#endif
{
	int startid;
	int endid;
	int extra;
	AMX *amx;
	cell Store[MAX_NODES];
	while( true )
    {
		if(!QueueVector.empty())
		{
			Lock  q (mutex_q);
			Lock  p (mutex_p);
			if (q.acquire ())
			{
				//cout << "ACQUIRED_NOT_EMPTY\n" << endl;
				startid = QueueVector.back().start;
				endid = QueueVector.back().end;
				extra = QueueVector.back().extraid;
				amx = QueueVector.back().script;
				QueueVector.pop_back();
				//if(
					q.release();
				//== false)
				//{
				//	cout << "Calc can't release the 'q' lock!\n";
				//}
				//else
				//{
				//	cout << "Calc released the 'q' lock!\n";
				//}
				way = dgraph->findPath_r(xNode[startid].NodeID ,xNode[endid].NodeID);
				dgraph->reset();
				for(int i = 0 ; i < way[0]; ++i)
				{
					Store[i] = way[i+2];
				}
				
				while(p.acquire () == false)
				{}
				PassVector.push(PassData(Store,way[0],extra,amx,way[1]));
				//if(
					p.release();
				//	== false)
				//{
				//	cout << "Calc can't release the 'p' lock!\n";
				//}
			}
			//else
			//{
			//	cout << "Calc can't aquire the 'q' lock!\n";
			//}
		}
		SLEEP(30);
		//-------------------------
    }

	EXIT_THREAD();//should be never reached..
}