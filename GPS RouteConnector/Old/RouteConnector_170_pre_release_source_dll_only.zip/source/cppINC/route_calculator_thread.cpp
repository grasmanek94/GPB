/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
#include<windows.h>

#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#ifdef OS_WINDOWS
	void Thread::BackgroundCalculator( void *unused )
#else
	void *Thread::BackgroundCalculator( void *unused )
#endif
{
	while( true )
    {
		//-------------------------
		//while(!QueueVector.empty())
		if(!QueueVector.empty())
		{
			while(locked.queue) { }
			locked.queue = true;
			int startid;
			int endid;
			int extra;
			AMX *amx;
			startid = QueueVector.back().start;
			endid = QueueVector.back().end;
			extra = QueueVector.back().extraid;
			amx = QueueVector.back().script;
			QueueVector.pop_back();
			locked.queue = false;
			way = dgraph->findPath_r(xNode[startid].NodeID ,xNode[endid].NodeID);
			dgraph->reset();
			cell Store[MAX_NODES];
			for(int i = 0 ; i < way[0]; ++i)
			{
				Store[i] = way[i+2];
			}
			while(locked.passer) { }
			locked.passer = true;
			PassVector.push(PassData(Store,way[0],extra,amx,way[1]));
			locked.passer = false;
		}
		SLEEP(10);
		//-------------------------
    }

	EXIT_THREAD();//should be never reached..
}