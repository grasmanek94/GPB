/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gpb.googlecode.com/
*/
AMX_NATIVE_INFO AMXNatives[ ] =
{
	{"AddNode", n_AddNode},
	{"AddNodeEx" , n_AddNodeEx},
	{"GetNodePos", n_GetNodePos},
	{"ConnectNodes", n_ConnectNodes},
	{"WriteNodesToFile", n_WriteNodesToFile},
	{"ReadNodesFromFile", n_ReadNodesFromFile},
	{"NearestPlayerNode", n_NearestPlayerNode},
	{"NearestNodeFromPoint", n_NearestNodeFromPoint},
	{"CalculatePath",n_CalculatePath},
	{"IsNodeIntersection",n_IsNodeIntersection},
	{"GetAngleBetweenNodes",n_GetangleBetweenNodes},
	{"GetConnectedNodes",n_GetConnectedNodes},
	{"GetNextEmptyNodeID",n_GetNextEmptyNodeID},
	{"GetQueueSize",n_GetQueueSize},
	{"GetConnectedNodeID",n_GetConnectedNodeID},
	{"GetConnectedNodeDistance",n_GetConnectedNodeDistance},
	{"GetDistanceBetweenNodes",n_GetDistanceBetweenNodes},
	{"IsNodeInPathFinder",n_IsNodeInGraph},
	{"StoreRouteArray",n_StoreArray},
	{"GetRouteArray",n_ReturnArray},
	{"DeleteArray",n_DeleteArray},
	{"GetRouteAtPos",n_GetRouteAtPos},
	{"AddExistingNodeToPathFinder",n_AddNotAddedNodeToGraph},
	{"RemoveNode",n_RemoveNode},
	{"DisconnectNodeFromNode",n_DisconnectNodeFromNode},
	{"DisconnectAllFromNode",n_DisconnectAllFromNode},
	{"DeleteNodeSystemAtNode",n_ReturnDeletedNodeArray},
	{"GetNodeDirectionToConnect",n_GetNodeDirectionToConnect},
	{"SetNodeDirectionToConnect",n_SetNodeDirectionToConnect},
	{"NodeExists",n_NodeExists},
	{"GetPluginVersion",n_GetPluginVersion},
	{"GetGPSdatVersion",n_GetGPSdatVersion},
	{"RemoveAllRouteIDFromQueue",n_DeleteRouteIDFromQueue},
	{"gps_OnGameModeInit",n_OnGameModeInit},
	{"gps_OnPlayerConnect",n_OnPlayerConnect},
	{"gps_OnPlayerDisconnect",n_OnPlayerDisconnect},
	{"gps_ManualPlayerAdding",n_ManualPlayerAdding},
	{"gps_AddPlayer",n_AddPlayer},
	{"gps_RemovePlayer",n_RemovePlayer},
	{"GetRouteArrayFromTo",n_GetRouteFromTo},
	{"GetRouteArraySize",n_GetRouteArraySize},
	{0,                0}
};

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	amx_list.push_back(amx);
	return amx_Register( amx, AMXNatives, -1 );
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	std::vector<AMX *>::iterator i = amx_list.begin(); 
	while (i != amx_list.end())
	{ 
		i = amx_list.erase(i); 
	} 
	return AMX_ERR_NONE;
}

static cell AMX_NATIVE_CALL n_GetGPSdatVersion( AMX* amx, cell* params )
{
	return GPSdatVersion;
}

static cell AMX_NATIVE_CALL n_NodeExists( AMX* amx, cell* params )
{
	return NodeExists(params[1]);
}

static cell AMX_NATIVE_CALL n_GetPluginVersion( AMX* amx, cell* params )
{
	return PLUGIN_VERSION;
}

static cell AMX_NATIVE_CALL n_ConnectNodes( AMX* amx, cell* params )
{
	return ConnectNodes(params[1],params[2],params[3],params[4]);
}

static cell AMX_NATIVE_CALL n_NearestNodeFromPoint( AMX* amx, cell* params )
{
	return NearestNodeFromPoint(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4]),params[5]);
}

static cell AMX_NATIVE_CALL n_NearestPlayerNode( AMX* amx, cell* params )
{
	return NearestPlayerNode(params[1],amx_ctof(params[2]),params[3]);
}

static cell AMX_NATIVE_CALL n_AddNode( AMX* amx, cell* params )
{
	return AddNode(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]),params[4]);
}

static cell AMX_NATIVE_CALL n_AddNodeEx( AMX* amx, cell* params )
{
	return AddNodeEx(params[1],amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4]),params[5]);
}

static cell AMX_NATIVE_CALL n_GetConnectedNodes( AMX* amx, cell* params )
{
	return GetConnectedNodes(params[1]);
}

static cell AMX_NATIVE_CALL n_GetQueueSize( AMX* amx, cell* params )
{
	int size = (-1);
	if(locked.queue == false)
	{
		locked.queue = true;
		size = QueueVector.size();
		locked.queue = false;
	}
	return size;
}

static cell AMX_NATIVE_CALL n_CalculatePath( AMX* amx, cell* params )
{
	while(locked.queue){}
	locked.queue = true;
	QueueVector.push_back(QuedData(params[1],params[2],params[3],amx));
	locked.queue = false;
	return 1;
}

static cell AMX_NATIVE_CALL n_DeleteRouteIDFromQueue( AMX* amx, cell* params )
{
	if(locked.queue) return -1;
	locked.queue = true;
	int routeid = params[1];
	int removed = 0;
	for (int i = QueueVector.size(); --i >= 0; ) 
	{     
		if(QueueVector.at(i).extraid == routeid)
		{
			QueueVector.erase(QueueVector.begin()+i);
			++removed;
		}
	}
	locked.queue = false;
	return removed;
}

static cell AMX_NATIVE_CALL n_WriteNodesToFile( AMX* amx, cell* params )
{
	char * tmp;
	amx_StrParam(amx,params[1],tmp);
	return WriteNodeData(tmp);
}

static cell AMX_NATIVE_CALL n_ReadNodesFromFile( AMX* amx, cell* params )
{
	char * tmp;
	amx_StrParam(amx,params[1],tmp);
	return ReadNodeData(tmp);
}

static cell AMX_NATIVE_CALL n_GetNodePos( AMX* amx, cell* params )
{
	if(params[1] < 0 || params[1] > (MAX_NODES-1))
		return 0;
	if(xNode[params[1]].Exists == false)
		return -1;
	cell* cptr;
	amx_GetAddr(amx, params[2], &cptr);
	*cptr = amx_ftoc(xNode[params[1]].xPOS);
	amx_GetAddr(amx, params[3], &cptr);
	*cptr = amx_ftoc(xNode[params[1]].yPOS);
	amx_GetAddr(amx, params[4], &cptr);
	*cptr = amx_ftoc(xNode[params[1]].zPOS);
	return 1;
}

static cell AMX_NATIVE_CALL n_GetangleBetweenNodes( AMX* amx, cell* params )
{
	float C = 0.0f;
	if(params[1] < 0 || params[1] > (MAX_NODES-1))
		return amx_ftoc(C);
	if(params[2] < 0 || params[2] > (MAX_NODES-1))
		return amx_ftoc(C);
	if(params[3] < 0 || params[3] > (MAX_NODES-1))
		return amx_ftoc(C);


	double a = sqrt(pow(xNode[params[1]].xPOS-xNode[params[2]].xPOS,2.0f)+pow(xNode[params[1]].yPOS-xNode[params[2]].yPOS,2.0f)+pow(xNode[params[1]].zPOS-xNode[params[2]].zPOS,2.0f));
	double b = sqrt(pow(xNode[params[2]].xPOS-xNode[params[3]].xPOS,2.0f)+pow(xNode[params[2]].yPOS-xNode[params[3]].yPOS,2.0f)+pow(xNode[params[2]].zPOS-xNode[params[3]].zPOS,2.0f));
	double c = sqrt(pow(xNode[params[1]].xPOS-xNode[params[3]].xPOS,2.0f)+pow(xNode[params[1]].yPOS-xNode[params[3]].yPOS,2.0f)+pow(xNode[params[1]].zPOS-xNode[params[3]].zPOS,2.0f));
	C = (float)acos((a*a+b*b-c*c)/(2*a*b));
	return amx_ftoc(C);
}

static cell AMX_NATIVE_CALL n_GetConnectedNodeDistance( AMX* amx, cell* params )
{
	float C = GetConnectedNodeDistance(params[1],params[2]);
	return amx_ftoc(C);
}

static cell AMX_NATIVE_CALL n_IsNodeIntersection( AMX* amx, cell* params )
{
	int connects = GetConnectedNodes(params[1]);
	if(connects == -1)return -1;
	if(connects < 3)return 0;
	return 1;
}

static cell AMX_NATIVE_CALL n_GetNextEmptyNodeID( AMX* amx, cell* params )
{
	return GetNextEmptyNodeID();
}

static cell AMX_NATIVE_CALL n_GetConnectedNodeID( AMX* amx, cell* params )
{
	return GetConnectedNodeID(params[1],params[2]);
}

static cell AMX_NATIVE_CALL n_GetDistanceBetweenNodes( AMX* amx, cell* params )
{
	float C = GetDistanceBetweenPoints(params[1],params[2]);
	return amx_ftoc(C);
}

static cell AMX_NATIVE_CALL n_IsNodeInGraph( AMX* amx, cell* params )
{
	return IsNodeAddedToGraph(params[1]);
}

static cell AMX_NATIVE_CALL n_AddNotAddedNodeToGraph( AMX* amx, cell* params )
{
	return AddNotAddedNodeToGraph(params[1]);
}

static cell AMX_NATIVE_CALL n_ReturnArray( AMX* amx, cell* params )
{
	for(int i = 0, j = RouteVector.size(); i < j; ++i)
	{
		if(RouteVector.at(i).id == params[1])
		{
			cell *dest = NULL;
			amx_GetAddr(amx,params[2],&dest);
			for(int a = 0, b = params[3]; a < b; ++a)
			{
				dest[a] = RouteVector.at(i).Paths[a];
			}
			return RouteVector.at(i).amount_of_nodes;
		}
	}
	return 0;
}

static cell AMX_NATIVE_CALL n_DeleteArray( AMX* amx, cell* params )
{
	for(int i = 0, j = RouteVector.size(); i < j; ++i)
	{
		if(RouteVector.at(i).id == params[1])
		{
			RouteID.erase(RouteID.begin()+i);
			free(RouteVector[i].Paths);
			free(RouteVector[i].Taken);
			RouteVector.erase(RouteVector.begin()+i);
			return 1;
		}
	}
	return 0;
}

static cell AMX_NATIVE_CALL n_StoreArray( AMX* amx, cell* params )
{
	int IDcounter = 0;
	for(int i = 0,j = RouteID.size(); i < j; ++i)
	{
		if(RouteID.at(i) == IDcounter)
		{
			i = 0;
			IDcounter++;
		}
	}
	cell *dest = NULL;
	amx_GetAddr(amx,params[2],&dest);
	int amount_of_nodes = params[1];
	RouteID.push_back(IDcounter);
	RouteVector.push_back(RouteData(dest,amount_of_nodes,IDcounter));
	return IDcounter;
}

static cell AMX_NATIVE_CALL n_GetRouteAtPos( AMX* amx, cell* params )
{
	for(int i = 0, j = RouteVector.size(); i < j; ++i)
	{
		if(RouteVector.at(i).id == params[1])
		{
			if(RouteVector.at(i).amount_of_nodes > i)
			{
				cell *dest = NULL;
				amx_GetAddr(amx,params[3],&dest);
				*dest = RouteVector.at(i).amount_of_nodes;
				return RouteVector.at(i).Paths[params[2]];
			}
		}
	}
	return 0;
}

static cell AMX_NATIVE_CALL n_GetRouteFromTo( AMX* amx, cell* params )
{
	for(int i = 0, j = RouteVector.size(); i < j; ++i)
	{
		if(RouteVector.at(i).id == params[1])
		{
			cell *dest = NULL;
			amx_GetAddr(amx,params[4],&dest);
			int c = 0;
			for(int a = params[2], b = params[3]; a < b; ++a)
			{
				if(c == params[5])
				{
					return c;
				}
				dest[c] = RouteVector.at(i).Paths[a];
				c++;
			}
			return c;
		}
	}
	return 0;
}

static cell AMX_NATIVE_CALL n_GetRouteArraySize( AMX* amx, cell* params )
{
	return RouteVector.at(params[1]).amount_of_nodes;
}

static cell AMX_NATIVE_CALL n_RemoveNode( AMX* amx, cell* params )
{
	return RemoveNode(params[1]);
}

static cell AMX_NATIVE_CALL n_DisconnectNodeFromNode( AMX* amx, cell* params )
{
	return DisconnectNodeFromNode(params[1],params[2]);
}

static cell AMX_NATIVE_CALL n_DisconnectAllFromNode( AMX* amx, cell* params )
{
	return DisconnectAllConnectionsFromNode(params[1]);
}

static cell AMX_NATIVE_CALL n_ReturnDeletedNodeArray( AMX* amx, cell* params )
{
	RemoveWholeNodePath(params[1]);
	cell *dest = NULL;
	amx_GetAddr(amx,params[2],&dest);
	int b = 0;
	b = params[3];
	if(b > (int)RemoveNodes.size())
		b = (int)RemoveNodes.size();

	for(int a = 0; a < b; ++a)
	{
		dest[a] = RemoveNodes.at(a).ID;
	}
	return RemoveNodes.size();
}

static cell AMX_NATIVE_CALL n_GetNodeDirectionToConnect( AMX* amx, cell* params )
{
	return GetNodeDirectionToConnect(params[1],params[2]);
}

static cell AMX_NATIVE_CALL n_SetNodeDirectionToConnect( AMX* amx, cell* params )
{
	return SetNodeDirectionToConnect(params[1],params[2],params[3]);
}

static cell AMX_NATIVE_CALL n_OnGameModeInit( AMX* amx, cell* params )
{
	return OnGameModeInit();
}

static cell AMX_NATIVE_CALL n_OnPlayerConnect( AMX* amx, cell* params )
{
	return OnPlayerConnect(params[1]);
}

static cell AMX_NATIVE_CALL n_OnPlayerDisconnect( AMX* amx, cell* params )
{
	return OnPlayerDisconnect(params[1]);
}

static cell AMX_NATIVE_CALL n_ManualPlayerAdding( AMX* amx, cell* params )
{
	ManualAdding = params[1];
	return ManualAdding;
}

static cell AMX_NATIVE_CALL n_AddPlayer( AMX* amx, cell* params )
{
	if(!IsPlayerConnected(params[1]))
		return 0;

	int size = PlayerLoopList.size();
	for (int index=0; index < size; ++index)
	{
		if(PlayerLoopList.at(index) == params[1])
		{
			return 2;
		}
	}
	PlayerLoopList.push_back(params[1]);	
	return 1;
}

static cell AMX_NATIVE_CALL n_RemovePlayer( AMX* amx, cell* params )
{
	int size = PlayerLoopList.size();
	for (int index=0; index < size; ++index)
	{
		if(PlayerLoopList.at(index) == params[1])
		{
			PlayerLoopList.erase(PlayerLoopList.begin()+index);
			return 1;
		}
	}
	return 0;
}