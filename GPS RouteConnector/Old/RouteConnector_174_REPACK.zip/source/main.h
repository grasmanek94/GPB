#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gpb.googlecode.com/
*/
using namespace std;
//no need to change the code in here at all.
static cell AMX_NATIVE_CALL n_NodeExists( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_ConnectNodes( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_NearestNodeFromPoint( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_NearestPlayerNode( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_AddNode( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_AddNodeEx( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetConnectedNodes( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetQueueSize( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_CalculatePath( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_WriteNodesToFile( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_ReadNodesFromFile( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetNodePos( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetangleBetweenNodes( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetConnectedNodeDistance( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_IsNodeIntersection( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetNextEmptyNodeID( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetConnectedNodeID( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetDistanceBetweenNodes( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_IsNodeInGraph( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_AddNotAddedNodeToGraph( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_ReturnArray( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_DeleteArray( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_StoreArray( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetRouteAtPos( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetRouteFromTo( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetRouteArraySize( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetNextNodeInArray( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_SetNodeFlagIndex( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_SetNodeFlagID( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_IsNodeInArray( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_RemoveNode( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_DisconnectNodeFromNode( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_DisconnectAllFromNode( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetNodeDirectionToConnect( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_SetNodeDirectionToConnect( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_DeleteRouteIDFromQueue( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetGPSdatVersion( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetPluginVersion( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_ReturnDeletedNodeArray( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_ManualPlayerAdding( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_AddPlayer( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_RemovePlayer( AMX* amx, cell* params );
//
static cell AMX_NATIVE_CALL n_EnableOPCNIC( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_DisableOPCNIC( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_OPCNICuseRealDistance( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_OPCNICuseArea( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_DisablePlayerOCNI( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_EnablePlayerOCNIC( AMX* amx, cell* params );

#if defined OS_WINDOWS
#include <Windows.h>
struct Lock //thanks to 'doublep' from StackOverflow for this RAII solution, edited it
{ 
  MUTEX mutex; 
  bool    locked; 
 
  Lock (MUTEX mutex) 
    : mutex (mutex), 
      locked (false) 
  {//cout << "LOCK CONSTRUCTOR CALLED " << GetCurrentThreadId() << "\n";
  } 
 
  ~Lock () 
  { release (); 
  //cout << "LOCK DESTRUCTOR CALLED " << GetCurrentThreadId() << "\n";
  } 
 
  bool acquire (int timeout = -1) 
  { 

    if (!locked && TryEnterCriticalSection(&mutex) != 0)
	{
		//cout << "LOCK AQUIRE CALLED " << GetCurrentThreadId() << " | TRUE\n";
		locked = true;
	}
	//else
	//{
	//	cout << "LOCK AQUIRE CALLED " << GetCurrentThreadId() << " | FALSE\n";
	//}
    return locked; 
  } 
 
  int release () 
  { 
    if (locked) 
	{LeaveCriticalSection(&mutex); locked = false; 
	//cout << "LOCK RELEASE CALLED " << GetCurrentThreadId() << " | TRUE\n";
	return true;} 
	//cout << "LOCK RELEASE CALLED " << GetCurrentThreadId() << " | FALSE\n";
    return false; 
  } 
}; 

MUTEX mutex_q;
MUTEX mutex_p;
#else
struct Lock //and here is my little edit for linux
{ 
  MUTEX&  mutex; 
  bool    locked; 
 
  Lock (MUTEX& mutex) 
    : mutex (mutex), 
      locked (false) 
  { } 
 
  ~Lock () 
  { release (); } 
 
  bool acquire (int timeout = -1) 
  { 
    if (!locked && pthread_mutex_lock (&mutex) == 0) 
      locked = true; 
    return locked; 
  } 
 
  int release () 
  { 
    if (locked) 
      locked = (pthread_mutex_unlock (&mutex) == 1); 
    return !locked; 
  } 
}; 

MUTEX mutex_q = PTHREAD_MUTEX_INITIALIZER;
MUTEX mutex_p = PTHREAD_MUTEX_INITIALIZER;

#endif

bool constructed = false;
bool OnPCNIDCenable = true;
bool CheckPlayerOCNIDC[MAX_PLAYERS];
bool UseRealClosestDistance = false;

int * way = new int[MAX_NODES+2];
char * IntToName(int integer);

float GetConnectedNodeDistance(int NodeID,int ConnectID);
float GetDistanceBetweenPoints(int NodeID1,int NodeID2);

int IsNodeAddedToGraph(int NodeID);
int AddNotAddedNodeToGraph(int NodeID);
int AddNode(float X,float Y, float Z, int AddToGraph,int AddToAreaScanner);
int AddNodeEx(int i,float X,float Y, float Z, int AddToGraph);
int GetNextEmptyNodeID();
int ConnectNodes(int NodeOne, int NodeTwo, int AddToGraph,int direction);
int NearestPlayerNode(int playerid, float MaxDist, int ignorenode, int UseArea);
int NearestNodeFromPoint(float X, float Y, float Z, float MaxDist, int ignorenode, int UseArea);
int ReadNodeData(char * file);
int WriteNodeData(char * file);
int GetConnectedNodes(int NodeID);
int GetNodeDirectionToConnect(int NodeID, int ConnectID);
int GetConnectedNodeID(int NodeID,int ConnectID);
int constructGaph();
int GlobOnUpdateIndex = (-1);
int OnPlayerClosestNodeIDChange(int playerid, int oldnode, int newnode);
int DisconnectAllConnectionsFromNode(int Node);
int DisconnectNodeFromNode(int Node_One,int Node_Two);
int RemoveNode(int Node);
int RemoveWholeNodePath(int NodeID);
int NodeExists(int NodeID);
int GetNodeDirectionToConnect(int NodeID, int ConnectID);
int SetNodeDirectionToConnect(int NodeID, int ConnectID,int Direction);
int GPSdatVersion = 0;
int UpdateCheck();
int g_Ticked  = 0;
int g_TickMax = PLUGIN_PRIVATE_UPDATE_AC;
int RemoveWholeNodePath(int NodeID);
int ManualAdding = 0;
//
Graph* dgraph;

struct ConnectInfo
{
	int ID;
	float Distance;
	int connect_direction;
};

struct NodesInfo
{
	bool Exists;
	float xPOS;
	float yPOS;
	float zPOS;
	bool AddedToGraph;
	Node* NodeID;
	ConnectInfo CW[MAX_CONNECTIONS];
};

struct NodesInfoScanner
{
	int NodeID;
	NodesInfoScanner(int i_NodeID)
	{
		NodeID = i_NodeID;
	}
};

struct QuedData
{
	int start;
	int end;
	int extraid;
	AMX * script;
	QuedData(int start_,int end_,int extraid_, AMX * script_)
	{
		start = start_;
		end = end_;
		extraid = extraid_;
		script = script_;
	}
};

struct PassData
{
	cell * Paths;
	int amount_of_nodes;
	int extraid;
	AMX * script;
	int MoveCost;
	PassData(cell *Paths_,int amount_of_nodes_, int extraid_, AMX * script_,int MoveCost_)
	{
		Paths = Paths_;
		amount_of_nodes = amount_of_nodes_;
		extraid = extraid_;
		script = script_;
		MoveCost = MoveCost_;
	}
};

//thanks to fabsch for helping fixing the array bug | http://forum.sa-mp.com/member.php?u=52846
struct RouteData
{
	cell * Paths;
	bool * Taken;
	int amount_of_nodes;
	int id;
	RouteData(cell *Paths_,int amount_of_nodes_, int id_)
	{
		Taken = (bool*)malloc(amount_of_nodes_ * sizeof(bool));
		Paths = (cell*)malloc(amount_of_nodes_ * sizeof(cell));
		memcpy(Paths, Paths_, amount_of_nodes_ * sizeof(cell));
		amount_of_nodes = amount_of_nodes_;
		id = id_;
	}
};
//

struct NewLast
{
	int lastID;
	int newID;
};

struct RM
{
	int ID;
	bool closed;
	RM(int ID_,bool closed_)
	{
		ID = ID_;
		closed = closed_;
	}
};

#define GetArea(a,b,c,d)  a = (int)floor((c+20000.0f)/AREA_SIZE);b=(int)floor((d+20000.0f)/AREA_SIZE)
#define GetAreaEx(a)  (int)floor((a+20000.0f)/AREA_SIZE)

bool inList(int ID, std::vector<RM>* pList);

vector			<RouteData>						RouteVector;
vector			<int>							RouteID;
vector			<int>							PlayerLoopList;
vector			<AMX *>							amx_list;
vector			<RM>							RemoveNodes;
vector			<QuedData>						QueueVector;
vector			<NodesInfoScanner>				Area[401][401];//160.801 Areas, -20.000 to 20.000 (40.000x40.000 = 1.600.000.000 square units), is an 100x100 units area with each unit holding nodes. (6000x6000 area, if all nodes spread evenly each area unit holds 38 nodes, not one big area with 35k nodes :p)

queue			<PassData>						PassVector;

NewLast			ChangeNode[MAX_PLAYERS];
NodesInfo		xNode[MAX_NODES];

#if defined PLUGIN_HAS_NO_HOOK

static cell AMX_NATIVE_CALL n_OnPlayerConnect( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_OnPlayerDisconnect( AMX* amx, cell* params );

bool OnPlayerConnect(int playerid)
#else
PLUGIN_EXPORT int PLUGIN_CALL OnPlayerConnect(int playerid)
#endif
{
	ChangeNode[playerid].newID = -1;
	ChangeNode[playerid].lastID = -1;
	if(ManualAdding == 0)
	{
		PlayerLoopList.push_back(playerid);	
	}
	return true;
}

#if defined PLUGIN_HAS_NO_HOOK
bool OnPlayerDisconnect(int playerid)
#else
PLUGIN_EXPORT int PLUGIN_CALL OnPlayerDisconnect(int playerid,int reason)
#endif
{
	int size = PlayerLoopList.size();
	for (int index=0; index < size; ++index)
	{
		if(PlayerLoopList.at(index) == playerid)
		{
			PlayerLoopList.erase(PlayerLoopList.begin()+index);
			break;
		}
	}
	ChangeNode[playerid].newID = -1;
	ChangeNode[playerid].lastID = -1;	
	return true;
}

Thread::Thread( void )
{
}

Thread::~Thread( void )
{
}

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	cout << "---Unloading---\r\n\tGamer_Z's Project Bundle: \r\n\t\tRoute Connector (a.k.a. GPS)\r\n---UNLOADED---";
}
//-------------------------------------------//
//-------------------------------------------//
//----------------TESTING ZONE---------------//
