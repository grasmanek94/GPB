/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick()
{
	if(g_Ticked == g_TickMax)
	{
		if(!locked.passer)//try another time if locked, won't lagg the server, while(true) {} would
		{
			locked.passer = true;
			if(!PassVector.empty())
			{
				cell amx_addr = NULL;
				cell * amx_physAddr = NULL;
				int ptr;
				for (std::vector<AMX *>::iterator a = amx_list.begin(); a != amx_list.end(); ++a)
				{
					if (!amx_FindPublic(* a, "GPS_WhenRouteIsCalculated", &ptr) && PassVector.front().script == *a)
					{
						amx_Push(* a, PassVector.front().MoveCost);
						amx_Push(* a, PassVector.front().amount_of_nodes);
						amx_PushArray(* a, &amx_addr, &amx_physAddr, PassVector.front().Paths, 1792);
						amx_Push(* a, PassVector.front().extraid);
						amx_Exec(* a, NULL, ptr);
						amx_Release(* a,amx_addr);
					}
				}
				PassVector.pop();
			}
			locked.passer = false;
		}
		int playerid = 0;	
		int size = PlayerLoopList.size();
		for (int index = 0; index < size; ++index)
		{
			playerid = PlayerLoopList.at(index);

			int Nearest = -1;
			float prevdist = 9999.99f;
			float newdist;

			float X;			
			float Y;
			float Z;

			GetPlayerPos(playerid,X,Y,Z);

			ChangeNode[playerid].lastID = ChangeNode[playerid].newID;
			for(int i = 0; i < MAX_NODES; ++i)
			{
				if(xNode[i].Exists == false)
					continue;
				newdist = sqrt(pow(xNode[i].xPOS-X,2.0f)+pow(xNode[i].yPOS-Y,2.0f)+pow(xNode[i].zPOS-Z,2.0f));
				if(newdist < prevdist)
				{
					prevdist = newdist;
					Nearest = i;
				}
			}
			ChangeNode[playerid].newID = Nearest;
			if(ChangeNode[playerid].lastID != ChangeNode[playerid].newID && ChangeNode[playerid].lastID != (-1))
			{
				OnPlayerClosestNodeIDChange(playerid, ChangeNode[playerid].lastID,ChangeNode[playerid].newID);
			}
		}
		g_Ticked = -1;
	}
	g_Ticked += 1;
}