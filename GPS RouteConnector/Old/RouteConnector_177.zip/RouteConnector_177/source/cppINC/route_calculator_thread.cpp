#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
#include<windows.h>

#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#ifdef OS_WINDOWS
	void BackgroundCalculator( void *unused )
#else
	void *BackgroundCalculator( void *unused )
#endif
{
	int startid;
	int endid;
	int extra;
	AMX *amx;
	cell Store[MAX_NODES];
	while( true )
    {
		if(!QueueVector.empty())
		{
			Lock  q (mutex_q);
			Lock  p (mutex_p);
			if (q.acquire ())
			{
				//cout << "ACQUIRED_NOT_EMPTY\n" << endl;
				startid = QueueVector.back().start;
				endid = QueueVector.back().end;
				extra = QueueVector.back().extraid;
				amx = QueueVector.back().script;
				QueueVector.pop_back();
				//if(
				q.release();
				//== false)
				//{
				//	cout << "Calc can't release the 'q' lock!\n";
				//}
				//else
				//{
				//	cout << "Calc released the 'q' lock!\n";
				//}
				//way = dgraph->findPath_r(xNode[startid].NodeID ,xNode[endid].NodeID);

					///////
				std::vector<Vertex> predecessors(num_vertices(dgraph)); // To store parents 
				std::vector<Weight> distances(num_vertices(dgraph)); // To store distances 
 
				IndexMap indexMap; // = boost::get(boost::vertex_index, g); 
				IndexMap vi = get(boost::vertex_index, dgraph); 
				Viter i, iend; 
				//Create our own vertex index.
				int c = 0; 
				for (boost::tie(i, iend) = vertices(dgraph); i != iend; ++i, ++c) 
				{ 
					indexMap[*i] = c; 
				} 
				PredecessorMap predecessorMap(&predecessors[0], indexMap); 
				DistanceMap distanceMap(&distances[0], indexMap); 
				boost::dijkstra_shortest_paths(dgraph, Vx[startid],   boost::distance_map(distanceMap).predecessor_map(predecessorMap)); 
 
 
				// Extract a shortest path 
				std::cout << std::endl; 
				typedef std::vector<Graph::edge_descriptor> PathType; 
				PathType path; 
				Vertex v = Vx[endid];  
				for(Vertex u = predecessorMap[v];  
				u != v; // Keep tracking the path until we get to the source 
				v = u, u = predecessorMap[v]) // Set the current vertex to the current predecessor,     and the predecessor to one level up 
				{ 
					std::pair<Graph::edge_descriptor, bool> edgePair = edge(u, v, dgraph); 
					Graph::edge_descriptor edge = edgePair.first; 
					path.push_back( edge ); 
				} 
 
				// Write shortest path 
				//std::cout << "Shortest path from " << startid << " to " << endid << ":" << std::endl; 
				//float totalDistance = 0; 
				int num = 0;
				for(PathType::reverse_iterator pathIterator = path.rbegin(); pathIterator !=       path.rend(); ++pathIterator) 
				{ 
				//std::cout << source(*pathIterator, dgraph) << " -> " <<     target(*pathIterator, dgraph)
				//          << " = " << get( boost::edge_weight, dgraph, *pathIterator ) << "|" << 
					way[++num] = get(vi, source(*pathIterator, dgraph)) ;
				//<< std::endl; 
 
				} 
				way[++num] = endid;
				way[0] = num;
					//////
				for(int i = 0 ; i < way[0]; ++i)
				{
					Store[i] = way[i+1];
				}
				
				while(p.acquire () == false)
				{}
				PassVector.push(PassData(Store,way[0],extra,amx,distanceMap[Vx[endid]]));
				//if(
					p.release();
				//	== false)
				//{
				//	cout << "Calc can't release the 'p' lock!\n";
				//}
			}
			//else
			//{
			//	cout << "Calc can't aquire the 'q' lock!\n";
			//}
		}
		SLEEP(30);
		//-------------------------
    }

	EXIT_THREAD();//should be never reached..
}