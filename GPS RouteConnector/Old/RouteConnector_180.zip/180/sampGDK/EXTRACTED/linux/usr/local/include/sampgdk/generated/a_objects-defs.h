#undef CreateObject
#define CreateObject sampgdk_CreateObject

#undef AttachObjectToVehicle
#define AttachObjectToVehicle sampgdk_AttachObjectToVehicle

#undef AttachObjectToObject
#define AttachObjectToObject sampgdk_AttachObjectToObject

#undef AttachObjectToPlayer
#define AttachObjectToPlayer sampgdk_AttachObjectToPlayer

#undef SetObjectPos
#define SetObjectPos sampgdk_SetObjectPos

#undef GetObjectPos
#define GetObjectPos sampgdk_GetObjectPos

#undef SetObjectRot
#define SetObjectRot sampgdk_SetObjectRot

#undef GetObjectRot
#define GetObjectRot sampgdk_GetObjectRot

#undef IsValidObject
#define IsValidObject sampgdk_IsValidObject

#undef DestroyObject
#define DestroyObject sampgdk_DestroyObject

#undef MoveObject
#define MoveObject sampgdk_MoveObject

#undef StopObject
#define StopObject sampgdk_StopObject

#undef IsObjectMoving
#define IsObjectMoving sampgdk_IsObjectMoving

#undef EditObject
#define EditObject sampgdk_EditObject

#undef EditPlayerObject
#define EditPlayerObject sampgdk_EditPlayerObject

#undef SelectObject
#define SelectObject sampgdk_SelectObject

#undef CancelEdit
#define CancelEdit sampgdk_CancelEdit

#undef CreatePlayerObject
#define CreatePlayerObject sampgdk_CreatePlayerObject

#undef AttachPlayerObjectToPlayer
#define AttachPlayerObjectToPlayer sampgdk_AttachPlayerObjectToPlayer

#undef AttachPlayerObjectToVehicle
#define AttachPlayerObjectToVehicle sampgdk_AttachPlayerObjectToVehicle

#undef SetPlayerObjectPos
#define SetPlayerObjectPos sampgdk_SetPlayerObjectPos

#undef GetPlayerObjectPos
#define GetPlayerObjectPos sampgdk_GetPlayerObjectPos

#undef SetPlayerObjectRot
#define SetPlayerObjectRot sampgdk_SetPlayerObjectRot

#undef GetPlayerObjectRot
#define GetPlayerObjectRot sampgdk_GetPlayerObjectRot

#undef IsValidPlayerObject
#define IsValidPlayerObject sampgdk_IsValidPlayerObject

#undef DestroyPlayerObject
#define DestroyPlayerObject sampgdk_DestroyPlayerObject

#undef MovePlayerObject
#define MovePlayerObject sampgdk_MovePlayerObject

#undef StopPlayerObject
#define StopPlayerObject sampgdk_StopPlayerObject

#undef IsPlayerObjectMoving
#define IsPlayerObjectMoving sampgdk_IsPlayerObjectMoving

#undef SetObjectMaterial
#define SetObjectMaterial sampgdk_SetObjectMaterial

#undef SetPlayerObjectMaterial
#define SetPlayerObjectMaterial sampgdk_SetPlayerObjectMaterial

#undef SetObjectMaterialText
#define SetObjectMaterialText sampgdk_SetObjectMaterialText

#undef SetPlayerObjectMaterialText
#define SetPlayerObjectMaterialText sampgdk_SetPlayerObjectMaterialText

