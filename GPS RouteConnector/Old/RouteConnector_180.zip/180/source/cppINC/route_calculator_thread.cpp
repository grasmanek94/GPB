#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/

#ifdef OS_WINDOWS
	void Thread::BackgroundCalculator( void *unused )
#else
	void *Thread::BackgroundCalculator( void *unused )
#endif
{
	int startid;
	int endid;
	int extra;
	AMX *amx;
	vector <cell>way;
	int costx;
	while( true )
    {
		if(!QueueVector.empty())
		{
			Lock  q (mutex_q);
			Lock  p (mutex_p);
			if (q.acquire ())
			{
				startid = QueueVector.back().start;
				endid = QueueVector.back().end;
				extra = QueueVector.back().extraid;
				amx = QueueVector.back().script;
				QueueVector.pop_back();
				q.release();
				///////////////////////////////////////
				/*LARGE_INTEGER frequency;        // ticks per second
				LARGE_INTEGER t1, t2;           // ticks
				double elapsedTime;

				// get ticks per second
				QueryPerformanceFrequency(&frequency);

				// start timer
				QueryPerformanceCounter(&t1);*/
				///////////////////////////////////////
				dgraph->findPath_r(xNode[startid].NodeID ,xNode[endid].NodeID,way,costx);
				///////////////////////////////////////
				//QueryPerformanceCounter(&t2);
				//elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
				///////////////////////////////////////
				//cout << elapsedTime << " ms.\n";
				///////////////////////////////////////
				dgraph->reset();
				
				while(p.acquire () == false)
				{}
				PassVector.push(PassData(way.begin(),way.end(),extra,costx,amx));
				way.clear();
				costx = 0;
				p.release();
			}
		}
		SLEEP(30);
		//-------------------------
    }

	EXIT_THREAD();//should be never reached..
}