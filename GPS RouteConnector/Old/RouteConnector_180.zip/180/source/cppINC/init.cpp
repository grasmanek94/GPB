#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{
	#if defined OS_WINDOWS
	InitializeCriticalSection(&mutex_q);
	InitializeCriticalSection(&mutex_p);
	#else
	pthread_mutex_init (&mutex_q,NULL);
	pthread_mutex_init (&mutex_p,NULL);
	#endif
	for(int i = 0; i < MAX_NODES; ++i)
	{
		xNode[i].Exists = false;
		xNode[i].AddedToGraph = false;
		xNode[i].NodeID = NULL;
		for(int j = 0; j < MAX_CONNECTIONS; ++j)
		{
			xNode[i].CW[j].ID = (-1);
		}
	}
	for(int i = 0; i < MAX_PLAYERS; ++i)
	{
		CheckPlayerOCNIDC[i] = true;
	}

	ReadNodeData("scriptfiles/GPS.dat");
	sampgdk_initialize_plugin(ppData);
	cout << "---Loading---\r\n\tGamer_Z's Project Bundle: \r\n\t\tRoute Connector (a.k.a. GPS) R" << PLUGIN_VERSION << "\r\n---LOADED---";
	START_THREAD( Thread::BackgroundCalculator, 0);
	return true;
}
