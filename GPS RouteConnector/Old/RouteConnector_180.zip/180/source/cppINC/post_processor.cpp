#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
cell ppamx_addr = NULL;
cell * ppamx_physAddr = NULL;
PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick()
{
	if(g_Ticked++ == g_TickMax)
	{
		if(!PassVector.empty())
		{
			Lock  q (mutex_p);
			int tries = 0;
			while (q.acquire (1) == false && ++tries < 10)
			{
			}
			if(q.locked)
			{
				int ptr;
				float Cx;
				for (std::vector<AMX *>::iterator a = amx_list.begin(); a != amx_list.end(); ++a)
				{
					if (!amx_FindPublic(* a, "GPS_WhenRouteIsCalculated", &ptr) && PassVector.front().script == *a)
					{
						Cx = (float)PassVector.front().MoveCost;
						amx_Push(* a, amx_ftoc(Cx));
						amx_Push(* a, PassVector.front().Paths.size());
						cell * RawPath = new cell[PassVector.front().Paths.size()+1];
						copy(PassVector.front().Paths.begin(),PassVector.front().Paths.end(),RawPath);
						amx_PushArray(* a, &ppamx_addr, &ppamx_physAddr, RawPath, PassVector.front().Paths.size()+1);
						amx_Push(* a, PassVector.front().extraid);
						amx_Exec(* a, NULL, ptr);
						amx_Release(* a,ppamx_addr);
						free(RawPath);
					}
				}
				PassVector.pop();
				q.release ();
			}
		}
		if(OnPCNIDCenable == true)
		{
			int playerid = 0;	
			int size = PlayerLoopList.size();
			for (int index = 0; index < size; ++index)
			{
				playerid = PlayerLoopList.at(index);
				
				if(CheckPlayerOCNIDC[playerid] == false)
				{
					continue;
				}
				int Nearest = -1;
				double prevdist = 4800000000.11f;//(40000*40000)*3+0.11
				double newdist;
				
				float X;			
				float Y;
				float Z;
				
				GetPlayerPos(playerid,&X,&Y,&Z);
				if(UseRealClosestDistance == true)
				{
					ChangeNode[playerid].lastID = ChangeNode[playerid].newID;
					for(int i = 0; i < MAX_NODES; ++i)
					{
						if(xNode[i].Exists == false)
							continue;
						newdist = sqrt(pow(xNode[i].xPOS-X,2.0f)+pow(xNode[i].yPOS-Y,2.0f)+pow(xNode[i].zPOS-Z,2.0f));
						if(newdist < prevdist)
						{
							prevdist = newdist;
							Nearest = i;
						}
					}
				}
				else
				{
					int Xloc = 0, Yloc = 0;
					GetArea(Xloc,Yloc,X,Y);
					ChangeNode[playerid].lastID = ChangeNode[playerid].newID;
					for(int i = 0,j = (int)Area[Xloc][Yloc].size(); i < j; ++i)
					{
						int NDX = Area[Xloc][Yloc].at(i).NodeID;
						if(xNode[NDX].Exists == false)
							continue;
						newdist = sqrt(pow(xNode[NDX].xPOS-X,2.0f)+pow(xNode[NDX].yPOS-Y,2.0f)+pow(xNode[NDX].zPOS-Z,2.0f));
						if(newdist < prevdist)
						{
							prevdist = newdist;
							Nearest = NDX;
						}
					}
				}
				ChangeNode[playerid].newID = Nearest;
				if(ChangeNode[playerid].lastID != ChangeNode[playerid].newID && ChangeNode[playerid].lastID != (-1))
				{
					OnPlayerClosestNodeIDChange(playerid, ChangeNode[playerid].lastID,ChangeNode[playerid].newID);
				}
			}
		}
		g_Ticked = 0;
	}
}