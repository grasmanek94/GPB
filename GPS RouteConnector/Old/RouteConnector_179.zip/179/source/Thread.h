#pragma once
/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
#ifndef __THREAD_H
#define __THREAD_H

class Thread
{
	public:
									Thread						( void );
								   ~Thread						( void );
#ifdef OS_WINDOWS
	static void						BackgroundCalculator		( void *unused );
#else
	static void	*					BackgroundCalculator		( void *unused );
#endif

};

#endif