/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gpb.googlecode.com/
*/
#define PLUGIN_VERSION (179)
//#define PLUGIN_HAS_NO_HOOK // No OnPlayerConnect and OnPlayerDisconnect calling by sampGDK becaus of crash, disable define @ your own risk
/*
	When disabling be sure edit the main.def to this:
	
LIBRARY	"RouteConnectorPlugin"
EXPORTS
	Supports
	Load
	Unload
	AmxLoad
	AmxUnload
	ProcessTick
	OnPlayerConnect
	OnPlayerDisconnect

else if no hook just use this def (seems this one is NOT crashing...):

LIBRARY	"RouteConnectorPlugin"
EXPORTS
	Supports
	Load
	Unload
	AmxLoad
	AmxUnload
	ProcessTick

*/
#define AREA_SIZE 75.0f//Define your Area size here lol.
/*
	remember to change 
vector			<NodesInfoScanner>				Area[x][x];
x = round_up(40000.0/AREA_SIZE)+1
*/
//-------------------------------------------//
#include "defines.h"
//-------------------------------------------//
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iterator>
#include <queue>
#include <cstring>
#include <limits>
#include <fstream>
#include <stack>
#include <set>
#include <string>

//-------------------------------------------//
#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
	#include <windows.h>
#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#include <sampgdk/core.h>
#include <sampgdk/a_players.h>
#include <sampgdk/plugin.h>
#include <sampgdk/a_vehicles.h>
#include <sampgdk/a_samp.h>
//-------------------------------------------//
#undef MAX_PLAYERS
#define MAX_PLAYERS (1000)
#include "Graph.h"
#include "Thread.h"
//-------------------------------------------//
//char buffexr [33];
//void main()
//{
//	sampgdk_logprintf("Last line %d, last files: %s",__LINE__,__FILE__);
//}
//#define free sampgdk_logprintf("Last line %d, last files: %s",__LINE__,__FILE__);free
#include "main.h"

#include "./cppINC/natives.cpp"
#include "./cppINC/functions.cpp"
#include "./cppINC/route_calculator_thread.cpp"
#include "./cppINC/post_processor.cpp"
#include "./cppINC/init.cpp"
//-------------------------------------------//