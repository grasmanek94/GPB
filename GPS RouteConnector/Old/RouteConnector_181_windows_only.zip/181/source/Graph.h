#pragma once
/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/

#ifndef _GRAPH_H_
#define _GRAPH_H
#include <sampgdk/plugin.h>
#include "Node.h"

class Graph
{
public:
	Graph(void);
	~Graph(void);

	//void addNode(int name, bool exists);
	void addNode(int name, bool exists, Node** NodeID );
	void connect_oneway(int ppFirst, int ppSecond, int moveCost);
	void connect_oneway(Node* pFirst, Node* pSecond, int moveCost);
	//int * findPath_r(int start, int end);
	void findPath_r(Node* pStart, Node* pEnd, std::vector<cell> &road, int &costMx);
	void reset(void);
private:
	void findNodesx(int firstName, Node** ppFirstNode);
	bool inList(Node* pNode, std::vector<Node*>* pList);
	static bool compareNodes(Node* pFirst, Node* pSecond);
	std::vector<Node*> mNodes;
};

#endif

