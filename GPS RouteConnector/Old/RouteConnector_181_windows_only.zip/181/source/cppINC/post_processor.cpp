#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
cell ppamx_addr = NULL;
cell * ppamx_physAddr = NULL;
int cccptr;

PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick()
{
	if(PassVector.try_pop(LocalPass))
	{
		if (!amx_FindPublic(LocalPass.script, "GPS_WhenRouteIsCalculated", &cccptr))
		{
			amx_Push(LocalPass.script, LocalPass.MoveCost);
			amx_Push(LocalPass.script, LocalPass.Paths.size());
			cell * RawPath = new cell[LocalPass.Paths.size()+1];
			copy(LocalPass.Paths.begin(),LocalPass.Paths.end(),RawPath);
			amx_PushArray(LocalPass.script, &ppamx_addr, &ppamx_physAddr, RawPath, LocalPass.Paths.size()+1);
			amx_Push(LocalPass.script, LocalPass.extraid);
			amx_Exec(LocalPass.script, NULL, cccptr);
			amx_Release(LocalPass.script,ppamx_addr);
			free(RawPath);
		}
	}
	if(g_Ticked++ == g_TickMax)
	{
		if(OnPCNIDCenable == true)
		{
			int playerid = 0;	
			int size = PlayerLoopList.size();
			for (int index = 0; index < size; ++index)
			{
				playerid = PlayerLoopList.at(index);
				
				if(CheckPlayerOCNIDC[playerid] == false)
				{
					continue;
				}
				int Nearest = -1;
				double prevdist = 4800000000.11f;//(40000*40000)*3+0.11
				double newdist;
				
				float X;			
				float Y;
				float Z;
				
				GetPlayerPos(playerid,&X,&Y,&Z);
				if(UseRealClosestDistance == true)
				{
					ChangeNode[playerid].lastID = ChangeNode[playerid].newID;
					for(int i = 0; i < MAX_NODES; ++i)
					{
						if(xNode[i].Exists == false)
							continue;
						newdist = sqrt(pow(xNode[i].xPOS-X,2.0f)+pow(xNode[i].yPOS-Y,2.0f)+pow(xNode[i].zPOS-Z,2.0f));
						if(newdist < prevdist)
						{
							prevdist = newdist;
							Nearest = i;
						}
					}
				}
				else
				{
					int Xloc = 0, Yloc = 0;
					GetArea(Xloc,Yloc,X,Y);
					ChangeNode[playerid].lastID = ChangeNode[playerid].newID;
					for(int i = 0,j = (int)Area[Xloc][Yloc].size(); i < j; ++i)
					{
						int NDX = Area[Xloc][Yloc].at(i).NodeID;
						if(xNode[NDX].Exists == false)
							continue;
						newdist = sqrt(pow(xNode[NDX].xPOS-X,2.0f)+pow(xNode[NDX].yPOS-Y,2.0f)+pow(xNode[NDX].zPOS-Z,2.0f));
						if(newdist < prevdist)
						{
							prevdist = newdist;
							Nearest = NDX;
						}
					}
				}
				ChangeNode[playerid].newID = Nearest;
				if(ChangeNode[playerid].lastID != ChangeNode[playerid].newID && ChangeNode[playerid].lastID != (-1))
				{
					OnPlayerClosestNodeIDChange(playerid, ChangeNode[playerid].lastID,ChangeNode[playerid].newID);
				}
			}
		}
		g_Ticked = 0;
	}
}