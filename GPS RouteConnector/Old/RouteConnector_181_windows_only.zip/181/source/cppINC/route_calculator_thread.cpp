#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
vector <cell>tbcway;
cell tbccostx;
QuedData RecievedData;
#ifdef OS_WINDOWS
	void Thread::BackgroundCalculator( void *unused )
#else
	void *Thread::BackgroundCalculator( void *unused )
#endif
{

	while( true )
    {
		if(QueueVector.try_pop(RecievedData))
		{
			///////////////////////////////////////
			//LARGE_INTEGER frequency;        // ticks per second
			//LARGE_INTEGER t1, t2;           // ticks
			//double elapsedTime;

			//QueryPerformanceFrequency(&frequency);
			//QueryPerformanceCounter(&t1);
			///////////////////////////////////////
			dgraph->findPath_r(xNode[RecievedData.start].NodeID ,xNode[RecievedData.end].NodeID,tbcway,tbccostx);
			///////////////////////////////////////
			//QueryPerformanceCounter(&t2);
			//elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
			//cout << elapsedTime << " ms.a\n";
			///////////////////////////////////////
			//QueryPerformanceCounter(&t1);
			///////////////////////////////////////
			dgraph->reset();
			///////////////////////////////////////
			//QueryPerformanceCounter(&t2);
			//elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
			//cout << elapsedTime << " ms.b\n";
			///////////////////////////////////////
			//QueryPerformanceCounter(&t1);
			///////////////////////////////////////
			PassVector.push(PassData(tbcway.begin(),tbcway.end(),RecievedData.extraid,tbccostx,RecievedData.script));
			tbcway.clear();
			tbccostx = 0;
			///////////////////////////////////////
			//QueryPerformanceCounter(&t2);
			//elapsedTime = (t2.QuadPart - t1.QuadPart) * 1000.0 / frequency.QuadPart;
			//cout << elapsedTime << " ms.c\n";
			///////////////////////////////////////
		}
		SLEEP(5);
		//-------------------------
    }

	EXIT_THREAD();//should be never reached..
}