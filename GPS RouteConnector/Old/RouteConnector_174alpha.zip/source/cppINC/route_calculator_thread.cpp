#pragma once

/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
#include<windows.h>

#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#ifdef OS_WINDOWS
	void Thread::BackgroundCalculator( void *unused )
#else
	void *Thread::BackgroundCalculator( void *unused )
#endif
{
	while( true )
    {
		//-------------------------
		//while(!QueueVector.empty())
		#if defined OS_WINDOWS
		if(MUTEX_LOCK(&mutex_q, 5) == 1)
		#else
		if(MUTEX_LOCK(&mutex_q) == 1)
		#endif
		{
			if(!QueueVector.empty())
			{
				int startid;
				int endid;
				int extra;
				AMX *amx;
				startid = QueueVector.back().start;
				endid = QueueVector.back().end;
				extra = QueueVector.back().extraid;
				amx = QueueVector.back().script;
				QueueVector.pop_back();
				#if defined OS_WINDOWS
				MUTEX_UNLOCK(&mutex_q);
				#else
				MUTEX_UNLOCK(&mutex_q);
				#endif
				way = dgraph->findPath_r(xNode[startid].NodeID ,xNode[endid].NodeID);
				dgraph->reset();
				cell Store[MAX_NODES];
				for(int i = 0 ; i < way[0]; ++i)
				{
					Store[i] = way[i+2];
				}
				#if defined OS_WINDOWS
				while(MUTEX_LOCK(&mutex_p,90000) != 1)
				{

				}
				PassVector.push(PassData(Store,way[0],extra,amx,way[1]));
				MUTEX_UNLOCK(&mutex_p);
				#else
				while(MUTEX_LOCK(&mutex_p) != 1)
				{

				}
				PassVector.push(PassData(Store,way[0],extra,amx,way[1]));
				MUTEX_UNLOCK(&mutex_p);
				#endif
			}
			
		}
		SLEEP(25);
		//-------------------------
    }

	EXIT_THREAD();//should be never reached..
}