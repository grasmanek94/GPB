/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
#define PLUGIN_VERSION (168)
//-------------------------------------------//
#include "defines.h"
//-------------------------------------------//
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <queue>
#include <cstring>
#include <limits>
#include <fstream>
#include <stack>
#include <set>
#include <string>
//-------------------------------------------//
#include "./amx/sampgdk.h"
//-------------------------------------------//
#include "Graph.h"
#include "Thread.h"
//-------------------------------------------//
#include "main.h"
#include "./cppINC/natives.cpp"
#include "./cppINC/functions.cpp"
#include "./cppINC/route_calculator_thread.cpp"
#include "./cppINC/post_processor.cpp"
#include "./cppINC/init.cpp"
//-------------------------------------------//
//-------------------------------------------//
//----------------TESTING ZONE---------------//