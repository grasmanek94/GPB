/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/

#ifndef _NODE_H_
#define _NODE_H_

#include <string>
#include <vector>

//Forward declare Node so Edge can see it
class Node;

struct Edge
{
	Edge(Node* node, int cost) : pNode(node), moveCost(cost){}
	Node* pNode;
	int moveCost;
};

class Node
{
public:
	Node(void);
	Node(int name, bool exists);
	~Node(void);

	void createEdge(Node* pTarget, int moveCost);

	void setGCost(int cost);
	void setClosed(bool closed);
	void setParent(Node* pParent);

	int getGCost(void);
	int getFCost(void);
	bool getClosed(void);
	Node* getParent(void);
	int getName(void);
	bool DoesExist(void);
	bool DoesExist_yes(void);
	std::vector<Edge*>* getEdges(void);

	void calcFCost(void);
	void reset(void);
private:
	int mGCost;
	int mTotal;
	bool mClosed;
	Node* mpParent;
	int mName;
	bool mHeur;
	std::vector<Edge*> mEdges;
};

#endif
