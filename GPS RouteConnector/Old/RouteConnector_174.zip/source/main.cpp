/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gpb.googlecode.com/
*/
#define PLUGIN_VERSION (174)
#define PLUGIN_HAS_NO_HOOK // No OnPlayerConnect and OnPlayerDisconnect calling by sampGDK becaus of crash, disable define @ your own risk
/*
	When disabling be sure edit the main.def to this:
	
LIBRARY	"RouteConnectorPlugin"
EXPORTS
	Supports
	Load
	Unload
	AmxLoad
	AmxUnload
	ProcessTick
	OnPlayerConnect
	OnPlayerDisconnect

else if no hook just use this def (seems this one is NOT crashing...):

LIBRARY	"RouteConnectorPlugin"
EXPORTS
	Supports
	Load
	Unload
	AmxLoad
	AmxUnload
	ProcessTick

*/
#define AREA_SIZE 200.0f//Define your Area size here lol.
//-------------------------------------------//
#include "defines.h"
//-------------------------------------------//
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <queue>
#include <cstring>
#include <limits>
#include <fstream>
#include <stack>
#include <set>
#include <string>
//-------------------------------------------//
#include <sampgdk/core.h>
#include <sampgdk/players.h>
#include <sampgdk/plugin.h>
#include <sampgdk/vehicles.h>
#include <sampgdk/samp.h>
//-------------------------------------------//
#undef MAX_PLAYERS
#define MAX_PLAYERS (800)
#include "Graph.h"
#include "Thread.h"
//-------------------------------------------//
#include "main.h"

#include "./cppINC/natives.cpp"
#include "./cppINC/functions.cpp"
#include "./cppINC/route_calculator_thread.cpp"
#include "./cppINC/post_processor.cpp"
#include "./cppINC/init.cpp"
//-------------------------------------------//