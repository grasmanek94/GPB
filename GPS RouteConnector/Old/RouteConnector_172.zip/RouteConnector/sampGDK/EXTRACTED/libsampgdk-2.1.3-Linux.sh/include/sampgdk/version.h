/* Version information */ 

#ifndef SAMPGDK_VERSION_H
#define SAMPGDK_VERSION_H

#include <sampgdk/config.h>
#include <sampgdk/export.h>

#define SAMPGDK_VERSION_MAJOR 2
#define SAMPGDK_VERSION_MINOR 1
#define SAMPGDK_VERSION_PATCH 3
#define SAMPGDK_VERSION_COMMIT 7
#define SAMPGDK_VERSION_STRING "2.1.3.7"

SAMPGDK_EXPORT int SAMPGDK_CALL sampgdk_version();
SAMPGDK_EXPORT const char *SAMPGDK_CALL sampgdk_version_string();

#endif
