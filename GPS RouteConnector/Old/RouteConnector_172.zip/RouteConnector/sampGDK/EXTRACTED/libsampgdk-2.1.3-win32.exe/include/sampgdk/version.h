/* Version information */ 

#ifndef SAMPGDK_VERSION_H
#define SAMPGDK_VERSION_H

#include <sampgdk/config.h>
#include <sampgdk/export.h>

#define SAMPGDK_VERSION_MAJOR 2
#define SAMPGDK_VERSION_MINOR 1
#define SAMPGDK_VERSION_PATCH 3
#define SAMPGDK_VERSION_COMMIT 1
#define SAMPGDK_VERSION_STRING "2.1.3.1"

SAMPGDK_EXPORT int SAMPGDK_CALL sampgdk_major();
SAMPGDK_EXPORT int SAMPGDK_CALL sampgdk_minor();
SAMPGDK_EXPORT const char *SAMPGDK_CALL sampgdk_version();

#endif
