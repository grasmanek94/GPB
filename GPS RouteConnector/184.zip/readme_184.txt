R184:
Changed each area size to 100x100 units, which makes effectively 60x60 areas in SA, which is 3600 areas.
Fixed GetQueueSize
added RebuildGraph and GetAmountOfFreeNodeSlots functions
Little bugfixes in ConnectNodes (return values) and updated documentation in include.