distance parameter in RouteCalculated callback should be fixed and working correctly.
added NodePosX[], NodePosY[] and NodePosZ[] arrays to the callback, please see .include file for more details.
Seriousy, look into the include file before using or your scripts will kill you. Tip: #pragma dynamic
Done little bugfixing in AreaScanner and ClosestNodeID stuff with MP2.
