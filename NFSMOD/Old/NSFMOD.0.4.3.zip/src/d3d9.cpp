/*
 * NFS: Underground 2 | 'NFSMOD' By Gamer_Z/Grasmanek94 | http://gpb.googlecode.com/
 */
#include <main.h>

extern proxyIDirect3DDevice9	*pDirect3DDevice9;

VehicleInfo *Vehicles[NFS_MAX_VEHICLES];//14 vehicles seems to be the limit in NFS UG2 ?
VehicleInfo SAVED;

namespace Recorder
{
	short State = 0;
	std::chrono::high_resolution_clock::time_point StartTime;
	std::chrono::high_resolution_clock::duration Current;
	struct FrameInfo//~380 bytes / frame | max 45600 bytes @ 120 fps | max 3.7 GB raw data for 24 hours of recording
	{
		std::chrono::high_resolution_clock::duration time;
		VehicleInfo Vehicle;
		int Nitro;
		float RPM;
		int CurrentGear;
	};

	std::vector<std::deque<FrameInfo>> History;
	std::deque<FrameInfo> frames;

	FrameInfo g_Temp;

	void ProcessRecord()
	{
		Current = std::chrono::high_resolution_clock::now()-StartTime;
		g_Temp.time = Current;
		PROTECT;//current shift
		auto& CurrentGear = POINTER(int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x38);
		auto& Nitro			= POINTER(int,POINTER(unsigned int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x34) + 0x41C);
		auto& RPM			= POINTER(float,CameraPosBaseAddr + 0x440);
		g_Temp.CurrentGear = CurrentGear;
		g_Temp.Nitro = Nitro;
		g_Temp.RPM = RPM;
		UNPROTECT;
		PROTECT;
		#define SRECORDASSIGN(x) g_Temp.Vehicle.x = Vehicles[0]->x
		SRECORDASSIGN(unknown_01[0]);SRECORDASSIGN(unknown_01[1]);SRECORDASSIGN(unknown_01[2]);SRECORDASSIGN(unknown_01[3]);
		SRECORDASSIGN(unknown_01[4]);SRECORDASSIGN(unknown_01[5]);SRECORDASSIGN(unknown_01[6]);SRECORDASSIGN(unknown_01[7]);
		SRECORDASSIGN(unknown_02);SRECORDASSIGN(unknown_03.x);SRECORDASSIGN(unknown_03.y);SRECORDASSIGN(unknown_03.z);
		SRECORDASSIGN(unknown_04);SRECORDASSIGN(unknown_05);SRECORDASSIGN(unknown_06);SRECORDASSIGN(unknown_07[0]);
		SRECORDASSIGN(unknown_07[1]);SRECORDASSIGN(unknown_07[2]);SRECORDASSIGN(unknown_08.x);SRECORDASSIGN(unknown_08.y);
		SRECORDASSIGN(unknown_08.z);SRECORDASSIGN(unknown_09);SRECORDASSIGN(unknown_10[0].w);SRECORDASSIGN(unknown_10[0].x);
		SRECORDASSIGN(unknown_10[0].y);SRECORDASSIGN(unknown_10[0].z);SRECORDASSIGN(unknown_10[1].w);SRECORDASSIGN(unknown_10[1].x);
		SRECORDASSIGN(unknown_10[1].y);SRECORDASSIGN(unknown_10[1].z);SRECORDASSIGN(unknown_10[2].w);SRECORDASSIGN(unknown_10[2].x);
		SRECORDASSIGN(unknown_10[2].y);SRECORDASSIGN(unknown_10[2].z);SRECORDASSIGN(unknown_10[3].w);SRECORDASSIGN(unknown_10[3].x);
		SRECORDASSIGN(unknown_10[3].y);SRECORDASSIGN(unknown_10[3].z);SRECORDASSIGN(unknown_10[4].w);SRECORDASSIGN(unknown_10[4].x);
		SRECORDASSIGN(unknown_10[4].y);SRECORDASSIGN(unknown_10[4].z);SRECORDASSIGN(unknown_12_is_zero_when_accelerating);
		SRECORDASSIGN(SpeedAndBrakeAccelerator);SRECORDASSIGN(Pos.x);SRECORDASSIGN(Pos.y);SRECORDASSIGN(Pos.z);SRECORDASSIGN(Velocity.x);
		SRECORDASSIGN(Velocity.y);SRECORDASSIGN(Velocity.z);SRECORDASSIGN(TurnSpeed.x);SRECORDASSIGN(TurnSpeed.y);SRECORDASSIGN(TurnSpeed.z);
		SRECORDASSIGN(Rotation.Front.w);SRECORDASSIGN(Rotation.Front.x);SRECORDASSIGN(Rotation.Front.y);SRECORDASSIGN(Rotation.Front.z);
		SRECORDASSIGN(Rotation.Right.w);SRECORDASSIGN(Rotation.Right.x);SRECORDASSIGN(Rotation.Right.y);SRECORDASSIGN(Rotation.Right.z);
		SRECORDASSIGN(Rotation.Up.w);SRECORDASSIGN(Rotation.Up.x);SRECORDASSIGN(Rotation.Up.y);SRECORDASSIGN(Rotation.Up.z);	
		UNPROTECT;
		frames.push_back(g_Temp);
		return;
	}

	void ResetFrames()
	{
		frames.clear();
		if(State == 2)
			State = 0;
	}

	void Stop()
	{
		if(State == 1)
		{
			History.push_back(frames);
		}
		State = 0;
	}

	void ProcessPlay(bool Simple = false)
	{
		if(!frames.empty())
		{
			Current = std::chrono::high_resolution_clock::now()-StartTime;
			if(Current >= frames.front().time)
			{
				if(!Simple)
				{
					PROTECT;//current shift
					auto& CurrentGear = POINTER(int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x38);
					auto& Nitro			= POINTER(int,POINTER(unsigned int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x34) + 0x41C);
					auto& RPM			= POINTER(float,CameraPosBaseAddr + 0x440);
					CurrentGear = frames.front().CurrentGear;
					Nitro = frames.front().Nitro;
					RPM = frames.front().RPM;
					UNPROTECT;
				}
				PROTECT;	
				#define LRECORDASSIGN(x) Vehicles[0]->x = frames.front().Vehicle.x
				if(!Simple)
				{
					LRECORDASSIGN(unknown_01[0]);LRECORDASSIGN(unknown_01[1]);LRECORDASSIGN(unknown_01[2]);LRECORDASSIGN(unknown_01[3]);
					LRECORDASSIGN(unknown_01[4]);LRECORDASSIGN(unknown_01[5]);LRECORDASSIGN(unknown_01[6]);LRECORDASSIGN(unknown_01[7]);
					LRECORDASSIGN(unknown_02);LRECORDASSIGN(unknown_03.x);LRECORDASSIGN(unknown_03.y);LRECORDASSIGN(unknown_03.z);
					LRECORDASSIGN(unknown_04);LRECORDASSIGN(unknown_05);LRECORDASSIGN(unknown_06);LRECORDASSIGN(unknown_07[0]);
					LRECORDASSIGN(unknown_07[1]);LRECORDASSIGN(unknown_07[2]);LRECORDASSIGN(unknown_08.x);LRECORDASSIGN(unknown_08.y);
					LRECORDASSIGN(unknown_08.z);LRECORDASSIGN(unknown_09);LRECORDASSIGN(unknown_10[0].w);LRECORDASSIGN(unknown_10[0].x);
					LRECORDASSIGN(unknown_10[0].y);LRECORDASSIGN(unknown_10[0].z);LRECORDASSIGN(unknown_10[1].w);LRECORDASSIGN(unknown_10[1].x);
					LRECORDASSIGN(unknown_10[1].y);LRECORDASSIGN(unknown_10[1].z);LRECORDASSIGN(unknown_10[2].w);LRECORDASSIGN(unknown_10[2].x);
					LRECORDASSIGN(unknown_10[2].y);LRECORDASSIGN(unknown_10[2].z);LRECORDASSIGN(unknown_10[3].w);LRECORDASSIGN(unknown_10[3].x);
					LRECORDASSIGN(unknown_10[3].y);LRECORDASSIGN(unknown_10[3].z);LRECORDASSIGN(unknown_10[4].w);LRECORDASSIGN(unknown_10[4].x);
					LRECORDASSIGN(unknown_10[4].y);LRECORDASSIGN(unknown_10[4].z);LRECORDASSIGN(unknown_12_is_zero_when_accelerating);
				}
				LRECORDASSIGN(SpeedAndBrakeAccelerator);LRECORDASSIGN(Pos.x);LRECORDASSIGN(Pos.y);LRECORDASSIGN(Pos.z);LRECORDASSIGN(Velocity.x);
				LRECORDASSIGN(Velocity.y);LRECORDASSIGN(Velocity.z);LRECORDASSIGN(TurnSpeed.x);LRECORDASSIGN(TurnSpeed.y);LRECORDASSIGN(TurnSpeed.z);
				LRECORDASSIGN(Rotation.Front.w);LRECORDASSIGN(Rotation.Front.x);LRECORDASSIGN(Rotation.Front.y);LRECORDASSIGN(Rotation.Front.z);
				LRECORDASSIGN(Rotation.Right.w);LRECORDASSIGN(Rotation.Right.x);LRECORDASSIGN(Rotation.Right.y);LRECORDASSIGN(Rotation.Right.z);
				LRECORDASSIGN(Rotation.Up.w);LRECORDASSIGN(Rotation.Up.x);LRECORDASSIGN(Rotation.Up.y);LRECORDASSIGN(Rotation.Up.z);	
				UNPROTECT;
				frames.pop_front();
			}
			else
			{
				while(frames.front().time < Current)
				{
					frames.pop_front();
					if(frames.empty())
					{
						State = 0;
						break;
					}
				}
			}
		}
		else
		{
			State = 0;
		}
	}

	bool TryRecord()
	{
		if(State != 0)
			return false;
		ResetFrames();
		StartTime = std::chrono::high_resolution_clock::now();
		State = 1;
		return true;
	}

	bool TryReplay()
	{
		if(State != 0)
			return false;
		StartTime = std::chrono::high_resolution_clock::now();
		State = 2;
		return true;
	}
};

//crash prevention
bool ValidVehicle(VehicleInfo *&vehicle)
{
	if(vehicle)
	{
		if(!IsBadWritePtr(&vehicle->Pos.x,12))//make sure XYZ pos is WRITEABLE
		{
			if(!IsBadReadPtr(&vehicle->Pos.x,12))//make sure XYZ pos is READABLE
			{
				if(vehicle->Pos.x != NULL)//make sure the XYZ pos actually does exist in the world
				{
					return true;
				}
			}
		}
	}
	return false;
}

std::vector <int> ValidVehicles;

//true if some vehicles found, false if pool cannot be populated
bool PopulateVehiclePool()
{
	ValidVehicles.clear();
	for(int i = 0; i < NFS_MAX_VEHICLES; ++i)//populate vehicle pool
	{
		PROTECT;
		Vehicles[i] = &POINTER(VehicleInfo,POINTER(unsigned int,(POINTER(unsigned int,0x0089CDA8 + (i*4)) + 0x20)));
		if(ValidVehicle(Vehicles[i]))
		{
			ValidVehicles.push_back(i);
		}
		UNPROTECT;
	}
	return !ValidVehicles.empty();
}


void FrameTick(IDirect3DDevice9 * device, HWND wnd)
{
	KeyManagerRun();//key press/release detection
	if (GetCursorPos(&MouseCursorPosition))
		ScreenToClient(g_WindowHandle, &MouseCursorPosition);
	DirectXFont::Access(0)->Print(0.0,0.0,0xFFFFFFFF,"{FFFF0000}NFS {FFFFFF00}MOD {FF00FFFF}1.0 {FFFFFFFF}By Gamer_Z a.k.a Grasmanek94 | {FFFFFF00}Website: {FF00FFFF}http://gpb.googlecode.com/",true);

	PROTECT;
	if(!PositionBaseAddress)
		return;
	auto BaseAddr = POINTER(unsigned int,PositionBaseAddress + 0x20);
	if(IsBadReadPtr(&BaseAddr,0x04) != 0)
		return;
	UNPROTECT;

	if(!PopulateVehiclePool())//try to find valid vehicles
		return;

	#define info Vehicles[PLAYER_VEHICLE]
	DirectXFont::Access(0)->Print(0.0,15.0,0xFFFFFFFF,string_format("Speed: %03.3f / Valid vehicles available: %03d",sqrt(info->Velocity.x*info->Velocity.x+info->Velocity.y*info->Velocity.y+info->Velocity.z*info->Velocity.z),ValidVehicles.size()).c_str(),true);

	//float Angle = 0.0f;
	//{//calculate the cars' ZAngle
	//	float offX = 20.0f;
	//	float x = offX * info->Rotation.Front.x + info->Pos.x;
	//	float y = offX * info->Rotation.Front.y + info->Pos.y;
	//	Angle = (atan2(x-info->Pos.x, y-info->Pos.y) * 180.0f / PI);
	//}

	/*
	static bool airbreak = false;
	if(Keys(VK_F4).Pressed)
	{
		if(airbreak)
			airbreak = false;
		else
			airbreak = true;
	}

	if(airbreak)
	{
		if ( Keys('W').Down )d[0] += 1.0f;
		if ( Keys('S').Down )d[0] -= 1.0f;
		if ( Keys('A').Down )d[1] += 1.0f;
		if ( Keys('D').Down )d[1] -= 1.0f;
		if ( Keys('Q').Down )d[2] += 1.0f;
		if ( Keys('Z').Down )d[2] -= 1.0f;
		// pitch (x-axis)
		if ( Keys('I').Down )xyvect[0] += 1.0f;
		if ( Keys('K').Down )xyvect[0] -= 1.0f;
		// roll (y-axis)
		if ( Keys('J').Down )xyvect[1] += 1.0f;
		if ( Keys('L').Down )xyvect[1] -= 1.0f;
		// yaw (z-axis)
		if ( Keys('U').Down )zvect[2] -= 1.0f;
		if ( Keys('O').Down )zvect[2] += 1.0f;
		//TODO: SET ROT AND POS
	}
	*/
	if(!Recorder::State)
	{
		if(Keys(VK_SHIFT).Down)//extra speed/hack
		{
			info->Velocity.x *= 1.010f;
			info->Velocity.y *= 1.010f;
			info->Velocity.z *= 1.010f;
		}
		if(Keys(VK_TAB).Down)//super brake
		{
			info->Velocity.x = 0.0f;
			info->Velocity.y = 0.0f;
			info->Velocity.z = 0.0f;
		}
		if(Keys(VK_BACK).Pressed)//jump forward 20 units
		{
			float offX = 20.0f;
			float offY = 0.0f;
			float offZ = 0.0f;

			float x = offX * info->Rotation.Front.x + offY * info->Rotation.Right.x + offZ * info->Rotation.Up.x + info->Pos.x;
			float y = offX * info->Rotation.Front.y + offY * info->Rotation.Right.y + offZ * info->Rotation.Up.y + info->Pos.y;
			float z = offX * info->Rotation.Front.z + offY * info->Rotation.Right.z + offZ * info->Rotation.Up.z + info->Pos.z;

			info->Pos.x = x;
			info->Pos.y = y;
			info->Pos.z = z;
		}

		if(Keys(VK_F9).Pressed)
		{
			SAVEPlayerVehicleInfo();
		}
		if(Keys(VK_F11).Pressed)
		{
			LOADPlayerVehicleInfo();
		}
		if(Keys('Q').Down)//teleport all here LOL
		{
			for(unsigned int i = 1, j = ValidVehicles.size(); i < j; ++i)
			{
				int vehicle = ValidVehicles.at(i);
				float offX = 5*i;
				float offY = 5.0f;
				float offZ = 0.0f;

				VehicleInfoAssign(Vehicles[vehicle],info);

				Vehicles[vehicle]->Pos.x = offX * info->Rotation.Front.x + offY * info->Rotation.Right.x + offZ * info->Rotation.Up.x + info->Pos.x;
				Vehicles[vehicle]->Pos.y = offX * info->Rotation.Front.y + offY * info->Rotation.Right.y + offZ * info->Rotation.Up.y + info->Pos.y;
				Vehicles[vehicle]->Pos.z = offX * info->Rotation.Front.z + offY * info->Rotation.Right.z + offZ * info->Rotation.Up.z + info->Pos.z;
			}
		}
		PROTECT;//nitro & RPM
		auto& Nitro			= POINTER(int,POINTER(unsigned int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x34) + 0x41C);
		auto& RPM			= POINTER(float,CameraPosBaseAddr + 0x440);
		DirectXFont::Access(0)->Print(0.0,30.0,0xFFFFFFFF,string_format("Nitro: %d / RPM: %.0f",Nitro,RPM).c_str(),true);
		UNPROTECT;	
	
		PROTECT;//camera stuff
		auto CamBaseAddr	= POINTER(unsigned int,CameraBaseAddress + 0x40);
		auto& CamRot		= POINTER(Point4D,CamBaseAddr);
		auto& CamPos		= POINTER(Point3D,CameraPosBaseAddr + 0x50);
		auto& CamOther1		= POINTER(float,POINTER(unsigned int,OtherCameraStuff + 0x38) + 0x00);
		auto& CamOther2		= POINTER(float,POINTER(unsigned int,OtherCameraStuff + 0x38) + 0x08);
		auto& CamOther3		= POINTER(float,POINTER(unsigned int,OtherCameraStuff + 0x38) + 0xB8);
		UNPROTECT;	

		PROTECT;//current shift
		auto& CurrentShift = POINTER(int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x38);
		UNPROTECT;

		PROTECT;//distance in run
		auto& DistBtwnCars	= POINTER(float,POINTER(unsigned int,DistanceBaseAddr + 0x1C) + 0x24);
		DistBtwnCars = 301.0f;
		UNPROTECT;

		PROTECT;//#drag race engine no blow hack
		auto& EngineHeat	= POINTER(float,POINTER(unsigned int,PositionBaseAddress + 0x48) + 0x8C);
		EngineHeat = 0.0f;
		UNPROTECT;

		PROTECT;//money hack
		PlayerMoney = 2000000000;
		UNPROTECT;

		PROTECT;//#drifting vars
		auto& curr_percent_traveled		= POINTER(float,POINTER(unsigned int,DriftingBaseAddr + 0xBD0) + 0x14);
		auto& curr_percent_traveled2	= POINTER(float,POINTER(unsigned int,DriftingBaseAddr + 0xBD0) + 0x20);
		auto& percent_traveled_to		= POINTER(float,POINTER(unsigned int,POINTER(unsigned int,DriftingBaseAddr + 0xBD0) + 0x1D8) + 0x30);
		UNPROTECT;

		if(Keys(VK_F5).Pressed)
		{
			Keys(VK_F5).ConsumePressed();
			Recorder::TryRecord();
		}
		if(Keys(VK_F6).Pressed)
		{
			Keys(VK_F6).ConsumePressed();
			Recorder::TryReplay();
		}
	}

	if(Recorder::State == 1)//recording
	{
		Recorder::ProcessRecord();
		DirectXFont::Access(0)->Print(0.0,30.0,0xFFFF0000,string_format("RECORDING (%d frames recorded)",Recorder::frames.size()).c_str(),true);	
		if(Keys(VK_F5).Pressed)
		{
			Keys(VK_F5).ConsumePressed();
			Recorder::Stop();
		}
	}
	else if(Recorder::State == 2)//playing
	{
		Recorder::ProcessPlay();
		DirectXFont::Access(0)->Print(0.0,30.0,0xFF00FF00,string_format("REPLAY (%d frames left)",Recorder::frames.size()).c_str(),true);
		if(Keys(VK_F6).Pressed)
		{
			Keys(VK_F6).ConsumePressed();
			Recorder::Stop();
		}
	}
	#undef info
}

void InitializeDX(IDirect3DDevice9 * device)
{
	DirectXFont::Add("Lucida Console",10,FW_BOLD);
	DirectXFont::InitializeAll();
}

void UninitializeDX(IDirect3DDevice9 * device)
{
	DirectXFont::InvalidateAll();
}

IDirect3D9 * WINAPI sys_Direct3DCreate9 ( UINT SDKVersion )
{
	pDirect3D9 = NULL;
	if ( process_init() )
		pDirect3D9 = new proxyIDirect3D9( orig_Direct3DCreate9(SDKVersion) );

	return pDirect3D9;
}

void OnGameLaunch()
{

}