/*
 * NFS: Underground 2 | 'NFSMOD' By Gamer_Z/Grasmanek94 | http://gpb.googlecode.com/
 */
#include <main.h>
#include <iostream>
#include <glm/gtx/quaternion.hpp>

HINSTANCE				g_hOrigDll = NULL;
HMODULE					g_hDllModule = NULL;
HWND					g_WindowHandle = NULL;
char					g_szWorkingDirectory[MAX_PATH];
t_WindowsInfo			WindowsInfo;
extern proxyIDirect3DDevice9	*pDirect3DDevice9;

static int init ( void )
{
	if ( g_hOrigDll == NULL )
	{
		if ( GetModuleFileName(g_hDllModule, g_szWorkingDirectory, sizeof(g_szWorkingDirectory) - 32) != 0 )
		{
			if ( strrchr(g_szWorkingDirectory, '\\') != NULL )
				*strrchr( g_szWorkingDirectory, '\\' ) = 0;
			else
				strcpy( g_szWorkingDirectory, "." );
		}
		else
		{
			strcpy( g_szWorkingDirectory, "." );
		}

		g_hOrigDll = LoadLibrary( "proxyloader_d3d9.dll" );
		char	filename[MAX_PATH];
		if ( g_hOrigDll == NULL )
		{	
			GetSystemDirectory( filename, (UINT) (MAX_PATH - strlen("\\d3d9.dll") - 1) );

			strcat( filename, "\\d3d9.dll" );
			g_hOrigDll = LoadLibrary( filename );
			if ( g_hOrigDll == NULL )
			{
				return 0;
			}
		}
		orig_Direct3DCreate9 = ( D3DC9 ) GetProcAddress( g_hOrigDll, "Direct3DCreate9" );
		if ( orig_Direct3DCreate9 == NULL )
		{
			FreeLibrary( g_hOrigDll );
			return 0;
		}
	}
	return 1;
}

IDirect3D9 * WINAPI sys_Direct3DCreate9 ( UINT SDKVersion )
{
	pDirect3D9 = NULL;
	if ( init() )
		pDirect3D9 = new proxyIDirect3D9( orig_Direct3DCreate9(SDKVersion) );

	return pDirect3D9;
}

namespace DirectXFont
{
	std::map<std::pair<std::string,std::pair<int,DWORD>>,CD3DFont> fonts;
	std::map<unsigned int,std::pair<std::string,std::pair<int,DWORD>>> font_id;
	unsigned int FontCounter = -1;
	int Add(std::string fontname, int size, DWORD flags)
	{
		if(fonts.find(std::make_pair(fontname,std::make_pair(size,flags))) == fonts.end())
		{
			for(auto it = font_id.begin(); it != font_id.end(); ++it)
			{
				if(it->second == std::make_pair(fontname,std::make_pair(size,flags)))
				{
					return it->first;//guaranteed to happen
				}
			}
		}
		fonts.emplace(std::make_pair(fontname,std::make_pair(size,flags)),CD3DFont(fontname.c_str(),size,flags));
		font_id[++FontCounter] = std::make_pair(fontname,std::make_pair(size,flags));
		return FontCounter;
	}
	bool Initialize(unsigned int ID)
	{
		if(ID < 0)
			return false;
		if(fonts.find(font_id[ID]) == fonts.end())
			return false;
		return fonts.at(font_id[ID]).Initialize( pDirect3DDevice9 ) == S_OK;
	}
	bool Remove(unsigned int ID)
	{
		if(ID < 0)
			return false;
		if(fonts.find(font_id[ID]) == fonts.end())
			return false;
		fonts.at(font_id[ID]).Invalidate();
		fonts.erase(font_id[ID]);
		return true;
	}
	void InitializeAll()
	{
		for(auto it = fonts.begin(); it != fonts.end(); ++it)
			it->second.Initialize( pDirect3DDevice9 );
	}
	void InvalidateAll()
	{
		for(auto it = fonts.begin(); it != fonts.end(); ++it)
			it->second.Invalidate();
	}
	CD3DFont * Access(int ID)
	{
		if(ID < 0)
			return 0;
		if(fonts.find(font_id[ID]) == fonts.end())
			return 0;
		return &fonts.at(font_id[ID]);
	}
};

std::string string_format(const std::string fmt, ...) 
{
	int size = 512;
	std::string str;
	va_list ap;
	while (1) {
		str.resize(size);
		va_start(ap, fmt);
		int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
		va_end(ap);
		if (n > -1 && n < size) {
			str.resize(n);
			return str;
		}
		if (n > -1)
			size = n + 1;
		else
			size *= 2;
	}
	return str;
}

//let the "hacking" begin :)
#define AddVar(Type,Name,Address) Type& Name = *reinterpret_cast<Type*>(Address)

AddVar(unsigned int,PositionBaseAddress,0x0089CDA8);//base address
AddVar(unsigned int,CameraBaseAddress,0x0086E6FC);//base address
AddVar(unsigned int,CameraPosBaseAddr,0x0089CCF8);//base address
AddVar(unsigned int,DistanceBaseAddr,0x0089CD04);//base address
AddVar(int,PlayerMoney,0x00861E74);

struct Point4D { float x, y, z, w; };
struct Point3D { float x, y, z; };
struct Point2D { float x, y; };

struct QuatRot
{
	Point4D Front;
	Point4D Right;//somehow affects car rotation when anything here is set
	Point4D Up;//also floats between -1 and 1;; surely rotation?
};

#define NFS_MAX_VEHICLES (14)//seriously just 14.. (including the player)

struct VehicleInfo//vehicle structure which is recreated by me
{
	float unknown_01[8];
	Point3D Pos;
	float AlwaysNaN;
	QuatRot Rotation;
	float AlwaysZero[3];
	float AlwaysOne;//?...
	Point3D Velocity;
	float BigNumBelowZero;
	Point3D TurnSpeed;
	float UnknownMaybeDamageOrSomething;//
	float SpeedAndBrakeAccelerator;// > 0 = brake, < 0 = accelerate | *just like speedhack* velocity *= -SpeedAndBrakeAccelerator
	float unknown_03;
};

VehicleInfo *Vehicles[NFS_MAX_VEHICLES];//14 vehicles seems to be the limit in NFS UG2 ?

struct CameraInfo
{
	Point3D Position;
	Point4D Rotation;
};

CameraInfo OldCamera;

#define PI 3.1415926535897932384626433f

struct KeyManager
{
	bool Pressed;
	bool Down;
	bool Released;
	bool Up;
};

KeyManager Keys[256];

void KeyManagerRun()
{
	for(unsigned int i = 0; i < 256; ++i)
	{
		if(GetAsyncKeyState(i))
		{
			if(!Keys[i].Down)
			{
				Keys[i].Down = true;
				Keys[i].Pressed = true;
				Keys[i].Released = false;
				Keys[i].Up = false;
			}
			else
			{
				Keys[i].Pressed = false;
			}
		}
		else
		{
			if(!Keys[i].Up)
			{
				Keys[i].Released = true;
				Keys[i].Up = true;
				Keys[i].Down = false;
				Keys[i].Pressed = false;
			}
			else
			{
				Keys[i].Released = false;
			}
		}
	}
}

#define Keys(a) Keys[a]

#define PLAYER_VEHICLE (0)

bool ValidVehicle(VehicleInfo *&vehicle)
{
	if(vehicle)
	{
		if(!IsBadWritePtr(&vehicle->Pos.x,12))//make sure XYZ pos is WRITEABLE
		{
			if(!IsBadReadPtr(&vehicle->Pos.x,12))//make sure XYZ pos is READABLE
			{
				if(vehicle->Pos.x != NULL)//make sure the XYZ pos actually does exist in the world
				{
					return true;
				}
			}
		}
	}
	return false;
}

std::vector <int> ValidVehicles;

#define PROTECT try{
#define UNPROTECT }catch(...){}
#define POINTER(type,addr) (*(type*)(addr))

int PopulateVehiclePool()
{
	ValidVehicles.clear();
	for(int i = 0; i < NFS_MAX_VEHICLES; ++i)//populate vehicle pool
	{
		PROTECT;
		Vehicles[i] = &POINTER(VehicleInfo,POINTER(unsigned int,(POINTER(unsigned int,0x0089CDA8 + (i*4)) + 0x20)));
		if(ValidVehicle(Vehicles[i]))
		{
			ValidVehicles.push_back(i);
		}
		UNPROTECT;
	}
	return ValidVehicles.size();
}

void FrameTick(IDirect3DDevice9 * device, HWND wnd)
{
	KeyManagerRun();//key press/release detection

	DirectXFont::Access(0)->Print(0.0,0.0,0xFFFFFFFF,"{FFFF0000}NFS {FFFFFF00}MOD {FF00FFFF}1.0 {FFFFFFFF}By Gamer_Z a.k.a Grasmanek94 | {FFFFFF00}Website: {FF00FFFF}http://gpb.googlecode.com/",true);
	
	bool GOOD = true;

	PROTECT;
	if(!PositionBaseAddress)
		return;
	auto BaseAddr = POINTER(unsigned int,PositionBaseAddress + 0x20);
	if(IsBadReadPtr(&BaseAddr,0x04) != 0)
		return;
	UNPROTECT;

	if(!GOOD)
		return;

	PopulateVehiclePool();//try to find valid vehicles

	if(ValidVehicles.empty())
		return;

	#define info Vehicles[PLAYER_VEHICLE]
	DirectXFont::Access(0)->Print(0.0,15.0,0xFFFFFFFF,string_format("Speed: %03.3f / Valid vehicles available: %03d",sqrt(info->Velocity.x*info->Velocity.x+info->Velocity.y*info->Velocity.y+info->Velocity.z*info->Velocity.z),ValidVehicles.size()).c_str(),true);

	static bool airbreak = false;

	float Angle = 0.0f;
	{//calculate the cars' ZAngle
		float offX = 20.0f;
		float x = offX * info->Rotation.Front.x + info->Pos.x;
		float y = offX * info->Rotation.Front.y + info->Pos.y;
		Angle = (atan2(x-info->Pos.x, y-info->Pos.y) * 180.0f / PI);
	}

	if(Keys(VK_F4).Pressed)
	{
		if(airbreak)
			airbreak = false;
		else
			airbreak = true;
	}

	if(airbreak)
	{
	/*	if ( Keys('W').Down )d[0] += 1.0f;
		if ( Keys('S').Down )d[0] -= 1.0f;
		if ( Keys('A').Down )d[1] += 1.0f;
		if ( Keys('D').Down )d[1] -= 1.0f;
		if ( Keys('Q').Down )d[2] += 1.0f;
		if ( Keys('Z').Down )d[2] -= 1.0f;
		// pitch (x-axis)
		if ( Keys('I').Down )xyvect[0] += 1.0f;
		if ( Keys('K').Down )xyvect[0] -= 1.0f;
		// roll (y-axis)
		if ( Keys('J').Down )xyvect[1] += 1.0f;
		if ( Keys('L').Down )xyvect[1] -= 1.0f;
		// yaw (z-axis)
		if ( Keys('U').Down )zvect[2] -= 1.0f;
		if ( Keys('O').Down )zvect[2] += 1.0f;
		//TODO: SET ROT AND POS*/
	}

	if(Keys(VK_SHIFT).Down)//extra speed/hack
	{
		info->Velocity.x *= 1.010f;
		info->Velocity.y *= 1.010f;
		info->Velocity.z *= 1.010f;
	}
	if(Keys(VK_TAB).Down)//super brake
	{
		info->Velocity.x = 0.0f;
		info->Velocity.y = 0.0f;
		info->Velocity.z = 0.0f;
	}
	if(Keys(VK_BACK).Pressed)//jump forward 20 units
	{
		float offX = 20.0f;
		float offY = 0.0f;
		float offZ = 0.0f;

		float x = offX * info->Rotation.Front.x + offY * info->Rotation.Right.x + offZ * info->Rotation.Up.x + info->Pos.x;
		float y = offX * info->Rotation.Front.y + offY * info->Rotation.Right.y + offZ * info->Rotation.Up.y + info->Pos.y;
		float z = offX * info->Rotation.Front.z + offY * info->Rotation.Right.z + offZ * info->Rotation.Up.z + info->Pos.z;

		info->Pos.x = x;
		info->Pos.y = y;
		info->Pos.z = z;
	}
	if(Keys('Q').Pressed)//teleport all here LOL
	{
		for(unsigned int i = 1, j = ValidVehicles.size(); i < j; ++i)
		{
			int vehicle = ValidVehicles.at(i);
			float offX = 5*i;
			float offY = 5.0f;
			float offZ = 0.0f;

			Vehicles[vehicle]->Pos.x = offX * info->Rotation.Front.x + offY * info->Rotation.Right.x + offZ * info->Rotation.Up.x + info->Pos.x;
			Vehicles[vehicle]->Pos.y = offX * info->Rotation.Front.y + offY * info->Rotation.Right.y + offZ * info->Rotation.Up.y + info->Pos.y;
			Vehicles[vehicle]->Pos.z = offX * info->Rotation.Front.z + offY * info->Rotation.Right.z + offZ * info->Rotation.Up.z + info->Pos.z;

			Vehicles[vehicle]->Velocity.x = info->Velocity.x;
			Vehicles[vehicle]->Velocity.y = info->Velocity.y;
			Vehicles[vehicle]->Velocity.z = info->Velocity.z;

			Vehicles[vehicle]->Rotation.Front.w = info->Rotation.Front.w;
			Vehicles[vehicle]->Rotation.Front.x = info->Rotation.Front.x;
			Vehicles[vehicle]->Rotation.Front.y = info->Rotation.Front.y;
			Vehicles[vehicle]->Rotation.Front.z = info->Rotation.Front.z;
			Vehicles[vehicle]->Rotation.Right.w = info->Rotation.Right.w;
			Vehicles[vehicle]->Rotation.Right.x = info->Rotation.Right.x;
			Vehicles[vehicle]->Rotation.Right.y = info->Rotation.Right.y;
			Vehicles[vehicle]->Rotation.Right.z = info->Rotation.Right.z;
			Vehicles[vehicle]->Rotation.Up.w = info->Rotation.Up.w;
			Vehicles[vehicle]->Rotation.Up.x = info->Rotation.Up.x;
			Vehicles[vehicle]->Rotation.Up.y = info->Rotation.Up.y;
			Vehicles[vehicle]->Rotation.Up.z = info->Rotation.Up.z;

		}
	}
	DirectXFont::Access(0)->Print(0.0,105.0,0xFFFFFFFF,string_format("Airbreak: %s {FFFFFFFF}Angle: %.3f",(airbreak) ? "{FFFF0000}ON" : "{FF00FF00}OFF",Angle).c_str(),true);
		
	PROTECT;//nitro & RPM
	auto& Nitro			= POINTER(int,POINTER(unsigned int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x34) + 0x41C);
	auto& RPM			= POINTER(float,CameraPosBaseAddr + 0x440);
	DirectXFont::Access(0)->Print(0.0,30.0,0xFFFFFFFF,string_format("Nitro: %d / RPM: %.0f",Nitro,RPM).c_str(),true);
	Nitro = 2000000000;
	UNPROTECT;	
	
	PROTECT;//camera stuff
	auto CamBaseAddr	= POINTER(unsigned int,CameraBaseAddress + 0x40);
	auto& CamRot		= POINTER(Point4D,CamBaseAddr);
	auto& CamPos		= POINTER(Point3D,CameraPosBaseAddr + 0x50);
	UNPROTECT;	

	PROTECT;//current shift
	auto& CurrentShift	= POINTER(int,POINTER(unsigned int,PositionBaseAddress + 0x4C) + 0x38);
	UNPROTECT;

	PROTECT;//distance in run
	auto& DistBtwnCars	= POINTER(float,POINTER(unsigned int,DistanceBaseAddr + 0x1C) + 0x24);
	DistBtwnCars = 301.0f;
	UNPROTECT;

	PROTECT;//#drag race engine no blow hack
	auto& EngineHeat	= POINTER(float,POINTER(unsigned int,PositionBaseAddress + 0x48) + 0x8C);
	EngineHeat = 0.0f;
	UNPROTECT;

	PROTECT;//money hack
	PlayerMoney = 2000000000;
	UNPROTECT;

	#undef info
}

/*

Vehicle
Position.X: (0x0089CDA8 + 0x20) + 0x20
Position.Y: (0x0089CDA8 + 0x20) + 0x24
Position.Z: (0x0089CDA8 + 0x20) + 0x28
Rotation.X: (0x0089CDA8 + 0x20) + 0x30
Rotation.Y: (0x0089CDA8 + 0x20) + 0x34
Rotation.Z: (0x0089CDA8 + 0x20) + 0x38
Rotation.W: (0x0089CDA8 + 0x20) + 0x3C
Velocity.X: (0x0089CDA8 + 0x20) + 0x70
Velocity.Y: (0x0089CDA8 + 0x20) + 0x74
Velocity.Z: (0x0089CDA8 + 0x20) + 0x78

Player
Nitro:		((0x0089CDA8 + 0x4C) + 0x34) + 0x41
RPM:		(0x0089CCF8 + 0x440)

Camera
Rotation.X: (0x0086E6FC + 0x40) + 0x00
Rotation.Y: (0x0086E6FC + 0x40) + 0x04
Rotation.Z: (0x0086E6FC + 0x40) + 0x08
Rotation.W: (0x0086E6FC + 0x40) + 0x0C

Position.X: (0x0089CCF8 + 0x50)
Position.Y: (0x0089CCF8 + 0x54)
Position.Z: (0x0089CCF8 + 0x58)

*/

void InitializeDX(IDirect3DDevice9 * device)
{
	DirectXFont::Add("Lucida Console",10,FW_BOLD);
	DirectXFont::InitializeAll();
}

void UninitializeDX(IDirect3DDevice9 * device)
{
	DirectXFont::InvalidateAll();
}

void OnGameLaunch()
{

}

/////////////////////////////////////////////////////////////////////////////////////
LONG WINAPI unhandledExceptionFilter ( struct _EXCEPTION_POINTERS *ExceptionInfo )
{
	return EXCEPTION_CONTINUE_SEARCH;
}

BOOL APIENTRY DllMain ( HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved )
{
	std::string commands(GetCommandLine());
	switch ( ul_reason_for_call )
	{
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls( hModule );
		g_hDllModule = hModule;
		SetUnhandledExceptionFilter( unhandledExceptionFilter );
		break;

	case DLL_PROCESS_DETACH:

		if ( g_hOrigDll != NULL )
		{
			FreeLibrary( g_hOrigDll );
			g_hOrigDll = NULL;
		}
		break;
	}

	return true;
}