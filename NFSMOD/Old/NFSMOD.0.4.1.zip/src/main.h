#pragma once

#ifndef __MODMAIN_H
#define __MODMAIN_H

#define WIN32_LEAN_AND_MEAN
#define _CRT_SECURE_NO_WARNINGS 1

// let's do a precompiled header, why not
#pragma message( "Compiling precompiled header.\n" )

// handler not registered as safe handler
#pragma warning( disable : 4733 )

// API/SDK includes
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <shellapi.h>
#include <d3dx9.h>
#include <Gdiplus.h>
#include <assert.h>
#include <algorithm>
#include <list>
#include <map>
#include <set>
#include <string>
#include <vector>

#include <CDirect3DData.h>
#include "stdtypes.h"
#include "d3drender.h"
#include "proxyIDirect3D9.h"
#include "proxyIDirect3DDevice9.h"

// externals
extern HMODULE					g_hDllModule;
extern char						g_szWorkingDirectory[MAX_PATH];
extern t_WindowsInfo			WindowsInfo;

#endif
