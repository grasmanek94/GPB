This is the "MENU" key: http://en.wikipedia.org/wiki/Menu_key

Place d3d9.dll in you NFS directory (where speed2.exe is)

Versions 1.0 (not tested), 1.1 (not testet), 1.2 (tested) supported.

Download newest version always from http://gpb.googlecode.com/

MENU + F1 shows the cheat menu (need to hold down).

Addidtional keys:

BACKSPACE - jump 20 units forward
SHIFT - extra speed
~ - extra brake
TAB - Super brake
F5 - start recording playback
F6 - play last replay
F9 - save vehicle position
F11 - load vehicle position
Q - teleport all vehicles in range in front of your vehicle
F7 - Change replay

Keys prefixed with MENU key (MENU + key):

0 - Toggle all cheats
1 - Toggle recorder (enable / disable F5/F6)
2 - Toggle speedhacks (enable / disable ~/TAB/SHIFT)
3 - Toggle jumper (enable / disable BACKSPACE)
4 - Toggle control (enable / disable Q)
5 - Toggle Saver (enable / disable F9/F11)
6 - Toggle DriftAnywhere (enable / allow to drift where you already drifted in DRIFT cup)
7 - Toggle Moneyhack (Freeze/unfreeze money at 2,000,000,000)
8 - Toggle NoEngineHeat (engines does not overheat in drag)
9 - Toggle ReloadNitro (keeps your nitro at 50,000 Nitro Units)
F1 - Show help
F2 - load settings
F3 - save settings
F4 - Toggle rain control (enable / disable [/])
[ - decrease rain amount (min is 0)
] - increase rain amount (max is 1)

All replays you record are stored in "NFSMOD/Replays" folder. 
Functionality to play those recorded replays will be added soon.

To compile the source on your own you need DirectX SDK.