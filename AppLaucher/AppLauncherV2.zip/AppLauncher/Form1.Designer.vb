﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.Button75 = New System.Windows.Forms.Button()
        Me.Button76 = New System.Windows.Forms.Button()
        Me.Button77 = New System.Windows.Forms.Button()
        Me.Button78 = New System.Windows.Forms.Button()
        Me.Button79 = New System.Windows.Forms.Button()
        Me.Button80 = New System.Windows.Forms.Button()
        Me.Button81 = New System.Windows.Forms.Button()
        Me.Button82 = New System.Windows.Forms.Button()
        Me.Button83 = New System.Windows.Forms.Button()
        Me.Button84 = New System.Windows.Forms.Button()
        Me.Button85 = New System.Windows.Forms.Button()
        Me.Button86 = New System.Windows.Forms.Button()
        Me.Button87 = New System.Windows.Forms.Button()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.Button93 = New System.Windows.Forms.Button()
        Me.Button94 = New System.Windows.Forms.Button()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.Button101 = New System.Windows.Forms.Button()
        Me.Button102 = New System.Windows.Forms.Button()
        Me.Button103 = New System.Windows.Forms.Button()
        Me.Button104 = New System.Windows.Forms.Button()
        Me.Button105 = New System.Windows.Forms.Button()
        Me.Button106 = New System.Windows.Forms.Button()
        Me.Button107 = New System.Windows.Forms.Button()
        Me.Button108 = New System.Windows.Forms.Button()
        Me.Button109 = New System.Windows.Forms.Button()
        Me.Button110 = New System.Windows.Forms.Button()
        Me.Button111 = New System.Windows.Forms.Button()
        Me.Button112 = New System.Windows.Forms.Button()
        Me.Button113 = New System.Windows.Forms.Button()
        Me.Button114 = New System.Windows.Forms.Button()
        Me.Button115 = New System.Windows.Forms.Button()
        Me.Button116 = New System.Windows.Forms.Button()
        Me.Button117 = New System.Windows.Forms.Button()
        Me.Button118 = New System.Windows.Forms.Button()
        Me.Button119 = New System.Windows.Forms.Button()
        Me.Button120 = New System.Windows.Forms.Button()
        Me.Button121 = New System.Windows.Forms.Button()
        Me.Button122 = New System.Windows.Forms.Button()
        Me.Button123 = New System.Windows.Forms.Button()
        Me.Button124 = New System.Windows.Forms.Button()
        Me.Button125 = New System.Windows.Forms.Button()
        Me.Button128 = New System.Windows.Forms.Button()
        Me.Button130 = New System.Windows.Forms.Button()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.LineShape5 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.Button133 = New System.Windows.Forms.Button()
        Me.Button134 = New System.Windows.Forms.Button()
        Me.Button135 = New System.Windows.Forms.Button()
        Me.Button136 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(73, 762)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = " Quit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(422, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(167, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Tag = "C:/Games/OpenTTD/openttd.exe"
        Me.Button2.Text = "OpenTTD"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(77, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(167, 23)
        Me.Button3.TabIndex = 1
        Me.Button3.Tag = "C:/Games/Age Of Empires 2/age2_x1.exe"
        Me.Button3.Text = "Age Of Empires 2"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(77, 61)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(167, 23)
        Me.Button5.TabIndex = 1
        Me.Button5.Tag = "C:/Games/Atomic Bomberman/bm95Win7.bat"
        Me.Button5.Text = "Atomic Bomberman"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(77, 177)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(167, 23)
        Me.Button7.TabIndex = 1
        Me.Button7.Tag = "C:/Games/Dune 2000/DUNE2000.EXE"
        Me.Button7.Text = "Dune 2000"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(77, 235)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(167, 23)
        Me.Button10.TabIndex = 1
        Me.Button10.Tag = "C:\Games\F-22 Total Air War 2.0\tawmenu.exe"
        Me.Button10.Text = "F22 Total Air War 2.0"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(249, 3)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(167, 23)
        Me.Button14.TabIndex = 1
        Me.Button14.Tag = "C:/Games/GTA San Andreas/gta_sa.exe"
        Me.Button14.Text = "GTA San Andreas"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(250, 32)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(167, 23)
        Me.Button15.TabIndex = 1
        Me.Button15.Tag = "C:/Games/GTA San Andreas/samp.exe"
        Me.Button15.Text = "GTA San Andreas MP"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(250, 61)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(167, 23)
        Me.Button16.TabIndex = 1
        Me.Button16.Tag = "C:/Games/Hacker Evolution/Hacker Evolution Duality.exe"
        Me.Button16.Text = "Hacker Evolution"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(77, 119)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(167, 23)
        Me.Button18.TabIndex = 3
        Me.Button18.Tag = "C:\Games\Bridge Building Game\bridge.exe"
        Me.Button18.Text = "Bridge Building Game"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(250, 119)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(167, 23)
        Me.Button20.TabIndex = 3
        Me.Button20.Tag = "C:/Games/Joint Operations Typhoon Rising/Jointops.exe"
        Me.Button20.Text = "Joint Operations"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(250, 148)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(167, 23)
        Me.Button21.TabIndex = 3
        Me.Button21.Tag = "C:/Games/Killing Floor/StartKillingFloor.exe"
        Me.Button21.Text = "Killing Floor"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(250, 206)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(167, 23)
        Me.Button23.TabIndex = 3
        Me.Button23.Tag = "C:/Games/Minecraft/MinecraftSP.exe"
        Me.Button23.Text = "Minecraft"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(250, 264)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(167, 23)
        Me.Button26.TabIndex = 3
        Me.Button26.Tag = "C:/Games/Need for Speed Underground 2/SPEED2.EXE"
        Me.Button26.Text = "Need for Speed Underground 2"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(423, 32)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(167, 23)
        Me.Button27.TabIndex = 3
        Me.Button27.Tag = "C:/Games/Red Alert 3/RA3.exe"
        Me.Button27.Text = "Red Alert 3"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(423, 61)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(167, 23)
        Me.Button28.TabIndex = 3
        Me.Button28.Tag = "C:/Games/Red Alert 3/Data/WorldBuilder.exe"
        Me.Button28.Text = "Red Alert 3 World Builder"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(422, 90)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(167, 23)
        Me.Button29.TabIndex = 3
        Me.Button29.Tag = "C:/Games/S.W.A.T. 4/ContentExpansion/System/Swat4X.exe"
        Me.Button29.Text = "S.W.A.T. 4 Exp"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(422, 235)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(167, 23)
        Me.Button31.TabIndex = 3
        Me.Button31.Tag = "C:/Games/Trackmania United Forever/TmForever.exe"
        Me.Button31.Text = "Trackmania United Forever"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(422, 264)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(167, 23)
        Me.Button32.TabIndex = 4
        Me.Button32.Tag = "C:/Games/Unreal Tournament/System/UnrealTournament.exe"
        Me.Button32.Text = "Unreal Tournament"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(422, 148)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(167, 23)
        Me.Button33.TabIndex = 5
        Me.Button33.Tag = "C:/Programs/Steam/SteamApps/common/sniper ghost warrior/Sniper_x86.exe"
        Me.Button33.Text = "Sniper Ghost Warrior (STEAM)"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(250, 235)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(167, 23)
        Me.Button34.TabIndex = 6
        Me.Button34.Tag = "C:/Programs/MTA San Andreas/Multi Theft Auto.exe"
        Me.Button34.Text = "Multi Theft Auto"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(611, 235)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(176, 23)
        Me.Button35.TabIndex = 7
        Me.Button35.Tag = "C:/Programs/ASCII.Art.Studio.v2.2.1.Portable[Software]-Dr.Upload/AsciiArtStudio.e" & _
    "xe"
        Me.Button35.Text = " ASCII Art Studio"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(611, 264)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(176, 23)
        Me.Button36.TabIndex = 7
        Me.Button36.Tag = "C:/Programs/AVS4YOU/AVSImageConverter/AVSImageConverter.exe"
        Me.Button36.Text = " AVS Image Converter"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.Location = New System.Drawing.Point(611, 293)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(176, 23)
        Me.Button37.TabIndex = 7
        Me.Button37.Tag = "C:/Programs/AVSVideoConverter/AVSVideoConverter.exe"
        Me.Button37.Text = " AVS Video Converter"
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Location = New System.Drawing.Point(611, 322)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(176, 23)
        Me.Button38.TabIndex = 7
        Me.Button38.Tag = "C:/Programs/CamStudio 2.6b/Recorder.exe"
        Me.Button38.Text = " CamStudio"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.Location = New System.Drawing.Point(611, 351)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(176, 23)
        Me.Button39.TabIndex = 7
        Me.Button39.Tag = "C:/Programs/chaos A.D Keybinder 2.2/chaosAD Keybinder.exe"
        Me.Button39.Text = " Chaos A.D. Keybinder"
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.Location = New System.Drawing.Point(611, 380)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(176, 23)
        Me.Button40.TabIndex = 7
        Me.Button40.Tag = "C:/Programs/Cheat Engine 6.1/Cheat Engine.exe"
        Me.Button40.Text = " Cheat Engine 6.1"
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.Location = New System.Drawing.Point(611, 409)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(176, 23)
        Me.Button41.TabIndex = 7
        Me.Button41.Tag = "C:/Programs/DAEMON Tools Lite/DTLite.exe"
        Me.Button41.Text = " Daemon Tools Lite"
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button42
        '
        Me.Button42.Location = New System.Drawing.Point(611, 438)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(176, 23)
        Me.Button42.TabIndex = 7
        Me.Button42.Tag = "C:/Programs/DOSBox-0.74/DOSBox.exe"
        Me.Button42.Text = " Dos Box"
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.Location = New System.Drawing.Point(611, 467)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(176, 23)
        Me.Button43.TabIndex = 7
        Me.Button43.Tag = "C:/Programs/DOSShell/DOSShell.exe"
        Me.Button43.Text = " Dos Shell"
        Me.Button43.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.Location = New System.Drawing.Point(611, 496)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(176, 23)
        Me.Button44.TabIndex = 7
        Me.Button44.Tag = "C:/Programs/DriverGenius/DriverGenius.exe"
        Me.Button44.Text = " Driver Genius"
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.Location = New System.Drawing.Point(793, 206)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(176, 23)
        Me.Button45.TabIndex = 7
        Me.Button45.Tag = "C:/Programs/IZArc/IZArc.exe"
        Me.Button45.Text = " Iz Archiver"
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button46
        '
        Me.Button46.Location = New System.Drawing.Point(793, 235)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(176, 23)
        Me.Button46.TabIndex = 7
        Me.Button46.Tag = "C:/Programs/Jitbit Macro Recorder LITE/MacroRecorder.exe"
        Me.Button46.Text = " JiBit Macro Recorder"
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button47
        '
        Me.Button47.Location = New System.Drawing.Point(793, 264)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(176, 23)
        Me.Button47.TabIndex = 7
        Me.Button47.Tag = "C:/Programs/Microsoft/Mathematics/MathApp.exe"
        Me.Button47.Text = " Microsoft Mathematics"
        Me.Button47.UseVisualStyleBackColor = True
        '
        'Button48
        '
        Me.Button48.Location = New System.Drawing.Point(793, 293)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(176, 23)
        Me.Button48.TabIndex = 7
        Me.Button48.Tag = "C:/Programs/Microsoft Network Monitor 3/netmon.exe"
        Me.Button48.Text = " Microsoft Network Monitor 3.0"
        Me.Button48.UseVisualStyleBackColor = True
        '
        'Button49
        '
        Me.Button49.Location = New System.Drawing.Point(793, 322)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(176, 23)
        Me.Button49.TabIndex = 7
        Me.Button49.Tag = "C:/Programs/mIRC/mirc.exe"
        Me.Button49.Text = " mIRC"
        Me.Button49.UseVisualStyleBackColor = True
        '
        'Button50
        '
        Me.Button50.Location = New System.Drawing.Point(793, 351)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(176, 23)
        Me.Button50.TabIndex = 7
        Me.Button50.Tag = "C:/Programs/mmlogic14/Mmlogic.exe"
        Me.Button50.Text = " Mm Logic"
        Me.Button50.UseVisualStyleBackColor = True
        '
        'Button51
        '
        Me.Button51.Location = New System.Drawing.Point(793, 380)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(176, 23)
        Me.Button51.TabIndex = 7
        Me.Button51.Tag = "C:/Programs/MSWLogo/logo32.exe -e"
        Me.Button51.Text = " MSW Logo"
        Me.Button51.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.Location = New System.Drawing.Point(793, 409)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(176, 23)
        Me.Button53.TabIndex = 7
        Me.Button53.Tag = "C:/Programs/Nero/Nero 10/Nero StartSmart/NeroStartSmart.exe"
        Me.Button53.Text = " Nero 10"
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button54
        '
        Me.Button54.Location = New System.Drawing.Point(793, 438)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(176, 23)
        Me.Button54.TabIndex = 7
        Me.Button54.Tag = "C:/Programs/NoteTab Pro 6/NotePro.exe"
        Me.Button54.Text = " NoteTab Pro 6"
        Me.Button54.UseVisualStyleBackColor = True
        '
        'Button55
        '
        Me.Button55.Location = New System.Drawing.Point(975, 177)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(176, 23)
        Me.Button55.TabIndex = 7
        Me.Button55.Tag = "C:/Programs/Total Commander 756/TOTALCMD.EXE"
        Me.Button55.Text = " Total Commander"
        Me.Button55.UseVisualStyleBackColor = True
        '
        'Button56
        '
        Me.Button56.Location = New System.Drawing.Point(975, 206)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(176, 23)
        Me.Button56.TabIndex = 7
        Me.Button56.Tag = "C:/Programs/UniExtr/UniExtract.exe"
        Me.Button56.Text = " Universal Extractor"
        Me.Button56.UseVisualStyleBackColor = True
        '
        'Button58
        '
        Me.Button58.Location = New System.Drawing.Point(975, 235)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(176, 23)
        Me.Button58.TabIndex = 7
        Me.Button58.Tag = "C:/Programs/VoipBuster/VoipBuster.exe"
        Me.Button58.Text = " VoipBuster"
        Me.Button58.UseVisualStyleBackColor = True
        '
        'Button59
        '
        Me.Button59.Location = New System.Drawing.Point(975, 264)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(176, 23)
        Me.Button59.TabIndex = 7
        Me.Button59.Tag = "C:/Programs/Winamp/winamp.exe"
        Me.Button59.Text = " Winamp"
        Me.Button59.UseVisualStyleBackColor = True
        '
        'Button60
        '
        Me.Button60.Location = New System.Drawing.Point(975, 293)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(176, 23)
        Me.Button60.TabIndex = 7
        Me.Button60.Tag = "C:/Programs/WinUHA/WinUha.exe"
        Me.Button60.Text = " WinUHARC"
        Me.Button60.UseVisualStyleBackColor = True
        '
        'Button61
        '
        Me.Button61.Location = New System.Drawing.Point(975, 322)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(176, 23)
        Me.Button61.TabIndex = 7
        Me.Button61.Tag = "C:/Programs/XAMPP/xampp-control.exe"
        Me.Button61.Text = " XAMPP"
        Me.Button61.UseVisualStyleBackColor = True
        '
        'Button62
        '
        Me.Button62.Location = New System.Drawing.Point(975, 148)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(176, 23)
        Me.Button62.TabIndex = 7
        Me.Button62.Tag = "C:/Programs/Xfire/Xfire.exe"
        Me.Button62.Text = " Xfire"
        Me.Button62.UseVisualStyleBackColor = True
        '
        'Button63
        '
        Me.Button63.Location = New System.Drawing.Point(975, 351)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(176, 23)
        Me.Button63.TabIndex = 7
        Me.Button63.Tag = "C:/Program Files (x86)/AcerCrystalEye/Acer Crystal Eye webcam.exe"
        Me.Button63.Text = "Acer Crystal Eye Webcam"
        Me.Button63.UseVisualStyleBackColor = True
        '
        'Button64
        '
        Me.Button64.Location = New System.Drawing.Point(975, 380)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(176, 23)
        Me.Button64.TabIndex = 7
        Me.Button64.Tag = "C:/Program Files (x86)/Alcohol Soft/Alcohol 120/AxLaUn.exe"
        Me.Button64.Text = " Alcohol 120%"
        Me.Button64.UseVisualStyleBackColor = True
        '
        'Button65
        '
        Me.Button65.Location = New System.Drawing.Point(611, 525)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(176, 23)
        Me.Button65.TabIndex = 7
        Me.Button65.Tag = "C:/Programs/EASEUS/EASEUS Partition Master 9.0.0 Server Edition/bin/epm0.exe"
        Me.Button65.Text = " Easeus Partition Master"
        Me.Button65.UseVisualStyleBackColor = True
        '
        'Button66
        '
        Me.Button66.Location = New System.Drawing.Point(793, 467)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(176, 23)
        Me.Button66.TabIndex = 7
        Me.Button66.Tag = "C:/Programs/Olly Debugger 2.01a3/ollydbg.exe"
        Me.Button66.Text = " Olly Debugger 2.01a3"
        Me.Button66.UseVisualStyleBackColor = True
        '
        'Button68
        '
        Me.Button68.Location = New System.Drawing.Point(611, 554)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(176, 23)
        Me.Button68.TabIndex = 7
        Me.Button68.Tag = "C:/Programs/EasyBCD/EasyBCD.exe"
        Me.Button68.Text = " EasyBCD"
        Me.Button68.UseVisualStyleBackColor = True
        '
        'Button69
        '
        Me.Button69.Location = New System.Drawing.Point(793, 496)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(176, 23)
        Me.Button69.TabIndex = 7
        Me.Button69.Tag = "C:/Programs/PAK Explorer/PakExplorer.exe"
        Me.Button69.Text = " Battlezone PAK Explorer"
        Me.Button69.UseVisualStyleBackColor = True
        '
        'Button70
        '
        Me.Button70.Location = New System.Drawing.Point(975, 409)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(176, 23)
        Me.Button70.TabIndex = 7
        Me.Button70.Tag = "C:/Program Files (x86)/EgisTec MyWinLocker/Launcher/x86/MiniLauncher.exe"
        Me.Button70.Text = " MyWinLocker"
        Me.Button70.UseVisualStyleBackColor = True
        '
        'Button71
        '
        Me.Button71.Location = New System.Drawing.Point(611, 583)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(176, 23)
        Me.Button71.TabIndex = 7
        Me.Button71.Tag = "C:/Programs/efs/search.exe"
        Me.Button71.Text = " Effective File Search"
        Me.Button71.UseVisualStyleBackColor = True
        '
        'Button72
        '
        Me.Button72.Location = New System.Drawing.Point(793, 525)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(176, 23)
        Me.Button72.TabIndex = 7
        Me.Button72.Tag = "C:/Programs/RADVideo/radvideo.exe"
        Me.Button72.Text = " RAD Video Tools"
        Me.Button72.UseVisualStyleBackColor = True
        '
        'Button73
        '
        Me.Button73.Location = New System.Drawing.Point(975, 438)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(176, 23)
        Me.Button73.TabIndex = 7
        Me.Button73.Tag = "C:/Program Files (x86)/Free Download Manager/fdm.exe"
        Me.Button73.Text = " Free Download Manager"
        Me.Button73.UseVisualStyleBackColor = True
        '
        'Button74
        '
        Me.Button74.Location = New System.Drawing.Point(611, 612)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(176, 23)
        Me.Button74.TabIndex = 7
        Me.Button74.Tag = "C:/Programs/FileZillaClient/filezilla.exe"
        Me.Button74.Text = " File Zilla Client"
        Me.Button74.UseVisualStyleBackColor = True
        '
        'Button75
        '
        Me.Button75.Location = New System.Drawing.Point(793, 554)
        Me.Button75.Name = "Button75"
        Me.Button75.Size = New System.Drawing.Size(176, 23)
        Me.Button75.TabIndex = 7
        Me.Button75.Tag = "C:/Programs/RapidSVN-0.12.0/bin/rapidsvn.exe"
        Me.Button75.Text = " Rapid SVN"
        Me.Button75.UseVisualStyleBackColor = True
        '
        'Button76
        '
        Me.Button76.Location = New System.Drawing.Point(975, 467)
        Me.Button76.Name = "Button76"
        Me.Button76.Size = New System.Drawing.Size(176, 23)
        Me.Button76.TabIndex = 7
        Me.Button76.Tag = "C:/Program Files (x86)/Gadu-Gadu 10/gg.exe"
        Me.Button76.Text = " Gadu-Gadu 10"
        Me.Button76.UseVisualStyleBackColor = True
        '
        'Button77
        '
        Me.Button77.Location = New System.Drawing.Point(611, 641)
        Me.Button77.Name = "Button77"
        Me.Button77.Size = New System.Drawing.Size(176, 23)
        Me.Button77.TabIndex = 7
        Me.Button77.Tag = "C:/Programs/FL Studio 10/FL (extended memory).exe"
        Me.Button77.Text = " FL Studio 10"
        Me.Button77.UseVisualStyleBackColor = True
        '
        'Button78
        '
        Me.Button78.Location = New System.Drawing.Point(793, 583)
        Me.Button78.Name = "Button78"
        Me.Button78.Size = New System.Drawing.Size(176, 23)
        Me.Button78.TabIndex = 7
        Me.Button78.Tag = "C:/Programs/RealTemp_360/RealTemp.exe"
        Me.Button78.Text = " RealTemp"
        Me.Button78.UseVisualStyleBackColor = True
        '
        'Button79
        '
        Me.Button79.Location = New System.Drawing.Point(77, 728)
        Me.Button79.Name = "Button79"
        Me.Button79.Size = New System.Drawing.Size(167, 23)
        Me.Button79.TabIndex = 7
        Me.Button79.Tag = "C:/Program Files (x86)/Opera/opera.exe"
        Me.Button79.Text = " Opera"
        Me.Button79.UseVisualStyleBackColor = True
        '
        'Button80
        '
        Me.Button80.Location = New System.Drawing.Point(611, 670)
        Me.Button80.Name = "Button80"
        Me.Button80.Size = New System.Drawing.Size(176, 23)
        Me.Button80.TabIndex = 7
        Me.Button80.Tag = "C:/Programs/FLV Converter/Emicsoft FLV Converter.exe"
        Me.Button80.Text = " FLV Converter"
        Me.Button80.UseVisualStyleBackColor = True
        '
        'Button81
        '
        Me.Button81.Location = New System.Drawing.Point(793, 612)
        Me.Button81.Name = "Button81"
        Me.Button81.Size = New System.Drawing.Size(176, 23)
        Me.Button81.TabIndex = 7
        Me.Button81.Tag = "C:/Programs/Relics Archv Ext/RelicArchiveExtractor.exe"
        Me.Button81.Text = " Relics Archive Extractor"
        Me.Button81.UseVisualStyleBackColor = True
        '
        'Button82
        '
        Me.Button82.Location = New System.Drawing.Point(975, 496)
        Me.Button82.Name = "Button82"
        Me.Button82.Size = New System.Drawing.Size(176, 23)
        Me.Button82.TabIndex = 7
        Me.Button82.Tag = "C:/Program Files (x86)/Orbitdownloader/orbitdm.exe"
        Me.Button82.Text = " Orbit Download Manager"
        Me.Button82.UseVisualStyleBackColor = True
        '
        'Button83
        '
        Me.Button83.Location = New System.Drawing.Point(611, 699)
        Me.Button83.Name = "Button83"
        Me.Button83.Size = New System.Drawing.Size(176, 23)
        Me.Button83.TabIndex = 7
        Me.Button83.Tag = "C:/Programs/ftp/MiniFTPServer.exe"
        Me.Button83.Text = " Fmini FTP server"
        Me.Button83.UseVisualStyleBackColor = True
        '
        'Button84
        '
        Me.Button84.Location = New System.Drawing.Point(793, 641)
        Me.Button84.Name = "Button84"
        Me.Button84.Size = New System.Drawing.Size(176, 23)
        Me.Button84.TabIndex = 7
        Me.Button84.Tag = "C:/Programs/SAM422/SAMBC.exe"
        Me.Button84.Text = " SAM Broadcaster"
        Me.Button84.UseVisualStyleBackColor = True
        '
        'Button85
        '
        Me.Button85.Location = New System.Drawing.Point(975, 525)
        Me.Button85.Name = "Button85"
        Me.Button85.Size = New System.Drawing.Size(176, 23)
        Me.Button85.TabIndex = 7
        Me.Button85.Tag = "C:/Program Files (x86)/Skype/Phone/Skype.exe"
        Me.Button85.Text = " Skype"
        Me.Button85.UseVisualStyleBackColor = True
        '
        'Button86
        '
        Me.Button86.Location = New System.Drawing.Point(611, 728)
        Me.Button86.Name = "Button86"
        Me.Button86.Size = New System.Drawing.Size(176, 23)
        Me.Button86.TabIndex = 7
        Me.Button86.Tag = "C:/Programs/Hamachi/hamachi.exe"
        Me.Button86.Text = " Hamachi 1"
        Me.Button86.UseVisualStyleBackColor = True
        '
        'Button87
        '
        Me.Button87.Location = New System.Drawing.Point(793, 670)
        Me.Button87.Name = "Button87"
        Me.Button87.Size = New System.Drawing.Size(176, 23)
        Me.Button87.TabIndex = 7
        Me.Button87.Tag = "C:/Programs/Samsung Kies/Kies/Kies.exe"
        Me.Button87.Text = " Samsung Kies"
        Me.Button87.UseVisualStyleBackColor = True
        '
        'Button89
        '
        Me.Button89.Location = New System.Drawing.Point(793, 3)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(176, 23)
        Me.Button89.TabIndex = 7
        Me.Button89.Tag = "C:/Programs/Hamachi2/hamachi-2-ui.exe"
        Me.Button89.Text = " Hamachi 2 UI"
        Me.Button89.UseVisualStyleBackColor = True
        '
        'Button90
        '
        Me.Button90.Location = New System.Drawing.Point(793, 699)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(176, 23)
        Me.Button90.TabIndex = 7
        Me.Button90.Tag = "C:/Programs/San Andreas Mod Installer/sami.exe"
        Me.Button90.Text = " San Andreas Mod Installer"
        Me.Button90.UseVisualStyleBackColor = True
        '
        'Button91
        '
        Me.Button91.Location = New System.Drawing.Point(975, 554)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(176, 23)
        Me.Button91.TabIndex = 7
        Me.Button91.Tag = "C:/Program Files (x86)/Tunatic/tunatic.exe"
        Me.Button91.Text = " Tunatic"
        Me.Button91.UseVisualStyleBackColor = True
        '
        'Button92
        '
        Me.Button92.Location = New System.Drawing.Point(793, 32)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(176, 23)
        Me.Button92.TabIndex = 7
        Me.Button92.Tag = "C:/Programs/Hex Workshop v6/HWorks32.exe"
        Me.Button92.Text = " Hex Workshop"
        Me.Button92.UseVisualStyleBackColor = True
        '
        'Button93
        '
        Me.Button93.Location = New System.Drawing.Point(793, 728)
        Me.Button93.Name = "Button93"
        Me.Button93.Size = New System.Drawing.Size(176, 23)
        Me.Button93.TabIndex = 7
        Me.Button93.Tag = "C:/Programs/SHOUTcast/sc_serv.exe"
        Me.Button93.Text = " SHOUTcast Server"
        Me.Button93.UseVisualStyleBackColor = True
        '
        'Button94
        '
        Me.Button94.Location = New System.Drawing.Point(975, 583)
        Me.Button94.Name = "Button94"
        Me.Button94.Size = New System.Drawing.Size(176, 23)
        Me.Button94.TabIndex = 7
        Me.Button94.Tag = "C:/Program Files (x86)/uTorrent/uTorrent.exe"
        Me.Button94.Text = " uTorrent"
        Me.Button94.UseVisualStyleBackColor = True
        '
        'Button95
        '
        Me.Button95.Location = New System.Drawing.Point(793, 61)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(176, 23)
        Me.Button95.TabIndex = 7
        Me.Button95.Tag = "C:/Programs/HideIPEasy/HideIPEasy.exe"
        Me.Button95.Text = " Hide IP Easy"
        Me.Button95.UseVisualStyleBackColor = True
        '
        'Button96
        '
        Me.Button96.Location = New System.Drawing.Point(975, 3)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(176, 23)
        Me.Button96.TabIndex = 7
        Me.Button96.Tag = "notepad ""C:/Programs/SHOUTcast/sc_serv.ini"""
        Me.Button96.Text = " SHOUTcast Server Configuration"
        Me.Button96.UseVisualStyleBackColor = True
        '
        'Button97
        '
        Me.Button97.Location = New System.Drawing.Point(975, 612)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(176, 23)
        Me.Button97.TabIndex = 7
        Me.Button97.Tag = "C:/Program Files (x86)/VMware/VMware Workstation/vmware.exe"
        Me.Button97.Text = " VMware Workstation"
        Me.Button97.UseVisualStyleBackColor = True
        '
        'Button98
        '
        Me.Button98.Location = New System.Drawing.Point(793, 90)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(176, 23)
        Me.Button98.TabIndex = 7
        Me.Button98.Tag = "C:/Programs/IcoExtract/iconsext.exe"
        Me.Button98.Text = " Icon Extractor"
        Me.Button98.UseVisualStyleBackColor = True
        '
        'Button99
        '
        Me.Button99.Location = New System.Drawing.Point(975, 32)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(176, 23)
        Me.Button99.TabIndex = 7
        Me.Button99.Tag = "C:/Programs/Sothink SWF Decompiler/SWFDecompiler.exe"
        Me.Button99.Text = " Sothink SWF decompiler"
        Me.Button99.UseVisualStyleBackColor = True
        '
        'Button100
        '
        Me.Button100.Location = New System.Drawing.Point(975, 641)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(176, 23)
        Me.Button100.TabIndex = 7
        Me.Button100.Tag = "C:/Program Files/Fraps/fraps.exe"
        Me.Button100.Text = " FRAPS"
        Me.Button100.UseVisualStyleBackColor = True
        '
        'Button101
        '
        Me.Button101.Location = New System.Drawing.Point(793, 119)
        Me.Button101.Name = "Button101"
        Me.Button101.Size = New System.Drawing.Size(176, 23)
        Me.Button101.TabIndex = 7
        Me.Button101.Tag = "C:/Programs/IDA Pro 6.1/idaq.exe"
        Me.Button101.Text = " IDA 6.1 PRO"
        Me.Button101.UseVisualStyleBackColor = True
        '
        'Button102
        '
        Me.Button102.Location = New System.Drawing.Point(975, 61)
        Me.Button102.Name = "Button102"
        Me.Button102.Size = New System.Drawing.Size(176, 23)
        Me.Button102.TabIndex = 7
        Me.Button102.Tag = "C:/Programs/Steam/steam.exe"
        Me.Button102.Text = " STEAM"
        Me.Button102.UseVisualStyleBackColor = True
        '
        'Button103
        '
        Me.Button103.Location = New System.Drawing.Point(975, 670)
        Me.Button103.Name = "Button103"
        Me.Button103.Size = New System.Drawing.Size(176, 23)
        Me.Button103.TabIndex = 7
        Me.Button103.Tag = "C:/Program Files/Sandboxie/Start.exe"
        Me.Button103.Text = " Sandboxie"
        Me.Button103.UseVisualStyleBackColor = True
        '
        'Button104
        '
        Me.Button104.Location = New System.Drawing.Point(793, 148)
        Me.Button104.Name = "Button104"
        Me.Button104.Size = New System.Drawing.Size(176, 23)
        Me.Button104.TabIndex = 7
        Me.Button104.Tag = "C:/Programs/inSSIDer 2.0/inSSIDer.exe"
        Me.Button104.Text = " inSSIDer 2.0"
        Me.Button104.UseVisualStyleBackColor = True
        '
        'Button105
        '
        Me.Button105.Location = New System.Drawing.Point(975, 90)
        Me.Button105.Name = "Button105"
        Me.Button105.Size = New System.Drawing.Size(176, 23)
        Me.Button105.TabIndex = 7
        Me.Button105.Tag = "C:/Programs/SWFtext/SWFText.exe"
        Me.Button105.Text = " SFW text"
        Me.Button105.UseVisualStyleBackColor = True
        '
        'Button106
        '
        Me.Button106.Location = New System.Drawing.Point(975, 699)
        Me.Button106.Name = "Button106"
        Me.Button106.Size = New System.Drawing.Size(176, 23)
        Me.Button106.TabIndex = 7
        Me.Button106.Tag = "C:/Program Files/Sony/Vegas Pro 10.0/vegas100.exe"
        Me.Button106.Text = " Sony Vegas Pro 10"
        Me.Button106.UseVisualStyleBackColor = True
        '
        'Button107
        '
        Me.Button107.Location = New System.Drawing.Point(793, 177)
        Me.Button107.Name = "Button107"
        Me.Button107.Size = New System.Drawing.Size(176, 23)
        Me.Button107.TabIndex = 7
        Me.Button107.Tag = "C:/Programs/IrfanView/i_view32.exe"
        Me.Button107.Text = " Irfan View"
        Me.Button107.UseVisualStyleBackColor = True
        '
        'Button108
        '
        Me.Button108.Location = New System.Drawing.Point(975, 119)
        Me.Button108.Name = "Button108"
        Me.Button108.Size = New System.Drawing.Size(176, 23)
        Me.Button108.TabIndex = 7
        Me.Button108.Tag = "C:/Programs/TeamSpeak 3 Client/ts3client_win32.exe"
        Me.Button108.Text = " TeamSpeak 3 Client"
        Me.Button108.UseVisualStyleBackColor = True
        '
        'Button109
        '
        Me.Button109.Location = New System.Drawing.Point(975, 728)
        Me.Button109.Name = "Button109"
        Me.Button109.Size = New System.Drawing.Size(176, 23)
        Me.Button109.TabIndex = 7
        Me.Button109.Tag = "C:/Program Files/WinRAR/WinRAR.exe"
        Me.Button109.Text = " WinRAR"
        Me.Button109.UseVisualStyleBackColor = True
        '
        'Button110
        '
        Me.Button110.Location = New System.Drawing.Point(611, 148)
        Me.Button110.Name = "Button110"
        Me.Button110.Size = New System.Drawing.Size(176, 23)
        Me.Button110.TabIndex = 7
        Me.Button110.Tag = "C:/Programs/Advanced Renamer/ARen.exe"
        Me.Button110.Text = " Advanced Renamer"
        Me.Button110.UseVisualStyleBackColor = True
        '
        'Button111
        '
        Me.Button111.Location = New System.Drawing.Point(611, 119)
        Me.Button111.Name = "Button111"
        Me.Button111.Size = New System.Drawing.Size(176, 23)
        Me.Button111.TabIndex = 7
        Me.Button111.Tag = "C:/Programs/Photoshop CS5/Adobe Photoshop CS5/Photoshop.exe"
        Me.Button111.Text = " Adobe Photoshop"
        Me.Button111.UseVisualStyleBackColor = True
        '
        'Button112
        '
        Me.Button112.Location = New System.Drawing.Point(611, 90)
        Me.Button112.Name = "Button112"
        Me.Button112.Size = New System.Drawing.Size(176, 23)
        Me.Button112.TabIndex = 7
        Me.Button112.Tag = "C:/Programs/Adobe Flash/Adobe Flash CS5/Flash.exe"
        Me.Button112.Text = " Adobe Flash"
        Me.Button112.UseVisualStyleBackColor = True
        '
        'Button113
        '
        Me.Button113.Location = New System.Drawing.Point(611, 177)
        Me.Button113.Name = "Button113"
        Me.Button113.Size = New System.Drawing.Size(176, 23)
        Me.Button113.TabIndex = 7
        Me.Button113.Tag = "C:/Programs/Any Audio Converter/AudioConverter.exe"
        Me.Button113.Text = " Any Audio Converter"
        Me.Button113.UseVisualStyleBackColor = True
        '
        'Button114
        '
        Me.Button114.Location = New System.Drawing.Point(611, 206)
        Me.Button114.Name = "Button114"
        Me.Button114.Size = New System.Drawing.Size(176, 23)
        Me.Button114.TabIndex = 7
        Me.Button114.Tag = "C:/Programs/AnyToISO/anytoiso.exe"
        Me.Button114.Text = " Any To Iso Converter"
        Me.Button114.UseVisualStyleBackColor = True
        '
        'Button115
        '
        Me.Button115.Location = New System.Drawing.Point(611, 61)
        Me.Button115.Name = "Button115"
        Me.Button115.Size = New System.Drawing.Size(176, 23)
        Me.Button115.TabIndex = 7
        Me.Button115.Tag = "C:/Programs/Dreamweaver/Adobe Dreamweaver CS5/Dreamweaver.exe"
        Me.Button115.Text = " Adobe Dreamweaver"
        Me.Button115.UseVisualStyleBackColor = True
        '
        'Button116
        '
        Me.Button116.Location = New System.Drawing.Point(611, 32)
        Me.Button116.Name = "Button116"
        Me.Button116.Size = New System.Drawing.Size(176, 23)
        Me.Button116.TabIndex = 7
        Me.Button116.Tag = "C:/Programs/Adobe/Adobe Premiere Pro CS5/Adobe Premiere Pro.exe"
        Me.Button116.Text = " Adobe Premiere CS5"
        Me.Button116.UseVisualStyleBackColor = True
        '
        'Button117
        '
        Me.Button117.Location = New System.Drawing.Point(611, 3)
        Me.Button117.Name = "Button117"
        Me.Button117.Size = New System.Drawing.Size(176, 23)
        Me.Button117.TabIndex = 7
        Me.Button117.Tag = "C:/Programs/7-Zip/7zFM.exe"
        Me.Button117.Text = " 7-Zip"
        Me.Button117.UseVisualStyleBackColor = True
        '
        'Button118
        '
        Me.Button118.Location = New System.Drawing.Point(77, 699)
        Me.Button118.Name = "Button118"
        Me.Button118.Size = New System.Drawing.Size(167, 23)
        Me.Button118.TabIndex = 8
        Me.Button118.Tag = "C:\Programs\Mozilla Firefox\firefox.exe"
        Me.Button118.Text = "Mozilla Firefox"
        Me.Button118.UseVisualStyleBackColor = True
        '
        'Button119
        '
        Me.Button119.Location = New System.Drawing.Point(77, 670)
        Me.Button119.Name = "Button119"
        Me.Button119.Size = New System.Drawing.Size(167, 23)
        Me.Button119.TabIndex = 9
        Me.Button119.Tag = "C:\Users\Rafal\AppData\Local\Google\Chrome\Application\chrome.exe"
        Me.Button119.Text = "Google Chrome"
        Me.Button119.UseVisualStyleBackColor = True
        '
        'Button120
        '
        Me.Button120.Location = New System.Drawing.Point(77, 641)
        Me.Button120.Name = "Button120"
        Me.Button120.Size = New System.Drawing.Size(167, 23)
        Me.Button120.TabIndex = 10
        Me.Button120.Tag = "C:\Program Files (x86)\Internet Explorer\iexplore.exe"
        Me.Button120.Text = "Internet Explorer 32bit"
        Me.Button120.UseVisualStyleBackColor = True
        '
        'Button121
        '
        Me.Button121.Location = New System.Drawing.Point(77, 612)
        Me.Button121.Name = "Button121"
        Me.Button121.Size = New System.Drawing.Size(167, 23)
        Me.Button121.TabIndex = 11
        Me.Button121.Tag = "C:\Program Files\Internet Explorer\iexplore.exe"
        Me.Button121.Text = "Internet Explorer 64bit"
        Me.Button121.UseVisualStyleBackColor = True
        '
        'Button122
        '
        Me.Button122.Location = New System.Drawing.Point(251, 337)
        Me.Button122.Name = "Button122"
        Me.Button122.Size = New System.Drawing.Size(339, 23)
        Me.Button122.TabIndex = 12
        Me.Button122.Tag = "C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\VCExpress.exe"
        Me.Button122.Text = " Microsoft Visual C++ Express 2010"
        Me.Button122.UseVisualStyleBackColor = True
        '
        'Button123
        '
        Me.Button123.Location = New System.Drawing.Point(251, 366)
        Me.Button123.Name = "Button123"
        Me.Button123.Size = New System.Drawing.Size(339, 23)
        Me.Button123.TabIndex = 13
        Me.Button123.Tag = "C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\vbexpress.exe"
        Me.Button123.Text = "Microsoft Visual Basic 2010 Express"
        Me.Button123.UseVisualStyleBackColor = True
        '
        'Button124
        '
        Me.Button124.Location = New System.Drawing.Point(251, 395)
        Me.Button124.Name = "Button124"
        Me.Button124.Size = New System.Drawing.Size(339, 23)
        Me.Button124.TabIndex = 13
        Me.Button124.Tag = "C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\vcsexpress.exe"
        Me.Button124.Text = " Microsoft Visual C# 2010 Express 2010"
        Me.Button124.UseVisualStyleBackColor = True
        '
        'Button125
        '
        Me.Button125.Location = New System.Drawing.Point(251, 424)
        Me.Button125.Name = "Button125"
        Me.Button125.Size = New System.Drawing.Size(339, 23)
        Me.Button125.TabIndex = 16
        Me.Button125.Tag = "C:\Program Files (x86)\Microsoft Visual Studio 9.0\Common7\IDE\VCExpress.exe"
        Me.Button125.Text = " Microsoft Visual C++ 2008 Express"
        Me.Button125.UseVisualStyleBackColor = True
        '
        'Button128
        '
        Me.Button128.Location = New System.Drawing.Point(251, 453)
        Me.Button128.Name = "Button128"
        Me.Button128.Size = New System.Drawing.Size(339, 23)
        Me.Button128.TabIndex = 18
        Me.Button128.Tag = "C:\Program Files (x86)\K-Lite Codec Pack\Media Player Classic\mpc-hc.exe"
        Me.Button128.Text = "Media Player Classic"
        Me.Button128.UseVisualStyleBackColor = True
        '
        'Button130
        '
        Me.Button130.Location = New System.Drawing.Point(251, 482)
        Me.Button130.Name = "Button130"
        Me.Button130.Size = New System.Drawing.Size(339, 23)
        Me.Button130.TabIndex = 20
        Me.Button130.Tag = "explorer C:\Fraps"
        Me.Button130.Text = "FRAPS Movies and Screenshots"
        Me.Button130.UseVisualStyleBackColor = True
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape2, Me.RectangleShape1, Me.LineShape5, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1366, 768)
        Me.ShapeContainer1.TabIndex = 23
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape2
        '
        Me.RectangleShape2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.RectangleShape2.Location = New System.Drawing.Point(64, 355)
        Me.RectangleShape2.Name = "RectangleShape2"
        Me.RectangleShape2.Size = New System.Drawing.Size(181, 127)
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RectangleShape1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RectangleShape1.FillColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RectangleShape1.FillGradientColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RectangleShape1.Location = New System.Drawing.Point(68, 605)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.SelectionColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.RectangleShape1.Size = New System.Drawing.Size(179, 150)
        '
        'LineShape5
        '
        Me.LineShape5.BorderColor = System.Drawing.Color.Lime
        Me.LineShape5.Name = "LineShape5"
        Me.LineShape5.X1 = 62
        Me.LineShape5.X2 = 598
        Me.LineShape5.Y1 = 299
        Me.LineShape5.Y2 = 299
        '
        'LineShape1
        '
        Me.LineShape1.BorderColor = System.Drawing.Color.Lime
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 599
        Me.LineShape1.X2 = 599
        Me.LineShape1.Y1 = 0
        Me.LineShape1.Y2 = 768
        '
        'Button133
        '
        Me.Button133.Location = New System.Drawing.Point(77, 366)
        Me.Button133.Name = "Button133"
        Me.Button133.Size = New System.Drawing.Size(167, 23)
        Me.Button133.TabIndex = 24
        Me.Button133.Tag = "C:/Program Files/Microsoft Office/Office14/WINWORD.EXE"
        Me.Button133.Text = "Word"
        Me.Button133.UseVisualStyleBackColor = True
        '
        'Button134
        '
        Me.Button134.Location = New System.Drawing.Point(77, 395)
        Me.Button134.Name = "Button134"
        Me.Button134.Size = New System.Drawing.Size(167, 23)
        Me.Button134.TabIndex = 25
        Me.Button134.Tag = "C:/Program Files/Microsoft Office/Office14/POWERPNT.EXE"
        Me.Button134.Text = "Powerpoint"
        Me.Button134.UseVisualStyleBackColor = True
        '
        'Button135
        '
        Me.Button135.Location = New System.Drawing.Point(77, 424)
        Me.Button135.Name = "Button135"
        Me.Button135.Size = New System.Drawing.Size(167, 23)
        Me.Button135.TabIndex = 26
        Me.Button135.Tag = "C:/Program Files/Microsoft Office/Office14/EXCEL.EXE"
        Me.Button135.Text = "Excel"
        Me.Button135.UseVisualStyleBackColor = True
        '
        'Button136
        '
        Me.Button136.Location = New System.Drawing.Point(77, 453)
        Me.Button136.Name = "Button136"
        Me.Button136.Size = New System.Drawing.Size(167, 23)
        Me.Button136.TabIndex = 27
        Me.Button136.Tag = "C:/Program Files/Microsoft Office/Office14/MSACCESS.EXE"
        Me.Button136.Text = "Access"
        Me.Button136.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Lime
        Me.Label1.Location = New System.Drawing.Point(104, 347)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Office 2010 Pro Plus"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Lime
        Me.Label2.Location = New System.Drawing.Point(138, 596)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Browsers"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(77, 32)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(167, 23)
        Me.Button4.TabIndex = 30
        Me.Button4.Tag = "C:\Games\Apache Air Assault\launcher.exe"
        Me.Button4.Text = "Apache Air Assault"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(77, 90)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(167, 23)
        Me.Button6.TabIndex = 31
        Me.Button6.Tag = "C:\Games\Battlezone 2\bzone.exe"
        Me.Button6.Text = "Battlezone 2"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(250, 90)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(167, 23)
        Me.Button8.TabIndex = 32
        Me.Button8.Tag = "C:/Games/Homeworld2/Bin/Release/Homeworld2.exe"
        Me.Button8.Text = "Homeworld 2"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(77, 148)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(167, 23)
        Me.Button9.TabIndex = 33
        Me.Button9.Tag = "C:\Games\Dark Reign 2\dr2.exe"
        Me.Button9.Text = "Dark Reign 2"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(77, 206)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(167, 23)
        Me.Button11.TabIndex = 34
        Me.Button11.Tag = "C:\Games\Empire Earth II\EE2X.exe"
        Me.Button11.Text = "Empire Earth 2"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(77, 264)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(167, 23)
        Me.Button12.TabIndex = 35
        Me.Button12.Tag = "C:/Games/Ghost Recon/GhostRecon.exe"
        Me.Button12.Text = "Ghost Recon"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(250, 177)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(167, 23)
        Me.Button13.TabIndex = 36
        Me.Button13.Tag = "C:\Games\LeagueOfLegends\League of Legends\lol.launcher.exe"
        Me.Button13.Text = "League Of Legends"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(423, 119)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(167, 23)
        Me.Button17.TabIndex = 37
        Me.Button17.Tag = "C:\Games\Saints Row The Third\game_launcher.exe"
        Me.Button17.Text = "Saints Row The Third"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(423, 177)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(167, 23)
        Me.Button19.TabIndex = 38
        Me.Button19.Tag = "C:\Games\Star Wars Battlefront II\GameData\battlefrontII.exe"
        Me.Button19.Text = "Star Wars Battlefront II"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(422, 206)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(167, 23)
        Me.Button22.TabIndex = 39
        Me.Button22.Tag = "C:\Games\The Lord of the Rings - Conquest\Conquest.exe"
        Me.Button22.Text = "Lord Of The Rings - Conquest"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(1366, 768)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button136)
        Me.Controls.Add(Me.Button135)
        Me.Controls.Add(Me.Button134)
        Me.Controls.Add(Me.Button133)
        Me.Controls.Add(Me.Button130)
        Me.Controls.Add(Me.Button128)
        Me.Controls.Add(Me.Button125)
        Me.Controls.Add(Me.Button124)
        Me.Controls.Add(Me.Button123)
        Me.Controls.Add(Me.Button122)
        Me.Controls.Add(Me.Button121)
        Me.Controls.Add(Me.Button120)
        Me.Controls.Add(Me.Button119)
        Me.Controls.Add(Me.Button118)
        Me.Controls.Add(Me.Button117)
        Me.Controls.Add(Me.Button116)
        Me.Controls.Add(Me.Button115)
        Me.Controls.Add(Me.Button112)
        Me.Controls.Add(Me.Button94)
        Me.Controls.Add(Me.Button111)
        Me.Controls.Add(Me.Button93)
        Me.Controls.Add(Me.Button114)
        Me.Controls.Add(Me.Button113)
        Me.Controls.Add(Me.Button110)
        Me.Controls.Add(Me.Button64)
        Me.Controls.Add(Me.Button92)
        Me.Controls.Add(Me.Button109)
        Me.Controls.Add(Me.Button54)
        Me.Controls.Add(Me.Button91)
        Me.Controls.Add(Me.Button108)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button90)
        Me.Controls.Add(Me.Button107)
        Me.Controls.Add(Me.Button63)
        Me.Controls.Add(Me.Button89)
        Me.Controls.Add(Me.Button106)
        Me.Controls.Add(Me.Button53)
        Me.Controls.Add(Me.Button105)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button87)
        Me.Controls.Add(Me.Button104)
        Me.Controls.Add(Me.Button62)
        Me.Controls.Add(Me.Button86)
        Me.Controls.Add(Me.Button103)
        Me.Controls.Add(Me.Button85)
        Me.Controls.Add(Me.Button102)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button84)
        Me.Controls.Add(Me.Button101)
        Me.Controls.Add(Me.Button61)
        Me.Controls.Add(Me.Button83)
        Me.Controls.Add(Me.Button100)
        Me.Controls.Add(Me.Button51)
        Me.Controls.Add(Me.Button82)
        Me.Controls.Add(Me.Button99)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button81)
        Me.Controls.Add(Me.Button98)
        Me.Controls.Add(Me.Button60)
        Me.Controls.Add(Me.Button80)
        Me.Controls.Add(Me.Button97)
        Me.Controls.Add(Me.Button50)
        Me.Controls.Add(Me.Button79)
        Me.Controls.Add(Me.Button96)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button78)
        Me.Controls.Add(Me.Button95)
        Me.Controls.Add(Me.Button59)
        Me.Controls.Add(Me.Button77)
        Me.Controls.Add(Me.Button49)
        Me.Controls.Add(Me.Button76)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button75)
        Me.Controls.Add(Me.Button58)
        Me.Controls.Add(Me.Button74)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.Button73)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button72)
        Me.Controls.Add(Me.Button71)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.Button70)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button69)
        Me.Controls.Add(Me.Button56)
        Me.Controls.Add(Me.Button68)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button66)
        Me.Controls.Add(Me.Button55)
        Me.Controls.Add(Me.Button65)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Opacity = 0.96R
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " "
        Me.TransparencyKey = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Button53 As System.Windows.Forms.Button
    Friend WithEvents Button54 As System.Windows.Forms.Button
    Friend WithEvents Button55 As System.Windows.Forms.Button
    Friend WithEvents Button56 As System.Windows.Forms.Button
    Friend WithEvents Button58 As System.Windows.Forms.Button
    Friend WithEvents Button59 As System.Windows.Forms.Button
    Friend WithEvents Button60 As System.Windows.Forms.Button
    Friend WithEvents Button61 As System.Windows.Forms.Button
    Friend WithEvents Button62 As System.Windows.Forms.Button
    Friend WithEvents Button63 As System.Windows.Forms.Button
    Friend WithEvents Button64 As System.Windows.Forms.Button
    Friend WithEvents Button65 As System.Windows.Forms.Button
    Friend WithEvents Button66 As System.Windows.Forms.Button
    Friend WithEvents Button68 As System.Windows.Forms.Button
    Friend WithEvents Button69 As System.Windows.Forms.Button
    Friend WithEvents Button70 As System.Windows.Forms.Button
    Friend WithEvents Button71 As System.Windows.Forms.Button
    Friend WithEvents Button72 As System.Windows.Forms.Button
    Friend WithEvents Button73 As System.Windows.Forms.Button
    Friend WithEvents Button74 As System.Windows.Forms.Button
    Friend WithEvents Button75 As System.Windows.Forms.Button
    Friend WithEvents Button76 As System.Windows.Forms.Button
    Friend WithEvents Button77 As System.Windows.Forms.Button
    Friend WithEvents Button78 As System.Windows.Forms.Button
    Friend WithEvents Button79 As System.Windows.Forms.Button
    Friend WithEvents Button80 As System.Windows.Forms.Button
    Friend WithEvents Button81 As System.Windows.Forms.Button
    Friend WithEvents Button82 As System.Windows.Forms.Button
    Friend WithEvents Button83 As System.Windows.Forms.Button
    Friend WithEvents Button84 As System.Windows.Forms.Button
    Friend WithEvents Button85 As System.Windows.Forms.Button
    Friend WithEvents Button86 As System.Windows.Forms.Button
    Friend WithEvents Button87 As System.Windows.Forms.Button
    Friend WithEvents Button89 As System.Windows.Forms.Button
    Friend WithEvents Button90 As System.Windows.Forms.Button
    Friend WithEvents Button91 As System.Windows.Forms.Button
    Friend WithEvents Button92 As System.Windows.Forms.Button
    Friend WithEvents Button93 As System.Windows.Forms.Button
    Friend WithEvents Button94 As System.Windows.Forms.Button
    Friend WithEvents Button95 As System.Windows.Forms.Button
    Friend WithEvents Button96 As System.Windows.Forms.Button
    Friend WithEvents Button97 As System.Windows.Forms.Button
    Friend WithEvents Button98 As System.Windows.Forms.Button
    Friend WithEvents Button99 As System.Windows.Forms.Button
    Friend WithEvents Button100 As System.Windows.Forms.Button
    Friend WithEvents Button101 As System.Windows.Forms.Button
    Friend WithEvents Button102 As System.Windows.Forms.Button
    Friend WithEvents Button103 As System.Windows.Forms.Button
    Friend WithEvents Button104 As System.Windows.Forms.Button
    Friend WithEvents Button105 As System.Windows.Forms.Button
    Friend WithEvents Button106 As System.Windows.Forms.Button
    Friend WithEvents Button107 As System.Windows.Forms.Button
    Friend WithEvents Button108 As System.Windows.Forms.Button
    Friend WithEvents Button109 As System.Windows.Forms.Button
    Friend WithEvents Button110 As System.Windows.Forms.Button
    Friend WithEvents Button111 As System.Windows.Forms.Button
    Friend WithEvents Button112 As System.Windows.Forms.Button
    Friend WithEvents Button113 As System.Windows.Forms.Button
    Friend WithEvents Button114 As System.Windows.Forms.Button
    Friend WithEvents Button115 As System.Windows.Forms.Button
    Friend WithEvents Button116 As System.Windows.Forms.Button
    Friend WithEvents Button117 As System.Windows.Forms.Button
    Friend WithEvents Button118 As System.Windows.Forms.Button
    Friend WithEvents Button119 As System.Windows.Forms.Button
    Friend WithEvents Button120 As System.Windows.Forms.Button
    Friend WithEvents Button121 As System.Windows.Forms.Button
    Friend WithEvents Button122 As System.Windows.Forms.Button
    Friend WithEvents Button123 As System.Windows.Forms.Button
    Friend WithEvents Button124 As System.Windows.Forms.Button
    Friend WithEvents Button125 As System.Windows.Forms.Button
    Friend WithEvents Button128 As System.Windows.Forms.Button
    Friend WithEvents Button130 As System.Windows.Forms.Button
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape5 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Button133 As System.Windows.Forms.Button
    Friend WithEvents Button134 As System.Windows.Forms.Button
    Friend WithEvents Button135 As System.Windows.Forms.Button
    Friend WithEvents Button136 As System.Windows.Forms.Button
    Friend WithEvents RectangleShape2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button

End Class
