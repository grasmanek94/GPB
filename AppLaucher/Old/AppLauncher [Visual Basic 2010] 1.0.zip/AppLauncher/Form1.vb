﻿Public Class Form1
    'Shell(Button.Tag, AppWinStyle.NormalFocus)
    'Application.Exit()
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Application.Exit()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Shell("C:/Games/OpenTTD/openttd.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Shell("C:/Games/Age Of Empires 2/age2_x1.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Shell("C:/Games/Aliens vs. Predator 2/avp2.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        Shell("C:/Games/Atomic Bomberman/bm95Win7.bat", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        Shell("C:/Games/Counter-Strike Source/hl2.exe -game cstrike -nojoy", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        Shell("C:/Games/Dune 2000/DUNE2000.EXE", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        Shell("C:/Games/Faces of War/facesofwar.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        Shell("C:/Games/Far Cry 2/bin/FarCry2.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Shell("C:/Games/Ghost Recon/GhostRecon.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        Shell("C:/Games/Grand Theft Auto Vice City/gta-vc.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button12_Click(sender As System.Object, e As System.EventArgs) Handles Button12.Click
        Shell("C:/Games/Grand Theft Auto Vice City/vc-mp.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button13_Click(sender As System.Object, e As System.EventArgs) Handles Button13.Click
        Shell("C:/Games/Grid/GRID.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button14_Click(sender As System.Object, e As System.EventArgs) Handles Button14.Click
        Shell("C:/Games/GTA San Andreas/gta_sa.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button15_Click(sender As System.Object, e As System.EventArgs) Handles Button15.Click
        Shell("C:/Games/GTA San Andreas/samp.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button16_Click(sender As System.Object, e As System.EventArgs) Handles Button16.Click
        Shell("C:/Games/Hacker Evolution/Hacker Evolution Duality.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button17_Click(sender As System.Object, e As System.EventArgs) Handles Button17.Click
        Shell("C:/Games/Hitman Blood Money/HitmanBloodMoney.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button18_Click(sender As System.Object, e As System.EventArgs) Handles Button18.Click
        Shell("C:/Games/Homeworld2/Bin/Release/Homeworld2.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button19_Click(sender As System.Object, e As System.EventArgs) Handles Button19.Click
        Shell("C:/Games/Homeworld2/Bin/Release/StartPirate.bat", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button20_Click(sender As System.Object, e As System.EventArgs) Handles Button20.Click
        Shell("C:/Games/Joint Operations Typhoon Rising/Jointops.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button21_Click(sender As System.Object, e As System.EventArgs) Handles Button21.Click
        Shell("C:/Games/Killing Floor/StartKillingFloor.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button22_Click(sender As System.Object, e As System.EventArgs) Handles Button22.Click
        Shell("C:/Games/Minecraft/crafty.bat", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button23_Click(sender As System.Object, e As System.EventArgs) Handles Button23.Click
        Shell("C:/Games/Minecraft/MinecraftSP.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button24_Click(sender As System.Object, e As System.EventArgs) Handles Button24.Click
        Shell("C:/Games/Need for Speed The Run Limited Edition/Need For Speed The Run.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button25_Click(sender As System.Object, e As System.EventArgs) Handles Button25.Click
        Shell("C:/Games/Need for Speed Undercover/nfs.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button26_Click(sender As System.Object, e As System.EventArgs) Handles Button26.Click
        Shell("C:/Games/Need for Speed Underground 2/SPEED2.EXE", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button27_Click(sender As System.Object, e As System.EventArgs) Handles Button27.Click
        Shell("C:/Games/Red Alert 3/RA3.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button28_Click(sender As System.Object, e As System.EventArgs) Handles Button28.Click
        Shell("C:/Games/Red Alert 3/Data/WorldBuilder.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button29_Click(sender As System.Object, e As System.EventArgs) Handles Button29.Click
        Shell("C:/Games/S.W.A.T. 4/ContentExpansion/System/Swat4X.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button30_Click(sender As System.Object, e As System.EventArgs) Handles Button30.Click
        Shell("C:/Games/Sniper Ghost Warrior/Sniper_x86.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button31_Click(sender As System.Object, e As System.EventArgs) Handles Button31.Click
        Shell("C:/Games/Trackmania United Forever/TmForever.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button32_Click(sender As System.Object, e As System.EventArgs) Handles Button32.Click
        Shell("C:/Games/Unreal Tournament/System/UnrealTournament.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button33_Click(sender As System.Object, e As System.EventArgs) Handles Button33.Click
        Shell("C:/Programs/Steam/SteamApps/common/sniper ghost warrior/Sniper_x86.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button34_Click(sender As System.Object, e As System.EventArgs) Handles Button34.Click
        Shell("C:/Programs/MTA San Andreas/Multi Theft Auto.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button117_Click(sender As System.Object, e As System.EventArgs) Handles Button117.Click
        Shell("C:/Programs/7-Zip/7zFM.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button116_Click(sender As System.Object, e As System.EventArgs) Handles Button116.Click
        Shell("C:/Programs/Adobe/Adobe Premiere Pro CS5/Adobe Premiere Pro.exe", AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button115_Click(sender As System.Object, e As System.EventArgs) Handles Button115.Click
        Shell(Button115.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button112_Click(sender As System.Object, e As System.EventArgs) Handles Button112.Click
        Shell(Button112.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button111_Click(sender As System.Object, e As System.EventArgs) Handles Button111.Click
        Shell(Button111.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button110_Click(sender As System.Object, e As System.EventArgs) Handles Button110.Click
        Shell(Button110.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button113_Click(sender As System.Object, e As System.EventArgs) Handles Button113.Click
        Shell(Button113.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button114_Click(sender As System.Object, e As System.EventArgs) Handles Button114.Click
        Shell(Button114.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button35_Click(sender As System.Object, e As System.EventArgs) Handles Button35.Click
        Shell(Button35.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button36_Click(sender As System.Object, e As System.EventArgs) Handles Button36.Click
        Shell(Button36.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button37_Click(sender As System.Object, e As System.EventArgs) Handles Button37.Click
        Shell(Button37.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button38_Click(sender As System.Object, e As System.EventArgs) Handles Button38.Click
        Shell(Button38.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button39_Click(sender As System.Object, e As System.EventArgs) Handles Button39.Click
        Shell(Button39.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button40_Click(sender As System.Object, e As System.EventArgs) Handles Button40.Click
        Shell(Button40.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button41_Click(sender As System.Object, e As System.EventArgs) Handles Button41.Click
        Shell(Button41.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button42_Click(sender As System.Object, e As System.EventArgs) Handles Button42.Click
        Shell(Button42.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button43_Click(sender As System.Object, e As System.EventArgs) Handles Button43.Click
        Shell(Button43.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button44_Click(sender As System.Object, e As System.EventArgs) Handles Button44.Click
        Shell(Button44.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button65_Click(sender As System.Object, e As System.EventArgs) Handles Button65.Click
        Shell(Button65.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button68_Click(sender As System.Object, e As System.EventArgs) Handles Button68.Click
        Shell(Button68.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button71_Click(sender As System.Object, e As System.EventArgs) Handles Button71.Click
        Shell(Button71.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button74_Click(sender As System.Object, e As System.EventArgs) Handles Button74.Click
        Shell(Button74.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button77_Click(sender As System.Object, e As System.EventArgs) Handles Button77.Click
        Shell(Button77.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button80_Click(sender As System.Object, e As System.EventArgs) Handles Button80.Click
        Shell(Button80.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button83_Click(sender As System.Object, e As System.EventArgs) Handles Button83.Click
        Shell(Button83.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button86_Click(sender As System.Object, e As System.EventArgs) Handles Button86.Click
        Shell(Button86.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button89_Click(sender As System.Object, e As System.EventArgs) Handles Button89.Click
        Shell(Button89.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button92_Click(sender As System.Object, e As System.EventArgs) Handles Button92.Click
        Shell(Button92.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button95_Click(sender As System.Object, e As System.EventArgs) Handles Button95.Click
        Shell(Button95.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button98_Click(sender As System.Object, e As System.EventArgs) Handles Button98.Click
        Shell(Button98.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button101_Click(sender As System.Object, e As System.EventArgs) Handles Button101.Click
        Shell(Button101.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button104_Click(sender As System.Object, e As System.EventArgs) Handles Button104.Click
        Shell(Button104.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button107_Click(sender As System.Object, e As System.EventArgs) Handles Button107.Click
        Shell(Button107.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button45_Click(sender As System.Object, e As System.EventArgs) Handles Button45.Click
        Shell(Button45.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button46_Click(sender As System.Object, e As System.EventArgs) Handles Button46.Click
        Shell(Button46.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button47_Click(sender As System.Object, e As System.EventArgs) Handles Button47.Click
        Shell(Button47.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button48_Click(sender As System.Object, e As System.EventArgs) Handles Button48.Click
        Shell(Button48.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button49_Click(sender As System.Object, e As System.EventArgs) Handles Button49.Click
        Shell(Button49.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button50_Click(sender As System.Object, e As System.EventArgs) Handles Button50.Click
        Shell(Button50.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button51_Click(sender As System.Object, e As System.EventArgs) Handles Button51.Click
        Shell(Button51.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button52_Click(sender As System.Object, e As System.EventArgs) Handles Button52.Click
        Shell(Button52.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button53_Click(sender As System.Object, e As System.EventArgs) Handles Button53.Click
        Shell(Button53.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button54_Click(sender As System.Object, e As System.EventArgs) Handles Button54.Click
        Shell(Button54.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button66_Click(sender As System.Object, e As System.EventArgs) Handles Button66.Click
        Shell(Button66.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button69_Click(sender As System.Object, e As System.EventArgs) Handles Button69.Click
        Shell(Button69.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button72_Click(sender As System.Object, e As System.EventArgs) Handles Button72.Click
        Shell(Button72.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button75_Click(sender As System.Object, e As System.EventArgs) Handles Button75.Click
        Shell(Button75.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button78_Click(sender As System.Object, e As System.EventArgs) Handles Button78.Click
        Shell(Button78.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button81_Click(sender As System.Object, e As System.EventArgs) Handles Button81.Click
        Shell(Button81.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button84_Click(sender As System.Object, e As System.EventArgs) Handles Button84.Click
        Shell(Button84.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button87_Click(sender As System.Object, e As System.EventArgs) Handles Button87.Click
        Shell(Button87.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button90_Click(sender As System.Object, e As System.EventArgs) Handles Button90.Click
        Shell(Button90.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button93_Click(sender As System.Object, e As System.EventArgs) Handles Button93.Click
        Shell(Button93.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button96_Click(sender As System.Object, e As System.EventArgs) Handles Button96.Click
        Shell(Button96.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button99_Click(sender As System.Object, e As System.EventArgs) Handles Button99.Click
        Shell(Button99.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button102_Click(sender As System.Object, e As System.EventArgs) Handles Button102.Click
        Shell(Button102.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button105_Click(sender As System.Object, e As System.EventArgs) Handles Button105.Click
        Shell(Button105.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button108_Click(sender As System.Object, e As System.EventArgs) Handles Button108.Click
        Shell(Button108.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button55_Click(sender As System.Object, e As System.EventArgs) Handles Button55.Click
        Shell(Button55.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button56_Click(sender As System.Object, e As System.EventArgs) Handles Button56.Click
        Shell(Button56.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button57_Click(sender As System.Object, e As System.EventArgs) Handles Button57.Click
        Shell(Button57.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button58_Click(sender As System.Object, e As System.EventArgs) Handles Button58.Click
        Shell(Button58.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button59_Click(sender As System.Object, e As System.EventArgs) Handles Button59.Click
        Shell(Button59.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button60_Click(sender As System.Object, e As System.EventArgs) Handles Button60.Click
        Shell(Button60.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button61_Click(sender As System.Object, e As System.EventArgs) Handles Button61.Click
        Shell(Button61.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button62_Click(sender As System.Object, e As System.EventArgs) Handles Button62.Click
        Shell(Button62.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button63_Click(sender As System.Object, e As System.EventArgs) Handles Button63.Click
        Shell(Button63.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button64_Click(sender As System.Object, e As System.EventArgs) Handles Button64.Click
        Shell(Button64.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button67_Click(sender As System.Object, e As System.EventArgs) Handles Button67.Click
        Shell(Button67.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button70_Click(sender As System.Object, e As System.EventArgs) Handles Button70.Click
        Shell(Button70.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button73_Click(sender As System.Object, e As System.EventArgs) Handles Button73.Click
        Shell(Button73.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button76_Click(sender As System.Object, e As System.EventArgs) Handles Button76.Click
        Shell(Button76.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button79_Click(sender As System.Object, e As System.EventArgs) Handles Button79.Click
        Shell(Button79.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button82_Click(sender As System.Object, e As System.EventArgs) Handles Button82.Click
        Shell(Button82.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button91_Click(sender As System.Object, e As System.EventArgs) Handles Button91.Click
        Shell(Button91.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button85_Click(sender As System.Object, e As System.EventArgs) Handles Button85.Click
        Shell(Button85.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button88_Click(sender As System.Object, e As System.EventArgs) Handles Button88.Click
        Shell(Button88.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button94_Click(sender As System.Object, e As System.EventArgs) Handles Button94.Click
        Shell(Button94.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button97_Click(sender As System.Object, e As System.EventArgs) Handles Button97.Click
        Shell(Button97.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button100_Click(sender As System.Object, e As System.EventArgs) Handles Button100.Click
        Shell(Button100.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button103_Click(sender As System.Object, e As System.EventArgs) Handles Button103.Click
        Shell(Button103.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button106_Click(sender As System.Object, e As System.EventArgs) Handles Button106.Click
        Shell(Button106.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button109_Click(sender As System.Object, e As System.EventArgs) Handles Button109.Click
        Shell(Button109.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button118_Click(sender As System.Object, e As System.EventArgs) Handles Button118.Click
        Shell(Button118.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button119_Click(sender As System.Object, e As System.EventArgs) Handles Button119.Click
        Shell(Button119.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button120_Click(sender As System.Object, e As System.EventArgs) Handles Button120.Click
        Shell(Button120.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button121_Click(sender As System.Object, e As System.EventArgs) Handles Button121.Click
        Shell(Button121.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button124_Click(sender As System.Object, e As System.EventArgs) Handles Button124.Click
        Shell(Button124.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button123_Click(sender As System.Object, e As System.EventArgs) Handles Button123.Click
        Shell(Button123.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button122_Click(sender As System.Object, e As System.EventArgs) Handles Button122.Click
        Shell(Button122.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button127_Click(sender As System.Object, e As System.EventArgs) Handles Button127.Click
        Shell(Button127.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button126_Click(sender As System.Object, e As System.EventArgs) Handles Button126.Click
        Shell(Button126.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button129_Click(sender As System.Object, e As System.EventArgs) Handles Button129.Click
        Shell(Button129.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button125_Click(sender As System.Object, e As System.EventArgs) Handles Button125.Click
        Shell(Button125.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button128_Click(sender As System.Object, e As System.EventArgs) Handles Button128.Click
        Shell(Button128.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button130_Click(sender As System.Object, e As System.EventArgs) Handles Button130.Click
        Shell(Button130.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button131_Click(sender As System.Object, e As System.EventArgs) Handles Button131.Click
        Shell(Button131.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button132_Click(sender As System.Object, e As System.EventArgs) Handles Button132.Click
        Shell(Button132.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button133_Click(sender As System.Object, e As System.EventArgs) Handles Button133.Click
        Shell(Button133.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button134_Click(sender As System.Object, e As System.EventArgs) Handles Button134.Click
        Shell(Button134.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button135_Click(sender As System.Object, e As System.EventArgs) Handles Button135.Click
        Shell(Button135.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub

    Private Sub Button136_Click(sender As System.Object, e As System.EventArgs) Handles Button136.Click
        Shell(Button136.Tag, AppWinStyle.NormalFocus)
        Application.Exit()
    End Sub
End Class
