// MAIN STUFF /////////////////////////////
///////////////////////////////////////////
///////////////////////////////////////////

#include "SAMP_VER.h"

#define RAKSAMP_VERSION "v0.7-0.3x-R1-2"
#define NETCODE_OPENCONNLULZ 0x00001B39 //kye rlz! :D
#define NETGAME_VERSION 0x22E7

#define AUTHOR "jlfm, bartekdvd"

#define REJECT_REASON_BAD_VERSION	1
#define REJECT_REASON_BAD_NICKNAME	2
#define REJECT_REASON_BAD_MOD		3
#define REJECT_REASON_BAD_PLAYERID	4

#define MAX_PLAYERS 1000 //due to limit in samp's servers browser (samp.exe)
#define MAX_VEHICLES 2000
#define MAX_SCRIPTS 32

typedef signed char			int8_t;
typedef unsigned char		uint8_t;
typedef signed short		int16_t;
typedef unsigned short		uint16_t;
typedef signed int			int32_t;
typedef unsigned int		uint32_t;
typedef signed long long	int64_t;
typedef unsigned long long	uint64_t;
#define snprintf	_snprintf
#define vsnprintf	_vsnprintf
#define isfinite	_finite

#define EVENT_TYPE_PAINTJOB			1
#define EVENT_TYPE_CARCOMPONENT		2
#define EVENT_TYPE_CARCOLOR			3
#define EVENT_ENTEREXIT_MODSHOP		4

#define KEY_UP                      -128
#define KEY_DOWN                    128
#define KEY_LEFT                    -128
#define KEY_RIGHT                   128
#define KEY_ACTION                  1
#define KEY_CROUCH                  2
#define KEY_FIRE                    4
#define KEY_SPRINT                  8
#define KEY_SECONDARY_ATTACK        16
#define KEY_JUMP                    32
#define KEY_LOOK_RIGHT              64
#define KEY_HANDBRAKE               128
#define KEY_LOOK_LEFT               256
#define KEY_SUBMISSION              512
#define KEY_LOOK_BEHIND             512
#define KEY_WALK                    1024
#define KEY_ANALOG_UP               2048
#define KEY_ANALOG_DOWN             4096
#define KEY_ANALOG_LEFT             8192
#define KEY_ANALOG_RIGHT            16384
