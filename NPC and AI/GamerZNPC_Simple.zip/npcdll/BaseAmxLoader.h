#pragma once

#include <boost/date_time.hpp>
#include <main.h>
#include <Pointer.h>
#include <Windows.h>

boost::posix_time::ptime * time_t_epoch;

unsigned long long  GetCurrentEpochMicroSec()
{
	boost::posix_time::ptime now = boost::posix_time::microsec_clock::local_time();
	boost::posix_time::time_duration diff = now - (*time_t_epoch);
	return diff.total_microseconds();
}

void OnLoad();
void OnTick();

std::string string_format(const std::string fmt, ...) 
{
	int size = 512;
	std::string str;
	va_list ap;
	while (1) {
		str.resize(size);
		va_start(ap, fmt);
		int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
		va_end(ap);
		if (n > -1 && n < size) {
			str.resize(n);
			return str;
		}
		if (n > -1)
			size = n + 1;
		else
			size *= 2;
	}
	return str;
}

void OnNPCConnect(unsigned short Npc_PlayerId);
void OnRecordingPlaybackEnd();
void OnNPCEnterVehicle(unsigned short vehicleid);
void OnNPCExitVehicle();

bool AmIConnected = false;
unsigned short ServerPort = 0;

#include <boost/lexical_cast.hpp>

void InitializeBeforRealJob()
{
	std::string command_line_parameters(GetCommandLine());
	size_t start = command_line_parameters.find("-p")+3;
	size_t end = command_line_parameters.find(" ",start);
	ServerPort = boost::lexical_cast<unsigned short>(command_line_parameters.substr(start,end-start));
	int
		num,
		idx;
	// Operate on the raw AMX file, don't use the amx_ functions to avoid issues
	// with the fact that we've not actually finished initialisation yet.  Based
	// VERY heavilly on code from "amx.c" in the PAWN runtime library.
	AMX_HEADER *
		hdr = (AMX_HEADER *)thisscript->base;
	AMX_FUNCSTUB *
		func;
	num = NUMENTRIES(hdr, natives, libraries);
	std::string display;
	std::vector<AMX_NATIVE_INFO> ninfo;
	for (idx = 0; idx != num; ++idx)
	{
		func = GETENTRY(hdr, natives, idx);
		if(func->address)
		{
			tagAMX_NATIVE_INFO temp;
			temp.name = (const char*)GETENTRYNAME(hdr, func);
			temp.func = (AMX_NATIVE)func->address;
			ninfo.push_back(temp);
		}
	}
	tagAMX_NATIVE_INFO temp;
	temp.name = 0;
	temp.func = 0;
	ninfo.push_back(temp);
	fake_register(&ninfo[0],-1);
}
static cell AMX_NATIVE_CALL GAMER_NPC_PROCESS_CALLBACK( AMX* amx, cell* params )
{
	switch(params[1])
	{
		case 1:
			InitializeBeforRealJob();
			OnNPCConnect(params[2]);
			AmIConnected = true;
			OnLoad();
			return 1;
		case 2:
			OnRecordingPlaybackEnd();
			return 1;
		case 3:
			OnNPCEnterVehicle(params[2]);
			return 1;
		case 4:
			OnNPCExitVehicle();
			return 1;
	}
	return 0;
}

AMX_NATIVE_INFO FunctionList[] =
{
	{"GAMER_NPC_PROCESS_CALLBACK", GAMER_NPC_PROCESS_CALLBACK},
	{0,0}
};

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad(AMX * amx)
{
	thisscript = amx; 
	return amx_Register(amx,FunctionList,-1);
}
PLUGIN_EXPORT int PLUGIN_CALL AmxUnload(AMX * amx){return 0;}

PLUGIN_EXPORT bool PLUGIN_CALL
	Load(void ** ppData)
{
	time_t_epoch = new boost::posix_time::ptime(boost::gregorian::date(1970,1,1));
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	logprintf = (logprintf_t)ppData[PLUGIN_DATA_LOGPRINTF];
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload(){}
PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() {return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;}

auto thisnpc = new Pointer<NPCDataFoot*>(0x454168);
auto thisnpcvehicle = new Pointer<NPCDataVehicle*>(0x44D3C0);

inline NPCDataFoot* GetMe()
{
	return (*thisnpc)();
}
inline NPCDataVehicle* GetVehicle()
{
	return (*thisnpcvehicle)();
}

inline unsigned short GetPort()
{
	return ServerPort;
}

PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick() 
{
	if(!AmIConnected)
		return;
	OnTick();
}
