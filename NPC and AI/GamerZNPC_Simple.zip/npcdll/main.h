#pragma once
#include <SDK/plugin.h>
#include <sampgdk/core.h>
#include <sampgdk/a_npc.h>

typedef
	void (* logprintf_t)(char *, ...);

logprintf_t
	logprintf;

extern void *
	pAMXFunctions;

#define USENAMETABLE(hdr) \
	((hdr)->defsize==sizeof(AMX_FUNCSTUBNT))

#define NUMENTRIES(hdr,field,nextfield) \
	(unsigned)(((hdr)->nextfield - (hdr)->field) / (hdr)->defsize)

#define GETENTRY(hdr,table,index) \
	(AMX_FUNCSTUB *)((unsigned char*)(hdr) + (unsigned)(hdr)->table + (unsigned)index*(hdr)->defsize)

#define GETENTRYNAME(hdr,entry) \
	(USENAMETABLE(hdr) ? \
	(char *)((unsigned char*)(hdr) + (unsigned)((AMX_FUNCSTUBNT*)(entry))->nameofs) : \
	((AMX_FUNCSTUB*)(entry))->name)

AMX* thisscript = NULL;