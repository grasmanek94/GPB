//----------------------------------------------------------
//
//   SA:MP Multiplayer Modification For GTA:SA
//   Copyright 2004-2006 SA:MP Team
//
//----------------------------------------------------------

#include "plugincommon.h"
#include "amx/amx.h"

// Remove the "const" from the other definition.
//typedef cell (NEW_AMX_NATIVE_CALL *AMX_NATIVE)(struct tagAMX *amx, cell *params);
//#define AMX_NATIVE_CALL NEW_AMX_NATIVE_CALL
