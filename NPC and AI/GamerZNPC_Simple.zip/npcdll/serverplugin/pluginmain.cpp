#include <iostream>
#include <unordered_set>
#include <unordered_map>
#include <array>
#include <boost/lexical_cast.hpp>
#include <sampgdk/core.hpp>
#include <sampgdk/a_samp.h>
#include <sampgdk/plugin.h>
#include <../InterProcess.h>

#if 1
#define dbg(); std::cout << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
#else
#define dbg();
#endif

enum NPCUpdateType
{
	NPCU_NewConnectedNPC,
	NCPU_DisconnectedNPC,
	NPCU_FinishedMoving
};

void OnNPCUpdate(unsigned short npc_playerid, NPCUpdateType type, int additionaldata=0);

std::string string_format(const std::string fmt, ...) 
{
	int size = 512;
	std::string str;
	va_list ap;
	while (1) {
		str.resize(size);
		va_start(ap, fmt);
		int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
		va_end(ap);
		if (n > -1 && n < size) {
			str.resize(n);
			return str;
		}
		if (n > -1)
			size = n + 1;
		else
			size *= 2;
	}
	return str;
}

static ThisPlugin serverplugin;

#pragma comment(lib,"./sampgdk3_s.lib")

#define MAX_PLAYERS (1024)

std::string NPCSharedMemoryName		("SAMP_NPC_SHAREDMEM_GNPC_");
std::string ServerSharedMemoryName	("SAMP_SVR_SHAREDMEM_GNPC_");
ExchangeData DataTransmision;

message_queue * ServerMsgQueue;

class CNPCManager
{
	std::array<message_queue*,MAX_PLAYERS> NPCID_To_MsgQueue;
public:
	CNPCManager()
	{
		for(auto &i: NPCID_To_MsgQueue)
			i = NULL;
	}
	void OnNPCConnect(unsigned short npc_playerid)
	{
		dbg();
		try
		{
			NPCID_To_MsgQueue[npc_playerid] = new message_queue(open_or_create              
				,string_format("%s%04x",NPCSharedMemoryName.c_str(),npc_playerid).c_str()   
				,QueueMaxSize                  
				,sizeof(ExchangeData)               
			);	
			
			OnNPCUpdate(npc_playerid,NPCU_NewConnectedNPC);
		}
		catch(interprocess_exception &ex)
		{
			std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
		}
	}
	void OnNPCDisconnect(unsigned short npc_playerid)
	{
		if(NPCID_To_MsgQueue[npc_playerid])
		{
			message_queue::remove(string_format("%s%04x",NPCSharedMemoryName.c_str(),npc_playerid).c_str());
			NPCID_To_MsgQueue[npc_playerid] = NULL;
			OnNPCUpdate(npc_playerid,NCPU_DisconnectedNPC);
		}
	}
	int TryUpdate(unsigned short npc_playerid)
	{
		try
		{
			if(!NPCID_To_MsgQueue[npc_playerid])
				return 2;
			return (NPCID_To_MsgQueue[npc_playerid]->try_send(&DataTransmision,sizeof(ExchangeData),1) == true);
		}
		catch(interprocess_exception &ex)
		{
			std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
			return 3;
		}
	}
} NPCManager;


PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerDisconnect(int playerid, int reason)
{
	NPCManager.OnNPCDisconnect(playerid);
	return true;
}

#include <Windows.h>
PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{	
	//MessageBox(NULL,string_format("Pos(%d):Quat(%d):NPCDataFoot(%d):NPCDataVehicle(%d):ExchangeData(%d)",sizeof(Pos),sizeof(Quat),sizeof(NPCDataFoot),sizeof(NPCDataVehicle),sizeof(ExchangeData)).c_str(),"Reported sizes Server",0);
	return serverplugin.Load(ppData) >= 0;
}

static cell AMX_NATIVE_CALL GamerNPC_Pos( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetPosition;
	DataTransmision.InCarData.Position.X = amx_ctof(params[2]);
	DataTransmision.InCarData.Position.Y = amx_ctof(params[3]);
	DataTransmision.InCarData.Position.Z = amx_ctof(params[4]);
	DataTransmision.OnFootData.Position.X = amx_ctof(params[2]);
	DataTransmision.OnFootData.Position.Y = amx_ctof(params[3]);
	DataTransmision.OnFootData.Position.Z = amx_ctof(params[4]);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_Quat( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetRotation;
	DataTransmision.InCarData.Rotation.W = amx_ctof(params[2]);
	DataTransmision.InCarData.Rotation.X = amx_ctof(params[3]);
	DataTransmision.InCarData.Rotation.Y = amx_ctof(params[4]);
	DataTransmision.InCarData.Rotation.Z = amx_ctof(params[5]);
	DataTransmision.OnFootData.Rotation.W = amx_ctof(params[2]);
	DataTransmision.OnFootData.Rotation.X = amx_ctof(params[3]);
	DataTransmision.OnFootData.Rotation.Y = amx_ctof(params[4]);
	DataTransmision.OnFootData.Rotation.Z = amx_ctof(params[5]);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_Animation( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetAnimation;
	DataTransmision.OnFootData.AnimationIndex = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_LRAnalog( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetLRAnalog;
	DataTransmision.OnFootData.lrAnalog = params[2];
	DataTransmision.InCarData.lrAnalog = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_UDAnalog( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetUDAnalog;
	DataTransmision.OnFootData.udAnalog = params[2];
	DataTransmision.InCarData.udAnalog = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_MyHealth( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetHealth;
	DataTransmision.OnFootData.Health = static_cast<Byte>((int)floor(amx_ctof(params[2])) % 0xFF);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_Armour( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetArmour;
	DataTransmision.OnFootData.Armour = static_cast<Byte>((int)floor(amx_ctof(params[2])) % 0xFF);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_Weapon( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetWeapon;
	DataTransmision.OnFootData.CurrWeapon = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_SpecialAction( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetAction;
	DataTransmision.OnFootData.SpecialAction = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_Velocity( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetVelocity;
	DataTransmision.OnFootData.Velocity.X = amx_ctof(params[2]);
	DataTransmision.OnFootData.Velocity.Y = amx_ctof(params[3]);
	DataTransmision.OnFootData.Velocity.Z = amx_ctof(params[4]);
	DataTransmision.InCarData.Velocity.X = amx_ctof(params[2]);
	DataTransmision.InCarData.Velocity.Y = amx_ctof(params[3]);
	DataTransmision.InCarData.Velocity.Z = amx_ctof(params[4]);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_SurfOffset( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetSurfOffset;
	DataTransmision.OnFootData.SurfOffset.X = amx_ctof(params[2]);
	DataTransmision.OnFootData.SurfOffset.Y = amx_ctof(params[3]);
	DataTransmision.OnFootData.SurfOffset.Z = amx_ctof(params[4]);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_SurfInfo( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetSurfInfo;
	DataTransmision.OnFootData.SurfInfo = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_Keys( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetKeys;
	DataTransmision.OnFootData.Keys = params[2];
	DataTransmision.InCarData.Keys = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_CarHealth( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetCarHealth;
	DataTransmision.InCarData.CarHealth = amx_ctof(params[2]);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_CarSiren( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetSiren;
	DataTransmision.InCarData.SirenOn = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_LandingGearState( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetLandingGearState;
	DataTransmision.InCarData.LandingGearState = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_TrailerID( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetTIDOTA;
	DataTransmision.InCarData.TrailerID_or_ThrustAngle = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_ThrustAngle( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetTIDOTA;
	DataTransmision.InCarData.TrailerID_or_ThrustAngle = params[2];
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_TrainSpeed( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_SetTrainSpeed;
	DataTransmision.InCarData.TrainSpeed = amx_ctof(params[2]);
	return NPCManager.TryUpdate(params[1]);
}

static cell AMX_NATIVE_CALL GamerNPC_MoveTo( AMX* amx, cell* params )
{
	DataTransmision.CommandType = TDT_CMD_StartMove;
	DataTransmision.MoveToPos.X = amx_ctof(params[2]);
	DataTransmision.MoveToPos.Y = amx_ctof(params[3]);
	DataTransmision.MoveToPos.Z = amx_ctof(params[4]);
	DataTransmision.MoveSpeed = amx_ctof(params[5]);
	return NPCManager.TryUpdate(params[1]);
}

#define entry(name) {#name, name}
AMX_NATIVE_INFO AMXNatives[ ] =
{
	entry(GamerNPC_Pos),
	entry(GamerNPC_Quat),
	entry(GamerNPC_Animation),
	entry(GamerNPC_LRAnalog),
	entry(GamerNPC_UDAnalog),
	entry(GamerNPC_MyHealth),
	entry(GamerNPC_Armour),
	entry(GamerNPC_Weapon),
	entry(GamerNPC_SpecialAction),
	entry(GamerNPC_Velocity),
	entry(GamerNPC_SurfOffset),
	entry(GamerNPC_SurfInfo),
	entry(GamerNPC_Keys),
	entry(GamerNPC_CarHealth),
	entry(GamerNPC_CarSiren),
	entry(GamerNPC_LandingGearState),
	entry(GamerNPC_TrailerID),
	entry(GamerNPC_ThrustAngle),
	entry(GamerNPC_TrainSpeed),
	entry(GamerNPC_MoveTo),
	{0,                0}
};

std::unordered_map<AMX*,int> HavePublic;
PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	static int index;
	if (amx_FindPublic(amx, "OnNPCUpdate", &index) == AMX_ERR_NONE)
		HavePublic[amx] = index;
	return amx_Register( amx, AMXNatives, -1 );
}

void OnNPCUpdate(unsigned short npc_playerid, NPCUpdateType type, int additionaldata)
{
	for(auto &i: HavePublic)
	{
		amx_Push(i.first,additionaldata);
		amx_Push(i.first,type);
		amx_Push(i.first,npc_playerid);
		amx_Exec(i.first,NULL,i.second);
	}
}

PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick()
{
	static bool init = false;
	static unsigned int priority;
	static size_t sizexxx;
	if(!init)
	{
		try
		{
			ServerMsgQueue = new message_queue(open_or_create              
					,string_format("%s%04x",ServerSharedMemoryName.c_str(),GetServerVarAsInt("port")).c_str()
					,1024 * QueueMaxSize                  
					,sizeof(ExchangeData)               
				);	
		}
		catch(interprocess_exception &ex)
		{
			std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
		}
		init = true;
	}
	if(ServerMsgQueue)
	{
		try
		{
			if(ServerMsgQueue->try_receive(&DataTransmision,sizeof(ExchangeData),sizexxx,priority))
			{
				switch(DataTransmision.CommandType)
				{
				case TDT_NewNPC:
					{
						NPCManager.OnNPCConnect(DataTransmision.NPCPlayerID);
						break;
					}
				case TDT_SIGNAL_MOVE_COMPLETE:
					{
						OnNPCUpdate(DataTransmision.NPCPlayerID,NPCU_FinishedMoving);
						break;
					}
				default:
					{
						std::cout << "UNKNOWN RECEIVED DATA!!!" << std::endl;
						break;
					}
				}
			}
		}
		catch(interprocess_exception &ex)
		{
			std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
		}
	}
}

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	message_queue::remove(string_format("%s%04x",ServerSharedMemoryName.c_str(),GetServerVarAsInt("port")).c_str());
	serverplugin.Unload();
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	HavePublic.erase(amx);
	return AMX_ERR_NONE;
}