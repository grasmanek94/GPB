
#include <iostream>
#include <Pointer.h>
#include <main.h>
#include <GTAstructs.h>
#include <BaseAmxLoader.h>

NPCDataFoot FootData;
NPCDataVehicle VehicleData;

#include <InterProcess.h>

ExchangeData DataTransmision;
class CCurrentNPC
{
	Byte PlaybackState;//none, vehicle, foot
public:
	unsigned short NPCPlayerID;
	unsigned int ProcessID;
	bool Moving;
	float LeftDist;
	float MoveSpeed;
	Pos MovePos;
	Pos Adders;
	CCurrentNPC()
		: PlaybackState(0x00), NPCPlayerID(0xFFFF), ProcessID(0xFFFFFFFF)
	{}
	void SetPlaybackState(Byte state)
	{
		static const char* recordings[] = 
		{
			"GAMER_Z_NPC_STATE_0NIL",
			"GAMER_Z_NPC_STATE_1ONE",
			"GAMER_Z_NPC_STATE_2TWO"
		};
		switch(state)
		{
		case 1:
			{
				sampgdk_StopRecordingPlayback();
				sampgdk_StartRecordingPlayback(1,recordings[1]);
				PlaybackState = 1;
				break;
			}
		case 2:
			{
				sampgdk_StopRecordingPlayback();
				sampgdk_StartRecordingPlayback(2,recordings[2]);
				PlaybackState = 2;
				break;
			}
		default:
			{
				sampgdk_StopRecordingPlayback();
				sampgdk_StartRecordingPlayback(0,recordings[0]);
				PlaybackState = 0;
				break;
			}
		}
	}
	Byte GetPlaybackState()
	{
		return PlaybackState;
	}
} CurrentNPC;

message_queue * ToServer;
message_queue * Receive;

std::string MySharedMemoryName		("SAMP_NPC_SHAREDMEM_GNPC_");
std::string ServerSharedMemoryName	("SAMP_SVR_SHAREDMEM_GNPC_");

#if 1
#define dbg(); std::cout << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
#else
#define dbg();
#endif

void OnLoad()
{
	//MessageBox(NULL,string_format("Pos(%d):Quat(%d):NPCDataFoot(%d):NPCDataVehicle(%d):ExchangeData(%d)",sizeof(Pos),sizeof(Quat),sizeof(NPCDataFoot),sizeof(NPCDataVehicle),sizeof(ExchangeData)).c_str(),"Reported sizes Client",0);
	try
	{
		ServerSharedMemoryName.append(string_format("%04x",GetPort()));
		ToServer = new message_queue(open_or_create              
			,ServerSharedMemoryName.c_str()         
			,1024*QueueMaxSize                    
			,sizeof(ExchangeData)               
		);

		DataTransmision.CommandType = TDT_NewNPC;
		DataTransmision.NPCPlayerID = CurrentNPC.NPCPlayerID;

		MySharedMemoryName.append(string_format("%04x",CurrentNPC.NPCPlayerID));

		
		Receive = new message_queue(open_or_create              
			,MySharedMemoryName.c_str()       
			,QueueMaxSize                  
			,sizeof(ExchangeData)               
		);	
		std::cout << "DATA|" << ToServer << "|" << Receive << "|" << std::endl;
		ToServer->send(&DataTransmision,sizeof(ExchangeData),1);
	}
	catch(interprocess_exception &ex)
	{
		std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
	}
}

void OnNPCConnect(unsigned short Npc_PlayerId)
{
	dbg();
	CurrentNPC.NPCPlayerID = Npc_PlayerId;
	CurrentNPC.SetPlaybackState(2);
}

void OnRecordingPlaybackEnd()
{
	CurrentNPC.SetPlaybackState(CurrentNPC.GetPlaybackState());
}

void OnNPCEnterVehicle(unsigned short vehicleid)
{
	dbg();
	CurrentNPC.SetPlaybackState(1);
}

void OnNPCExitVehicle()
{
	dbg();
	CurrentNPC.SetPlaybackState(2);
}

void OnTick()
{
	static unsigned int priority;
	static size_t sizexxx;
	static unsigned long long LastTick;
	if(Receive)
	{
		try
		{
			if(Receive->try_receive(&DataTransmision,sizeof(ExchangeData),sizexxx,priority))
			{
				dbg();
				std::cout << DataTransmision.CommandType << std::endl;
				switch(DataTransmision.CommandType)
				{
				case TDT_CMD_SetAnimation: 
					{ 
						FootData.AnimationIndex = DataTransmision.OnFootData.AnimationIndex;
						break; 
					}
				case TDT_CMD_SetPosition: 
					{ 
						std::cout << "DoSetPos" << std::endl;
						FootData.Position.X = DataTransmision.OnFootData.Position.X;
						FootData.Position.Y = DataTransmision.OnFootData.Position.Y;
						FootData.Position.Z = DataTransmision.OnFootData.Position.Z;
						VehicleData.Position.X = DataTransmision.InCarData.Position.X;
						VehicleData.Position.Y = DataTransmision.InCarData.Position.Y;
						VehicleData.Position.Z = DataTransmision.InCarData.Position.Z;
						break; 
					}
				case TDT_CMD_SetLRAnalog: 
					{ 
						VehicleData.lrAnalog = DataTransmision.InCarData.lrAnalog;
						FootData.lrAnalog = DataTransmision.OnFootData.lrAnalog;
						break; 
					}
				case TDT_CMD_SetUDAnalog: 
					{ 
						VehicleData.udAnalog = DataTransmision.InCarData.udAnalog;
						FootData.udAnalog = DataTransmision.OnFootData.udAnalog;
						break; 
					}
				case TDT_CMD_SetRotation: 
					{ 
						if(GetVehicle()->VehicleID)
						{
							VehicleData.Rotation.W = DataTransmision.InCarData.Rotation.W;
							VehicleData.Rotation.X = DataTransmision.InCarData.Rotation.X;
							VehicleData.Rotation.Y = DataTransmision.InCarData.Rotation.Y;
							VehicleData.Rotation.Z = DataTransmision.InCarData.Rotation.Z;
						}
						else
						{
							FootData.Rotation.W = DataTransmision.OnFootData.Rotation.W;
							FootData.Rotation.X = DataTransmision.OnFootData.Rotation.X;
							FootData.Rotation.Y = DataTransmision.OnFootData.Rotation.Y;
							FootData.Rotation.Z = DataTransmision.OnFootData.Rotation.Z;
						}
						break; 
					}
				case TDT_CMD_SetHealth: 
					{ 
						FootData.Health = DataTransmision.OnFootData.Health;
						break; 
					}
				case TDT_CMD_SetArmour: 
					{ 
						FootData.Armour = DataTransmision.OnFootData.Armour;
						break; 
					}
				case TDT_CMD_SetWeapon: 
					{ 
						FootData.CurrWeapon = DataTransmision.OnFootData.CurrWeapon;
						break; 
					}
				case TDT_CMD_SetAction: 
					{ 
						FootData.SpecialAction = DataTransmision.OnFootData.SpecialAction;
						break; 
					}
				case TDT_CMD_SetVelocity: 
					{ 
						FootData.Velocity.X = DataTransmision.OnFootData.Velocity.X;
						FootData.Velocity.Y = DataTransmision.OnFootData.Velocity.Y;
						FootData.Velocity.Z = DataTransmision.OnFootData.Velocity.Z;
						VehicleData.Velocity.X = DataTransmision.InCarData.Velocity.X;
						VehicleData.Velocity.Y = DataTransmision.InCarData.Velocity.Y;
						VehicleData.Velocity.Z = DataTransmision.InCarData.Velocity.Z;
						break; 
					}
				case TDT_CMD_SetSurfOffset:
					{ 
						FootData.SurfOffset.X = DataTransmision.OnFootData.SurfOffset.X;
						FootData.SurfOffset.Y = DataTransmision.OnFootData.SurfOffset.Y;
						FootData.SurfOffset.Z = DataTransmision.OnFootData.SurfOffset.Z;
						break; 
					}
				case TDT_CMD_SetSurfInfo: 
					{ 
						FootData.SurfInfo = DataTransmision.OnFootData.SurfInfo;
						break; 
					}
				case TDT_CMD_SetKeys: 
					{ 
						VehicleData.Keys = DataTransmision.InCarData.Keys;
						FootData.Keys = DataTransmision.OnFootData.Keys;
						break; 
					}
				case TDT_CMD_SetCarHealth: 
					{ 
						VehicleData.CarHealth = DataTransmision.InCarData.CarHealth;
						break; 
					}
				case TDT_CMD_SetSiren: 
					{ 
						VehicleData.SirenOn = DataTransmision.InCarData.SirenOn;
						break; 
					}
				case TDT_CMD_SetLandingGearState: 
					{ 
						VehicleData.LandingGearState = DataTransmision.InCarData.LandingGearState;
						break; 
					}
				case TDT_CMD_SetTIDOTA: 
					{ 
						VehicleData.TrailerID_or_ThrustAngle = DataTransmision.InCarData.TrailerID_or_ThrustAngle;
						break; 
					}
				case TDT_CMD_SetTrainSpeed: 
					{ 
						VehicleData.TrainSpeed = DataTransmision.InCarData.TrainSpeed;
						break; 
					}

				case TDT_CMD_SetPlaybackState: 
					{ 
						CurrentNPC.SetPlaybackState(DataTransmision.State);
						break; 
					}
				case TDT_CMD_StartMove:
					{
						CurrentNPC.Moving = true;
						CurrentNPC.MovePos.X = DataTransmision.MoveToPos.X;
						CurrentNPC.MovePos.Y = DataTransmision.MoveToPos.Y;
						CurrentNPC.MovePos.Z = DataTransmision.MoveToPos.Z;
						CurrentNPC.MoveSpeed = DataTransmision.MoveSpeed;

						CurrentNPC.Adders.X = (CurrentNPC.MovePos.X-FootData.Position.X)/CurrentNPC.MoveSpeed;
						CurrentNPC.Adders.Y = (CurrentNPC.MovePos.Y-FootData.Position.Y)/CurrentNPC.MoveSpeed;
						CurrentNPC.Adders.Z = (CurrentNPC.MovePos.Z-FootData.Position.Z)/CurrentNPC.MoveSpeed;
						CurrentNPC.LeftDist = 1000000000.0f;
						break;
					}
				}
			}
		}
		catch(interprocess_exception &ex)
		{
			std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
		}
		static unsigned long long diff;
		static unsigned long long curr;
		static float fdiff;
		curr = GetCurrentEpochMicroSec();
		diff = curr-LastTick;
		LastTick = curr;
		fdiff = static_cast<float>(diff);
		if(CurrentNPC.Moving)
		{
			float mag = (CurrentNPC.MoveSpeed*(fdiff/1000000.0f));
			VehicleData.Velocity.X = CurrentNPC.Adders.X*mag;
			VehicleData.Velocity.Y = CurrentNPC.Adders.Y*mag;
			VehicleData.Velocity.Z = CurrentNPC.Adders.Z*mag;
			VehicleData.Position.X += VehicleData.Velocity.X;
			VehicleData.Position.Y += VehicleData.Velocity.Y;
			VehicleData.Position.Z += VehicleData.Velocity.Z;
			FootData.Position = VehicleData.Position;
			FootData.Velocity = VehicleData.Velocity;
			Pos Temp;
			Temp.X = (CurrentNPC.MovePos.X-VehicleData.Position.X);
			Temp.Y = (CurrentNPC.MovePos.X-VehicleData.Position.X);
			Temp.Z = (CurrentNPC.MovePos.X-VehicleData.Position.X);
			float CurrDist = ((Temp.X*Temp.X)+(Temp.Y*Temp.Y)+(Temp.Z*Temp.Z));
			if(CurrDist < CurrentNPC.LeftDist)
			{
				CurrentNPC.LeftDist = CurrDist;
				if(CurrentNPC.LeftDist < 0.001f)
				{
					CurrentNPC.Moving = false;
					VehicleData.Velocity.X = 0.0f;
					VehicleData.Velocity.Y = 0.0f;
					VehicleData.Velocity.Z = 0.0f;
					FootData.Velocity = VehicleData.Velocity;
					DataTransmision.CommandType = TDT_SIGNAL_MOVE_COMPLETE;
					try
					{
						ToServer->try_send(&DataTransmision,sizeof(ExchangeData),1);
					}
					catch(interprocess_exception &ex)
					{
						std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
					}
				}
			}
			else
			{
				CurrentNPC.Moving = false;
				VehicleData.Velocity.X = 0.0f;
				VehicleData.Velocity.Y = 0.0f;
				VehicleData.Velocity.Z = 0.0f;
				FootData.Velocity = VehicleData.Velocity;
				DataTransmision.CommandType = TDT_SIGNAL_MOVE_COMPLETE;
				try
				{
					ToServer->try_send(&DataTransmision,sizeof(ExchangeData),1);
				}
				catch(interprocess_exception &ex)
				{
					std::cout << ex.what() << ":" << __FILE__ << ":" << __FUNCTION__ << ":" << __LINE__ << std::endl;
				}
			}
		}
		if(CurrentNPC.GetPlaybackState() == 1)
		{
			GetVehicle()->Apply(VehicleData);
		}
		else
		{
			GetMe()->Apply(FootData);
		}
	}
}

class UglyDestructorHack
{
public:
	~UglyDestructorHack()
	{
		message_queue::remove(MySharedMemoryName.c_str());
		delete Receive;
	}
}_UglyDestructorHack;