#pragma once

#include "GTAstructs.h"
#include <boost/interprocess/ipc/message_queue.hpp>
using namespace boost::interprocess;

enum TransmissionDataType
{
	TDT_NewNPC,
	TDT_CMD_SetAnimation,
	TDT_CMD_SetPosition,
	TDT_CMD_SetLRAnalog,
	TDT_CMD_SetUDAnalog,
	TDT_CMD_SetRotation,
	TDT_CMD_SetHealth,
	TDT_CMD_SetArmour,
	TDT_CMD_SetWeapon,
	TDT_CMD_SetAction,
	TDT_CMD_SetVelocity,
	TDT_CMD_SetSurfOffset,
	TDT_CMD_SetSurfInfo,
	TDT_CMD_SetKeys,
	TDT_CMD_SetCarHealth,
	TDT_CMD_SetSiren,
	TDT_CMD_SetLandingGearState,
	TDT_CMD_SetTIDOTA,
	TDT_CMD_SetTrainSpeed,
	
	TDT_CMD_SetPlaybackState,

	TDT_CMD_StopMove,
	TDT_CMD_StartMove,

	TDT_SIGNAL_MOVE_COMPLETE,
};

const unsigned short QueueMaxSize = 256;

#pragma pack(push, 1)
struct ExchangeData
{
	unsigned short	CommandType;
	unsigned short	NPCPlayerID;
	Byte			State;
	NPCDataFoot		OnFootData;
	NPCDataVehicle	InCarData;
	float MoveSpeed;
	Pos MoveToPos;
	//206
	ExchangeData(unsigned short CommandType = 0, unsigned short NPCPlayerid = 0xFFFF)
		: CommandType(CommandType), NPCPlayerID(NPCPlayerid)
	{}
	ExchangeData(unsigned short CommandType, unsigned short NPCPlayerid, NPCDataFoot& foot_data, NPCDataVehicle& car_data)
		: CommandType(CommandType), NPCPlayerID(NPCPlayerid), OnFootData(foot_data), InCarData(car_data)
	{}
};
#pragma pack(pop)