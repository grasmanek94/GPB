#pragma once

struct Pos
{
	float
		X,
		Y,
		Z;
};

struct Quat
{
	float
		W,
		X,
		Y,
		Z;
};

typedef unsigned char Byte;

//THIS IS >>NOT<< FROM THE WIKI

//0x454168
#pragma pack(push, 1)
struct NPCDataFoot
{
	unsigned short lrAnalog;
	unsigned short udAnalog;
	unsigned short Keys;
	Pos Position;
	Quat Rotation;
	Byte Health;
	Byte Armour;
	Byte CurrWeapon;
	Byte SpecialAction;
	Pos Velocity;
	Pos SurfOffset;
	unsigned short SurfInfo;
	unsigned short AnimationIndex;
	void Apply(NPCDataFoot &data)
	{
		lrAnalog=data.lrAnalog;
		udAnalog=data.udAnalog;
		Keys=data.Keys;
		Position.X=data.Position.X;
		Position.Y=data.Position.Y;
		Position.Z=data.Position.Z;
		Rotation.W=data.Rotation.W;
		Rotation.X=data.Rotation.X;
		Rotation.Y=data.Rotation.Y;
		Rotation.Z=data.Rotation.Z;
		Health=data.Health;
		Armour=data.Armour;
		CurrWeapon=data.CurrWeapon;
		SpecialAction=data.SpecialAction;
		Velocity.X=data.Velocity.X;
		Velocity.Y=data.Velocity.Y;
		Velocity.Z=data.Velocity.Z;
		SurfOffset.X=data.SurfOffset.X;
		SurfOffset.Y=data.SurfOffset.Y;
		SurfOffset.Z=data.SurfOffset.Z;
		SurfInfo=data.SurfInfo;
		AnimationIndex=data.AnimationIndex;
	}
	NPCDataFoot()
	{
		lrAnalog=0;
		udAnalog=0;
		Keys=0;
		Position.X=0.0f;
		Position.Y=0.0f;
		Position.Z=0.0f;
		Rotation.W=0.0f;
		Rotation.X=0.0f;
		Rotation.Y=0.0f;
		Rotation.Z=0.0f;
		Health=0;
		Armour=0;
		CurrWeapon=0;
		SpecialAction=0;
		Velocity.X=0.0f;
		Velocity.Y=0.0f;
		Velocity.Z=0.0f;
		SurfOffset.X=0.0f;
		SurfOffset.Y=0.0f;
		SurfOffset.Z=0.0f;
		SurfInfo=0;
		AnimationIndex=0;
	}
};
#pragma pack(pop)
//0x44D3C0
#pragma pack(push, 1)
struct NPCDataVehicle
{
	unsigned short VehicleID;
	unsigned short lrAnalog;
	unsigned short udAnalog;
	unsigned short Keys;
	Quat Rotation;
	Pos Position;
	Pos Velocity;
	float CarHealth;
	Byte PlayerHealth;
	Byte PlayerArmour;
	Byte CurrentWeapon;
	Byte SirenOn;
	Byte LandingGearState;
	unsigned short TrailerID_or_ThrustAngle;
	float TrainSpeed;
	void Apply(NPCDataVehicle &data)
	{
		lrAnalog=data.lrAnalog;
		udAnalog=data.udAnalog;
		Keys=data.Keys;
		Rotation.W=data.Rotation.W;
		Rotation.X=data.Rotation.X;
		Rotation.Y=data.Rotation.Y;
		Rotation.Z=data.Rotation.Z;
		Position.X=data.Position.X;
		Position.Y=data.Position.Y;
		Position.Z=data.Position.Z;
		Velocity.X=data.Velocity.X;
		Velocity.Y=data.Velocity.Y;
		Velocity.Z=data.Velocity.Z;
		CarHealth=data.CarHealth;
		PlayerHealth=data.PlayerHealth;
		PlayerArmour=data.PlayerArmour;
		CurrentWeapon=data.CurrentWeapon;
		SirenOn=data.SirenOn;
		LandingGearState=data.LandingGearState;
		TrailerID_or_ThrustAngle=data.TrailerID_or_ThrustAngle;
		TrainSpeed=data.TrainSpeed;
	}
	NPCDataVehicle()
	{
		VehicleID = 0;
		lrAnalog = 0;
		udAnalog = 0;
		Keys = 0;
		Rotation.W = 0.0f;
		Rotation.X = 0.0f;
		Rotation.Y = 0.0f;
		Rotation.Z = 0.0f;
		Position.X = 0.0f;
		Position.Y = 0.0f;
		Position.Z = 0.0f;
		Velocity.X = 0.0f;
		Velocity.Y = 0.0f;
		Velocity.Z = 0.0f;
		CarHealth = 1000.0f;
		PlayerHealth=100;
		PlayerArmour=0;
		CurrentWeapon=0;
		SirenOn=0;
		LandingGearState=0;
		TrailerID_or_ThrustAngle=0;
		TrainSpeed=0.0f;
	}
};
#pragma pack(pop)
