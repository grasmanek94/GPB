#ifndef SAMPGDK_AMX_H
#define SAMPGDK_AMX_H
#pragma once

#include <sampgdk/config.h>
#include <sdk/amx/amx.h>

#endif /* !SAMPGDK_AMX_H */
