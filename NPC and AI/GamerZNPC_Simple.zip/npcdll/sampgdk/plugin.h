#ifndef SAMPGDK_PLUGIN_H
#define SAMPGDK_PLUGIN_H
#pragma once

#include <sampgdk/config.h>
#include <sdk/amx/amx.h>
#include <sampgdk/core.h>
#include <sdk/plugin.h>

#endif /* !SAMPGDK_PLUGIN_H */
