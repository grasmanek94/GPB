#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <iostream>
#include <string>
#include <unordered_map>
#include <map>
#include <vector>
#include <unordered_set>


#include "common.h"

// raknet stuff
#include "PacketEnumerations.h"
#include "RakNetworkFactory.h"
#include "RakClientInterface.h"
#include "NetworkTypes.h"
#include "BitStream.h"
#include "StringCompressor.h"

#pragma warning(disable:4996)

// sa-mp stuff
#include "samp_netencr.h"
#include "SAMPRPC.h"
#include "SAMP_VER.h"
#include "npc.h"

void gen_random(char *s, const int len);
void Log ( char *fmt, ... );

#include "samp.h"
extern SAMP* pSamp;
