#include "main.h"
#include "pmain.h"
#include "plugin.h"

#include <stdlib.h>
#include <string.h>
#include <time.h>

logprintf_t
	logprintf;

extern void
	*pAMXFunctions;

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

#include <string>
#include <concurrent_queue.h>
#include <unordered_set>
#include <unordered_map>
#include <boost/thread.hpp>
#include <boost/variant.hpp>
#include <boost/filesystem.hpp>
#include <atomic>

std::unordered_map<AMX*,int> Scripts;

#include "npc.h"

struct Position4D
{
	float 
		x,
		y,
		z,
		a;

	Position4D(float x = 0.0f, float y = 0.0f, float z = 0.0f, float a = 0.0f): 
		x(x), y(y),z(z), a(a) 
	{}

	Position4D& operator=(Position4D src) 
	{
		x = src.x;
		y = src.y;
		z = src.z;
		a = src.a;
		return *this;
	}	
	float lenght()
	{
		return x*x+y*y+z*z+a*a;
	}
	float slenght()
	{
		return sqrt(lenght());
	}
	float GetDistance(Position4D &dest)
	{
		return Position4D(dest.x-x,dest.y-y,dest.z-z,dest.a-a).slenght();
	}
};

class NPCLogic;

enum QueueCommand
{
	QueueCommand_SetPos,
	QueueCommand_StatusUpdate,
	QueueCommand_Disconnect
};

typedef std::vector<boost::variant<QueueCommand,Position4D,int,std::string,ConnectionStatus,PLAYERID>> QueueData;
typedef std::pair<NPCLogic*,QueueData> QueueLogic;
concurrency::concurrent_queue<QueueLogic> NPC_cmd_Queue;
concurrency::concurrent_queue<QueueLogic> Server_cmd_Queue;
std::unordered_set<NPCLogic*> NPCs;
std::unordered_map<PLAYERID,NPCLogic*> PlayerIDToNPC;

class NPCLogic : public NPC
{
public:
	NPCLogic() : NPC()
	{
		ZeroMemory(&onfoot_data,sizeof(ONFOOT_SYNC_DATA));
		ZeroMemory(&incar_data,sizeof(INCAR_SYNC_DATA));
		ZeroMemory(&aim_data,sizeof(AIM_SYNC_DATA));
		ZeroMemory(&passenger_data,sizeof(PASSENGER_SYNC_DATA));
		NPCs.insert(this);
	}
	~NPCLogic()
	{
		NPCs.erase(this);
	}
	void OnConnectionStatusUpdate(ConnectionStatus status)
	{
		if(status == CONNECTION_SUCCESS)
		{
			RequestClass(0);
			Spawn();
		}
		QueueData data;
		data.push_back(QueueCommand_StatusUpdate);
		data.push_back(status);
		data.push_back(GetPlayerID());
		NPC_cmd_Queue.push(QueueLogic(this,data));
	}
	void Process()
	{
		//
	}
};

std::atomic<bool> Running = true;
boost::thread * worker = nullptr;
#include <boost/chrono.hpp>

void NPCThread()
{
	if(NPCplugin::Init())
	{
		logprintf("SAMP.dll and/or BASS.dll missing or unreadable!");
		delete worker;
		return;
	}	
	//boost::chrono::high_resolution_clock::time_point start = boost::chrono::high_resolution_clock::now();
	//boost::chrono::high_resolution_clock::time_point end = boost::chrono::high_resolution_clock::now();
	while(Running)
	{	
		//start = boost::chrono::high_resolution_clock::now();
		QueueLogic data;
		while(Server_cmd_Queue.try_pop(data))
		{
			switch(boost::get<QueueCommand>(data.second[0]))
			{
			//case QueueCommand_SetPos:
			//	data.first->SetPosition(boost::get<Position4D>(data.second[1]));
			//	break;
			case QueueCommand_Disconnect:
				delete data.first;
				break;
			default:

				break;
			}
		}
		for(auto &npc: NPCs)
		{
			npc->Process();
			npc->Tick();
		}
		//end = boost::chrono::high_resolution_clock::now();
		//std::cout << end-start << std::endl;
		boost::this_thread::sleep(boost::posix_time::microseconds(1000));
	}
}

PLUGIN_EXPORT bool PLUGIN_CALL Load(void **ppData)
{
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	logprintf = (logprintf_t)ppData[PLUGIN_DATA_LOGPRINTF];
	logprintf("Gamer_Z's NPC system is loading...");
	worker = new boost::thread(NPCThread);
	logprintf("Gamer_Z's NPC system loaded");
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload()
{
	Running = false;
	if(worker)
	{
		worker->join();
		delete worker;
	}
	for(auto &npc: NPCs)
		npc->Disconnect(0);
	logprintf("Gamer_Z's NPC system unloaded");
}

PLUGIN_EXPORT void PLUGIN_CALL ProcessTick()
{
	QueueLogic TickData;
	while(NPC_cmd_Queue.try_pop(TickData))
	{
		switch(boost::get<QueueCommand>(TickData.second[0]))
		{
		case QueueCommand_StatusUpdate:
			if(boost::get<ConnectionStatus>(TickData.second[1]) == CONNECTION_SUCCESS)
				PlayerIDToNPC[boost::get<PLAYERID>(TickData.second[2])] = TickData.first;
			for(auto &callback: Scripts)
			{
				amx_Push(callback.first,static_cast<cell>(boost::get<PLAYERID>(TickData.second[2])));
				amx_Push(callback.first,static_cast<cell>(boost::get<ConnectionStatus>(TickData.second[1])));
				amx_Push(callback.first,reinterpret_cast<cell>(TickData.first));
				amx_Exec(callback.first,NULL,callback.second);
			}
			break;
		default:

			break;
		}
	}	
}

std::string AmxStr(AMX * amx, cell params)
{
	std::string temp("");
    int len = NULL;
    cell *addr  = NULL;

    amx_GetAddr(amx, params, &addr); 
    amx_StrLen(addr, &len);
    if(len)
    {
        char* text = new char[ ++len ];
        amx_GetString(text, addr, 0, len);
		temp.assign(text);
        delete[] text;
    }
	return temp; 
}

static cell AMX_NATIVE_CALL GAMER_NPC_TryConnect(AMX *amx, cell *params)
{
	NPCLogic* npc = new NPCLogic();
	npc->Nickname().assign(AmxStr(amx,params[1]));
	npc->Password().assign(AmxStr(amx,params[2]));
	npc->Port() = params[3];
	return reinterpret_cast<cell>(npc);
}

static cell AMX_NATIVE_CALL GAMER_NPC_RemoveEx(AMX *amx, cell *params)
{
	if(!params[1])
		return 0;
	QueueLogic data;
	data.first = reinterpret_cast<NPCLogic*>(params[1]); 
	PlayerIDToNPC.erase(data.first->GetPlayerID());
	data.second.push_back(QueueCommand_Disconnect);
	Server_cmd_Queue.push(data);
	return 1;
}/*
static cell AMX_NATIVE_CALL GAMER_NPC_SetPosition(AMX *amx, cell *params)
{
	if(!params[1])
		return 0;
	QueueLogic data;
	data.first = reinterpret_cast<NPCLogic*>(params[1]);
	data.second.push_back(QueueCommand_SetPos);
	data.second.push_back(Position4D(amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4])));
	Server_cmd_Queue.push(data);
	return 1;
}
*/
static cell AMX_NATIVE_CALL GAMER_NPC_Remove(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	QueueLogic data;
	data.first = PlayerIDToNPC[params[1]]; 
	PlayerIDToNPC.erase(params[1]);
	data.second.push_back(QueueCommand_Disconnect);
	Server_cmd_Queue.push(data);
	return 1;
}

static cell AMX_NATIVE_CALL GAMER_NPC_SetPosition(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	PlayerIDToNPC[params[1]]->onfoot_data.vecPos[0] = amx_ctof(params[2]);
	PlayerIDToNPC[params[1]]->onfoot_data.vecPos[1] = amx_ctof(params[3]);
	PlayerIDToNPC[params[1]]->onfoot_data.vecPos[2] = amx_ctof(params[4]);
	return 1;
}

static cell AMX_NATIVE_CALL GAMER_NPC_GetPosition(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	cell * addr = NULL;
	amx_GetAddr(amx,params[2],&addr);
	*addr = amx_ftoc(PlayerIDToNPC[params[1]]->onfoot_data.vecPos[0]);
	amx_GetAddr(amx,params[3],&addr);
	*addr = amx_ftoc(PlayerIDToNPC[params[1]]->onfoot_data.vecPos[1]);
	amx_GetAddr(amx,params[4],&addr);
	*addr = amx_ftoc(PlayerIDToNPC[params[1]]->onfoot_data.vecPos[2]);
	return 1;
}

static cell AMX_NATIVE_CALL GAMER_NPC_SetVelocity(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	PlayerIDToNPC[params[1]]->onfoot_data.vecMoveSpeed[0] = amx_ctof(params[2]);
	PlayerIDToNPC[params[1]]->onfoot_data.vecMoveSpeed[1] = amx_ctof(params[3]);
	PlayerIDToNPC[params[1]]->onfoot_data.vecMoveSpeed[2] = amx_ctof(params[4]);
	return 1;
}

static cell AMX_NATIVE_CALL GAMER_NPC_GetVelocity(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	cell * addr = NULL;
	amx_GetAddr(amx,params[2],&addr);
	*addr = amx_ftoc(PlayerIDToNPC[params[1]]->onfoot_data.vecMoveSpeed[0]);
	amx_GetAddr(amx,params[3],&addr);
	*addr = amx_ftoc(PlayerIDToNPC[params[1]]->onfoot_data.vecMoveSpeed[1]);
	amx_GetAddr(amx,params[4],&addr);
	*addr = amx_ftoc(PlayerIDToNPC[params[1]]->onfoot_data.vecMoveSpeed[2]);
	return 1;
}

static cell AMX_NATIVE_CALL GAMER_NPC_SetAnimationID(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	PlayerIDToNPC[params[1]]->onfoot_data.iCurrentAnimationID = params[2];
	return 1;
}

static cell AMX_NATIVE_CALL GAMER_NPC_GetAnimationID(AMX *amx, cell *params)
{
	if(PlayerIDToNPC.find(params[1]) == PlayerIDToNPC.end())
		return 0;
	return PlayerIDToNPC[params[1]]->onfoot_data.iCurrentAnimationID;
}

#define entry(name) {#name, name}
AMX_NATIVE_INFO Natives[] =
{
	entry(GAMER_NPC_TryConnect),
	entry(GAMER_NPC_SetPosition),
	entry(GAMER_NPC_GetPosition),
	entry(GAMER_NPC_SetVelocity),
	entry(GAMER_NPC_GetVelocity),
	entry(GAMER_NPC_Remove),
	entry(GAMER_NPC_RemoveEx),
	entry(GAMER_NPC_SetAnimationID),
	entry(GAMER_NPC_GetAnimationID),
	{0,			0}
};


PLUGIN_EXPORT int PLUGIN_CALL AmxLoad(AMX *amx) 
{
	static int index;
	if (!amx_FindPublic( amx, "Gamer_Z_NPC_StatusUpdate", &index))
		Scripts.insert(std::pair<AMX*,int>(amx,index));
	return amx_Register(amx, Natives, -1);
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload(AMX *amx) 
{
	Scripts.erase(amx);
	return AMX_ERR_NONE;
}
