#pragma once

typedef void (* logprintf_t)(char *, ...);