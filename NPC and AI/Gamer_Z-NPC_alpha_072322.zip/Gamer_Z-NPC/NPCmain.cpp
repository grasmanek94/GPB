#include "main.h"

#define REJECT_REASON_BAD_VERSION 1
#define REJECT_REASON_BAD_NICKNAME 2
#define REJECT_REASON_BAD_MOD 3
#define REJECT_REASON_BAD_PLAYERID 4

void InitGame(RPCParameters *rpcParams);
void ConnectionRejected(RPCParameters *rpcParams);

std::unordered_map<NPC*,unsigned short> NPC_TO_PORT;
std::unordered_map<unsigned short,NPC*> PORT_TO_NPC;
std::unordered_set<NPC*> NPC_SET;

void NPC::Packet_AUTH_KEY(Packet *p)
{
	char auth_key[4*16] = {0};
	BYTE byteAuthKeyLen;
	byteAuthKeyLen;
	pSamp->getAuthKey(auth_key, (char*)(p->data + 2));
	byteAuthKeyLen = (BYTE)strlen(auth_key);
	
	RakNet::BitStream bsKey;
	bsKey.Write((BYTE)ID_AUTH_KEY);
	bsKey.Write((BYTE)byteAuthKeyLen);
	bsKey.Write(auth_key, byteAuthKeyLen);

	pRakClient->Send(&bsKey, SYSTEM_PRIORITY, RELIABLE, NULL);
}

VEHICLEID NPC::GetVehicle()
{
	return VehicleID;
}

PLAYERID NPC::GetPlayerID()
{
	return PlayerID;
}

bool NPC::IsPassenger()
{
	return Passenger;
}

void NPC::Packet_ConnectionSucceeded(Packet *p)
{
	RakNet::BitStream bsSuccAuth((unsigned char *)p->data, p->length, false);
	unsigned int uiChallenge;

	bsSuccAuth.IgnoreBits(8); // ID_CONNECTION_REQUEST_ACCEPTED
	bsSuccAuth.IgnoreBits(32); // binaryAddress
	bsSuccAuth.IgnoreBits(16); // port

	bsSuccAuth.Read(PlayerID);

	bsSuccAuth.Read(uiChallenge);

	//Log("Connected. Joining the game...");

	int iVersion = NETGAME_VERSION;
	BYTE byteMod = 1;
	char auth_bs[4*16] = {0};
	BYTE byteAuthBSLen;
	pSamp->getSerial(auth_bs);
	byteAuthBSLen = (BYTE)strlen(auth_bs);
	BYTE byteNameLen = (BYTE)nickname.length();

	unsigned int uiClientChallengeResponse = uiChallenge ^ iVersion;

	RakNet::BitStream bsSend;
	bsSend.Write(iVersion);
	bsSend.Write(byteMod);
	bsSend.Write(byteNameLen);
	bsSend.Write(nickname.c_str(), byteNameLen);
	
	bsSend.Write(uiClientChallengeResponse);
	bsSend.Write(byteAuthBSLen);
	bsSend.Write(auth_bs, byteAuthBSLen);
	char szClientVer[] = "0.3x-R1-2";
	const BYTE iClientVerLen = (sizeof(szClientVer)-1);
	bsSend.Write(iClientVerLen);
	bsSend.Write(szClientVer, iClientVerLen);

	pRakClient->RPC(&RPC_ClientJoin, &bsSend, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);

	Connected = true;

	OnConnectionStatusUpdate(GAME_JOINED);
}

int NPC::sampConnect()
{
	//std::cout << "connect 1" << std::endl;
	//if (!Connected) 
	//	Log("Connecting to %s:%d", const_cast<char*>(host.c_str()), port);

	//std::cout << "connect 2" << std::endl;
	if(pRakClient == NULL) 
		return 0;

	//std::cout << "connect 3" << std::endl;
	pRakClient->SetPassword(const_cast<char*>(password.c_str()));
	int retval = (int)pRakClient->Connect(const_cast<char*>(host.c_str()), port, 0, 0, 5);

	if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
	{
		PORT_TO_NPC.erase(NPC_TO_PORT[this]);
		NPC_TO_PORT.erase(this);
	}
	PORT_TO_NPC[pRakClient->GetInternalID().port] = this;
	NPC_TO_PORT[this] = pRakClient->GetInternalID().port;
		
	//std::cout << "pRakClientAddr: " << pRakClient->GetInternalID().port << std::endl;
	return retval;
}

void NPC::sampDisconnect(bool Timeout)
{
	if(pRakClient == NULL) return;

	if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
	{
		PORT_TO_NPC.erase(NPC_TO_PORT[this]);
		NPC_TO_PORT.erase(this);
	}

	//Log("Disconnected");

	if(Timeout)
		pRakClient->Disconnect(500);
	else
		pRakClient->Disconnect(0);

	Connected = false;
	GameInited = false;
}

void NPC::sampRequestClass(int iClass)
{
	if(pRakClient == NULL) return;
	//Log("Requesting class %d...", iClass);

	RakNet::BitStream bsSpawnRequest;
	bsSpawnRequest.Write(iClass);
	pRakClient->RPC(&RPC_RequestClass, &bsSpawnRequest, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}

void NPC::sampSpawn()
{
	if(pRakClient == NULL) return;

	//Log("Spawning...");

#ifndef SAMP_03c
	RakNet::BitStream bsSendRequestSpawn;
	pRakClient->RPC(&RPC_RequestSpawn, &bsSendRequestSpawn, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
#endif
	RakNet::BitStream bsSendSpawn;
	pRakClient->RPC(&RPC_Spawn, &bsSendSpawn, HIGH_PRIORITY, RELIABLE, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}

void NPC::RegisterRPCs()
{
	if(pRakClient)
	{
		//std::cout << "regustering..." << std::endl;
		pRakClient->RegisterAsRemoteProcedureCall(&RPC_InitGame, InitGame);
		pRakClient->RegisterAsRemoteProcedureCall(&RPC_ConnectionRejected, ConnectionRejected);
		//std::cout << "...registered" << std::endl;
	}
}

void NPC::UnRegisterRPCs()
{
	// Core RPCs
	if (pRakClient)
	{
		pRakClient->UnregisterAsRemoteProcedureCall(&RPC_InitGame);
		pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ConnectionRejected);
	}
}
void NPC::RequestClass(int classid)
{
	sampRequestClass(classid);
}
void NPC::Spawn()
{
	sampSpawn();
}
void NPC::Disconnect(bool timeout)
{
	if(Connected)
		sampDisconnect(timeout);
	ConnectionRequested = true;
}
NPC::NPC(): host("127.0.0.1"), port(7777), nickname("NPC"), password(""), PlayerID(0xFFFF) 
{
	GameInited = false;
	VehicleID = 0;
	Passenger = false;
	ConnectionRequested = false;
	// set up networking
	pRakClient = RakNetworkFactory::GetRakClientInterface();
	
	if(pRakClient)
		pRakClient->SetMTUSize(576);


	RegisterRPCs();
	NPC_SET.insert(this);
}
NPC::~NPC()
{ 
	if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
	{
		PORT_TO_NPC.erase(NPC_TO_PORT[this]);
		NPC_TO_PORT.erase(this);
	}
	NPC_SET.erase(this);
	UnRegisterRPCs(); 
}
std::string &NPC::Nickname()
{
	return nickname;
}
std::string &NPC::Password()
{
	return password;
}
unsigned short &NPC::Port()
{
	return port;
}
void NPC::DoInitDone()
{
	//std::cout << "DoInitDone()" << std::endl;
	GameInited = true;
}
void NPC::Tick()
{
	if(!pRakClient)
		return;
	unsigned char packetIdentifier;
	Packet *pkt;

	while(pkt = pRakClient->Receive())
	{
		if ( ( unsigned char ) pkt->data[ 0 ] == ID_TIMESTAMP )
		{
			if ( pkt->length > sizeof( unsigned char ) + sizeof( unsigned int ) )
				packetIdentifier = ( unsigned char ) pkt->data[ sizeof( unsigned char ) + sizeof( unsigned int ) ];
			else
				return;
		}
		else
			packetIdentifier = ( unsigned char ) pkt->data[ 0 ];

		switch(packetIdentifier)
		{
			case ID_DISCONNECTION_NOTIFICATION:
				Connected = false;
				if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
				{
					PORT_TO_NPC.erase(NPC_TO_PORT[this]);
					NPC_TO_PORT.erase(this);
				}
				Log("[RAKSAMP] Connection was closed by the server.");
				OnConnectionStatusUpdate(CONNECTION_CLOSED);
				break;
			case ID_CONNECTION_BANNED:
				Connected = false;
				if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
				{
					PORT_TO_NPC.erase(NPC_TO_PORT[this]);
					NPC_TO_PORT.erase(this);
				}
				Log("[RAKSAMP] You are banned.");
				OnConnectionStatusUpdate(CONNECTION_BANNED);
				break;			
			case ID_CONNECTION_ATTEMPT_FAILED:
				Connected = false;
				if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
				{
					PORT_TO_NPC.erase(NPC_TO_PORT[this]);
					NPC_TO_PORT.erase(this);
				}
				Log("[RAKSAMP] Connection attempt failed.");
				OnConnectionStatusUpdate(CONNECTION_FAILED);
				break;
			case ID_NO_FREE_INCOMING_CONNECTIONS:
				Connected = false;
				if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
				{
					PORT_TO_NPC.erase(NPC_TO_PORT[this]);
					NPC_TO_PORT.erase(this);
				}
				Log("[RAKSAMP] The server is full.");
				OnConnectionStatusUpdate(SERVER_FULL);
				break;
			case ID_INVALID_PASSWORD:
				Connected = false;
				if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
				{
					PORT_TO_NPC.erase(NPC_TO_PORT[this]);
					NPC_TO_PORT.erase(this);
				}
				Log("[RAKSAMP] Invalid password.");
				OnConnectionStatusUpdate(CONNECTION_BAD_PASSWORD);
				break;
			case ID_CONNECTION_LOST:
				Connected = false;
				if(NPC_TO_PORT.find(this) != NPC_TO_PORT.end())
				{
					PORT_TO_NPC.erase(NPC_TO_PORT[this]);
					NPC_TO_PORT.erase(this);
				}
				Log("[RAKSAMP] The connection was lost.");
				OnConnectionStatusUpdate(CONNECTION_LOST);
				break;
			case ID_CONNECTION_REQUEST_ACCEPTED:
				Packet_ConnectionSucceeded(pkt);
				OnConnectionStatusUpdate(CONNECTION_SUCCESS);
				//std::cout << "connection accepted" << std::endl;
				break;
			case ID_AUTH_KEY:
				Packet_AUTH_KEY(pkt);
				//std::cout << "auth key" << std::endl;
				break;
		}

		pRakClient->DeallocatePacket(pkt);
	}
	//std::cout << "stage 2" << std::endl;
	if(!ConnectionRequested)
	{
		//std::cout << "stage 3" << std::endl;
		sampConnect();
		ConnectionRequested = true;
	}
	//std::cout << "stage 4" << std::endl;
	if (Connected && GameInited)
	{
		if(VehicleID)
		{
			if(Passenger)
			{
				//passenger
				SendPassenger();
			}
			else
			{
				//driver
				SendCar();
			}
		}
		else
		{
			//onfoot
			SendFoot(0);
			//SendAim(0,0);
		}
	}
}
void NPC::Reconnect(bool timeout)
{
	if(Connected)
	{
		sampDisconnect(timeout);
		ConnectionRequested = false;
	}
	else
	{
		ConnectionRequested = false;
	}
}

void NPC::SendFoot(int sendDeathNoti)
{
	RakNet::BitStream bsPlayerSync;

	bsPlayerSync.Write((BYTE)ID_PLAYER_SYNC);
	bsPlayerSync.Write((PCHAR)&onfoot_data, sizeof(ONFOOT_SYNC_DATA));
	pRakClient->Send(&bsPlayerSync, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);

	if(sendDeathNoti && onfoot_data.byteHealth == 0)
		SendDeath(0, -1);
}

void NPC::SendCar()
{
	RakNet::BitStream bsVehicleSync;

	bsVehicleSync.Write((BYTE)ID_VEHICLE_SYNC);
	bsVehicleSync.Write((PCHAR)&incar_data,sizeof(INCAR_SYNC_DATA));
	pRakClient->Send(&bsVehicleSync, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
}

void NPC::SendPassenger()
{
	RakNet::BitStream bsPassengerSync;

	bsPassengerSync.Write((BYTE)ID_PASSENGER_SYNC);
	bsPassengerSync.Write((PCHAR)&passenger_data, sizeof(PASSENGER_SYNC_DATA));
	pRakClient->Send(&bsPassengerSync, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
}

void NPC::SendAim(DWORD dwAmmoInClip, int iReloading)
{
	RakNet::BitStream bsAimSync;

	if(iReloading)
		aim_data.byteWeaponState = WS_RELOADING;
	else
		aim_data.byteWeaponState = (dwAmmoInClip > 1) ? WS_MORE_BULLETS : dwAmmoInClip;

	aim_data.bUnk = 0x55;

	bsAimSync.Write((BYTE)ID_AIM_SYNC);
	bsAimSync.Write((PCHAR)&aim_data, sizeof(AIM_SYNC_DATA));
	pRakClient->Send(&bsAimSync, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
}

void NPC::EnterVehicle(VEHICLEID VehicleID, BYTE bPassenger)
{
	RakNet::BitStream bsSend;

	if(bPassenger)
		this->Passenger = true;
	else
		this->Passenger = false;

	this->VehicleID = VehicleID;
		
	bsSend.Write(VehicleID);
	bsSend.Write(bPassenger);
	pRakClient->RPC(&RPC_EnterVehicle, &bsSend, HIGH_PRIORITY, RELIABLE_SEQUENCED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}

void NPC::ExitVehicle()
{
	RakNet::BitStream bsSend;
	bsSend.Write(this->VehicleID);
	this->Passenger = false;
	pRakClient->RPC(&RPC_ExitVehicle, &bsSend, HIGH_PRIORITY, RELIABLE_SEQUENCED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
	this->VehicleID = 0;
}

void NPC::SendDeath(BYTE byteDeathReason, PLAYERID WhoWasResponsible)
{
	RakNet::BitStream bsPlayerDeath;

	bsPlayerDeath.Write(byteDeathReason);
	bsPlayerDeath.Write(WhoWasResponsible);
	pRakClient->RPC(&RPC_Death, &bsPlayerDeath, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}

void NPC::SendVehicleDeath(VEHICLEID VehicleID)
{
	RakNet::BitStream bsDeath;
	bsDeath.Write(VehicleID);
	pRakClient->RPC(&RPC_VehicleDestroyed, &bsDeath, HIGH_PRIORITY, RELIABLE_SEQUENCED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}

void NPC::SendVehicleDamage(WORD vehicleID, DWORD panel, DWORD door, BYTE lights, BYTE tires)
{
	RakNet::BitStream bsDamageVehicle;

	bsDamageVehicle.Write(vehicleID);
	bsDamageVehicle.Write(panel);
	bsDamageVehicle.Write(door);
	bsDamageVehicle.Write(lights);
	bsDamageVehicle.Write(tires);
	pRakClient->RPC(&RPC_DamageVehicle, &bsDamageVehicle, HIGH_PRIORITY, RELIABLE_ORDERED, 0, FALSE, UNASSIGNED_NETWORK_ID, NULL);
}

void NPC::OnConnectionStatusUpdate(ConnectionStatus status)
{
	//std::cout << "ConnectionStatusUpdate: " << status << std::endl;
}

bool NPC::IsConnected()
{
	return Connected;
}
SAMP * pSamp = NULL;

namespace NPCplugin
{
	int Init()
	{
		pSamp = new SAMP("samp.dll");

		if (pSamp->GetHMODULE() == NULL)
			return 1;

		srand((unsigned int)GetTickCount());
		return 0;
	}
	void Tick()
	{
		for(auto &bot: NPC_SET)
			bot->Tick();
	}
}

void Log ( char *fmt, ... )
{
	//va_list		ap;
	//va_start( ap, fmt );
	//LPTSTR buf = new TCHAR[512];
	//wvsprintf(buf, fmt, ap);
	//va_end( ap );
	//std::cout << buf << std::endl;
}

void gen_random(char *s, const int len)
{
	static const char alphanum[] =
		"0123456789"
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
		"abcdefghijklmnopqrstuvwxyz";

	for (int i = 0; i < len; ++i)
		s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];

	s[len] = 0;
}

void ConnectionRejected(RPCParameters *rpcParams)
{
	//std::cout << "connection rejected" << std::endl;
	PCHAR Data = reinterpret_cast<PCHAR>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char *)Data,(iBitLength/8)+1,false);
	BYTE byteRejectReason;

	bsData.Read(byteRejectReason);

	switch(byteRejectReason)
	{
	case REJECT_REASON_BAD_VERSION:
		if(PORT_TO_NPC.find(rpcParams->recipient->GetInternalID().port) != PORT_TO_NPC.end())
		{
			PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]->OnConnectionStatusUpdate(CONNECTION_ISSUE_BAD_VERSION);
			NPC_TO_PORT.erase(PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]);
			PORT_TO_NPC.erase(rpcParams->recipient->GetInternalID().port);
		}
		break;
	case REJECT_REASON_BAD_NICKNAME:
		if(PORT_TO_NPC.find(rpcParams->recipient->GetInternalID().port) != PORT_TO_NPC.end())
		{
			PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]->OnConnectionStatusUpdate(CONNECTION_ISSUE_BAD_NICKNAME);
			NPC_TO_PORT.erase(PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]);
			PORT_TO_NPC.erase(rpcParams->recipient->GetInternalID().port);
		}
		break;
	case REJECT_REASON_BAD_MOD:
		if(PORT_TO_NPC.find(rpcParams->recipient->GetInternalID().port) != PORT_TO_NPC.end())
		{
			PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]->OnConnectionStatusUpdate(CONNECTION_ISSUE_BAD_MOD);
			NPC_TO_PORT.erase(PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]);
			PORT_TO_NPC.erase(rpcParams->recipient->GetInternalID().port);
		}
		break;
	case REJECT_REASON_BAD_PLAYERID:
		if(PORT_TO_NPC.find(rpcParams->recipient->GetInternalID().port) != PORT_TO_NPC.end())
		{
			PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]->OnConnectionStatusUpdate(CONNECTION_ISSUE_BAD_PLAYERID);
			NPC_TO_PORT.erase(PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]);
			PORT_TO_NPC.erase(rpcParams->recipient->GetInternalID().port);
		}
		break;
	default:
		if(PORT_TO_NPC.find(rpcParams->recipient->GetInternalID().port) != PORT_TO_NPC.end())
		{
			PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]->OnConnectionStatusUpdate(CONNECTION_REJECTED);
			NPC_TO_PORT.erase(PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]);
			PORT_TO_NPC.erase(rpcParams->recipient->GetInternalID().port);
		}
		break;
	}
}

void InitGame(RPCParameters *rpcParams)
{
	//std::cout << "initgame" << std::endl;
	if(PORT_TO_NPC.find(rpcParams->recipient->GetInternalID().port) != PORT_TO_NPC.end())
		PORT_TO_NPC[rpcParams->recipient->GetInternalID().port]->DoInitDone();
}