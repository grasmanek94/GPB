#include <windows.h>

#pragma once

typedef unsigned short PLAYERID;
typedef unsigned short VEHICLEID;

#pragma pack(1)
typedef struct _ONFOOT_SYNC_DATA
{
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float vecPos[3];
	float fQuaternion[4];
	BYTE byteHealth;
	BYTE byteArmour;
	BYTE byteCurrentWeapon;
	BYTE byteSpecialAction;	
	float vecMoveSpeed[3];
	float vecSurfOffsets[3];
	WORD wSurfInfo;
	int	iCurrentAnimationID;
} ONFOOT_SYNC_DATA;

#pragma pack(1)
typedef struct _INCAR_SYNC_DATA
{
	VEHICLEID VehicleID;
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float fQuaternion[4];
	float vecPos[3];
	float vecMoveSpeed[3];
	float fCarHealth;
	BYTE bytePlayerHealth;
	BYTE bytePlayerArmour;
	BYTE byteCurrentWeapon;
	BYTE byteSirenOn;
	BYTE byteLandingGearState;
	WORD TrailerID_or_ThrustAngle;
	FLOAT fTrainSpeed;
} INCAR_SYNC_DATA;

#pragma pack(1)
typedef struct _PASSENGER_SYNC_DATA
{
	VEHICLEID VehicleID;
	BYTE byteSeatFlags : 7;
	BYTE byteDriveBy : 1;
	BYTE byteCurrentWeapon;
	BYTE bytePlayerHealth;
	BYTE bytePlayerArmour;
	WORD lrAnalog;
	WORD udAnalog;
	WORD wKeys;
	float vecPos[3];
} PASSENGER_SYNC_DATA;

enum eWeaponState
{
	WS_NO_BULLETS = 0,
	WS_LAST_BULLET = 1,
	WS_MORE_BULLETS = 2,
	WS_RELOADING = 3,
};

#pragma pack(1)
typedef struct _AIM_SYNC_DATA
{
	BYTE byteCamMode;
	float vecAimf1[3];
	float vecAimPos[3];
	float fAimZ;
	BYTE byteCamExtZoom : 6;	// 0-63 normalized
	BYTE byteWeaponState : 2;	// see eWeaponState
	BYTE bUnk;
} AIM_SYNC_DATA;

#pragma pack(1)
typedef struct _UNOCCUPIED_SYNC_DATA // 67
{
	VEHICLEID VehicleID;
	short cvecRoll[3];
	short cvecDirection[3];
	BYTE unk[13];
	float vecPos[3];
	float vecMoveSpeed[3];
	float vecTurnSpeed[3];
	float fHealth;
} UNOCCUPIED_SYNC_DATA;

enum ConnectionStatus
{
	CONNECTION_ISSUE_BAD_VERSION,
	CONNECTION_ISSUE_BAD_NICKNAME,
	CONNECTION_ISSUE_BAD_MOD,
	CONNECTION_ISSUE_BAD_PLAYERID,
	CONNECTION_CLOSED,
	CONNECTION_FAILED,
	CONNECTION_BANNED,
	CONNECTION_REJECTED,
	CONNECTION_BAD_PASSWORD,
	CONNECTION_LOST,
	CONNECTION_SUCCESS,//everything went smoothly
	SERVER_FULL,
	GAME_JOINED//we're not done yet...
};

class NPC
{
private:
	bool Connected;
	bool ConnectionRequested;
	bool Spawned;
	bool GameInited;

	std::string nickname;
	PLAYERID PlayerID;
	VEHICLEID VehicleID;
	bool Passenger;

	std::string host;
	unsigned short port;
	std::string password;
	int sampConnect();
	void sampDisconnect(bool Timeout);
	void sampRequestClass(int iClass);
	void sampSpawn();
	void RegisterRPCs();
	void UnRegisterRPCs();
#ifdef RAKSAMP_CLIENT
	void Packet_AUTH_KEY(Packet *p);
	void Packet_ConnectionSucceeded(Packet *p);
	RakClientInterface *pRakClient;
#endif
public:
#ifdef RAKSAMP_CLIENT
	void Tick();
	void DoInitDone();
#endif
	PLAYERID GetPlayerID();
	VEHICLEID GetVehicle();
	bool IsPassenger();
	void Disconnect(bool timeout);
	void RequestClass(int classid);
	void Spawn();
	///////////////////
	ONFOOT_SYNC_DATA		onfoot_data;
	INCAR_SYNC_DATA			incar_data;
	PASSENGER_SYNC_DATA		passenger_data;
	AIM_SYNC_DATA			aim_data;
	///////////////////
	NPC();
	~NPC();
	std::string &Nickname();
	std::string &Password();
	unsigned short &Port();
	bool IsConnected();
	void Reconnect(bool timeout);
	void SendFoot(int sendDeathNoti);
	void SendCar();
	void SendPassenger();
	void SendAim(DWORD dwAmmoInClip, int iReloading);
	void EnterVehicle(VEHICLEID VehicleID, BYTE bPassenger);
	void ExitVehicle();
	void SendDeath(BYTE byteDeathReason, PLAYERID WhoWasResponsible);
	void SendVehicleDeath(VEHICLEID VehicleID);
	void SendVehicleDamage(WORD vehicleID, DWORD panel, DWORD door, BYTE lights, BYTE tires);
	virtual void OnConnectionStatusUpdate(ConnectionStatus status);
};

namespace NPCplugin
{
	int Init();
	void Tick();
}
