#include "main.h"
#include "pmain.h"
#include "plugin.h"

#include <stdlib.h>
#include <string.h>
#include <time.h>

logprintf_t
	logprintf;

extern void
	*pAMXFunctions;

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

#include <string>
#include <concurrent_queue.h>
#include <unordered_set>
#include <unordered_map>
#include <boost/thread.hpp>
#include <boost/variant.hpp>
#include <atomic>

std::unordered_map<AMX*,int> Scripts;

#include "npc.h"

struct Position4D
{
	float 
		x,
		y,
		z,
		a;
};

class NPCLogic;

enum QueueCommand
{
	QueueCommand_SetPos,
	QueueCommand_StatusUpdate,
	QueueCommand_Something
};

typedef std::vector<boost::variant<QueueCommand,Position4D,int,std::string,ConnectionStatus,PLAYERID>> QueueData;
typedef std::pair<NPCLogic*,QueueData> QueueLogic;
concurrency::concurrent_queue<QueueLogic> NPC_cmd_Queue;
concurrency::concurrent_queue<QueueLogic> Server_cmd_Queue;
std::unordered_set<NPCLogic*> NPCs;

class NPCLogic : public NPC
{
public:
	NPCLogic() : NPC()
	{
		ZeroMemory(&onfoot_data,sizeof(ONFOOT_SYNC_DATA));
		ZeroMemory(&incar_data,sizeof(INCAR_SYNC_DATA));
		ZeroMemory(&aim_data,sizeof(AIM_SYNC_DATA));
		ZeroMemory(&passenger_data,sizeof(PASSENGER_SYNC_DATA));
		ZeroMemory(&dest,sizeof(Position4D));
		Moving = false;
		NPCs.insert(this);
		std::cout << "NPCLogic construct" << std::endl;
	}
	~NPCLogic()
	{
		NPCs.erase(this);
	}
	bool Moving;
	Position4D dest;
	void SetPosition(float x, float y, float z)
	{
		std::cout << "NPCLogic setpos" << std::endl;
		if(GetVehicle())
		{
			if(!IsPassenger())
			{
				incar_data.vecPos[0] = x;
				incar_data.vecPos[1] = y;
				incar_data.vecPos[2] = z;
			}
		}
		else
		{
			onfoot_data.vecPos[0] = x;
			onfoot_data.vecPos[1] = y;
			onfoot_data.vecPos[2] = z;
		}
	}
	void OnConnectionStatusUpdate(ConnectionStatus status)
	{
		std::cout << "NPCLogic connectionstatusupdate: " << status << std::endl;
		if(status == CONNECTION_SUCCESS)
		{
			RequestClass(0);
			Spawn();
		}
		QueueData data;
		data.push_back(QueueCommand_StatusUpdate);
		data.push_back(status);
		data.push_back(GetPlayerID());
		NPC_cmd_Queue.push(QueueLogic(this,data));
	}
	void Process()
	{
		//
	}
};

std::atomic<bool> Running = true;
boost::thread * worker = nullptr;

void NPCThread()
{
	if(NPCplugin::Init())
	{
		logprintf("SAMP.dll and/or BASS.dll missing or unreadable!");
		delete worker;
		return;
	}
	std::cout << "NPCLogic start thread" << std::endl;
	while(Running)
	{	
		QueueLogic data;
		if(Server_cmd_Queue.try_pop(data))
		{
			switch(boost::get<QueueCommand>(data.second[0]))
			{
			case QueueCommand_SetPos:
				data.first->SetPosition(boost::get<Position4D>(data.second[1]).x,boost::get<Position4D>(data.second[1]).y,boost::get<Position4D>(data.second[1]).z);
				break;
			default:

				break;
			}
		}
		for(auto &npc: NPCs)
		{
			npc->Process();
			npc->Tick();
		}
		boost::this_thread::sleep(boost::posix_time::microseconds(10000));
	}
}

PLUGIN_EXPORT bool PLUGIN_CALL Load(void **ppData)
{
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	logprintf = (logprintf_t)ppData[PLUGIN_DATA_LOGPRINTF];
	logprintf("Gamer_Z's NPC system is loading...");
	worker = new boost::thread(NPCThread);
	logprintf("Gamer_Z's NPC system loaded");
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload()
{
	Running = false;
	if(worker)
	{
		worker->join();
		delete worker;
	}
	for(auto &npc: NPCs)
		npc->Disconnect(0);
	logprintf("Gamer_Z's NPC system unloaded");
}

PLUGIN_EXPORT void PLUGIN_CALL ProcessTick()
{
	QueueLogic TickData;
	if(NPC_cmd_Queue.try_pop(TickData))
	{
		switch(boost::get<QueueCommand>(TickData.second[0]))
		{
		case QueueCommand_StatusUpdate:
			for(auto &callback: Scripts)
			{
				amx_Push(callback.first,static_cast<cell>(boost::get<PLAYERID>(TickData.second[2])));
				amx_Push(callback.first,static_cast<cell>(boost::get<ConnectionStatus>(TickData.second[1])));
				amx_Push(callback.first,reinterpret_cast<cell>(TickData.first));
				amx_Exec(callback.first,NULL,callback.second);
			}
			break;
		default:

			break;
		}
	}	
}

std::string AmxStr(AMX * amx, cell params)
{
	char * temp = new char[128];
	amx_StrParam(amx,params,temp);
	std::string stemp(temp);
	delete []temp;
	return stemp;
}

static cell AMX_NATIVE_CALL GAMER_NPC_TryConnect(AMX *amx, cell *params)
{
	NPCLogic* npc = new NPCLogic();
	//npc->Nickname().assign(AmxStr(amx,params[1]));
	//npc->Password().assign(AmxStr(amx,params[2]));
	//npc->Port() = params[3];
	npc->Nickname().assign("TestBot");
	npc->Password().assign("");
	npc->Port() = 7777;
	return reinterpret_cast<cell>(npc);
}

static cell AMX_NATIVE_CALL GAMER_NPC_SetPosition(AMX *amx, cell *params)
{
	QueueLogic data;
	data.first = reinterpret_cast<NPCLogic*>(params[1]);
	data.second.push_back(QueueCommand_SetPos);
	Position4D temp;
	temp.x = amx_ctof(params[2]);
	temp.y = amx_ctof(params[3]);
	temp.z = amx_ctof(params[4]);
	data.second.push_back(temp);
	Server_cmd_Queue.push(data);
	return 1;
}

AMX_NATIVE_INFO Natives[] =
{
	// Generic
	{"GAMER_NPC_TryConnect",	GAMER_NPC_TryConnect},
	{"GAMER_NPC_SetPosition",	GAMER_NPC_SetPosition},

	{0,			0}
};


PLUGIN_EXPORT int PLUGIN_CALL AmxLoad(AMX *amx) 
{
	static int index;
	if (!amx_FindPublic( amx, "Gamer_Z_NPC_StatusUpdate", &index))
		Scripts.insert(std::pair<AMX*,int>(amx,index));
	return amx_Register(amx, Natives, -1);
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload(AMX *amx) 
{
	Scripts.erase(amx);
	return AMX_ERR_NONE;
}
