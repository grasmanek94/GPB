#ifndef SAMPGDK_PLUGIN_H
#define SAMPGDK_PLUGIN_H
#pragma once

#include <sampgdk/config.h>
#include <sampgdk/amx.h>
#include <sampgdk/core.h>
#include <sampgdk/sdk/plugincommon.h>

#endif /* !SAMPGDK_PLUGIN_H */
