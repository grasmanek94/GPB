#include <sampgdk/config.h>
#include <sampgdk/amx/amx.h>
