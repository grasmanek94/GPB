UnlimitedFS allows you to run an unlimited amount of filterscripts and 
plugins. It loads ALL filterscripts and plugins from "filterscripts/" 
and "plugins/" directories respectively. Therefore you don't have to
edit server.cfg each time you add something. 

However UnlimitedFS doesn't handle RCON commands like "loadfs", etc, 
so there's a room for improvement.
