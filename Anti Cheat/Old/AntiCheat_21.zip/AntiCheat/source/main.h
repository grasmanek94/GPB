using namespace std;  

#define PI (314159265/100000000)

#define WEAPONS (55)

//
#define AC_DETECTED_DISABLED_WEAPON (0)
#define AC_DETECTED_JETPACK 		(1)
#define AC_DETECTED_SPAWNED_WEAPON  (3)
#define AC_DETECTED_SPEEDHACK		(4)
#define AC_DETECTED_MASSCARSPAWN	(5)

#define PLUGIN_PRIVATE_UPDATE_AC (45)

int IsWeaponAllowed[MAX_PLAYERS][WEAPONS];
int CheckWeapon = 1;
int IsJetpackAllowed[MAX_PLAYERS];
int CheckJetpack = 1;
int HasWeapon[MAX_PLAYERS][WEAPONS];
int SpawnWeaponCheck = 1;
int SpeedCheck = 1;
int g_Ticked = 0;
int g_TickMax = PLUGIN_PRIVATE_UPDATE_AC;
int Classes[500][3];
int ClassWp[500][3];
int CheckSpeedSwitch = 1;
bool PlaneState[500];
int PlayerEnterTime[MAX_PLAYERS];

vector<int> PlayerLoopList;

list <AMX *> amx_list;

int p_fix_Player(int playerid);
bool IsWeaponClassAllowed(int playerid,int weaponid);
int p_AddPlayerClassEx(int team,int skin, float x, float y, float z, float Angle, int weapon1, int weapon1_ammo, int weapon2, int weapon2_ammo, int weapon3, int weapon3_ammo);
int p_AddPlayerClass(int skin, float x, float y, float z, float Angle, int weapon1, int weapon1_ammo, int weapon2, int weapon2_ammo, int weapon3, int weapon3_ammo);
int AC_OnCheatDetected(int playerid,int type, int extraid);

int amxerr = (-1),amx_idx;