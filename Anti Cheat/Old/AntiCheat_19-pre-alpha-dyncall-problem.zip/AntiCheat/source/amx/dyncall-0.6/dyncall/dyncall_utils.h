#ifndef DYNCALL_UTILS_H
#define DYNCALL_UTILS_H

/* C portable macros. */

#ifndef DC_MAX
#define DC_MAX(a,b) ((a)>=(b))?(a):(b)
#endif

#endif /* DYNCALL_UTILS_H */

