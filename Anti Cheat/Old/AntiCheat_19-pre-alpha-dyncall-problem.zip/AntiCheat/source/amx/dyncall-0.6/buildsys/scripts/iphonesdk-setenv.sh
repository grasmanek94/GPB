#!/bin/sh
export PATH=/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin:${PATH}

