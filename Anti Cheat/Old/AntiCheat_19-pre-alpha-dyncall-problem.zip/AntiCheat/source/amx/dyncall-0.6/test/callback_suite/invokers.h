void DoInvoke(int index, void* addr);
