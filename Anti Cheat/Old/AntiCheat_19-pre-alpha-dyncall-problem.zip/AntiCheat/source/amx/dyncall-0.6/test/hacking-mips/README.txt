here are some snippets that helped when exploring the mips abis.
