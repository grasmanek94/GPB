typedef float f;
f _ffffffffff(f f0, f f1, f f2, f f3, f f4, f f5, f f6, f f7, f f8, f f9)
{
  return f0+f1+f2+f3+f4+f5+f6+f7+f8+f9;
}

