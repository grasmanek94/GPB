#include "common.h"

void l0() { }
void l1(int a) { }
void l2(int a, int b) { }
void l4(int a, int b, int c, int d) { }
void l8(int a, int b, int c, int d, int e, int f, int g, int h) { }

void n0() { ext(); }
void n1(int a) { ext(); }
void n2(int a, int b) { ext(); }
void n4(int a, int b, int c, int d) { ext(); }
void n8(int a, int b, int c, int d, int e, int f, int g, int h) { ext(); }

