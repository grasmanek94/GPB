int p_fix_Player(int playerid);
bool IsWeaponClassAllowed(int playerid,int weaponid);
int p_AddPlayerClassEx(int team,int skin, float x, float y, float z, float Angle, int weapon1, int weapon1_ammo, int weapon2, int weapon2_ammo, int weapon3, int weapon3_ammo);
int p_AddPlayerClass(int skin, float x, float y, float z, float Angle, int weapon1, int weapon1_ammo, int weapon2, int weapon2_ammo, int weapon3, int weapon3_ammo);
int AC_OnCheatDetected(int playerid,int type, int extraid);
