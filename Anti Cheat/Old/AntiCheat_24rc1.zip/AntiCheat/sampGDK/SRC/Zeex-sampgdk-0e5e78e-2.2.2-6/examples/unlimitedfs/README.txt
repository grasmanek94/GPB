unlimitedfs plugin allows you to run an unlimited amount of filterscripts (and plugins).

It loads ALL filterscripts located at "filterscripts/" and ALL plugins from "plugins/", 
hence there's no need to edit server.cfg every time something is added.

unlimitedfs doesn't handle RCON commands like loadfs/unloadfs, so there's a room for improvement.
