#define PLUGIN_REVISION_R (24)
/*
* Includes
*/
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <cstring>
#include <limits>
#include <sstream>
#include <list>

#include <sampgdk/core.h>
#include <sampgdk/players.h>
#include <sampgdk/plugin.h>
#include <sampgdk/vehicles.h>
#include <sampgdk/samp.h>
//-------------------------------------------//
#undef MAX_PLAYERS
#define MAX_PLAYERS (800)
#include "vehiclespeedlist.var"
#include "main.h"

int AC_OnCheatDetected(int playerid,int type, int extraid)
{
	for(list <AMX *>::iterator i = amx_list.begin(); i != amx_list.end(); ++i)
	{
		amxerr = amx_FindPublic(*i, "AC_OnCheatDetected", &amx_idx);
		if (amxerr == AMX_ERR_NONE)
		{
			amx_Push(* i, extraid);
			amx_Push(* i, type);
			amx_Push(* i, playerid);
			amx_Exec(* i, NULL, amx_idx);
			return 1;
		}
	}
    return 0;
}

//forward AC_OnCheatDetected(playerid,cheat_type,ac_extra);
//native ACget_UpdateDelay();
static cell AMX_NATIVE_CALL GetAntiCheatUpdateDelay( AMX* amx, cell* params )
{
	return g_TickMax;
}
//native ACget_JetpackAllowed(playerid = 0);
static cell AMX_NATIVE_CALL get_JetpackAllowed( AMX* amx, cell* params )
{
	return IsJetpackAllowed[params[1]];
}
//native ACset_UpdateDelay(ac_ticks);
static cell AMX_NATIVE_CALL SetAntiCheatUpdateDelay( AMX* amx, cell* params )
{
	int gg_divider = params[1];
	if(params[1] >= 1000)
	{
		gg_divider = 1000;
	}else
	if(params[1] <= 5)
	{
		gg_divider = 5;
	}else
	g_TickMax = gg_divider;
	return 1;
}
//native ACset_AllowedWeapon(weaponid,ac_status = 1,playerid = (-1));
static cell AMX_NATIVE_CALL SetAntiCheatAllowedWeapon( AMX* amx, cell* params )
{
	if(params[3] == (-1))
	{
		int i;
		for(i = 0; i < MAX_PLAYERS; i++)
		{
			IsWeaponAllowed[i][params[1]] = params[2];
		}
	}
	else
	{
		IsWeaponAllowed[params[3]][params[1]] = params[2];
	}
	return 1;
}
//native ACget_AllowedWeapon(weaponid,playerid = 0);
static cell AMX_NATIVE_CALL GetAntiCheatAllowedWeapon( AMX* amx, cell* params )
{
	return IsWeaponAllowed[params[2]][params[1]];
}
//native ACset_JetpackAllowed(ac_status = 1,playerid = (-1));
static cell AMX_NATIVE_CALL set_JetpackAllowed( AMX* amx, cell* params )
{
	if(params[2] == (-1))
	{
		int i;
		for(i = 0; i < MAX_PLAYERS; i++)
		{
			IsJetpackAllowed[i] = params[1];
		}
	}
	else
	{
		IsJetpackAllowed[params[2]] = params[1];
	}
	return 1;
}

//native ACset_SpeedCheck(ac_enable = 1);
static cell AMX_NATIVE_CALL set_SpeedCheck( AMX* amx, cell* params )
{
	SpeedCheck = params[1];
	return 1;
}
//native ACget_SpeedCheck();
static cell AMX_NATIVE_CALL get_SpeedCheck( AMX* amx, cell* params )
{
	return SpeedCheck;
}
//native ACset_WeaponCheck(ac_enable = 1);
static cell AMX_NATIVE_CALL set_WeaponCheck( AMX* amx, cell* params )
{
	CheckWeapon = params[1];
	return 1;
}
//native ACreset_PlayerMoney(playerid);
static cell AMX_NATIVE_CALL reset_PlayerMoney( AMX* amx, cell* params )
{
	if(params[1] < 0 || params[1] >= MAX_PLAYERS)return 0;
	PlayerMoney[params[1]] = 0;
	ResetPlayerMoney(params[1]);
	return 1;
}
//native ACset_JetpackCheck(ac_enable = 1);
static cell AMX_NATIVE_CALL set_JetpackCheck( AMX* amx, cell* params )
{
	CheckJetpack = params[1];
	return 1;
}
//native ACget_WeaponCheck();
static cell AMX_NATIVE_CALL get_WeaponCheck( AMX* amx, cell* params )
{
	return CheckWeapon;
}
//native ACget_JetpackCheck();
static cell AMX_NATIVE_CALL get_JetpackCheck( AMX* amx, cell* params )
{
	return CheckJetpack;
}
//native ACgive_PlayerWeapon(playerid, weaponid, ammo);
static cell AMX_NATIVE_CALL ACgive_PlayerWeapon( AMX* amx, cell* params )
{
	HasWeapon[params[1]][params[2]] = 1;
	GivePlayerWeapon(params[1],params[2],params[3]);
	return 1;
}
//native ACreset_PlayerWeapons(playerid);
static cell AMX_NATIVE_CALL ACreset_PlayerWeapons( AMX* amx, cell* params )
{
	ResetPlayerWeapons(params[1]);
	int i;
	for(i = 0; i < WEAPONS; i++)HasWeapon[params[1]][i] = 0;
	return 1;
}
//native ACset_SpawnWeaponCheck(enable = 1);
static cell AMX_NATIVE_CALL ACset_SpawnWeaponCheck( AMX* amx, cell* params )
{
	SpawnWeaponCheck = params[1];
	return 1;
}

//native ACget_SpawnWeaponCheck();
static cell AMX_NATIVE_CALL ACget_SpawnWeaponCheck( AMX* amx, cell* params )
{
	return SpawnWeaponCheck;
}

int milisecondsSpeedSwitch = 110;
//native ACset_SpeedCarChangeCheck(enable = 1, miliseconds = 110);
static cell AMX_NATIVE_CALL ACset_SpeedCarChangeCheck( AMX* amx, cell* params )
{
	CheckSpeedSwitch = params[1];
	milisecondsSpeedSwitch = params[2];
	return CheckSpeedSwitch;
}

//native AC_AddPlayerClass(modelid, Float:spawn_x, Float:spawn_y, Float:spawn_z, Float:z_angle, weapon1, weapon1_ammo, weapon2, weapon2_ammo, weapon3, weapon3_ammo);
static cell AMX_NATIVE_CALL n_AddPlayerClass( AMX* amx, cell* params )
{
	return p_AddPlayerClass(params[1],amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4]),amx_ctof(params[5]),params[6],params[7],params[8],params[9],params[10],params[11]);
}
//native AC_AddPlayerClassEx(teamid, modelid, Float:spawn_x, Float:spawn_y, Float:spawn_z, Float:z_angle, weapon1, weapon1_ammo, weapon2, weapon2_ammo, weapon3, weapon3_ammo);
static cell AMX_NATIVE_CALL n_AddPlayerClassEx( AMX* amx, cell* params )
{
	return p_AddPlayerClassEx(params[1],params[2],amx_ctof(params[3]),amx_ctof(params[4]),amx_ctof(params[5]),amx_ctof(params[6]),params[7],params[8],params[9],params[10],params[11],params[12]);
}

#define PLUGIN_HAS_NO_HOOK

#if defined PLUGIN_HAS_NO_HOOK
bool OnPlayerConnect(int playerid)
#else
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerConnect(int playerid)
#endif
{
	int size = PlayerLoopList.size();
	for (int index=0; index < size; ++index)
	{
		if(PlayerLoopList.at(index) == playerid)
		{
			return true;
		}
	}
	p_fix_Player(playerid);
	PlayerMoney[playerid] = 0;
	PlayerEnterTime[playerid] = 0;
	PlayerLoopList.push_back(playerid);	
	return true;
}

#if defined PLUGIN_HAS_NO_HOOK
bool OnPlayerDisconnect(int playerid, int reason)
#else
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerDisconnect(int playerid, int reason)
#endif
{
	PlayerMoney[playerid] = 0;
	int size = PlayerLoopList.size();
	for (int index=0; index < size; ++index)
	{
		if(PlayerLoopList.at(index) == playerid)
		{
			PlayerLoopList.erase(PlayerLoopList.begin()+index);
			break;
		}
	}
	return true;
}

#if defined PLUGIN_HAS_NO_HOOK
bool OnPlayerSpawn(int playerid)
#else
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerSpawn(int playerid)
#endif
{
	int skin = GetPlayerSkin(playerid);
	if(ClassWp[skin][0] > 0)
	{
		HasWeapon[playerid][Classes[skin][0]] = 1;
	}
	if(ClassWp[skin][1] > 0)
	{
		HasWeapon[playerid][Classes[skin][1]] = 1;
	}
	if(ClassWp[skin][2] > 0)
	{
		HasWeapon[playerid][Classes[skin][2]] = 1;
	}
	return true;
}

#if defined PLUGIN_HAS_NO_HOOK
bool OnPlayerStateChange(int playerid, int newstate, int oldstate)
#else
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerStateChange(int playerid, int newstate, int oldstate)
#endif
{
	//char szmsg[256];
	//sprintf(szmsg,"1) OnPlayerStateChange(%d,%d,%d); [OLD]LastKnownVehicle[%d] = %d; [NEW]LastKnownVehicle[%d] = %d;",playerid,newstate,oldstate,playerid,LastKnownVehicle[playerid],playerid,GetPlayerVehicleID(playerid));
	//SendClientMessageToAll(-1,szmsg);
	LastKnownVehicle[playerid] = GetPlayerVehicleID(playerid);
	if( newstate == PLAYER_STATE_DRIVER)
	{	
		if(CheckSpeedSwitch == 1)
		{
			PlayerEnterTime[playerid] = GetServerTickCount();
		}
		for( int i = 0, pid, size = PlayerLoopList.size(); i < size; ++i )
		{
			pid = PlayerLoopList.at(i);
			if( LastKnownVehicle[ playerid ] == LastKnownVehicle[ pid ] && GetPlayerState( pid ) == PLAYER_STATE_ONFOOT )
			{
				AC_OnCheatDetected(playerid,AC_DETECTED_HACK_CARJACK,0);
			}
		}
	}
	else
	{
		if(oldstate == PLAYER_STATE_DRIVER)
		{
			if((GetServerTickCount()-PlayerEnterTime[playerid]) < milisecondsSpeedSwitch)//player entered and exited vehicle faster than 220 ms.
			{
				AC_OnCheatDetected(playerid,AC_DETECTED_MASSCARSPAWN,0);
			}
		}
	}
	return true;
}

#if defined PLUGIN_HAS_NO_HOOK
bool OnPlayerUpdate(int playerid)
#else
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerUpdate(int playerid)
#endif
{
	if(DisableOnPlayerUpdateCheck)return true;
	//Credits go to Sasuke78200 for explaining me why so, and how to detect this kind of cheats
	if( GetPlayerState( playerid ) == PLAYER_STATE_DRIVER && LastKnownVehicle[ playerid ] != GetPlayerVehicleID( playerid ) )
	{
		AC_OnCheatDetected(playerid,AC_DETECTED_REMOTE_CONTROL,0);
	}
	return true;
}

#if defined PLUGIN_HAS_NO_HOOK
static cell AMX_NATIVE_CALL n_OnPlayerConnect( AMX* amx, cell* params )
{
	OnPlayerConnect(params[1]);
	return 1;
}

static cell AMX_NATIVE_CALL n_OnPlayerDisconnect( AMX* amx, cell* params )
{
	OnPlayerDisconnect(params[1],params[2]);
	return 1;
}

static cell AMX_NATIVE_CALL n_OnPlayerSpawn( AMX* amx, cell* params )
{
	OnPlayerSpawn(params[1]);
	return 1;
}

static cell AMX_NATIVE_CALL n_OnPlayerStateChange( AMX* amx, cell* params )
{
	OnPlayerStateChange(params[1],params[2],params[3]);
	return 1;
}

AMX * sparta = NULL;
static cell AMX_NATIVE_CALL n_OnPlayerUpdate( AMX* amx, cell* params )
{
	if(amx == sparta)
	{
		OnPlayerUpdate(params[1]);
	}
	return 1;
}
#endif

static cell AMX_NATIVE_CALL n_DisableCarJackCheck( AMX* amx, cell* params )
{
	DisableOnPlayerUpdateCheck = true;
	return 1;
}

static cell AMX_NATIVE_CALL n_EnableCarJackCheck( AMX* amx, cell* params )
{
	DisableOnPlayerUpdateCheck = true;
	return 1;
}

static cell AMX_NATIVE_CALL n_ThisIsSpartaLOL( AMX* amx, cell* params )
{
	sparta = amx;
	return 1;
}

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

bool GivesParachute[612];

PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{
	sampgdk_initialize(ppData);
	for(int i = 0; i < 612; ++i)
	{
		GivesParachute[i] = false;
	}

	GivesParachute[417] = true;
	GivesParachute[425] = true;
	GivesParachute[447] = true; 
	GivesParachute[460] = true; 
	GivesParachute[469] = true; 
	GivesParachute[476] = true; 
	GivesParachute[487] = true; 
	GivesParachute[488] = true; 
	GivesParachute[497] = true; 
	GivesParachute[511] = true; 
	GivesParachute[512] = true; 
	GivesParachute[513] = true; 
	GivesParachute[519] = true; 
	GivesParachute[520] = true; 
	GivesParachute[553] = true; 
	GivesParachute[548] = true; 
	GivesParachute[563] = true; 
	GivesParachute[577] = true; 
	GivesParachute[592] = true; 
	GivesParachute[593] = true; 

	for(int i = 0; i < MAX_PLAYERS; ++i)
	{
		PlaneState[i] = 0;
		for(int a = 0; a < 55; ++a)
		{
			IsWeaponAllowed[i][a] = 1;
		}
	}
	cout << "---Loading---\r\n\tGamer_Z's Project Bundle: \r\n\t\tAnti Cheat R" << PLUGIN_REVISION_R << "\r\n---LOADED---";
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	cout << "---Unloading---\r\n\tGamer_Z's Project Bundle: \r\n\t\tAnti Cheat\r\n---UNLOADED---";
}

static cell AMX_NATIVE_CALL GetACVersion( AMX* amx, cell* params )
{
	return PLUGIN_REVISION_R;
}

static cell AMX_NATIVE_CALL ACaddMassTimer( AMX* amx, cell* params )
{
	PlayerEnterTime[params[1]] += milisecondsSpeedSwitch+1;
	return 1;
}
//native AC_PlayerHasWeapon(playerid, weaponid);
static cell AMX_NATIVE_CALL ACGet_PlayerWeapon( AMX* amx, cell* params )
{
	if(params[1] >= MAX_PLAYERS || params[1] < 0)
		return (-1);
	int weapon = GetPlayerWeapon(params[1]);
	if ( HasWeapon[params[1]][weapon] == 1 )
		return 1;
	else return 0;
}

//native ACget_PlayerWeapon(playerid);
static cell AMX_NATIVE_CALL ACGet_PlayerWeaponEx( AMX* amx, cell* params )
{
	int weapon = GetPlayerWeapon(params[1]);
	if ( HasWeapon[params[1]][weapon] == 1 )
		return weapon;
	else return 0;
}

AMX_NATIVE_INFO AMXNatives[ ] =
{
	{"ACget_PlayerWeapon",ACGet_PlayerWeaponEx},
	{"AC_PlayerHasWeapon",ACGet_PlayerWeapon},
	{"ACset_UpdateDelay", SetAntiCheatUpdateDelay},
	{"ACget_UpdateDelay", GetAntiCheatUpdateDelay},

	{"ACset_AllowedWeapon", SetAntiCheatAllowedWeapon},
	{"ACget_AllowedWeapon", GetAntiCheatAllowedWeapon},

	{"ACget_JetpackAllowed", get_JetpackAllowed},
	{"ACset_JetpackAllowed", set_JetpackAllowed},

	{"ACset_WeaponCheck", set_WeaponCheck},
	{"ACset_JetpackCheck", set_JetpackCheck},

	{"ACget_WeaponCheck", get_WeaponCheck},
	{"ACget_JetpackCheck", get_JetpackCheck},

	{"ACgive_PlayerWeapon", ACgive_PlayerWeapon},
	{"ACreset_PlayerWeapons", ACreset_PlayerWeapons},
	{"ACset_SpawnWeaponCheck",ACset_SpawnWeaponCheck},
	{"ACget_SpawnWeaponCheck",ACget_SpawnWeaponCheck},

	{"ACget_SpeedCheck",get_SpeedCheck},
	{"ACset_SpeedCheck",set_SpeedCheck},

	{"AC_AddPlayerClassEx",n_AddPlayerClassEx},
	{"AC_AddPlayerClass",n_AddPlayerClass},

	{"GPB_AntiCheatVersion",GetACVersion},

	{"AC_addMassTimer",ACaddMassTimer},
	{"ACset_SpeedCarChangeCheck",ACset_SpeedCarChangeCheck},

	//
	#if defined PLUGIN_HAS_NO_HOOK
	{"AC_OnPlayerConnect",n_OnPlayerConnect},
	{"AC_OnPlayerDisconnect",n_OnPlayerDisconnect},
	{"AC_OnPlayerSpawn",n_OnPlayerSpawn},
	{"AC_OnPlayerStateChange",n_OnPlayerStateChange},
	{"AC_OnPlayerUpdate",n_OnPlayerUpdate},
	#endif
	{"AC_ThisIsSPARTA",n_ThisIsSpartaLOL},
	{"AC_EnableCarJackCheck",n_DisableCarJackCheck},
	{"AC_DisableCarJackCheck",n_EnableCarJackCheck},

	{0,                0}
};

// From "amx.c", part of the PAWN language runtime:
// http://code.google.com/p/pawnscript/source/browse/trunk/amx/amx.c

#define USENAMETABLE(hdr) \
	((hdr)->defsize==sizeof(AMX_FUNCSTUBNT))

#define NUMENTRIES(hdr,field,nextfield) \
	(unsigned)(((hdr)->nextfield - (hdr)->field) / (hdr)->defsize)

#define GETENTRY(hdr,table,index) \
	(AMX_FUNCSTUB *)((unsigned char*)(hdr) + (unsigned)(hdr)->table + (unsigned)index*(hdr)->defsize)

#define GETENTRYNAME(hdr,entry) \
	(USENAMETABLE(hdr) ? \
		(char *)((unsigned char*)(hdr) + (unsigned)((AMX_FUNCSTUBNT*)(entry))->nameofs) : \
		((AMX_FUNCSTUB*)(entry))->name)

//AMX_NATIVE
//	x_GivePlayerMoney;
//AMX_NATIVE
//	x_GetPlayerMoney;

static cell AMX_NATIVE_CALL
	n_GivePlayerMoney(AMX * amx, cell * params)
{
	if(params[1] < 0 || params[1] >= MAX_PLAYERS)return 0;
	PlayerMoney[params[1]] += params[2];
	//cout << "vcalled!\n";
	return GivePlayerMoney(params[1],PlayerMoney[params[1]]-GetPlayerMoney(params[1]));
}

static cell AMX_NATIVE_CALL
	n_GetPlayerMoney(AMX * amx, cell * params)
{
	if(params[1] < 0 || params[1] >= MAX_PLAYERS)return 0;
	//cout << "gcalled!\n";
	return PlayerMoney[params[1]];
}

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	//Code from sscanf2.5, [PAWN]SSCANF Author: Y_Less
	int
		num,
		idx;
	// Operate on the raw AMX file, don't use the amx_ functions to avoid issues
	// with the fact that we've not actually finished initialisation yet.  Based
	// VERY heavilly on code from "amx.c" in the PAWN runtime library.
	AMX_HEADER *
		hdr = (AMX_HEADER *)amx->base;
	AMX_FUNCSTUB *
		func;
	num = NUMENTRIES(hdr, natives, libraries);
	bool found[3] = {false,false,false};
	for (idx = 0; idx != num; ++idx)
	{
		func = GETENTRY(hdr, natives, idx);
		if (!strcmp("GetPlayerMoney", GETENTRYNAME(hdr, func)))
		{
			// Intercept the call!
			//x_GetPlayerMoney = (AMX_NATIVE)func->address;
			func->address = (ucell)n_GetPlayerMoney;
			found[0] = true;
		}
		if (!strcmp("GivePlayerMoney", GETENTRYNAME(hdr, func)))
		{
			// Intercept the call!
			//x_GivePlayerMoney = (AMX_NATIVE)func->address;
			func->address = (ucell)n_GivePlayerMoney;
			found[1] = true;
		}
		if (!strcmp("ResetPlayerMoney", GETENTRYNAME(hdr, func)))
		{
			// Intercept the call!
			//x_ResetPlayerMoney = (AMX_NATIVE)func->address;
			func->address = (ucell)reset_PlayerMoney;
			found[2] = true;
		}
		if(found[0] == true && found[1] == true && found[2] == true)break;
	}
	//End of sscanf cut
	amx_list.push_back(amx);
	return amx_Register( amx, AMXNatives, -1 );
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	amx_list.remove(amx);
	return AMX_ERR_NONE;
}

float s[3];
char sz[64];

PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick()
{
	if(g_Ticked == g_TickMax)
	{
		int playerid = 0;	
		int action = 0;
		int size = PlayerLoopList.size();
		int weaponid = 0, ammo = 0, i = 0;
		for (int index = 0; index < size; ++index)
		{
			playerid = PlayerLoopList.at(index);
			if(IsPlayerInAnyVehicle(playerid))
			{
				if(GivesParachute[GetVehicleModel(GetPlayerVehicleID(playerid))] == true)
				{
					PlaneState[playerid] = true;
				}
				else
				{
					PlaneState[playerid] = false;
				}
			}
			if(SpeedCheck == 1)
			{
				if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
				{
					int vid = GetPlayerVehicleID(playerid);
					GetVehicleVelocity(vid,&s[0],&s[1],&s[2]);
					s[0] *= s[0];
					s[1] *= s[1];
					s[2] *= s[2];
					if(sqrt(s[0]+s[1]+s[2])*175.0f > (MaxVehicleSpeed[GetVehicleModel(vid)]+6.75f))
					{
						if(sqrt(s[0]+s[1])*175.0f > 50.0 && s[2] > 0)
						{
							AC_OnCheatDetected(playerid,AC_DETECTED_SPEEDHACK,GetPlayerVehicleID(playerid));
						}
						continue;
					}
				}
			}
			if(CheckWeapon == 1)
			{
				if(SpawnWeaponCheck == 1)
				{
					for(i = 0; i < 13; i++)
					{
						GetPlayerWeaponData(playerid,i,&weaponid,&ammo);
						if(ammo > 0 && weaponid != 0)
						{
							if(IsWeaponAllowed[playerid][weaponid] == 0)
							{
								if(IsWeaponClassAllowed(playerid,weaponid) == false)
								{
									if(weaponid == 46)
									{
										if(PlaneState[playerid] == true)
										{
											IsWeaponAllowed[playerid][weaponid] = 1;
											PlaneState[playerid] = false;
										}
										else
										{
											AC_OnCheatDetected(playerid,AC_DETECTED_DISABLED_WEAPON,weaponid);
										}
									}
									else
									{
										AC_OnCheatDetected(playerid,AC_DETECTED_DISABLED_WEAPON,weaponid);
									}
								}
								continue;
							}else
							if(HasWeapon[playerid][weaponid] == 0)
							{
								if(weaponid == 46)
								{
									if(PlaneState[playerid] == true)
									{
										HasWeapon[playerid][weaponid] = 1;
										PlaneState[playerid] = false;
									}
									else
									{
										AC_OnCheatDetected(playerid,AC_DETECTED_SPAWNED_WEAPON,weaponid);
									}
								}
								else
								{
									AC_OnCheatDetected(playerid,AC_DETECTED_SPAWNED_WEAPON,weaponid);
								}
								continue;
							}
						}
					}
				}
				else
				{
					for(i = 0; i < 13; i++)
					{
						GetPlayerWeaponData(playerid,i,&weaponid,&ammo);
						if(ammo > 0 && weaponid != 0)
						{
							if(IsWeaponAllowed[playerid][weaponid] == 0)
							{
								if(IsWeaponClassAllowed(playerid,weaponid) == false)
								{
									AC_OnCheatDetected(playerid,AC_DETECTED_DISABLED_WEAPON,weaponid);
								}
								continue;
							}
						}
					}
				}
			}
			if(CheckJetpack == 1)
			{
				action = GetPlayerSpecialAction(playerid);
				if(action == 2)
				{
					if(IsJetpackAllowed[playerid] == 0)
					{
						AC_OnCheatDetected(playerid,AC_DETECTED_JETPACK,action);
						continue;
					}
				}
			}
		}
		g_Ticked = -1;
	}
	g_Ticked += 1;
}

int p_AddPlayerClass(int skin, float x, float y, float z, float Angle, int weapon1, int weapon1_ammo, int weapon2, int weapon2_ammo, int weapon3, int weapon3_ammo)
{
	Classes[skin][0] = weapon1;
	ClassWp[skin][0] = weapon1_ammo;
	Classes[skin][1] = weapon2;
	ClassWp[skin][1] = weapon2_ammo;
	Classes[skin][2] = weapon3;
	ClassWp[skin][2] = weapon3_ammo;

	return AddPlayerClass(skin,x,y,z,Angle,weapon1,weapon1_ammo,weapon2,weapon2_ammo,weapon3,weapon3_ammo);
}

int p_AddPlayerClassEx(int team,int skin, float x, float y, float z, float Angle, int weapon1, int weapon1_ammo, int weapon2, int weapon2_ammo, int weapon3, int weapon3_ammo)
{
	Classes[skin][0] = weapon1;
	ClassWp[skin][0] = weapon1_ammo;
	Classes[skin][1] = weapon2;
	ClassWp[skin][1] = weapon2_ammo;
	Classes[skin][2] = weapon3;
	ClassWp[skin][2] = weapon3_ammo;

	return AddPlayerClassEx(team,skin,x,y,z,Angle,weapon1,weapon1_ammo,weapon2,weapon2_ammo,weapon3,weapon3_ammo);
}

bool IsWeaponClassAllowed(int playerid,int weaponid)
{
	int skin = GetPlayerSkin(playerid);
	if(Classes[skin][0] == weaponid)return true;
	if(Classes[skin][1] == weaponid)return true;
	if(Classes[skin][2] == weaponid)return true;
	return false;
}

int p_fix_Player(int playerid)
{
	ResetPlayerWeapons(playerid);
	for(int i = 0; i < WEAPONS; i++)HasWeapon[playerid][i] = 0;
	return 1;
}
