#include <sampgdk/plugin.h>
