<?php
	//------------------------//
	$gps_version[0] 	= "173";//plugin
	$gps_version[1] 	= "173";//include
	$gps_version[2] 	= "162";//gps dat
	//------------------------//
	$ac_version[0] 		= "19";//plugin
	$ac_version[1] 		= "20";//include
	//------------------------//
	$drift_version[0] 	= "31";//plugin
	$drift_version[1] 	= "31";//include
	//------------------------//
	$fdlg_version[0] 	= "15";//include
	//------------------------//
	$ndlg_version[0] 	= "12";//include
	//------------------------//
	$name 				= $_GET['name'];
	$version 			= $_GET['version'];
	$port               = $_GET['port'];
    //------------------------//
    $up_to_date = 1;
	if($name == "GPS")
	{
		if($gps_version[0] != $version[0])
		{
		    $up_to_date = 0;
		    echo("		[Route Connector Plugin] Plugin (Current: " . $gps_version[0] . " Your: " . $version[0] . ")\r\n");
		}
		if($gps_version[1] != $version[1])
		{
  			$up_to_date = 0;
		    echo("		[Route Connector Plugin] Include (Current: " . $gps_version[1] . " Your: " . $version[1] . ")\r\n");
		}
		if($gps_version[2] != $version[2])
		{
  			$up_to_date = 0;
		    echo("		[Route Connector Plugin] GPS.dat (Current: " . $gps_version[2] . " Your: " . $version[2] . ")\r\n");
		}
		if($up_to_date == 1)
		{
		    echo("		[Route Connector Plugin] All components are up to date\r\n");
		}
	}
	if($name == "AC")
	{
		if($ac_version[0] != $version[0])
		{
		    $up_to_date = 0;
		    echo("		[Anti Cheat Plugin] Plugin (Current: " . $ac_version[0] . " Your: " . $version[0] . ")\r\n");
		}
		if($ac_version[1] != $version[1])
		{
		    $up_to_date = 0;
		    echo("		[Anti Cheat Plugin] Include (Current: " . $ac_version[1] . " Your: " . $version[1] . ")\r\n");
		}
		if($up_to_date == 1)
		{
		    echo("		[Anti Cheat Plugin] All components are up to date\r\n");
		}
	}
	if($name == "DRIFT")
	{
		if($drift_version[0] != $version[0])
		{
		    $up_to_date = 0;
		    echo("		[Drift Points Counter Plugin] Plugin (Current: " . $drift_version[0] . " Your: " . $version[0] . ")\r\n");
		}
		if($drift_version[1] != $version[1])
		{
		    $up_to_date = 0;
		    echo("		[Drift Points Counter Plugin] Include (Current: " . $drift_version[1] . " Your: " . $version[1] . ")\r\n");
		}
		if($up_to_date == 1)
		{
		    echo("		[Drift Points Counter Plugin] All components are up to date\r\n");
		}
	}
	if($name == "FDLG")
	{
		if($fdlg_version[0] != $version[0])
		{
		    $up_to_date = 0;
		    echo("		[Fast Dialogs Include] Include (Current: " . $fdlg_version[0] . " Your: " . $version[0] . ")\r\n");
		}
		if($up_to_date == 1)
		{
		    echo("		[Fast Dialogs Include] All components are up to date\r\n");
		}
	}
	if($name == "NDLG")
	{
		if($ndlg_version[0] != $version[0])
		{
		    $up_to_date = 0;
		    echo("		[Named Dialogs Include] Include (Current: " . $ndlg_version[0] . " Your: " . $version[0] . ")\r\n");
		}
		if($up_to_date == 1)
		{
		    echo("		[Named Dialogs Include] All components are up to date\r\n");
		}
	}
	$ip = $_SERVER['REMOTE_ADDR'];
	$str = "".$ip.":".$port."|".$name."|".$version[0]."\r\n";
	//do here some code to add "$str" to database/update
//
?>
