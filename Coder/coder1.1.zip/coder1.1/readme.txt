G-code 1.1 ,
Helps you encode information you want and decode it at later time, use table creator to create an unique table for the characters, copy it into the coder project and then compile.
enjoy.

You need .NET Framework 2.0 to run this, download and install it from here:
http://www.microsoft.com/nl-nl/download/details.aspx?id=19
Download the application, run it and follow the on-screen instructions.
