G-code 1.0 ,
Helps you encode information you want and decode it at later time, use table creator to create an unique table for the characters, copy it into the coder project and then compile.
ejoy.