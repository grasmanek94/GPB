#pragma once

class CHook
{
public:
	CHook();
	~CHook();
private:
};