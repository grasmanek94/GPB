/*****************************************************************************
*
*  PROJECT:		Multi Theft Auto v1.0
*  LICENSE:		See LICENSE in the top level directory
*  FILE:		sdk/game/CPedDamageResponseCalculator.h
*  PURPOSE:		ped damage response calculator interface
*  DEVELOPERS:  Jax <>
*
*  Multi Theft Auto is available from http://www.multitheftauto.com/
*
*****************************************************************************/

#ifndef __CGAME_PEDDAMAGERESPONSECALCULATOR
#define __CGAME_PEDDAMAGERESPONSECALCULATOR

class CPedDamageResponseCalculator
{
public:
};

#endif