place everything from "GTA San Andreas" into your GTA installation directory, backup files which exist, because you need to overwrite them with this files.

plugin_ShowMessageBox is a example plugin for Pawn4Singleplayer

source - this is the source.