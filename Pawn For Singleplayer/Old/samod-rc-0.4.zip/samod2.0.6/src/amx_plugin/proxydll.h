﻿#pragma once

#include <boost/filesystem.hpp>
#include <amx.h>

double PCFreq = 0.0;
__int64 CounterStart = 0;

void StartCounter()
{
    LARGE_INTEGER li;
    if(!QueryPerformanceFrequency(&li))
	{
	Log("QueryPerformanceFrequency failed!");
	}
	else
	{
		PCFreq = double(li.QuadPart)/1000.0;

		QueryPerformanceCounter(&li);
		CounterStart = li.QuadPart;
	}
}

double GetCounter()
{
    LARGE_INTEGER li;
    QueryPerformanceCounter(&li);
    return double(li.QuadPart-CounterStart)/PCFreq;
}

/////////////////////////////
extern IDirect3DDevice9		*origIDirect3DDevice9;

font_ptr TextCreate(const char * szFontName,int FontHeight,DWORD dwCreateFlags)
{
    CD3DFont* ptr = new CD3DFont(szFontName,FontHeight,dwCreateFlags);
    ptr->Initialize(origIDirect3DDevice9);
    return font_ptr(ptr);
}

std::vector<font_ptr> fonts;

//////////////////
std::vector<IDirect3DTexture9*> Textures;
std::vector<ID3DXSprite*>		Sprites;
std::vector<D3DXMATRIX>			D3DXMatrixes;
std::vector<D3DXVECTOR2>		D3DXVectors2;
std::vector<D3DXVECTOR3>		D3DXVectors3;
std::vector<RECT>				D3DXRectangles;

#define LocalPed pPedSelf
#define LocalPedSA pPedSelfSA

#define PlayerInfo (pPedSelf->GetPlayerInfo())

#define FUNCTION __declspec(dllexport)
HWND& GTAWindowHandle = *reinterpret_cast<HWND*>(0xC17054);
#include <functions.h>
AMX_NATIVE_INFO custom_Natives[] =
{
	{   "print",					PawnFunc::n_print },
	{	"GetGameVersion"	,	PawnFunc::GetGameVersion	}	,
	{	"GetBlurLevel"	,	PawnFunc::GetBlurLevel	}	,
	{	"GetGameTime"	,	PawnFunc::GetGameTime	}	,
	{	"GetFPS"	,	PawnFunc::GetFPS	}	,
	{	"GetGameSpeed"	,	PawnFunc::GetGameSpeed	}	,
	{	"GetGravity"	,	PawnFunc::GetGravity	}	,
	{	"GetBikeFrontWheelCounter"	,	PawnFunc::GetBikeFrontWheelCounter	}	,
	{	"GetBikeFrontWheelDist"	,	PawnFunc::GetBikeFrontWheelDist	}	,
	{	"GetBikeRearWheelCounter"	,	PawnFunc::GetBikeRearWheelCounter	}	,
	{	"GetBikeRearWheelDist"	,	PawnFunc::GetBikeRearWheelDist	}	,
	{	"GetCarLess3WheelCounter"	,	PawnFunc::GetCarLess3WheelCounter	}	,
	{	"GetCarTwoWheelCounter"	,	PawnFunc::GetCarTwoWheelCounter	}	,
	{	"GetCarTwoWheelDist"	,	PawnFunc::GetCarTwoWheelDist	}	,
	{	"GetCrossHair"	,	PawnFunc::GetCrossHair	}	,
	{	"GetDoesNotGetTired"	,	PawnFunc::GetDoesNotGetTired	}	,
	{	"GetFPSMoveHeading"	,	PawnFunc::GetFPSMoveHeading	}	,
	{	"GetLastTimeBigGunFired"	,	PawnFunc::GetLastTimeBigGunFired	}	,
	{	"GetLastTimeEaten"	,	PawnFunc::GetLastTimeEaten	}	,
	{	"GetPlayerMoney"	,	PawnFunc::GetPlayerMoney	}	,
	{	"GetWantedLevel"	,	PawnFunc::GetWantedLevel	}	,
	{	"SetMaximumWantedLevel"	,	PawnFunc::SetMaximumWantedLevel	}	,
	{	"SetWantedLevel"	,	PawnFunc::SetWantedLevel	}	,
	{	"SetWantedLevelNoDrop"	,	PawnFunc::SetWantedLevelNoDrop	}	,
	{	"GivePlayerParachute"	,	PawnFunc::GivePlayerParachute	}	,
	{	"SetDoesNotGetTired"	,	PawnFunc::SetDoesNotGetTired	}	,
	{	"SetLastTimeBigGunFired"	,	PawnFunc::SetLastTimeBigGunFired	}	,
	{	"SetLastTimeEaten"	,	PawnFunc::SetLastTimeEaten	}	,
	{	"SetPlayerMoney"	,	PawnFunc::SetPlayerMoney	}	,
	{	"StreamParachuteWeapon"	,	PawnFunc::StreamParachuteWeapon	}	,
	{	"RemoveWeaponModel"	,	PawnFunc::RemoveWeaponModel	}	,
	{	"RemoveAllWeapons"	,	PawnFunc::RemoveAllWeapons	}	,
	{	"GetAreaCode"	,	PawnFunc::GetAreaCode	}	,
	{	"GetArmor"	,	PawnFunc::GetArmor	}	,
	{	"GetCanBeShotInVehicle"	,	PawnFunc::GetCanBeShotInVehicle	}	,
	{	"GetCantBeKnockedOffBike"	,	PawnFunc::GetCantBeKnockedOffBike	}	,
	{	"GetCurrentRotation"	,	PawnFunc::GetCurrentRotation	}	,
	{	"GetCurrentWeaponSlot"	,	PawnFunc::GetCurrentWeaponSlot	}	,
	{	"GetDistFromCentreOfMassToBase"	,	PawnFunc::GetDistFromCentreOfMassToBase	}	,
	{	"GetElasticity"	,	PawnFunc::GetElasticity	}	,
	{	"GetFightingStyle"	,	PawnFunc::GetFightingStyle	}	,
	{	"GetHealth"	,	PawnFunc::GetHealth	}	,
	{	"GetMass"	,	PawnFunc::GetMass	}	,
	{	"GetModelIndex"	,	PawnFunc::GetModelIndex	}	,
	{	"GetMovementSpeed"	,	PawnFunc::GetMovementSpeed	}	,
	{	"GetOccupiedSeat"	,	PawnFunc::GetOccupiedSeat	}	,
	{	"GetPosition"	,	PawnFunc::GetPosition	}	,
	{	"GetRunState"	,	PawnFunc::GetRunState	}	,
	{	"GetStayInSamePlace"	,	PawnFunc::GetStayInSamePlace	}	,
	{	"GetTargetRotation"	,	PawnFunc::GetTargetRotation	}	,
	{	"GetTestForShotInVehicle"	,	PawnFunc::GetTestForShotInVehicle	}	,
	{	"GetTurnMass"	,	PawnFunc::GetTurnMass	}	,
	{	"GetTurnSpeed"	,	PawnFunc::GetTurnSpeed	}	,
	{	"GetUnderwater"	,	PawnFunc::GetUnderwater	}	,
	{	"GetType"	,	PawnFunc::GetType	}	,
	{	"GiveWeapon"	,	PawnFunc::GiveWeapon	}	,
	{	"IsBackfaceCulled"	,	PawnFunc::IsBackfaceCulled	}	,
	{	"IsDucking"	,	PawnFunc::IsDucking	}	,
	{	"IsFullyVisible"	,	PawnFunc::IsFullyVisible	}	,
	{	"IsInWater"	,	PawnFunc::IsInWater	}	,
	{	"IsOnFire"	,	PawnFunc::IsOnFire	}	,
	{	"IsOnScreen"	,	PawnFunc::IsOnScreen	}	,
	{	"IsStatic"	,	PawnFunc::IsStatic	}	,
	{	"IsStaticWaitingForCollision"	,	PawnFunc::IsStaticWaitingForCollision	}	,
	{	"IsVisible"	,	PawnFunc::IsVisible	}	,
	{	"IsWearingGoggles"	,	PawnFunc::IsWearingGoggles	}	,
	{	"Respawn"	,	PawnFunc::Respawn	}	,
	{	"SetAreaCode"	,	PawnFunc::SetAreaCode	}	,
	{	"SetArmor"	,	PawnFunc::SetArmor	}	,
	{	"SetBackfaceCulled"	,	PawnFunc::SetBackfaceCulled	}	,
	{	"GetBuoyancyConstant"	,	PawnFunc::GetBuoyancyConstant	}	,
	{	"SetBuoyancyConstant"	,	PawnFunc::SetBuoyancyConstant	}	,
	{	"SetCanBeShotInVehicle"	,	PawnFunc::SetCanBeShotInVehicle	}	,
	{	"SetCantBeKnockedOffBike"	,	PawnFunc::SetCantBeKnockedOffBike	}	,
	{	"SetCurrentRotation"	,	PawnFunc::SetCurrentRotation	}	,
	{	"SetCurrentWeaponSlot"	,	PawnFunc::SetCurrentWeaponSlot	}	,
	{	"SetDucking"	,	PawnFunc::SetDucking	}	,
	{	"SetElasticity"	,	PawnFunc::SetElasticity	}	,
	{	"SetFightingStyle"	,	PawnFunc::SetFightingStyle	}	,
	{	"SetFootBlood"	,	PawnFunc::SetFootBlood	}	,
	{	"SetGogglesState"	,	PawnFunc::SetGogglesState	}	,
	{	"SetHealth"	,	PawnFunc::SetHealth	}	,
	{	"SetIsStanding"	,	PawnFunc::SetIsStanding	}	,
	{	"SetLighting"	,	PawnFunc::SetLighting	}	,
	{	"GetLighting"	,	PawnFunc::GetLighting	}	,
	{	"SetMass"	,	PawnFunc::SetMass	}	,
	{	"SetModelIndex"	,	PawnFunc::SetModelIndex	}	,
	{	"SetMoveSpeed"	,	PawnFunc::SetMoveSpeed	}	,
	{	"SetOccupiedSeat"	,	PawnFunc::SetOccupiedSeat	}	,
	{	"SetOnFire"	,	PawnFunc::SetOnFire	}	,
	{	"SetOrientation"	,	PawnFunc::SetOrientation	}	,
	{	"SetOxygenLevel"	,	PawnFunc::SetOxygenLevel	}	,
	{	"SetPosition"	,	PawnFunc::SetPosition	}	,
	{	"SetStatic"	,	PawnFunc::SetStatic	}	,
	{	"SetStaticWaitingForCollision"	,	PawnFunc::SetStaticWaitingForCollision	}	,
	{	"SetStayInSamePlace"	,	PawnFunc::SetStayInSamePlace	}	,
	{	"SetTargetRotation"	,	PawnFunc::SetTargetRotation	}	,
	{	"SetTestForShotInVehicle"	,	PawnFunc::SetTestForShotInVehicle	}	,
	{	"SetTurnMass"	,	PawnFunc::SetTurnMass	}	,
	{	"SetTurnSpeed"	,	PawnFunc::SetTurnSpeed	}	,
	{	"SetUnderwater"	,	PawnFunc::SetUnderwater	}	,
	{	"SetUsesCollision"	,	PawnFunc::SetUsesCollision	}	,
	{	"SetVisible"	,	PawnFunc::SetVisible	}	,
	{	"Teleport"	,	PawnFunc::Teleport	}	,
	{	"SetGravity"	,	PawnFunc::SetGravity	}	,
	{	"SetBlurLevel"	,	PawnFunc::SetBlurLevel	}	,
	{	"SetGameSpeed"	,	PawnFunc::SetGameSpeed	}	,
	{   "AddFont"		,	PawnFunc::AddFont		}	,
	{   "DrawText"		,	PawnFunc::DXDrawText	}	,
	{   "format"		,	PawnFunc::format		}	,
	{   "GetScreenInfo" ,	PawnFunc::GetScreenInfo }   ,
	{   "GetTickCount"  ,   PawnFunc::_GetTickCount }   ,
	{   "DrawLine"      ,   PawnFunc::DXDrawLine    }   ,
	{   "GetVehicleCount",  PawnFunc::GetVehicleCount}  ,
	//vehicle
	{   "IsPlayerInVehicle",  PawnFunc::IsPlayerInVehicle }  ,
	{   "GetVehicleModel",  PawnFunc::GetVehicleModel }  ,
	{   "AddVehicleUpgrade",  PawnFunc::AddVehicleUpgrade }  ,
	{   "AreVehicleDoorsLocked",  PawnFunc::AreVehicleDoorsLocked }  ,
	{   "AreVehicleDoorsUndamageable",  PawnFunc::AreVehicleDoorsUndamageable }  ,
	{   "BurstVehicleTyre",  PawnFunc::BurstVehicleTyre }  ,
	{   "BreakVehicleTowLink",  PawnFunc::BreakVehicleTowLink }  ,
	{   "CarHasRoof",  PawnFunc::CarHasRoof }  ,
	{   "ExtinguishCarFire",  PawnFunc::ExtinguishCarFire }  ,
	{   "FixVehicle",  PawnFunc::FixVehicle }  ,
	{   "GetCanVehicleBeDamaged",  PawnFunc::GetCanVehicleBeDamaged }  ,
	{   "CanVehicleBeTargetedByBazooka",  PawnFunc::CanVehicleBeTargetedByBazooka }  ,
	{   "CanVehiclePetrolTankBeShot",  PawnFunc::CanVehiclePetrolTankBeShot }  ,
	{   "GetVehColorChangesWhenPaintjob",  PawnFunc::GetVehColorChangesWhenPaintjob }  ,
	{   "GetVehicleColor",  PawnFunc::GetVehicleColor }  ,
	{   "GetCurrentGear",  PawnFunc::GetCurrentGear }  ,
	{   "GetVehicleElasticity",  PawnFunc::GetVehicleElasticity }  ,
	{   "GetVehicleGasPedal",  PawnFunc::GetVehicleGasPedal }  ,
	{   "GetVehicleBreakPedal" , PawnFunc::GetVehicleBreakPedal } ,
	{   "SetVehicleHandlingData",  PawnFunc::SetVehicleHandlingData }  ,
	{   "SetVehclePaintjob",  PawnFunc::SetVehclePaintjob }  ,
	{   "SetVehclePaintjobDictionary",  PawnFunc::SetVehclePaintjobDictionary }  ,
	{   "SetChangeColourOnPaintjob",  PawnFunc::SetChangeColourOnPaintjob }  ,
	{   "GetVehicleHandlingDataFloat", PawnFunc::GetVehicleHandlingDataFloat }, 
	{   "GetVehicleHandlingDataInt",  PawnFunc::GetVehicleHandlingDataInt },
	{   "GetVehicleCenterOfMass"  , PawnFunc::GetVehicleCenterOfMass } ,

	{   "DrawBox"  , PawnFunc::DXd3dbox } ,
	{   "DrawBoxBorder"  , PawnFunc::DXdedboxborder } ,
	{   "GetCursorPosition" , PawnFunc::GetCursorPosition },
	{   "IsKeyPressed" , PawnFunc::KEYPRESSED },
	{   "IsKeyDown" , PawnFunc::KEYDOWN },
	//otherdx
	{   "CreateTexture", PawnFunc::DXCreateTexture  },
	{   "CreateSprite", PawnFunc::DXCreateSprite  },
	{   "CreateTextureHolder", PawnFunc::DXCreateTextureHolder  },
	{   "CreateSpriteHolder", PawnFunc::DXCreateSpriteHolder  },
	{   "CreateD3DMatrixHolder", PawnFunc::DXCreateD3DXMatrixHolder  },
	{   "CreateVector2Holder", PawnFunc::DXCreateD3DXVector2Holder  },
	{   "Vector2Set", PawnFunc::DXD3DXVector2Set  },
	{   "Vector2Get", PawnFunc::DXD3DXVector2Get  },
	{   "D3DMatrixTransformation2D", PawnFunc::DXD3DXMatrixTransformation2D  },
	{   "Sprite_Begin", PawnFunc::DXSprite_Begin  },
	{   "Sprite_End", PawnFunc::DXSprite_End  },
	{   "Sprite_SetTransform", PawnFunc::DXSprite_SetTransform  },
	{   "Sprite_Draw", PawnFunc::DXSprite_Draw  },
	{   "CreateVector3Holder", PawnFunc::DXCreateD3DXVector3Holder  },
	{   "Vector3Set", PawnFunc::DXD3DXVector3Set  },
	{   "Vector3Get", PawnFunc::DXD3DXVector3Get  },
	{   "CreateRectangleHolder", PawnFunc::DXCreateD3DXRectangleHolder  },
	{   "RectangleSet", PawnFunc::DXD3DXRectangleSet  },
	{   "RectangleGet", PawnFunc::DXD3DXRectangleGet  },
	{   "GetBackBufferHeight", PawnFunc::GetBackBufferHeight },
	{   "GetBackBufferWidth", PawnFunc::GetBackBufferWidth },
	{   "Texture_Release", PawnFunc::DXTextureRelease },
	{   "Sprite_Release", PawnFunc::DXSpriteRelease },
	{   "IsTextureNull", PawnFunc::DXTextureIsNull },
	{   "IsSpriteNull", PawnFunc::DXSpriteIsNull },

	{   "ShowCursor" , PawnFunc::ShowCursor },
	{   "EmulateKeyPress" , PawnFunc::EmulateKeyPressINPUT },
	{   "GetLastError"   , PawnFunc::PWNGetLastError },
	{ NULL, NULL }
};

#include <plugincommon.h>
#include <plugininternal.h>
#include <plugins.h>
#include <script.h>

