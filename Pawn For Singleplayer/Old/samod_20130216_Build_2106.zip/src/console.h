#include <main.h>
#include <proxydll.h>

namespace SA
{
	namespace MOD
	{
		namespace Console
		{
			std::string string_format(const std::string fmt, ...) 
			{
				int size = 512;
				std::string str;
				va_list ap;
				while (1) {
					str.resize(size);
					va_start(ap, fmt);
					int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
					va_end(ap);
					if (n > -1 && n < size) {
						str.resize(n);
						return str;
					}
					if (n > -1)
						size = n + 1;
					else
						size *= 2;
				}
				return str;
			}

			namespace var
			{
				float lines = 0.0f;
				float startpos = 0.0f;
				bool g_Console = false;
				bool ParseColorsInCommandLine = false;
				bool HasSeenWelcomeScreen = false;
				int LastEntry = 1;
				int Scroll = 0;
				double last_backspace;
				VideoMode mode;
				CD3DFont* font;
				std::vector < std::string > buffer;
				char string[512];
				std::string LastCommand;
				std::string TypedString;
			};
			
			void LogFromConsole ( const char *fmt, ... )
			{
				if ( !g_szWorkingDirectory ) return;

				SYSTEMTIME	time;
				va_list		ap;

				if ( g_flLogAll == NULL )
				{
					char	filename_all[512];
					snprintf( filename_all, sizeof(filename_all), "%s\\%s", g_szWorkingDirectory, "gz_sa_mod_all.log" );

					g_flLogAll = fopen( filename_all, "a" );
					if ( g_flLogAll == NULL )
						return;
				}

				GetLocalTime( &time );
				fprintf( g_flLogAll, "[%02d-%02d-%02d || %02d:%02d:%02d.%03d] ", time.wDay, time.wMonth, time.wYear, time.wHour,
						 time.wMinute, time.wSecond, time.wMilliseconds );
				va_start( ap, fmt );
				vfprintf( g_flLogAll, fmt, ap );
				va_end( ap );
				fprintf( g_flLogAll, "\n" );
				fflush( g_flLogAll );
			}

			void AddLine(const char * string,bool ToLog = true)//process commands here
			{
				if(strlen(string) == 0)
					return;
				if(ToLog)
					LogFromConsole("[Console] %s",string);
				var::buffer.push_back(string);
				if(var::buffer.size() == 512)
					var::buffer.erase (var::buffer.begin());
			}

			namespace Commands
			{
				typedef int (*func_t)(std::string);
				typedef std::map<std::string,func_t> function_map;
				// fill the map
				function_map execute;
				bool Initialised = false;
				//
				#define COMMAND(a) int a(std::string arguments)

				COMMAND(quit)
				{
					ExitProcess(0);
					return 1;
				}
				COMMAND(help)
				{
					AddLine("--------[Available Commands]--------");	
					for(auto it = execute.begin(); it != execute.end(); ++it)
						AddLine(it->first.c_str());
					AddLine("------------------------------------");
					return 1;
				}
				COMMAND(text)
				{
					AddLine(arguments.c_str());
					return 1;
				}
				COMMAND(loadscript)
				{
					return LoadScript(arguments);
				}
				COMMAND(unloadscript)
				{
					return UnloadScript(arguments);
				}
				COMMAND(unloadscripts)
				{
					UnloadScripts();
					return 1;
				}
				COMMAND(reloadscript)
				{
					return ReLoadScript(arguments);
				}
				COMMAND(loadamxplugin)
				{
					return LoadPlugin(arguments,true);
				}
				COMMAND(loaddll)
				{
					return LoadPlugin(arguments,false);
				}
				COMMAND(unloadplugin)
				{
					return UnloadPlugin(arguments);
				}
				COMMAND(unloadplugins)
				{
					UnloadPlugins();
					return 1;
				}
				COMMAND(unloadall)
				{
					UnloadScripts();
					UnloadPlugins();
					return 1;
				}
				COMMAND(loadall)
				{
					LoadPlugins();
					LoadScripts();
					return 1;
				}
				COMMAND(reloadall)
				{
					UnloadScripts();
					UnloadPlugins();
					LoadPlugins();
					LoadScripts();
					return 1;
				}
				COMMAND(listscripts)
				{
					AddLine(string_format("------------[Loaded Scripts (%d)]------------",scripts.size()).c_str());
					AddLine("{FF00FFFF}[IDENTIFIER]{FFFFFFFF} | [LOADED]{FFFFFFFF} | {FFFFFF00}[FILENAME]");
					for(std::vector<ScriptInfo>::iterator it = scripts.begin(); it != scripts.end(); ++it) 
					{
						AddLine(string_format("{FF00FFFF}%s{FFFFFFFF} | {%s}%s{FFFFFFFF} | {FFFFFF00}%s",it->Identifier.c_str(),((it->Loaded) ? "FF00FF00" : "FFFF0000"),((it->Loaded) ? "Loaded" : "ERROR: Not Loaded"),it->FileNameAndPath.c_str()).c_str());
					}
					AddLine("---------------------------------------------");
					return 1;
				}
				COMMAND(listplugins)
				{
					AddLine(string_format("------------[Loaded Plugins (%d)]------------",plugins.size()).c_str());
					AddLine("{FF00FFFF}[IDENTIFIER]{FFFFFFFF} | [Is AMX plugin or DLL]{FFFFFFFF} | {FFFFFF00}[INSTANCE]");
					for(std::vector<DLLInfo>::iterator it = plugins.begin(); it != plugins.end(); ++it) 
					{
						AddLine(string_format("{FF00FFFF}%s{FFFFFFFF} | {%s}%s{FFFFFFFF} | {FFFFFF00}%x",it->Identifier.c_str(),((it->IsAMX) ? "FF00FF00" : "FFFF0000"),((it->IsAMX) ? "AMX Plugin" : "DLL"),it->Instance).c_str());
					}
					AddLine("---------------------------------------------");
					return 1;
				}
				COMMAND(gameinfo)
				{
					AddLine("------------[Game Info]------------");
					AddLine(string_format("Peds: %d/%d",pPools->GetPedCount(),pool_actor->size).c_str());
					AddLine(string_format("Vehicles: %d/%d",pPools->GetVehicleCount(),pool_vehicle->size).c_str());
					AddLine(string_format("Objects: %d",pPools->GetObjectCount()).c_str());
					AddLine("-----------------------------------");
					return 1;
				}
				COMMAND(pawncmd)
				{
					cell
						retval,
						amx_addr,
						amx_ret,
						* amx_physAddr;

					for(std::vector<ScriptInfo>::iterator it = scripts.begin(); it != scripts.end(); ++it) 
					{
						if (!amx_FindPublic(&it->amx, "OnConsoleCommand", &PublicCall))
						{
							amx_PushString(&it->amx, &amx_addr, &amx_physAddr, arguments.c_str(), 0, 0);
							amx_Exec(&it->amx, &retval, PublicCall);
							amx_Release(&it->amx, amx_addr);
							if(retval != 0)
								return retval;
						}
					}				
					return 0;
				}
				COMMAND(addped)
				{
					if(arguments.size() > 0)
					{
						int x = atoi(arguments.c_str());
						pGameInterface->GetModelInfo ( x )->AddRef ( true );
						gsPed = pGameInterface->GetPools()->AddPed(static_cast < ePedModel > (x));
						if(gsPed != NULL)
						{
							gsPed->SetPosition(pPedSelf->GetPosition()->fX+2.0f,pPedSelf->GetPosition()->fY+2.0f,pPedSelf->GetPosition()->fZ+2.0f);
							return gsPed->GetArrayID();
						}					
						return -1;
					}
					return -2;	
				}
				COMMAND(addcped)
				{
					if(arguments.size() > 0)
					{
						int x = atoi(arguments.c_str());
						pGameInterface->GetModelInfo ( x )->AddRef ( true );
						gsPed = pGameInterface->GetPools()->AddCivilianPed(static_cast < ePedModel > (x));
						if(gsPed != NULL)
						{
							gsPed->SetPosition(pPedSelf->GetPosition()->fX+2.0f,pPedSelf->GetPosition()->fY+2.0f,pPedSelf->GetPosition()->fZ+2.0f);
							return gsPed->GetArrayID();
						}					
						return -1;
					}
					return -2;
				}
				COMMAND(lockme)
				{
					GTAfunc_LockActor(true);
					GTAfunc_TogglePlayerControllable(true);
					return 0;
				}
				COMMAND(unlockme)
				{
					GTAfunc_LockActor(false);
					GTAfunc_TogglePlayerControllable(false);
					return 0;
				}

				COMMAND(addvehicle)
				{
					if(arguments.size() > 0)
					{
						int x = atoi(arguments.c_str());
						pGameInterface->GetModelInfo ( x )->AddRef ( true );
						gsVehicle = pGameInterface->GetPools()->AddVehicle(static_cast < eVehicleTypes > (x));
						if(gsVehicle != NULL)
						{
							gsVehicle->SetPosition(pPedSelf->GetPosition()->fX+2.0f,pPedSelf->GetPosition()->fY+2.0f,pPedSelf->GetPosition()->fZ+2.0f);
							return gsVehicle->GetArrayID();
						}     
						return -1;
					}
					return -2; 
				}
				//
				void Init()
				{
					execute["quit"] = &quit;
					execute["text"] = &text;
					execute["load_script"] = &loadscript;
					execute["unload_script"] = &unloadscript;
					execute["reload_script"] = &reloadscript;
					execute["unload_all_scripts"] = &unloadscripts;
					execute["load_amxplugin"] = &loadamxplugin;
					execute["load_dll"] = &loaddll;
					execute["unload_plugin"] = &unloadplugin;
					execute["unload_all_plugins"] = &unloadplugins;
					execute["unload_all"] = &unloadall;
					execute["load_all"] = &loadall;
					execute["reload_all"] = &reloadall;
					execute["script_list"] = &listscripts;
					execute["plugin_list"] = &listplugins;
					execute["help"] = &help;
					execute["gameinfo"] = &gameinfo;
					execute["addped"] = &addped;
					execute["addcped"] = &addcped;
					execute["lockme"] = &lockme;
					execute["unlockme"] = &unlockme;
					execute["addvehicle"] = &addvehicle;
					Initialised = true;
				}
			};//commands

			void ProcessCommand(std::string str)
			{
				if(Commands::Initialised == false)
					Commands::Init();
				if(str.at(0) == '/')
				{
					Commands::pawncmd(str);
				}
				else
				{
					std::istringstream x(str);
					std::string command;
					std::getline(x, command, ' ');
					Commands::function_map::const_iterator it = Commands::execute.find(command);
					if( it == Commands::execute.end() )
					{
						AddLine(string_format("Unknown command: '%s'",command.c_str()).c_str());
						return;
					}
					std::string arguments;
					std::getline(x, arguments, '\0');
					int ret = (int)(*it->second)(arguments);
					if(ret != 1)
						AddLine(string_format("The command returned: %d",ret).c_str());
				}
				return;
			}

			void AddChar(char c)
			{
				char szInsert[2] = {c,0};
				var::TypedString.append(szInsert);
			}

			bool ProcessConsole()
			{
				bool ALT = KEY_DOWN(VK_LMENU) || KEY_DOWN(VK_RMENU);
				bool CTRL = KEY_DOWN(VK_LCONTROL) || KEY_DOWN(VK_RCONTROL);
				if(!var::g_Console)
				{
					if(ALT && CTRL && KEY_PRESSED(VK_F10))
					{
						KEY_CONSUME(VK_F10);
						var::g_Console = true;
						pGameInterface->GetSettings()->GetVideoModeInfo(&var::mode,pGameInterface->GetSettings()->GetCurrentVideoMode());
						var::mode.height /= 3;
						GTAfunc_LockActor(true);
						GTAfunc_TogglePlayerControllable(true);
						var::lines = var::mode.height / 30;
						var::startpos = var::lines * 29.0f;
						var::font = new CD3DFont("Lucida Console",var::lines,FW_BOLD);
						var::lines *= 1.7f;
						var::Scroll = 0;
						var::font->Initialize(origIDirect3DDevice9);
						if(!var::HasSeenWelcomeScreen)
						{
							AddLine("Welcome to the {FFFF0000}SA MOD{FFFFFFFF} {33FFFFFF}<<BASIC>>{FFFFFFFF} console");
#ifdef __DEBUGx
							AddLine("{FFFFFF00}Version 20130216 {FF00FFFF}Build 2106 {FFFFFFFF}[DEBUG VERSION]");
#else
							AddLine("{FFFFFF00}Version 20130216 {FF00FFFF}Build 2106 {FFFFFFFF}[RELEASE]");
#endif
							AddLine("-------------------------[KEYS]-------------------------");
							AddLine("{FF00FF00}CTRL + ALT + F10{FFFFFFFF} : Close console");
							AddLine("{FF00FF00}ARROW UP{FFFFFFFF} : Set console text input to previous text");
							AddLine("{FF00FF00}ARROW DOWN{FFFFFFFF} : Set console text input to next text");
							AddLine("{FF00FF00}PAGE UP{FFFFFFFF} : Scroll console log up");
							AddLine("{FF00FF00}PAGE DOWN{FFFFFFFF} : Scroll console log down");
							AddLine("{FF00FF00}TAB{FFFFFFFF} : To re-enter last used command");
							AddLine("-----------------------[COMMANDS]-----------------------");
							AddLine("Use '{FF00FF00}help{FFFFFFFF}' to see a list of available commands");
							AddLine("Use '{FF00FF00}/{FFFFFFFF}' to call pawn commands");
							AddLine("--------------------------------------------------------");

							var::HasSeenWelcomeScreen = true;
						}
						var::LastEntry = 1;
					}
				}
				else
				{
					if(CTRL && ALT && KEY_PRESSED(VK_F10))
					{
						KEY_CONSUME(VK_F10);
						GTAfunc_LockActor(false);
						GTAfunc_TogglePlayerControllable(false);
						var::g_Console = false;
					}
					else
					{
						render->D3DBoxBorder(0.0f,0.0f,(float)var::mode.width,(float)var::mode.height,0xF0000000,0xF0000000);
						render->D3DBoxBorder(-2.0f,var::mode.height-(var::lines)-2.0f,(float)var::mode.width+2.0f,var::lines+2.0f,0xFF00FF00,0x00000000);

						if(KEY_PRESSED(VK_PRIOR))//page up
						{
							var::Scroll+=5;
							if((var::Scroll+17) >= var::buffer.size())
							{
								var::Scroll = var::buffer.size()-17;
							}
						}

						if(KEY_PRESSED(VK_NEXT))//page down
						{
							var::Scroll-=5;
							if(var::Scroll < 0)
								var::Scroll = 0;
						}

						for(unsigned int i = (var::buffer.size()-1)-var::Scroll,j = i-17,x=0; j != i; --i)
						{
							if(i < 0)
								break;
							if(!var::buffer[i].empty())
							{
								var::font->Print(0.0,(var::startpos-((var::lines)*(x+1))),0xFFFFFFFF,var::buffer[i].c_str(),true);
								++x;
							}
							else
							{
								--j;
							}
						}

						if(var::TypedString.size() > 0)
						{
							if(KEY_PRESSED(VK_BACK))
							{
								var::last_backspace = GetCounter();
								var::TypedString.erase(var::TypedString.end()-1,var::TypedString.end());
							}else
							if(KEY_DOWN(VK_BACK))
							{
								if(GetCounter()-var::last_backspace > 125)
								{
									var::last_backspace = GetCounter();
									var::TypedString.erase(var::TypedString.end()-1,var::TypedString.end());
								}
							}
							if(KEY_PRESSED(VK_RETURN) || KEY_PRESSED(VK_SEPARATOR))
							{
								ProcessCommand(var::TypedString);
								var::LastCommand.assign(var::TypedString);
								var::TypedString.clear();
								var::LastEntry = 1;
							}
						}
						if(var::TypedString.size() < 512)
						{							
							if(GetAsyncKeyState(VK_SHIFT))
							{
								if(KEY_PRESSED(49))AddChar('!');
								if(KEY_PRESSED(50))AddChar('@');
								if(KEY_PRESSED(51))AddChar('#');
								if(KEY_PRESSED(52))AddChar('$');
								if(KEY_PRESSED(53))AddChar('%');
								if(KEY_PRESSED(54))AddChar('^');
								if(KEY_PRESSED(55))AddChar('&');
								if(KEY_PRESSED(56))AddChar('*');
								if(KEY_PRESSED(57))AddChar('(');
								if(KEY_PRESSED(48))AddChar(')');

								for(int i = 65; i < 91; ++i)
									if(KEY_PRESSED(i))AddChar(i);

								if(KEY_PRESSED(VK_OEM_1))AddChar(':');
								if(KEY_PRESSED(VK_OEM_2))AddChar('?');
								if(KEY_PRESSED(VK_OEM_3))AddChar('~');
								if(KEY_PRESSED(VK_OEM_4))AddChar('{');
								if(KEY_PRESSED(VK_OEM_5))AddChar('|');
								if(KEY_PRESSED(VK_OEM_6))AddChar('}');
								if(KEY_PRESSED(VK_OEM_7))AddChar('"');
								if(KEY_PRESSED(VK_OEM_PLUS))AddChar('+');
								if(KEY_PRESSED(VK_OEM_COMMA))AddChar('<');
								if(KEY_PRESSED(VK_OEM_MINUS))AddChar('_');
								if(KEY_PRESSED(VK_OEM_PERIOD))AddChar('>');
							}
							else
							{
								for(int i = 48; i < 58; ++i)
									if(KEY_PRESSED(i))AddChar(i);
								for(int i = 65; i < 91; ++i)
									if(KEY_PRESSED(i))AddChar(i+32);

								if(KEY_PRESSED(VK_OEM_1))AddChar(';');
								if(KEY_PRESSED(VK_OEM_2))AddChar('/');
								if(KEY_PRESSED(VK_OEM_3))AddChar('`');
								if(KEY_PRESSED(VK_OEM_4))AddChar('[');
								if(KEY_PRESSED(VK_OEM_5))AddChar('\\');
								if(KEY_PRESSED(VK_OEM_6))AddChar(']');
								if(KEY_PRESSED(VK_OEM_7))AddChar('\'');
								if(KEY_PRESSED(VK_OEM_PLUS))AddChar('=');
								if(KEY_PRESSED(VK_OEM_COMMA))AddChar(',');
								if(KEY_PRESSED(VK_OEM_MINUS))AddChar('-');
								if(KEY_PRESSED(VK_OEM_PERIOD))AddChar('.');
							}

							if(KEY_PRESSED(VK_TAB))AddChar('\t');
							if(KEY_PRESSED(VK_SPACE))AddChar(' ');
							if(KEY_PRESSED(VK_MULTIPLY))AddChar('*');
							if(KEY_PRESSED(VK_ADD))AddChar('+');
							if(KEY_PRESSED(VK_SUBTRACT))AddChar('-');
							if(KEY_PRESSED(VK_DECIMAL))AddChar('.');
							if(KEY_PRESSED(VK_DIVIDE))AddChar('/');

							for(int i = 96; i < 106; ++i)
									if(KEY_PRESSED(i))AddChar(i-48);

						}
						if(KEY_PRESSED(VK_UP))
						{
							--var::LastEntry;
							if((var::LastEntry*-1) > var::buffer.size()-1) 
								var::LastEntry = ((var::buffer.size()-1)*-1);
							var::TypedString = var::buffer.at(var::buffer.size()+(var::LastEntry-1));
						}

						if(KEY_PRESSED(VK_DOWN))
						{
							++var::LastEntry;
							if(var::LastEntry >= 1)
							{
								var::LastEntry = 1;
								var::TypedString.clear();
							}
							else
							{
								var::TypedString = var::buffer.at(var::buffer.size()+(var::LastEntry-1));
							}
						}

						if(KEY_PRESSED(VK_TAB))
						{
							var::TypedString.assign(var::LastCommand);
						}

						if(var::TypedString.size() > 0)
							var::font->Print(0.0,(var::mode.height-(var::lines)),0xFFFFFFFF,var::TypedString.c_str(),var::ParseColorsInCommandLine);
					}
				}
				return var::g_Console;
			}
		};//console
	};//mod
};//sa