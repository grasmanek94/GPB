//functions

namespace Functions
{
	////////player
	VOID FUNCTION SetPlayerMoney(long lMoney)
	{
		pGame->GetPlayerInfo()->SetPlayerMoney(lMoney);
	}
	long FUNCTION GetPlayerMoney()
	{
		return pGame->GetPlayerInfo()->GetPlayerMoney();
	}
	///////vehicles
	unsigned long FUNCTION AddVehicle(unsigned long VehicleModel,BYTE Color1, BYTE Color2, float X, float Y, float Z)
	{
		CVehicle *pVehicle = NULL;
		pVehicle = pGame->GetPools()->AddVehicle((eVehicleTypes)VehicleModel,Color1,Color2);
		if(pVehicle != NULL)
		{
			pVehicle->SetPosition(X,Y,Z);
			return pVehicle->GetArrayID();
		}
		return (0xFFFF);
	}
	void FUNCTION SetVehiclePos(unsigned long VehicleID, float X, float Y, float Z)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->SetPosition(X,Y,Z);
	}
	void FUNCTION RemoveVehicle(unsigned long VehicleID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->~CVehicle();
	}
	void FUNCTION AddVehicleComponent(unsigned long VehicleID, unsigned long ComponentID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->AddVehicleUpgrade(ComponentID);
	}
	void FUNCTION AttachVehicleToVehicle(unsigned long VehicleID, unsigned long VehicleID2, float PosX, float PosY, float PosZ, float RotX, float RotY, float RotZ)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->AttachEntityToEntity(*pGame->GetPools()->GetVehicle(VehicleID2),CVector(PosX,PosY,PosZ),CVector(RotX,RotY,RotZ));
	}
	void FUNCTION AttachTrailerToVehicle(unsigned long VehicleID, unsigned long TrailerID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->SetTowLink(pGame->GetPools()->GetVehicle(TrailerID));
	}
	void FUNCTION DetachTrailerFromVehicle(unsigned long VehicleID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->BreakTowLink();
	}
	void FUNCTION ChangeVehicleColor(unsigned long VehicleID, DWORD Color1, DWORD Color2, DWORD Color3, DWORD Color4)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->SetColor(SColor(Color1),SColor(Color2),SColor(Color3),SColor(Color4),0);
	}
	/*void FUNCTION ChangeVehiclePaintjob(unsigned long VehicleID, int PaintJobID)
	{
		//pGame->GetPools()->GetVehicle(VehicleID)->;???wtf
	}
	int FUNCTION GetVehiclePaintjob(unsigned long VehicleID)
	{
		//pGame->GetPools()->GetVehicle(VehicleID)->;??wtf!?!?!?!
		return 0;
	}
	void FUNCTION DetachVehicleFromVehicle(unsigned long VehicleID, unsigned long VehicleID2)
	{
		//pGame->GetPools()->GetVehicle(VehicleID)->??
	}
	unsigned long FUNCTION GetVehicleComponentInSlot(unsigned long VehicleID,int Slot)
	{
		//g_pCore->GetGame()->
		//return pGame->GetPools()->GetVehicle(VehicleID)->GetComponentMap().f;
	}*/
	unsigned long FUNCTION GetPlayerVehicleID()
	{
		return LocalPed->GetVehicle()->GetArrayID();
	}
	BYTE FUNCTION GetPlayerSeat()
	{
		return pGame->GetPedContext()->GetOccupiedSeat();
	}
	float FUNCTION GetVehicleHealth(unsigned long VehicleID)
	{
		return pGame->GetPools()->GetVehicle(VehicleID)->GetHealth();
	}
	WORD FUNCTION GetVehicleModel(unsigned long VehicleID)
	{
		return pGame->GetPools()->GetVehicle(VehicleID)->GetModelIndex();
	}
	void FUNCTION GetVehiclePos(unsigned long VehicleID, float *X, float *Y, float *Z)
	{
		CVector POS(*pGame->GetPools()->GetVehicle(VehicleID)->GetPosition());
		*X = POS.fX;
		*Y = POS.fY;
		*Z = POS.fZ;
	}
	unsigned long FUNCTION GetVehicleTrailer(unsigned long VehicleID)
	{
		return pGame->GetPools()->GetVehicle(VehicleID)->GetTowedVehicle()->GetArrayID();
	}
	unsigned long FUNCTION GetTrailerAttachedTo(unsigned long Trailer)
	{
		return pGame->GetPools()->GetVehicle(Trailer)->GetTowedByVehicle()->GetArrayID();
	}
};//namespace Functions