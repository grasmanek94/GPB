//functions
#include <proxydll.h>
//namespace Functions
//{
	////////player
	/*VOID FUNCTION SetPlayerMoney(long lMoney)
	{
		pGame->GetPlayerInfo()->SetPlayerMoney(lMoney);
	}
	long FUNCTION GetPlayerMoney()
	{
		return pGame->GetPlayerInfo()->GetPlayerMoney();
	}
	///////vehicles
	unsigned long FUNCTION AddVehicle(unsigned long VehicleModel,BYTE Color1, BYTE Color2, float X, float Y, float Z)
	{
		CVehicle *pVehicle = NULL;
		pVehicle = pGame->GetPools()->AddVehicle((eVehicleTypes)VehicleModel,Color1,Color2);
		if(pVehicle != NULL)
		{
			pVehicle->SetPosition(X,Y,Z);
			return pVehicle->GetArrayID();
		}
		return (0xFFFF);
	}
	void FUNCTION SetVehiclePos(unsigned long VehicleID, float X, float Y, float Z)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->SetPosition(X,Y,Z);
	}
	void FUNCTION RemoveVehicle(unsigned long VehicleID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->~CVehicle();
	}
	void FUNCTION AddVehicleComponent(unsigned long VehicleID, unsigned long ComponentID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->AddVehicleUpgrade(ComponentID);
	}
	void FUNCTION AttachVehicleToVehicle(unsigned long VehicleID, unsigned long VehicleID2, float PosX, float PosY, float PosZ, float RotX, float RotY, float RotZ)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->AttachEntityToEntity(*pGame->GetPools()->GetVehicle(VehicleID2),CVector(PosX,PosY,PosZ),CVector(RotX,RotY,RotZ));
	}
	void FUNCTION AttachTrailerToVehicle(unsigned long VehicleID, unsigned long TrailerID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->SetTowLink(pGame->GetPools()->GetVehicle(TrailerID));
	}
	void FUNCTION DetachTrailerFromVehicle(unsigned long VehicleID)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->BreakTowLink();
	}
	void FUNCTION ChangeVehicleColor(unsigned long VehicleID, DWORD Color1, DWORD Color2, DWORD Color3, DWORD Color4)
	{
		pGame->GetPools()->GetVehicle(VehicleID)->SetColor(SColor(Color1),SColor(Color2),SColor(Color3),SColor(Color4),0);
	}*/
	/*void FUNCTION ChangeVehiclePaintjob(unsigned long VehicleID, int PaintJobID)
	{
		//pGame->GetPools()->GetVehicle(VehicleID)->;???wtf
	}
	int FUNCTION GetVehiclePaintjob(unsigned long VehicleID)
	{
		//pGame->GetPools()->GetVehicle(VehicleID)->;??wtf!?!?!?!
		return 0;
	}
	void FUNCTION DetachVehicleFromVehicle(unsigned long VehicleID, unsigned long VehicleID2)
	{
		//pGame->GetPools()->GetVehicle(VehicleID)->??
	}
	unsigned long FUNCTION GetVehicleComponentInSlot(unsigned long VehicleID,int Slot)
	{
		//g_pCore->GetGame()->
		//return pGame->GetPools()->GetVehicle(VehicleID)->GetComponentMap().f;
	}*/
	/*unsigned long FUNCTION GetPlayerVehicleID()
	{
		return LocalPed->GetVehicle()->GetArrayID();
	}
	BYTE FUNCTION GetPlayerSeat()
	{
		return pGame->GetPedContext()->GetOccupiedSeat();
	}
	float FUNCTION GetVehicleHealth(unsigned long VehicleID)
	{
		return pGame->GetPools()->GetVehicle(VehicleID)->GetHealth();
	}
	WORD FUNCTION GetVehicleModel(unsigned long VehicleID)
	{
		return pGame->GetPools()->GetVehicle(VehicleID)->GetModelIndex();
	}
	void FUNCTION GetVehiclePos(unsigned long VehicleID, float *X, float *Y, float *Z)
	{
		CVector POS(*pGame->GetPools()->GetVehicle(VehicleID)->GetPosition());
		*X = POS.fX;
		*Y = POS.fY;
		*Z = POS.fZ;
	}
	unsigned long FUNCTION GetVehicleTrailer(unsigned long VehicleID)
	{
		return pGame->GetPools()->GetVehicle(VehicleID)->GetTowedVehicle()->GetArrayID();
	}
	unsigned long FUNCTION GetTrailerAttachedTo(unsigned long Trailer)
	{
		return pGame->GetPools()->GetVehicle(Trailer)->GetTowedByVehicle()->GetArrayID();
	}*/
//};//namespace Functions

//Pawn Functions
namespace PawnFunc
{
	static cell AMX_NATIVE_CALL GetGameVersion(AMX *amx, cell *params)
	{	
		return pGame->FindGameVersion();
	}
	static cell AMX_NATIVE_CALL GetBlurLevel(AMX *amx, cell *params)
	{
		return pGame->GetBlurLevel();
	}
	static cell AMX_NATIVE_CALL GetGameTime(AMX *amx, cell *params)
	{
		cell* cptra;
		cell* cptrb;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		pGame->GetClock()->Get((BYTE*)*cptra,(BYTE*)*cptrb);
		return 1;
	}
	static cell AMX_NATIVE_CALL GetFPS(AMX *amx, cell *params)
	{
		float temp = pGame->GetFPS();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetGameSpeed(AMX *amx, cell *params)
	{
		float temp = pGame->GetGameSpeed();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetGravity(AMX *amx, cell *params)
	{
		float temp = pGame->GetGravity();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetBikeFrontWheelCounter(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetBikeFrontWheelCounter();
	}
	static cell AMX_NATIVE_CALL GetBikeFrontWheelDist(AMX *amx, cell *params)
	{
		float temp = pGame->GetPlayerInfo()->GetBikeFrontWheelDist();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetBikeRearWheelCounter(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetBikeRearWheelCounter();
	}
	static cell AMX_NATIVE_CALL GetBikeRearWheelDist(AMX *amx, cell *params)
	{
		float temp = pGame->GetPlayerInfo()->GetBikeRearWheelDist();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetCarLess3WheelCounter(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetCarLess3WheelCounter();
	}
	static cell AMX_NATIVE_CALL GetCarTwoWheelCounter(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetCarTwoWheelCounter();
	}
	static cell AMX_NATIVE_CALL GetCarTwoWheelDist(AMX *amx, cell *params)
	{
		float temp = pGame->GetPlayerInfo()->GetCarTwoWheelDist();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetCrossHair(AMX *amx, cell *params)
	{
		bool IsEnabled;
		float PosX;
		float PosY;
		pGame->GetPlayerInfo()->GetCrossHair(IsEnabled,PosX,PosY);
		cell* cptra;
		cell* cptrb;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		*cptra = amx_ftoc(PosX);
		*cptrb = amx_ftoc(PosY);
		return IsEnabled;
	}
	static cell AMX_NATIVE_CALL GetDoesNotGetTired(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetDoesNotGetTired();
	}
	static cell AMX_NATIVE_CALL GetFPSMoveHeading(AMX *amx, cell *params)
	{
		float temp = pGame->GetPlayerInfo()->GetFPSMoveHeading();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetLastTimeBigGunFired(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetLastTimeBigGunFired();
	}
	static cell AMX_NATIVE_CALL GetLastTimeEaten(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetLastTimeEaten();
	}
	static cell AMX_NATIVE_CALL GetPlayerMoney(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetPlayerMoney();
	}
	static cell AMX_NATIVE_CALL GetWantedLevel(AMX *amx, cell *params)
	{
		return pGame->GetPlayerInfo()->GetWanted()->GetWantedLevel();
	}
	static cell AMX_NATIVE_CALL SetMaximumWantedLevel(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->GetWanted()->SetMaximumWantedLevel(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetWantedLevel(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->GetWanted()->SetWantedLevel(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetWantedLevelNoDrop(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->GetWanted()->SetWantedLevelNoDrop(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetWantedLevelNoFlash(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->GetWanted()->SetWantedLevelNoFlash(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL GivePlayerParachute(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->GivePlayerParachute();
		return 1;
	}
	static cell AMX_NATIVE_CALL SetDoesNotGetTired(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->SetDoesNotGetTired((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetLastTimeBigGunFired(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->SetLastTimeBigGunFired(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetLastTimeEaten(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->SetLastTimeEaten(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetPlayerMoney(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->SetPlayerMoney(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL StreamParachuteWeapon(AMX *amx, cell *params)
	{
		pGame->GetPlayerInfo()->StreamParachuteWeapon((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL RemoveWeaponModel(AMX *amx, cell *params)
	{
		LocalPed->ClearWeapon ( static_cast < eWeaponType > (params[1]));
		LocalPed->RemoveWeaponModel ( static_cast < eWeaponType > (params[1]) );

		// Set whatever weapon to 0 ammo so we don't keep it anymore
		CWeapon* pWeapon = LocalPed->GetWeapon ( static_cast < eWeaponType > (params[1]) );
		if ( pWeapon )
		{
			pWeapon->SetType ( WEAPONTYPE_UNARMED );
			pWeapon->SetAmmoInClip ( 0 );
			pWeapon->SetAmmoTotal ( 0 );
			pWeapon->Remove ();
		}
		return 1;
	}
	static cell AMX_NATIVE_CALL RemoveAllWeapons(AMX *amx, cell *params)
	{
		LocalPed->ClearWeapons();
		return 1;
	}
	static cell AMX_NATIVE_CALL GetAreaCode(AMX *amx, cell *params)
	{
		return LocalPed->GetAreaCode();
	}
	static cell AMX_NATIVE_CALL GetArmor(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetArmor();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetCanBeShotInVehicle(AMX *amx, cell *params)
	{
		return LocalPed->GetCanBeShotInVehicle();
	}
	static cell AMX_NATIVE_CALL GetCantBeKnockedOffBike(AMX *amx, cell *params)
	{
		return LocalPed->GetCantBeKnockedOffBike();
	}
	static cell AMX_NATIVE_CALL GetCurrentRotation(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetCurrentRotation();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetCurrentWeaponRange(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetCurrentWeaponRange();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetCurrentWeaponSlot(AMX *amx, cell *params)
	{
		return LocalPed->GetPedInterface()->bCurrentWeaponSlot;
	}
	/*static cell AMX_NATIVE_CALL GetCantBeKnockedOffBike(AMX *amx, cell *params)
	{
		CWeaponStat * stat = LocalPed->GetCurrentWeaponStat();
		stat->
		return 0;
	}*/
	static cell AMX_NATIVE_CALL GetDistFromCentreOfMassToBase(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetDistanceFromCentreOfMassToBaseOfModel();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetElasticity(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetElasticity();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetFightingStyle(AMX *amx, cell *params)
	{
		return LocalPed->GetFightingStyle();
	}
	static cell AMX_NATIVE_CALL GetFootBlood(AMX *amx, cell *params)
	{
		return LocalPed->GetFootBlood();
	}
	static cell AMX_NATIVE_CALL GetHealth(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetHealth();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetMass(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetMass();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetModelIndex(AMX *amx, cell *params)
	{
		return LocalPed->GetModelIndex();
	}
	static cell AMX_NATIVE_CALL GetMovementSpeed(AMX *amx, cell *params)
	{
		CVector pMs;
		LocalPed->GetMoveSpeed(&pMs);
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		*cptra = amx_ftoc(pMs.fX);
		*cptrb = amx_ftoc(pMs.fY);
		*cptrc = amx_ftoc(pMs.fZ);
		return 1;
	}
	static cell AMX_NATIVE_CALL GetOccupiedSeat(AMX *amx, cell *params)
	{
		return LocalPed->GetOccupiedSeat();
	}
	static cell AMX_NATIVE_CALL GetOxygenLevel(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetOxygenLevel();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetPosition(AMX *amx, cell *params)
	{
		CVector pMs(*LocalPed->GetPosition());
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		*cptra = amx_ftoc(pMs.fX);
		*cptrb = amx_ftoc(pMs.fY);
		*cptrc = amx_ftoc(pMs.fZ);
		return 1;
	}
	static cell AMX_NATIVE_CALL GetRunState(AMX *amx, cell *params)
	{
		return LocalPed->GetRunState();
	}
	static cell AMX_NATIVE_CALL GetStayInSamePlace(AMX *amx, cell *params)
	{
		return LocalPed->GetStayInSamePlace();
	}
	static cell AMX_NATIVE_CALL GetTargetRotation(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetTargetRotation();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetTestForShotInVehicle(AMX *amx, cell *params)
	{
		return LocalPed->GetTestForShotInVehicle();
	}
	static cell AMX_NATIVE_CALL GetTurnMass(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetTurnMass();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL GetTurnSpeed(AMX *amx, cell *params)
	{
		CVector pMs;
		LocalPed->GetTurnSpeed(&pMs);
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		*cptra = amx_ftoc(pMs.fX);
		*cptrb = amx_ftoc(pMs.fY);
		*cptrc = amx_ftoc(pMs.fZ);
		return 1;
	}
	static cell AMX_NATIVE_CALL GetUnderwater(AMX *amx, cell *params)
	{
		return LocalPed->GetUnderwater();
	}
	static cell AMX_NATIVE_CALL GetType(AMX *amx, cell *params)
	{
		return LocalPed->GetType();
	}
	/*static cell AMX_NATIVE_CALL GetWeapon(AMX *amx, cell *params)
	{
		return LocalPed->GetWeapon(static_cast < eWeaponType > (params[1]))->;
	}*/
	static cell AMX_NATIVE_CALL GiveWeapon(AMX *amx, cell *params)
	{
		LocalPed->GiveWeapon(static_cast < eWeaponType > (params[1]),params[2],static_cast < eWeaponSkill > (params[3]))->SetAsCurrentWeapon();
		return 1;
	}
	static cell AMX_NATIVE_CALL IsBackfaceCulled(AMX *amx, cell *params)
	{
		return LocalPed->IsBackfaceCulled();
	}
	static cell AMX_NATIVE_CALL IsDucking(AMX *amx, cell *params)
	{
		return LocalPed->IsDucking();
	}
	static cell AMX_NATIVE_CALL IsFullyVisible(AMX *amx, cell *params)
	{
		return LocalPed->IsFullyVisible();
	}
	static cell AMX_NATIVE_CALL IsInWater(AMX *amx, cell *params)
	{
		return LocalPed->IsInWater();
	}
	static cell AMX_NATIVE_CALL IsOnFire(AMX *amx, cell *params)
	{
		return LocalPed->IsOnFire();
	}
	static cell AMX_NATIVE_CALL IsOnScreen(AMX *amx, cell *params)
	{
		return LocalPed->IsOnScreen();
	}
	static cell AMX_NATIVE_CALL IsStatic(AMX *amx, cell *params)
	{
		return LocalPed->IsStatic();
	}
	static cell AMX_NATIVE_CALL IsStaticWaitingForCollision(AMX *amx, cell *params)
	{
		return LocalPed->IsStaticWaitingForCollision();
	}
	static cell AMX_NATIVE_CALL IsVisible(AMX *amx, cell *params)
	{
		return LocalPed->IsVisible();
	}
	static cell AMX_NATIVE_CALL IsWearingGoggles(AMX *amx, cell *params)
	{
		return LocalPed->IsWearingGoggles();
	}
	static cell AMX_NATIVE_CALL Respawn(AMX *amx, cell *params)
	{
		LocalPed->Respawn(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])),params[4]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetAreaCode(AMX *amx, cell *params)
	{
		LocalPed->SetAreaCode((BYTE)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetArmor(AMX *amx, cell *params)
	{
		LocalPed->SetArmor(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetBackfaceCulled(AMX *amx, cell *params)
	{
		LocalPed->SetBackfaceCulled((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL GetBuoyancyConstant(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetBuoyancyConstant();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL SetBuoyancyConstant(AMX *amx, cell *params)
	{
		LocalPed->SetBuoyancyConstant(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetCanBeShotInVehicle(AMX *amx, cell *params)
	{
		LocalPed->SetCanBeShotInVehicle((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetCantBeKnockedOffBike(AMX *amx, cell *params)
	{
		LocalPed->SetCantBeKnockedOffBike(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetCurrentRotation(AMX *amx, cell *params)
	{
		LocalPed->SetCurrentRotation(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetCurrentWeaponSlot(AMX *amx, cell *params)
	{
		LocalPed->SetCurrentWeaponSlot(static_cast < eWeaponSlot > (params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetDucking(AMX *amx, cell *params)
	{
		LocalPed->SetDucking((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetElasticity(AMX *amx, cell *params)
	{
		LocalPed->SetElasticity(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetFightingStyle(AMX *amx, cell *params)
	{
		LocalPed->SetFightingStyle(static_cast < eFightingStyle > (params[1]),(BYTE)params[2]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetFootBlood(AMX *amx, cell *params)
	{
		LocalPed->SetFootBlood(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetGogglesState(AMX *amx, cell *params)
	{
		LocalPed->SetGogglesState((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetHealth(AMX *amx, cell *params)
	{
		LocalPed->SetHealth(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetIsStanding(AMX *amx, cell *params)
	{
		LocalPed->SetIsStanding((bool)params[1]);
		return 1;
	}

	static cell AMX_NATIVE_CALL SetLighting(AMX *amx, cell *params)
	{
		LocalPed->SetLighting(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL GetLighting(AMX *amx, cell *params)
	{
		float temp = LocalPed->GetLighting();
		return amx_ftoc(temp);
	}
	static cell AMX_NATIVE_CALL SetMass(AMX *amx, cell *params)
	{
		LocalPed->SetMass(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetModelIndex(AMX *amx, cell *params)
	{
		LocalPed->SetModelIndex(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetMoveSpeed(AMX *amx, cell *params)
	{
		LocalPed->SetMoveSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetOccupiedSeat(AMX *amx, cell *params)
	{
		LocalPed->SetOccupiedSeat((BYTE)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetOnFire(AMX *amx, cell *params)
	{
		LocalPed->SetOnFire((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetOrientation(AMX *amx, cell *params)
	{
		LocalPed->SetOrientation(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetOxygenLevel(AMX *amx, cell *params)
	{
		LocalPed->SetOxygenLevel(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetPosition(AMX *amx, cell *params)
	{
		LocalPed->SetPosition(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetStatic(AMX *amx, cell *params)
	{
		LocalPed->SetStatic((BOOL)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetStaticWaitingForCollision(AMX *amx, cell *params)
	{
		LocalPed->SetStaticWaitingForCollision((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetStayInSamePlace(AMX *amx, cell *params)
	{
		LocalPed->SetStayInSamePlace((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetTargetRotation(AMX *amx, cell *params)
	{
		LocalPed->SetTargetRotation(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetTestForShotInVehicle(AMX *amx, cell *params)
	{
		LocalPed->SetTestForShotInVehicle((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetTurnMass(AMX *amx, cell *params)
	{
		LocalPed->SetTurnMass(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetTurnSpeed(AMX *amx, cell *params)
	{
		LocalPed->SetTurnSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetUnderwater(AMX *amx, cell *params)
	{
		LocalPed->SetUnderwater((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetUsesCollision(AMX *amx, cell *params)
	{
		LocalPed->SetUsesCollision((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetVisible(AMX *amx, cell *params)
	{
		LocalPed->SetVisible((bool)params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL Teleport(AMX *amx, cell *params)
	{
		LocalPed->Teleport(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		return 1;
	}
	//
	static cell AMX_NATIVE_CALL SetGravity(AMX *amx, cell *params)
	{
		pGame->SetGravity(amx_ctof(params[1]));
		return 1;
	}
	static cell AMX_NATIVE_CALL SetBlurLevel(AMX *amx, cell *params)
	{
		pGame->SetBlurLevel(params[1]);
		return 1;
	}
	static cell AMX_NATIVE_CALL SetGameSpeed(AMX *amx, cell *params)
	{
		pGame->SetGameSpeed(amx_ctof(params[1]));
		return 1;
	}
};//namespace PawnFunc