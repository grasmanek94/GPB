//functions
#include <main.h>
#include <proxydll.h>
char* format_amxstring(AMX *amx, cell *params, int parm, int &len);
int set_amxstring(AMX *amx,cell amx_addr,const char *source,int max);
namespace Functions
{
	void ConvertMatrixToEulerAngles ( const CMatrix& Matrix, float& fX, float& fY, float& fZ )
	{
		// Convert the given matrix to a padded matrix
		CMatrix_Padded matrixPadded ( Matrix );

		// Grab its pointer and call gta's func
		CMatrix_Padded* pMatrixPadded = &matrixPadded;
		DWORD dwFunc = FUNC_CMatrix__ConvertToEulerAngles;

		float* pfX = &fX;
		float* pfY = &fY;
		float* pfZ = &fZ;
		int iUnknown = 21;
		_asm
		{
			push    iUnknown
			push    pfZ
			push    pfY
			push    pfX
			mov     ecx, pMatrixPadded
			call    dwFunc
		}
	}
};//namespace Functions

//Pawn Functions
#define PWNFUNC(a) static cell AMX_NATIVE_CALL a(AMX *amx, cell *params)

namespace PawnFunc
{
	PWNFUNC(GetGameVersion)
	{		
		return pGameInterface->FindGameVersion();
	}
	PWNFUNC(GetBlurLevel)
	{
		return pGameInterface->GetBlurLevel();
	}
	PWNFUNC(GetGameTime)
	{
		cell* cptra;
		cell* cptrb;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		pGameInterface->GetClock()->Get((BYTE*)*cptra,(BYTE*)*cptrb);
		return 1;
	}
	PWNFUNC(GetFPS)
	{
		float temp = pGameInterface->GetFPS();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetGameSpeed)
	{
		float temp = pGameInterface->GetGameSpeed();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetGravity)
	{
		float temp = pGameInterface->GetGravity();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetBikeFrontWheelCounter)
	{
		return pGameInterface->GetPlayerInfo()->GetBikeFrontWheelCounter();
	}
	PWNFUNC(GetBikeFrontWheelDist)
	{
		float temp = pGameInterface->GetPlayerInfo()->GetBikeFrontWheelDist();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetBikeRearWheelCounter)
	{
		return pGameInterface->GetPlayerInfo()->GetBikeRearWheelCounter();
	}
	PWNFUNC(GetBikeRearWheelDist)
	{
		float temp = pGameInterface->GetPlayerInfo()->GetBikeRearWheelDist();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetCarLess3WheelCounter)
	{
		return pGameInterface->GetPlayerInfo()->GetCarLess3WheelCounter();
	}
	PWNFUNC(GetCarTwoWheelCounter)
	{
		return pGameInterface->GetPlayerInfo()->GetCarTwoWheelCounter();
	}
	PWNFUNC(GetCarTwoWheelDist)
	{
		float temp = pGameInterface->GetPlayerInfo()->GetCarTwoWheelDist();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetCrossHair)
	{
		bool IsEnabled;
		float PosX;
		float PosY;
		pGameInterface->GetPlayerInfo()->GetCrossHair(IsEnabled,PosX,PosY);
		cell* cptra;
		cell* cptrb;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		*cptra = amx_ftoc(PosX);
		*cptrb = amx_ftoc(PosY);
		return IsEnabled;
	}
	PWNFUNC(GetDoesNotGetTired)
	{
		return pGameInterface->GetPlayerInfo()->GetDoesNotGetTired();
	}
	PWNFUNC(GetFPSMoveHeading)
	{
		float temp = pGameInterface->GetPlayerInfo()->GetFPSMoveHeading();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetLastTimeBigGunFired)
	{
		return pGameInterface->GetPlayerInfo()->GetLastTimeBigGunFired();
	}
	PWNFUNC(GetLastTimeEaten)
	{
		return pGameInterface->GetPlayerInfo()->GetLastTimeEaten();
	}
	PWNFUNC(GetPlayerMoney)
	{
		return pGameInterface->GetPlayerInfo()->GetPlayerMoney();
	}
	PWNFUNC(GetWantedLevel)
	{
		return pGameInterface->GetPlayerInfo()->GetWanted()->GetWantedLevel();
	}
	PWNFUNC(SetMaximumWantedLevel)
	{
		pGameInterface->GetPlayerInfo()->GetWanted()->SetMaximumWantedLevel(params[1]);
		return 1;
	}
	PWNFUNC(SetWantedLevel)
	{
		pGameInterface->GetPlayerInfo()->GetWanted()->SetWantedLevel(params[1]);
		return 1;
	}
	PWNFUNC(SetWantedLevelNoDrop)
	{
		pGameInterface->GetPlayerInfo()->GetWanted()->SetWantedLevelNoDrop(params[1]);
		return 1;
	}
	PWNFUNC(GivePlayerParachute)
	{
		pGameInterface->GetPlayerInfo()->GivePlayerParachute();
		return 1;
	}
	PWNFUNC(SetDoesNotGetTired)
	{
		pGameInterface->GetPlayerInfo()->SetDoesNotGetTired((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetLastTimeBigGunFired)
	{
		pGameInterface->GetPlayerInfo()->SetLastTimeBigGunFired(params[1]);
		return 1;
	}
	PWNFUNC(SetLastTimeEaten)
	{
		pGameInterface->GetPlayerInfo()->SetLastTimeEaten(params[1]);
		return 1;
	}
	PWNFUNC(SetPlayerMoney)
	{
		pGameInterface->GetPlayerInfo()->SetPlayerMoney(params[1]);
		return 1;
	}
	PWNFUNC(StreamParachuteWeapon)
	{
		pGameInterface->GetPlayerInfo()->StreamParachuteWeapon((bool)params[1]);
		return 1;
	}
	PWNFUNC(RemoveWeaponModel)
	{
		LocalPed->ClearWeapon ( static_cast < eWeaponType > (params[1]));
		LocalPed->RemoveWeaponModel ( static_cast < eWeaponType > (params[1]) );

		// Set whatever weapon to 0 ammo so we don't keep it anymore
		CWeapon* pWeapon = LocalPed->GetWeapon ( static_cast < eWeaponType > (params[1]) );
		if ( pWeapon )
		{
			pWeapon->SetType ( WEAPONTYPE_UNARMED );
			pWeapon->SetAmmoInClip ( 0 );
			pWeapon->SetAmmoTotal ( 0 );
			pWeapon->Remove ();
		}
		return 1;
	}
	PWNFUNC(RemoveAllWeapons)
	{
		LocalPed->ClearWeapons();
		return 1;
	}
	PWNFUNC(GetAreaCode)
	{
		return LocalPed->GetAreaCode();
	}
	PWNFUNC(GetArmor)
	{
		float temp = LocalPed->GetArmor();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetCanBeShotInVehicle)
	{
		return LocalPed->GetCanBeShotInVehicle();
	}
	PWNFUNC(GetCantBeKnockedOffBike)
	{
		return LocalPed->GetCantBeKnockedOffBike();
	}
	PWNFUNC(GetCurrentRotation)
	{
		float temp = LocalPed->GetCurrentRotation()*57.2957795f;
		return amx_ftoc(temp);
	}
	PWNFUNC(GetCurrentWeaponSlot)
	{
		return LocalPed->GetPedInterface()->bCurrentWeaponSlot;
	}
	/*PWNFUNC(GetCantBeKnockedOffBike)
	{
		CWeaponStat * stat = LocalPed->GetCurrentWeaponStat();
		stat->
		return 0;
	}*/
	PWNFUNC(GetDistFromCentreOfMassToBase)
	{
		float temp = LocalPed->GetDistanceFromCentreOfMassToBaseOfModel();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetElasticity)
	{
		float temp = LocalPed->GetElasticity();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetFightingStyle)
	{
		return LocalPed->GetFightingStyle();
	}
	PWNFUNC(GetHealth)
	{
		float temp = 0.0f;
		if(params[1] = 1)
		{
			if(pVehicle != NULL)
			{
				temp = pVehicle->GetHealth();
			}else temp = LocalPed->GetHealth();
		}
		else temp = LocalPed->GetHealth();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetMass)
	{
		float temp = LocalPed->GetMass();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetModelIndex)
	{
		return LocalPed->GetModelIndex();
	}
	PWNFUNC(GetMovementSpeed)
	{
		CVector pMs;
		if(params[4] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->GetMoveSpeed(&pMs);
			}else LocalPed->GetMoveSpeed(&pMs);
		}else LocalPed->GetMoveSpeed(&pMs);
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		*cptra = amx_ftoc(pMs.fX);
		*cptrb = amx_ftoc(pMs.fY);
		*cptrc = amx_ftoc(pMs.fZ);
		return 1;
	}
	PWNFUNC(GetOccupiedSeat)
	{
		return LocalPed->GetOccupiedSeat();
	}
	PWNFUNC(GetPosition)
	{
		CVector pMs;
		if(params[4] == 1)
		{
			if(pVehicle != NULL)
			{
				pMs = *pVehicle->GetPosition();
			}else pMs = *LocalPed->GetPosition();
		}else pMs = *LocalPed->GetPosition();
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		*cptra = amx_ftoc(pMs.fX);
		*cptrb = amx_ftoc(pMs.fY);
		*cptrc = amx_ftoc(pMs.fZ);
		return 1;
	}
	PWNFUNC(GetRunState)
	{
		return LocalPed->GetRunState();
	}
	PWNFUNC(GetStayInSamePlace)
	{
		return LocalPed->GetStayInSamePlace();
	}
	PWNFUNC(GetTargetRotation)
	{
		float temp = LocalPed->GetTargetRotation();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetTestForShotInVehicle)
	{
		return LocalPed->GetTestForShotInVehicle();
	}
	PWNFUNC(GetTurnMass)
	{
		float temp = 0.0;
		if(params[1] = 1)
		{
			if(pVehicle != NULL)
			{
				temp = pVehicle->GetTurnMass();
			}else temp = LocalPed->GetTurnMass();
		}else temp = LocalPed->GetTurnMass();
		return amx_ftoc(temp);
	}
	PWNFUNC(GetTurnSpeed)
	{
		CVector pMs;
		if(params[4] == 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->GetTurnSpeed(&pMs);
			}else LocalPed->GetTurnSpeed(&pMs);
		}
		else LocalPed->GetTurnSpeed(&pMs);
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		*cptra = amx_ftoc(pMs.fX);
		*cptrb = amx_ftoc(pMs.fY);
		*cptrc = amx_ftoc(pMs.fZ);
		return 1;
	}
	PWNFUNC(GetUnderwater)
	{
		return LocalPed->GetUnderwater();
	}
	PWNFUNC(GetType)
	{
		return LocalPed->GetType();
	}
	/*PWNFUNC(GetWeapon)
	{
		return LocalPed->GetWeapon(static_cast < eWeaponType > (params[1]))->;
	}*/
	PWNFUNC(GiveWeapon)
	{
		LocalPed->GiveWeapon(static_cast < eWeaponType > (params[1]),params[2])->SetAsCurrentWeapon();
		return 1;
	}
	PWNFUNC(IsBackfaceCulled)
	{
		//return LocalPed->IsBackfaceCulled();
		return 0;
	}
	PWNFUNC(IsDucking)
	{
		return LocalPed->IsDucking();
	}
	PWNFUNC(IsFullyVisible)
	{
		//return LocalPed->IsFullyVisible();
		return 0;
	}
	PWNFUNC(IsInWater)
	{
		return LocalPed->IsInWater();
	}
	PWNFUNC(IsOnFire)
	{
		return LocalPed->IsOnFire();
	}
	PWNFUNC(IsOnScreen)
	{
		return LocalPed->IsOnScreen();
	}
	PWNFUNC(IsStatic)
	{
		return LocalPed->IsStatic();
	}
	PWNFUNC(IsStaticWaitingForCollision)
	{
		return LocalPed->IsStaticWaitingForCollision();
	}
	PWNFUNC(IsVisible)
	{
		return LocalPed->IsVisible();
	}
	PWNFUNC(IsWearingGoggles)
	{
		return LocalPed->IsWearingGoggles();
	}
	PWNFUNC(Respawn)
	{
		LocalPed->Respawn(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])),params[4]);
		return 1;
	}
	PWNFUNC(SetAreaCode)
	{
		LocalPed->SetAreaCode((BYTE)params[1]);
		return 1;
	}
	PWNFUNC(SetArmor)
	{
		LocalPed->SetArmor(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetBackfaceCulled)
	{
		//LocalPed->SetBackfaceCulled((bool)params[1]);
		return 1;
	}
	PWNFUNC(GetBuoyancyConstant)
	{
		float temp = LocalPed->GetBuoyancyConstant();
		return amx_ftoc(temp);
	}
	PWNFUNC(SetBuoyancyConstant)
	{
		LocalPed->SetBuoyancyConstant(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetCanBeShotInVehicle)
	{
		LocalPed->SetCanBeShotInVehicle((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetCantBeKnockedOffBike)
	{
		LocalPed->SetCantBeKnockedOffBike(params[1]);
		return 1;
	}
	PWNFUNC(SetCurrentRotation)
	{
		LocalPed->SetCurrentRotation(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetCurrentWeaponSlot)
	{
		LocalPed->SetCurrentWeaponSlot(static_cast < eWeaponSlot > (params[1]));
		return 1;
	}
	PWNFUNC(SetDucking)
	{
		LocalPed->SetDucking((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetElasticity)
	{
		LocalPed->SetElasticity(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetFightingStyle)
	{
		LocalPed->SetFightingStyle(static_cast < eFightingStyle > (params[1]),(BYTE)params[2]);
		return 1;
	}
	PWNFUNC(SetFootBlood)
	{
		//LocalPed->SetFootBlood(params[1]);
		return 1;
	}
	PWNFUNC(SetGogglesState)
	{
		LocalPed->SetGogglesState((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetHealth)
	{
		if(params[2] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->SetHealth(amx_ctof(params[1]));
			}
			else LocalPed->SetHealth(amx_ctof(params[1]));
		}else LocalPed->SetHealth(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetIsStanding)
	{
		LocalPed->SetIsStanding((bool)params[1]);
		return 1;
	}

	PWNFUNC(SetLighting)
	{
		LocalPed->SetLighting(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(GetLighting)
	{
		float temp = LocalPed->GetLighting();
		return amx_ftoc(temp);
	}
	PWNFUNC(SetMass)
	{
		if(params[2] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->SetMass(amx_ctof(params[1]));
			}
			else LocalPed->SetMass(amx_ctof(params[1]));
		}else LocalPed->SetMass(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetModelIndex)
	{
		LocalPed->SetModelIndex(params[1]);
		return 1;
	}
	PWNFUNC(SetMoveSpeed)
	{
		if(params[4] = 1)
		{
			vehicle_info *vehicle = vehicle_info_get( VEHICLE_SELF, 0 );
			if(vehicle != NULL)
			{
				pVehicle->SetMoveSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
				//vehicle->m_SpeedVec = CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			}
			else LocalPed->SetMoveSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
		}else LocalPed->SetMoveSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
		return 1;
	}
	PWNFUNC(SetOccupiedSeat)
	{
		LocalPed->SetOccupiedSeat((BYTE)params[1]);
		return 1;
	}
	PWNFUNC(SetOnFire)
	{
		LocalPed->SetOnFire((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetOrientation)
	{
		if(params[4] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->SetOrientation(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			}
			else LocalPed->SetOrientation(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		}else LocalPed->SetOrientation(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		return 1;
	}
	PWNFUNC(SetOxygenLevel)
	{
		//LocalPed->SetOxygenLevel(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetPosition)
	{
		if(params[4] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->SetPosition(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			}
			else LocalPed->SetPosition(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		}
		else LocalPed->SetPosition(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		return 1;
	}
	PWNFUNC(SetStatic)
	{
		LocalPed->SetStatic((BOOL)params[1]);
		return 1;
	}
	PWNFUNC(SetStaticWaitingForCollision)
	{
		LocalPed->SetStaticWaitingForCollision((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetStayInSamePlace)
	{
		LocalPed->SetStayInSamePlace((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetTargetRotation)
	{
		LocalPed->SetTargetRotation(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetTestForShotInVehicle)
	{
		LocalPed->SetTestForShotInVehicle((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetTurnMass)
	{
		if(params[2] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->SetTurnMass(amx_ctof(params[1]));
			}
			else LocalPed->SetTurnMass(amx_ctof(params[1]));
		}else LocalPed->SetTurnMass(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetTurnSpeed)
	{
		if(params[4] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->SetTurnSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
				//vehicle->m_SpinVec = CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			}
			else LocalPed->SetTurnSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));
		}
		else LocalPed->SetTurnSpeed(&CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])));	
		return 1;
	}
	PWNFUNC(SetUnderwater)
	{
		LocalPed->SetUnderwater((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetUsesCollision)
	{
		LocalPed->SetUsesCollision((bool)params[1]);
		return 1;
	}
	PWNFUNC(SetVisible)
	{
		LocalPed->SetVisible((bool)params[1]);
		return 1;
	}
	PWNFUNC(Teleport)
	{
		if(params[4] = 1)
		{
			if(pVehicle != NULL)
			{
				pVehicle->Teleport(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			}
			else LocalPed->Teleport(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		}
		else LocalPed->Teleport(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		return 1;
	}
	//
	PWNFUNC(SetGravity)
	{
		pGameInterface->SetGravity(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(SetBlurLevel)
	{
		pGameInterface->SetBlurLevel(params[1]);
		return 1;
	}
	PWNFUNC(SetGameSpeed)
	{
		pGameInterface->SetGameSpeed(amx_ctof(params[1]));
		return 1;
	}
	PWNFUNC(AddFont)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		fonts.push_back(TextCreate(tmp,params[2],params[3]));
		return fonts.size()-1;
	}
	PWNFUNC(DXDrawText)//FontID,X,Y,Color,Text
	{
		char * tmp;
		amx_StrParam(amx,params[5],tmp);
		fonts[params[1]]->PrintShadow(amx_ctof(params[2]),amx_ctof(params[3]),params[4],tmp);
		return 1;
	}
	// native format(output[], len, const format[], {Float,_}:...)
	PWNFUNC(format)
	{
	  int len;
	  return set_amxstring(amx, params[1], format_amxstring(amx, params, 3, len), params[2]);
	}
	PWNFUNC(GetScreenInfo)
	{
		VideoMode mode;
		pGameInterface->GetSettings()->GetVideoModeInfo(&mode,pGameInterface->GetSettings()->GetCurrentVideoMode());
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		cell* cptrd;
		amx_GetAddr(amx, params[1], &cptra);
		amx_GetAddr(amx, params[2], &cptrb);
		amx_GetAddr(amx, params[3], &cptrc);
		amx_GetAddr(amx, params[4], &cptrd);
		*cptra = mode.depth;
		*cptrb = mode.refRate;
		*cptrc = mode.height;
		*cptrd = mode.width;
		return 1;
	}
	PWNFUNC(_GetTickCount)
	{
		return (int)GetCounter();
	}
	PWNFUNC(DXDrawLine)
	{
		render->DrawLine(D3DXVECTOR3(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3])),D3DXVECTOR3(amx_ctof(params[4]),amx_ctof(params[5]),amx_ctof(params[6])),params[7]);
		return 1;
	}
	PWNFUNC(n_print)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		Log(tmp);
		return 1;
	}
	PWNFUNC(GetVehicleCount)
	{
		return pool_vehicle->size;
	}

	PWNFUNC(IsPlayerInVehicle)
	{
		return pVehicle != NULL;
	}
	PWNFUNC(GetVehicleModel)
	{
		if(pVehicle != NULL)
		{
			return pVehicle->GetModelIndex();
		}
		return 0;
	}
	PWNFUNC(AddVehicleUpgrade)
	{
		if(pVehicle != NULL)
		{
			pVehicle->AddVehicleUpgrade(params[1]);
			return 1;
		}
		return 0;
	}
	PWNFUNC(AreVehicleDoorsLocked)
	{
		if(pVehicle != NULL)
		{
			return pVehicle->AreDoorsLocked();
		}
		return -1;
	}
	PWNFUNC(AreVehicleDoorsUndamageable)
	{
		if(pVehicle != NULL)
		{
			return pVehicle->AreDoorsUndamageable();
		}
		return -1;
	}
	PWNFUNC(BurstVehicleTyre)
	{
		if(pVehicle != NULL)
		{
			pVehicle->BurstTyre(params[1]);
			return 1;
		}
		return 0;
	}
	PWNFUNC(BreakVehicleTowLink)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->BreakTowLink();
		}
		return -1;
	}
	PWNFUNC(CarHasRoof)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->CarHasRoof();
		}
		return -1;
	}
	PWNFUNC(ExtinguishCarFire)
	{
		if(pVehicle != NULL)
		{	
			pVehicle->ExtinguishCarFire();
			return 1;
		}
		return 0;
	}
	PWNFUNC(FixVehicle)
	{
		if(pVehicle != NULL)
		{	
			pVehicle->Fix();
			return 1;
		}
		return 0;
	}
	PWNFUNC(GetCanVehicleBeDamaged)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->GetCanBeDamaged();
		}
		return -1;
	}
	PWNFUNC(CanVehicleBeTargetedByBazooka)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->GetCanBeTargettedByHeatSeekingMissiles();
		}
		return -1;
	}
	PWNFUNC(CanVehiclePetrolTankBeShot)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->GetCanShootPetrolTank();
		}
		return -1;
	}
	PWNFUNC(GetVehColorChangesWhenPaintjob)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->GetChangeColourWhenRemapping();
		}
		return -1;
	}
	PWNFUNC(GetVehicleColor)
	{
		if(pVehicle != NULL)
		{	
			BYTE color[4];
			pVehicle->GetColor(&color[0],&color[1],&color[2],&color[3]);
			cell* cptra;
			cell* cptrb;
			cell* cptrc;
			cell* cptrd;
			amx_GetAddr(amx, params[1], &cptra);
			amx_GetAddr(amx, params[2], &cptrb);
			amx_GetAddr(amx, params[3], &cptrc);
			amx_GetAddr(amx, params[4], &cptrd);
			*cptra = color[0];
			*cptrb = color[1];
			*cptrc = color[2];
			*cptrd = color[3];
			return color[0] << 24 | color[1] << 16 | color[2] << 8 | color[3];
		}
		return 0;
	}
	PWNFUNC(GetCurrentGear)
	{
		if(pVehicle != NULL)
		{	
			return pVehicle->GetCurrentGear();
		}
		return -1;
	}
	PWNFUNC(GetVehicleElasticity)
	{
		float temp = 0.0f;
		if(pVehicle != NULL)
		{	
			temp = pVehicle->GetElasticity();
		}
		return amx_ctof(temp);
	}
	PWNFUNC(GetVehicleGasPedal)
	{
		float temp = 0.0f;
		if(pVehicle != NULL)
		{	
			temp = pVehicle->GetGasPedal();
		}
		return amx_ctof(temp);
	}
	PWNFUNC(GetVehicleBreakPedal)
	{
		float temp = 0.0f;
		if(pVehicle != NULL)
		{	
			temp = -pVehicle->GetGasPedal();
		}
		return amx_ctof(temp);
	}
	PWNFUNC(SetVehicleHandlingData)
	{
		vehicle_info *vehicle = vehicle_info_get( VEHICLE_SELF, 0 );
		if(vehicle != NULL)
		{	
			switch(params[1])
			{
				case 0:
					vehicle->pHandlingData->bABS = (params[2]);
				break;
				case 1:
					vehicle->pHandlingData->ucAnimGroup = (params[2]);
				break;
				case 2:
					vehicle->pHandlingData->fBrakeBias = (amx_ctof(params[2]));
				break;
				case 3:
					vehicle->pHandlingData->fBrakeDecelleration = (amx_ctof(params[2]));
				break;
				case 4:
					vehicle->pHandlingData->Transmission.ucDriveType = (params[2]);
				break;
				case 5:
					vehicle->pHandlingData->Transmission.ucEngineType = (params[2]);
				break;
				case 6:
					vehicle->pHandlingData->vecCenterOfMass = (CVector(amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4])));
				break;
				case 7:
					vehicle->pHandlingData->fCollisionDamageMultiplier = (amx_ctof(params[2]));
				break;
				case 8:
					vehicle->pHandlingData->fDragCoeff = (amx_ctof(params[2]));
				break;
				case 9:
					vehicle->pHandlingData->Transmission.fEngineAccelleration = (amx_ctof(params[2]));
				break;
				case 10:
					vehicle->pHandlingData->Transmission.fEngineInertia = (amx_ctof(params[2]));
				break;
				case 11:
					vehicle->pHandlingData->uiHandlingFlags = (params[2]);
				break;
				case 12:
					vehicle->pHandlingData->ucHeadLight = (params[2]);
				break;
				case 13:
					vehicle->pHandlingData->fMass = (amx_ctof(params[2]));
				break;
				case 14:
					vehicle->pHandlingData->Transmission.fMaxVelocity = (amx_ctof(params[2]));
				break;
				case 15:
					vehicle->pHandlingData->uiModelFlags = (params[2]);
				break;
				case 16:
					vehicle->pHandlingData->uiMonetary = (params[2]);
				break;
				case 17:
					vehicle->pHandlingData->Transmission.ucNumberOfGears = (params[2]);
				break;
				case 18:
					vehicle->pHandlingData->uiPercentSubmerged = (params[2]);
				break;
				case 19:
					vehicle->pHandlingData->fSeatOffsetDistance = (amx_ctof(params[2]));
				break;
				case 20:
					vehicle->pHandlingData->fSteeringLock = (amx_ctof(params[2]));
				break;
				case 21:
					vehicle->pHandlingData->fSuspensionAntidiveMultiplier = (amx_ctof(params[2]));
				break;
				case 22:
					vehicle->pHandlingData->fSuspensionDamping = (amx_ctof(params[2]));
				break;
				case 23:
					vehicle->pHandlingData->fSuspensionForceLevel = (amx_ctof(params[2]));
				break;
				case 24:
					vehicle->pHandlingData->fSuspensionFrontRearBias = (amx_ctof(params[2]));
				break;
				case 25:
					vehicle->pHandlingData->fSuspensionHighSpdDamping = (amx_ctof(params[2]));
				break;
				case 26:
					vehicle->pHandlingData->fSuspensionLowerLimit = (amx_ctof(params[2]));
				break;
				case 27:
					vehicle->pHandlingData->fSuspensionUpperLimit = (amx_ctof(params[2]));
				break;
				case 28:
					vehicle->pHandlingData->ucTailLight = (params[2]);
				break;
				case 29:
					vehicle->pHandlingData->fTractionBias = (amx_ctof(params[2]));
				break;
				case 30:
					vehicle->pHandlingData->fTractionLoss = (amx_ctof(params[2]));
				break;
				case 31:
					vehicle->pHandlingData->fTractionMultiplier = (amx_ctof(params[2]));
				break;
				case 32:
					vehicle->pHandlingData->fTurnMass = (amx_ctof(params[2]));
				break;
			}
			return 1;
		}
		return 0;
	}
	PWNFUNC(SetVehicleColor)
	{
		if(pVehicle != NULL)
		{
			pVehicle->SetColor(params[1],params[2],params[3],params[4]);
			return 1;
		}
		return 0;
	}
	PWNFUNC(SetVehclePaintjob)
	{
		if(pVehicle != NULL)
		{
			pVehicle->SetRemap(params[1]);
			return 1;
		}
		return 0;
	}
	PWNFUNC(SetVehclePaintjobDictionary)
	{
		if(pVehicle != NULL)
		{
			pVehicle->SetRemapTexDictionary(params[1]);
			return 1;
		}
		return 0;
	}
	PWNFUNC(SetChangeColourOnPaintjob)
	{
		if(pVehicle != NULL)
		{
			pVehicle->SetChangeColourWhenRemapping(params[1]);
			return 1;
		}
		return 0;
	}

	PWNFUNC(GetVehicleHandlingDataFloat)
	{
		vehicle_info *vehicle = vehicle_info_get( VEHICLE_SELF, 0 );
		float temp = 0.0f;
		if(vehicle != NULL)
		{	
			switch(params[1])
			{
				case 2:
					temp = vehicle->pHandlingData->fBrakeBias;
				break;
				case 3:
					temp = vehicle->pHandlingData->fBrakeDecelleration;
				break;
				case 7:
					temp = vehicle->pHandlingData->fCollisionDamageMultiplier;
				break;
				case 8:
					temp = vehicle->pHandlingData->fDragCoeff;
				break;
				case 9:
					temp = vehicle->pHandlingData->Transmission.fEngineAccelleration;
				break;
				case 10:
					temp = vehicle->pHandlingData->Transmission.fEngineInertia;
				break;
				case 13:
					temp = vehicle->pHandlingData->fMass;
				break;
				case 14:
					temp = vehicle->pHandlingData->Transmission.fMaxVelocity;
				break;
				case 19:
					temp = vehicle->pHandlingData->fSeatOffsetDistance;
				break;
				case 20:
					temp = vehicle->pHandlingData->fSteeringLock;
				break;
				case 21:
					temp = vehicle->pHandlingData->fSuspensionAntidiveMultiplier;
				break;
				case 22:
					temp = vehicle->pHandlingData->fSuspensionDamping;
				break;
				case 23:
					temp = vehicle->pHandlingData->fSuspensionForceLevel;
				break;
				case 24:
					temp = vehicle->pHandlingData->fSuspensionFrontRearBias;
				break;
				case 25:
					temp = vehicle->pHandlingData->fSuspensionHighSpdDamping;
				break;
				case 26:
					temp = vehicle->pHandlingData->fSuspensionLowerLimit;
				break;
				case 27:
					temp = vehicle->pHandlingData->fSuspensionUpperLimit;
				break;
				case 29:
					temp = vehicle->pHandlingData->fTractionBias;
				break;
				case 30:
					temp = vehicle->pHandlingData->fTractionLoss;
				break;
				case 31:
					temp = vehicle->pHandlingData->fTractionMultiplier;
				break;
				case 32:
					temp = vehicle->pHandlingData->fTurnMass;
				break;
			}
			return amx_ftoc(temp);
		}
		return amx_ftoc(temp);
	}

	PWNFUNC(GetVehicleHandlingDataInt)
	{
		vehicle_info *vehicle = vehicle_info_get( VEHICLE_SELF, 0 );
		if(vehicle != NULL)
		{	
			switch(params[1])
			{
				case 0:
					return vehicle->pHandlingData->bABS;
				case 1:
					return vehicle->pHandlingData->ucAnimGroup;
				case 4:
					return vehicle->pHandlingData->Transmission.ucDriveType;
				case 5:
					return vehicle->pHandlingData->Transmission.ucEngineType;
				case 11:
					return vehicle->pHandlingData->uiHandlingFlags;
				case 12:
					return vehicle->pHandlingData->ucHeadLight;
				case 15:
					return vehicle->pHandlingData->uiModelFlags;
				case 16:
					return vehicle->pHandlingData->uiMonetary;
				case 17:
					return vehicle->pHandlingData->Transmission.ucNumberOfGears;
				case 18:
					return vehicle->pHandlingData->uiPercentSubmerged;
				case 28:
					return vehicle->pHandlingData->ucTailLight;
			}
			return -1;
		}
		return -2;
	}

	PWNFUNC(GetVehicleCenterOfMass)
	{
		if(pVehicle != NULL)
		{	
			cell* cptra;
			cell* cptrb;
			cell* cptrc;
			amx_GetAddr(amx, params[1], &cptra);
			amx_GetAddr(amx, params[2], &cptrb);
			amx_GetAddr(amx, params[3], &cptrc);
			*cptra = amx_ftoc(pVehicle->GetHandlingData()->GetCenterOfMass().fX);
			*cptrb = amx_ftoc(pVehicle->GetHandlingData()->GetCenterOfMass().fX);
			*cptrc = amx_ftoc(pVehicle->GetHandlingData()->GetCenterOfMass().fX);
			return 1;
		}
		return 0;
	}
	PWNFUNC(DXd3dbox)
	{
		render->D3DBox(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4]),params[5]);
		return 1;
	}
	PWNFUNC(DXdedboxborder)
	{
		render->D3DBoxBorder(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4]),params[5],params[6]);
		return 1;
	}

	PWNFUNC(GetCursorPosition)
	{
		POINT cursor_pos;
		if (GetCursorPos(&cursor_pos) && ScreenToClient(pPresentParam.hDeviceWindow, &cursor_pos))
		{
			cell* cptra;
			cell* cptrb;
			amx_GetAddr(amx, params[1], &cptra);
			amx_GetAddr(amx, params[2], &cptrb);
			*cptra = cursor_pos.x;
			*cptrb = cursor_pos.y;
			return 1;
		}
		return 0;
	}
	PWNFUNC(ShowCursor)
	{
		origIDirect3DDevice9->ShowCursor(params[1]);
		return 1;
	}
	PWNFUNC(KEYPRESSED)
	{
		return (GetAsyncKeyState( params[1] ) < 0);
	}
	PWNFUNC(KEYDOWN)
	{
		return (GetAsyncKeyState( params[1] ) < 0);
	}
	PWNFUNC(DXCreateTexture)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		return D3DXCreateTextureFromFileA(origIDirect3DDevice9,tmp,&Textures[params[2]]);
	}
	PWNFUNC(DXCreateSprite)
	{
		D3DXCreateSprite( origIDirect3DDevice9, &Sprites[params[1]] );
		return 1;
	}
	PWNFUNC(DXCreateTextureHolder)
	{
		Textures.push_back(NULL);
		return Textures.size()-1;
	}
	PWNFUNC(DXCreateSpriteHolder)
	{
		Sprites.push_back(NULL);
		return Sprites.size()-1;
	}
	PWNFUNC(DXCreateD3DXMatrixHolder)
	{
		D3DXMatrixes.push_back(D3DXMATRIX());
		return D3DXMatrixes.size()-1;
	}
	PWNFUNC(DXCreateD3DXVector2Holder)
	{
		D3DXVectors2.push_back(D3DXVECTOR2());
		return D3DXVectors2.size()-1;
	}
	PWNFUNC(DXD3DXVector2Set)
	{
		D3DXVectors2[params[1]].x = amx_ctof(params[2]);
		D3DXVectors2[params[1]].y = amx_ctof(params[3]);
		return 1;
	}
	PWNFUNC(DXD3DXVector2Get)
	{
		cell* cptra;
		cell* cptrb;
		amx_GetAddr(amx, params[2], &cptra);
		amx_GetAddr(amx, params[3], &cptrb);
		*cptra = amx_ftoc(D3DXVectors2[params[1]].x);
		*cptrb = amx_ftoc(D3DXVectors2[params[1]].y);
		return 1;
	}
	PWNFUNC(DXD3DXMatrixTransformation2D)
	{
		D3DXMatrixTransformation2D((params[1] == -1) ? NULL : &D3DXMatrixes[params[1]],(params[2] == -1) ? NULL : &D3DXVectors2[params[2]],amx_ctof(params[3]),(params[4] == -1) ? NULL : &D3DXVectors2[params[4]],(params[5] == -1) ? NULL : &D3DXVectors2[params[5]],amx_ctof(params[6]),(params[7] == -1) ? NULL : &D3DXVectors2[params[7]]);
		return 1;
	}
	PWNFUNC(DXSprite_Begin)
	{
		return Sprites[params[1]]->Begin(params[2]);
	}
	PWNFUNC(DXSprite_End)
	{
		return Sprites[params[1]]->End();
	}
	PWNFUNC(DXSprite_SetTransform)
	{
		return Sprites[params[1]]->SetTransform(&D3DXMatrixes[params[2]]);
	}
	PWNFUNC(DXSprite_Draw)//D3DXRectangles
	{
		return Sprites[params[1]]->Draw(Textures[params[2]],(params[3] == -1) ? NULL : &D3DXRectangles[params[3]],(params[4] == -1) ? NULL : &D3DXVectors3[params[4]],(params[5] == -1) ? NULL : &D3DXVectors3[params[5]],params[6]);
	}
	PWNFUNC(DXCreateD3DXVector3Holder)
	{
		D3DXVectors3.push_back(D3DXVECTOR3());
		return D3DXVectors3.size()-1;
	}
	PWNFUNC(DXD3DXVector3Set)
	{
		D3DXVectors3[params[1]].x = amx_ctof(params[2]);
		D3DXVectors3[params[1]].y = amx_ctof(params[3]);
		D3DXVectors3[params[1]].z = amx_ctof(params[4]);
		return 1;
	}
	PWNFUNC(DXD3DXVector3Get)
	{
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		amx_GetAddr(amx, params[2], &cptra);
		amx_GetAddr(amx, params[3], &cptrb);
		amx_GetAddr(amx, params[4], &cptrc);
		*cptra = amx_ftoc(D3DXVectors3[params[1]].x);
		*cptrb = amx_ftoc(D3DXVectors3[params[1]].y);
		*cptrc = amx_ftoc(D3DXVectors3[params[1]].z);
		return 1;
	}
	PWNFUNC(DXCreateD3DXRectangleHolder)
	{
		D3DXRectangles.push_back(RECT());
		return D3DXRectangles.size()-1;
	}
	PWNFUNC(DXD3DXRectangleSet)
	{
		D3DXRectangles[params[1]].bottom = params[2];
		D3DXRectangles[params[1]].left = params[3];
		D3DXRectangles[params[1]].right = params[4];
		D3DXRectangles[params[1]].top = params[5];
		return 1;
	}
	PWNFUNC(DXD3DXRectangleGet)
	{
		cell* cptra;
		cell* cptrb;
		cell* cptrc;
		cell* cptrd;
		amx_GetAddr(amx, params[2], &cptra);
		amx_GetAddr(amx, params[3], &cptrb);
		amx_GetAddr(amx, params[4], &cptrc);
		amx_GetAddr(amx, params[5], &cptrd);
		*cptra = D3DXRectangles[params[1]].bottom;
		*cptrb = D3DXRectangles[params[1]].left;
		*cptrc = D3DXRectangles[params[1]].right;
		*cptrd = D3DXRectangles[params[1]].top;
		return 1;
	}
	PWNFUNC(GetBackBufferHeight)
	{
		return pPresentParam.BackBufferHeight;
	}
	PWNFUNC(GetBackBufferWidth)
	{
		return pPresentParam.BackBufferWidth;
	}
	PWNFUNC(DXTextureRelease)
	{
		SAFE_RELEASE(Textures[params[1]]);
		return 1;
	}
	PWNFUNC(DXSpriteRelease)
	{
		SAFE_RELEASE(Sprites[params[1]]);
		return 1;
	}
	PWNFUNC(DXTextureIsNull)
	{
		return (Textures[params[1]] == NULL) ? 1 : 0;
	}
	PWNFUNC(DXSpriteIsNull)
	{
		return (Sprites[params[1]] == NULL) ? 1 : 0;
	}
	PWNFUNC(EmulateKeyPressINPUT)
	{
		// This structure will be used to create the keyboard
		// input event.
		INPUT ip;

		// Set up a generic keyboard event.
		ip.type = INPUT_KEYBOARD;
		ip.ki.dwFlags = 0;
		if(params[4] == 1)
		{
			ip.ki.wScan = params[2]; // hardware scan code for key
			ip.ki.wVk = 0; // virtual-key code for the  key
			ip.ki.dwFlags |= KEYEVENTF_SCANCODE;
		}
		else
		{
			ip.ki.wScan = 0; // hardware scan code for key
			ip.ki.wVk = params[2]; // virtual-key code for the  key
		}

		ip.ki.time = 0;
		ip.ki.dwExtraInfo = 0;

		if(params[3] == 1)
		{
			ip.ki.dwFlags |= KEYEVENTF_EXTENDEDKEY;
		}
		if(params[1] == 1)
		{
			ip.ki.dwFlags |= KEYEVENTF_KEYUP;
		}
		return SendInput(1, &ip, sizeof(INPUT));
	}
	PWNFUNC(PWNGetLastError)
	{
		return GetLastError();
	}
	PWNFUNC(printf_f)
	{
		int len;
		Log("%s",format_amxstring(amx, params, 1, len));
		return 0;
	}
	PWNFUNC(ppGetVehicleMatrix)
	{
		if(pVehicle != NULL)
		{		
			CMatrix VehRot;
			pVehicle->GetMatrix(&VehRot);
			cell* cptr[12];
			for(unsigned short x = 0; x < 12; ++x)
			{
				amx_GetAddr(amx, params[x+1], &cptr[x]);
			}	
			*cptr[0] = amx_ftoc(VehRot.vRight.fX);
			*cptr[1] = amx_ftoc(VehRot.vRight.fY);
			*cptr[2] = amx_ftoc(VehRot.vRight.fZ);
			*cptr[3] = amx_ftoc(VehRot.vFront.fX);
			*cptr[4] = amx_ftoc(VehRot.vFront.fY);
			*cptr[5] = amx_ftoc(VehRot.vFront.fZ);
			*cptr[6] = amx_ftoc(VehRot.vUp.fX);
			*cptr[7] = amx_ftoc(VehRot.vUp.fY);
			*cptr[8] = amx_ftoc(VehRot.vUp.fZ);
			*cptr[9] = amx_ftoc(VehRot.vPos.fX);
			*cptr[10] = amx_ftoc(VehRot.vPos.fY);
			*cptr[11] = amx_ftoc(VehRot.vPos.fZ);
			return 1;
		}
		return 0;
	}
	PWNFUNC(ppSetVehicleMatrix)
	{
		if(pVehicle != NULL)
		{		
			CMatrix VehRot;
			VehRot.vRight = CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			VehRot.vFront = CVector(amx_ctof(params[4]),amx_ctof(params[5]),amx_ctof(params[6]));
			VehRot.vUp =    CVector(amx_ctof(params[7]),amx_ctof(params[8]),amx_ctof(params[9]));
			VehRot.vPos =   CVector(amx_ctof(params[10]),amx_ctof(params[11]),amx_ctof(params[12]));
			pVehicle->SetMatrix(&VehRot);
			return 1;
		}
		return 0;
	}
	PWNFUNC(ppRotateVehicleMatrix)
	{
		if(pVehicle != NULL)
		{		
			CMatrix VehRot;
			VehRot.vRight = CVector(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
			VehRot.vFront = CVector(amx_ctof(params[4]),amx_ctof(params[5]),amx_ctof(params[6]));
			VehRot.vUp =    CVector(amx_ctof(params[7]),amx_ctof(params[8]),amx_ctof(params[9]));
			VehRot.vPos =   CVector(amx_ctof(params[10]),amx_ctof(params[11]),amx_ctof(params[12]));
			CMatrix VehRotated;
			VehRotated = VehRot.Rotate(&CVector(amx_ctof(params[13]),amx_ctof(params[14]),amx_ctof(params[15])),amx_ctof(params[16]));
			cell* cptr[12];
			for(unsigned short x = 0; x < 12; ++x)
			{
				amx_GetAddr(amx, params[x+17], &cptr[x]);
			}	
			*cptr[0] = amx_ftoc(VehRotated.vRight.fX);
			*cptr[1] = amx_ftoc(VehRotated.vRight.fY);
			*cptr[2] = amx_ftoc(VehRotated.vRight.fZ);
			*cptr[3] = amx_ftoc(VehRotated.vFront.fX);
			*cptr[4] = amx_ftoc(VehRotated.vFront.fY);
			*cptr[5] = amx_ftoc(VehRotated.vFront.fZ);
			*cptr[6] = amx_ftoc(VehRotated.vUp.fX);
			*cptr[7] = amx_ftoc(VehRotated.vUp.fY);
			*cptr[8] = amx_ftoc(VehRotated.vUp.fZ);
			*cptr[9] = amx_ftoc(VehRotated.vPos.fX);
			*cptr[10] = amx_ftoc(VehRotated.vPos.fY);
			*cptr[11] = amx_ftoc(VehRotated.vPos.fZ);
			return 1;
		}
		return 0;
	}
	PWNFUNC(ppGetVehicleRotation)
	{
		if(pVehicle != NULL)
		{		
			CMatrix VehRot;
			pVehicle->GetMatrix(&VehRot);
			cell* cptr[6];
			for(unsigned short x = 0; x < 6; ++x)
			{
				amx_GetAddr(amx, params[x+2], &cptr[x]);
			}	
			float temp[6] = {0.0f};
			switch(params[1])
			{
			case 0:
				temp[0] = VehRot.vRight.GetAngleDegreesXY();
				temp[1] = VehRot.vRight.GetAngleDegreesYX();
				temp[2] = VehRot.vRight.GetAngleDegreesZY();
				temp[3] = VehRot.vRight.GetAngleDegreesYZ();
				temp[4] = VehRot.vRight.GetAngleDegreesZX();
				temp[5] = VehRot.vRight.GetAngleDegreesXZ();
			break;
			case 1:
				temp[0] = VehRot.vFront.GetAngleDegreesXY();
				temp[1] = VehRot.vFront.GetAngleDegreesYX();
				temp[2] = VehRot.vFront.GetAngleDegreesZY();
				temp[3] = VehRot.vFront.GetAngleDegreesYZ();
				temp[4] = VehRot.vFront.GetAngleDegreesZX();
				temp[5] = VehRot.vFront.GetAngleDegreesXZ();
			break;
			case 2:
				temp[0] = VehRot.vUp.GetAngleDegreesXY();
				temp[1] = VehRot.vUp.GetAngleDegreesYX();
				temp[2] = VehRot.vUp.GetAngleDegreesZY();
				temp[3] = VehRot.vUp.GetAngleDegreesYZ();
				temp[4] = VehRot.vUp.GetAngleDegreesZX();
				temp[5] = VehRot.vUp.GetAngleDegreesXZ();
			break;
			case 3:
				temp[0] = VehRot.vPos.GetAngleDegreesXY();
				temp[1] = VehRot.vPos.GetAngleDegreesYX();
				temp[2] = VehRot.vPos.GetAngleDegreesZY();
				temp[3] = VehRot.vPos.GetAngleDegreesYZ();
				temp[4] = VehRot.vPos.GetAngleDegreesZX();
				temp[5] = VehRot.vPos.GetAngleDegreesXZ();
			break;
			}
			*cptr[0] = amx_ftoc(temp[0]);
			*cptr[1] = amx_ftoc(temp[1]);
			*cptr[2] = amx_ftoc(temp[2]);
			*cptr[3] = amx_ftoc(temp[3]);
			*cptr[4] = amx_ftoc(temp[4]);
			*cptr[5] = amx_ftoc(temp[5]);
			return 1;
		}
		return 0;
	}
	PWNFUNC(ppGetVehicleRotationXYZ)
	{
		if(pVehicle != NULL)
		{		
			CMatrix VehRot;
			pVehicle->GetMatrix(&VehRot);
			cell* cptr[3];
			for(unsigned short x = 0; x < 3; ++x)
			{
				amx_GetAddr(amx, params[x+1], &cptr[x]);
			}	
			float temp[3] = {0.0f};
			Functions::ConvertMatrixToEulerAngles(VehRot,temp[0],temp[1],temp[2]);
			temp[0] *= 57.2957795f;
			temp[1] *= 57.2957795f;
			temp[2] *= 57.2957795f;
			*cptr[0] = amx_ftoc(temp[0]);
			*cptr[1] = amx_ftoc(temp[1]);
			*cptr[2] = amx_ftoc(temp[2]);
			return 1;
		}
		return 0;
	}
	
	PWNFUNC(ReloadMe)
	{
		reload_scripts_amx.push_back(amx);
		return 1;
	}
	PWNFUNC(ReloadScript)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		for(std::vector<ScriptInfo>::iterator it = scripts.begin(); it != scripts.end(); ++it) 
		{
			if(stricmp(it->Identifier.c_str(),tmp) == 0)
			{
				reload_scripts_amx.push_back(&it->amx);
				return 1;
			}
		}
		return 0;
	}
	PWNFUNC(pLoadScript)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		return LoadScript(std::string(tmp));
	}
	PWNFUNC(pUnloadScript)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		return UnloadScript(std::string(tmp));
	}
	PWNFUNC(ppLoadDLL)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		return LoadPlugin(std::string(tmp),params[2]);
	}
	PWNFUNC(ppUnloadDLL)
	{
		char * tmp;
		amx_StrParam(amx,params[1],tmp);
		return UnloadPlugin(std::string(tmp));
	}
	/*PWNFUNC(ppProcessLineOfSight)
	{
		CVector start(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		CVector end(amx_ctof(params[4]),amx_ctof(params[5]),amx_ctof(params[6]));

		if(pGameInterface->GetWorld()->ProcessLineOfSight(&start,&end,&GlobalCollision,NULL))
		{
			float colx = GlobalCollision->GetPosition()->fX;
			float coly = GlobalCollision->GetPosition()->fY;
			float colz = GlobalCollision->GetPosition()->fZ;
			cell* cptr[3];
			for(unsigned short x = 0; x < 3; ++x)
			{
				amx_GetAddr(amx, params[x+7], &cptr[x]);
			}	
			*cptr[0] = amx_ftoc(colx);
			*cptr[1] = amx_ftoc(coly);
			*cptr[2] = amx_ftoc(colz);
			if(GlobalCollision)
			{
				GlobalCollision->Destroy();
				GlobalCollision = NULL;
			}
			return 1;
		}
		if(GlobalCollision)
		{
			GlobalCollision->Destroy();
			GlobalCollision = NULL;
		}
		cell* cptrx[3];
		for(unsigned short x = 0; x < 3; ++x)
		{
			amx_GetAddr(amx, params[x+7], &cptrx[x]);
		}	
		*cptrx[0] = params[4];
		*cptrx[1] = params[5];
		*cptrx[2] = params[6];
		return 0;
	}*/
	PWNFUNC(ppProcessLineOfSight)
	{
		CVector start(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]));
		CVector end(amx_ctof(params[4]),amx_ctof(params[5]),amx_ctof(params[6]));
		CColPoint* pCollision = NULL;
		cell* cptr[3];
		for(unsigned short x = 0; x < 3; ++x)
		{
			amx_GetAddr(amx, params[x+7], &cptr[x]);
		}	
		if(pGameInterface->GetWorld()->ProcessLineOfSight(&start,&end,&pCollision,NULL))
		{
			*cptr[0] = amx_ftoc(pCollision->GetPosition()->fX);
			*cptr[1] = amx_ftoc(pCollision->GetPosition()->fY);
			*cptr[2] = amx_ftoc(pCollision->GetPosition()->fZ);
		}
		else
		{
			*cptr[0] = params[4];
			*cptr[1] = params[5];
			*cptr[2] = params[6];
		}
		if(pCollision)
		{
			pCollision->Destroy();
		}
		return 1;
	}
	PWNFUNC(Terminate)
	{
		ExitProcess(0);
		return 1;
	}
	PWNFUNC(DrawArea)
	{
		pGameInterface->GetRadar()->DrawAreaOnRadar(amx_ctof(params[1]),amx_ctof(params[2]),amx_ctof(params[3]),amx_ctof(params[4]),params[5]);
		return 1;
	}
//////////////////
};//namespace PawnFunc