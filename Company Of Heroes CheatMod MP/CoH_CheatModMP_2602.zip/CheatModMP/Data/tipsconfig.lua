locstring_id_end = 18444400
locstring_id_start = 18444401