#include <iostream>
#include <string>

#include <sampgdk/core.h>
#include <sampgdk/plugin.h>
#include <sampgdk/a_samp.h>
#include <0cmdpp.hpp>


std::string string_format(const std::string fmt, ...) 
{
	int size = 512;
	std::string str;
	va_list ap;
	while (1) {
		str.resize(size);
		va_start(ap, fmt);
		int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
		va_end(ap);
		if (n > -1 && n < size) {
			str.resize(n);
			return str;
		}
		if (n > -1)
			size = n + 1;
		else
			size *= 2;
	}
	return str;
}

bool OnPlayerCommandReceived(int playerid,std::string command, std::string params)
{
	return true;
}

void OnPlayerCommandExecuted(int playerid, std::string command, std::string params, bool success)
{
	return;
}

bool OnUnknownCommand(int playerid, std::string command, std::string params)
{
	SendClientMessage(playerid,0xFFFFFF,string_format("Unknown command issued by you: %s",command).c_str());
	return true;//disable message by server
	//return false;//show "unknown command" by sa-mp server
}

ZERO_COMMAND(start)// command /start
{
	printf("start issued, params: '%s'\n",params.c_str());
	return true;
}

ZERO_COMMAND(end)// command /end
{
	printf("end issued, params: '%s'\n",params.c_str());
	return false;
}

int main()
{
	return 0;
}

