Add "0cmdpp.cpp" to your project source files, add "0cmdpp.hpp" to the file where your commands are going to be.

Create commands with:

ZERO_COMMAND(command_name)//will create command: /command_name
{
	You have (int)playerid and (std::string)params available in this scope.
	<code>
	return <true/false>;
};