#pragma once

#include <string>
#include <map>

namespace SAMPGDK
{
	namespace ZeroCMD
	{
		class Command
		{
		public:
		   virtual bool do_command(int playerid, std::string params) = 0;
		};
		namespace Internal
		{
			void register_command(Command* cmd, std::string name);
			extern std::map<std::string, Command*> command_map;
		};
	};
};

//VS and clang have a mangled name limit of 2048 chars, g++ "unlimited" (well, limited by memory).
#define ZERO_COMMAND(name) \
class cmd ## name : public SAMPGDK::ZeroCMD::Command\
	{\
		public:\
		cmd ## name() { SAMPGDK::ZeroCMD::Internal::register_command(this, "/"#name); }\
		bool do_command(int playerid, std::string params);\
	};\
	inline bool cmd ## name::do_command(int playerid, std::string params)

bool OnPlayerCommandReceived(int playerid,std::string command, std::string params);
void OnPlayerCommandExecuted(int playerid, std::string, std::string params, bool success);

//note that the 'command' is always in lower-case because of the transformation done in the main processing step
bool OnUnknownCommand(int playerid, std::string command, std::string params);