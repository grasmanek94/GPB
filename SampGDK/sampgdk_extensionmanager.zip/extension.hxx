/*                   
		Copyright (c)  2013, Rafal "Gamer_Z" Grasman

		All rights reserved.

		Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

			-Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
			-Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
			-Neither the name of the organization nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

			Special Clause for SA-MP Servers:
			-The authors and or contributors must be credited in a visible and accessible area for the player, including but not limited to: about boxes, welcome messages on the server, commands displaying messages and/or message boxes

		THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
		AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
		IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
		ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
		LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR  CONSEQUENTIAL
		DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
		SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
		CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
		OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
		OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

		Extension manager for the whole gamemode, so you don't have to mix everything and can separate all stuff into classes :)
		C++ ! yay.
 */
#pragma once
#include <vector>
#include <utility>

/*
DEF file MUST contain:
EXPORTS
	Supports
	Load
	Unload
	ProcessTick
	OnGameModeInit
	OnGameModeExit
	OnPlayerConnect
	OnPlayerDisconnect
	OnPlayerCommandText
	OnPlayerEditObject
	OnPlayerSelectObject
	OnPlayerPickUpPickup
	OnPlayerEnterCheckpoint
	OnPlayerLeaveCheckpoint
	OnPlayerEnterRaceCheckpoint
	OnPlayerLeaveRaceCheckpoint
	OnPlayerSpawn
	OnPlayerDeath
	OnVehicleSpawn
	OnVehicleDeath
	OnPlayerRequestClass
	OnPlayerEnterVehicle
	OnPlayerExitVehicle
	OnPlayerStateChange
	OnRconCommand
	OnPlayerRequestSpawn
	OnVehicleMod
	OnEnterExitModShop
	OnVehiclePaintjob
	OnVehicleRespray
	OnVehicleDamageStatusUpdate
	OnUnoccupiedVehicleUpdate
	OnPlayerSelectedMenuRow
	OnPlayerExitedMenu
	OnPlayerInteriorChange
	OnPlayerKeyStateChange
	OnRconLoginAttempt
	OnDialogResponse
	OnPlayerTakeDamage
	OnPlayerGiveDamage
	OnPlayerClickMap
	OnPlayerClickTextDraw
	OnPlayerClickPlayerTextDraw
	OnPlayerClickPlayer
	OnPlayerEditAttachedObject
	OnPlayerStreamIn
	OnPlayerStreamOut
	OnVehicleStreamIn
	OnVehicleStreamOut
	OnPlayerUpdate
	OnPlayerText
*/

namespace Extension
{
	class Base;
	typedef std::pair<unsigned short,Base*> extension_filler;
	extern std::vector<extension_filler> * Extensions;

	bool Prioritizer (extension_filler &i,extension_filler &j);

	//returning false in any callback will stop the chain and the other callbacks of the same type will not be called in other extensions nor the main mode
	class Base
	{
		
	public:
		//max priority == 0xFFFF (most important), minimal == 0x0000 (least important)
		Base(unsigned short priority = 0x000) 
		{
			if(Extensions == NULL)
				Extensions = new std::vector<extension_filler>;
			Extensions->push_back(extension_filler(priority,this));
			std::sort(Extensions->begin(),Extensions->end(),Prioritizer);
		}
		virtual bool OnGameModeInit() { return true; }
		virtual bool OnGameModeExit() { return true; }
		virtual bool OnPlayerConnect(int playerid) { return true; }
		virtual bool OnPlayerDisconnect(int playerid, int reason) { return true; }
		virtual bool OnPlayerSpawn(int playerid) { return true; }
		virtual bool OnPlayerDeath(int playerid, int killerid, int reason) { return true; }
		virtual bool OnVehicleSpawn(int vehicleid) { return true; }
		virtual bool OnVehicleDeath(int vehicleid, int killerid) { return true; }
		virtual bool OnPlayerText(int playerid, std::string text) { return true; }
		virtual bool OnPlayerCommandText(int playerid, std::string cmdtext) { return true; }
		virtual bool OnPlayerRequestClass(int playerid, int classid) { return true; }
		virtual bool OnPlayerEnterVehicle(int playerid, int vehicleid, bool ispassenger) { return true; }
		virtual bool OnPlayerExitVehicle(int playerid, int vehicleid) { return true; }
		virtual bool OnPlayerStateChange(int playerid, int newstate, int oldstate) { return true; }
		virtual bool OnRconCommand(std::string command) { return true; }
		virtual bool OnPlayerRequestSpawn(int playerid) { return true; }
		virtual bool OnObjectMoved(int objectid) { return true; }
		virtual bool OnPlayerObjectMoved(int playerid, int objectid) { return true; }
		virtual bool OnPlayerPickUpPickup(int playerid, int pickupid) { return true; }
		virtual bool OnVehicleMod(int playerid, int vehicleid, int componentid) { return true; }
		virtual bool OnEnterExitModShop(int playerid, int enterexit, int interiorid) { return true; }
		virtual bool OnVehiclePaintjob(int playerid, int vehicleid, int paintjobid) { return true; }
		virtual bool OnVehicleRespray(int playerid, int vehicleid, int color1, int color2) { return true; }
		virtual bool OnVehicleDamageStatusUpdate(int vehicleid, int playerid) { return true; }
		virtual bool OnUnoccupiedVehicleUpdate(int vehicleid, int playerid, int passenger_seat) { return true; }
		virtual bool OnPlayerSelectedMenuRow(int playerid, int row) { return true; }
		virtual bool OnPlayerExitedMenu(int playerid) { return true; }
		virtual bool OnPlayerInteriorChange(int playerid, int newinteriorid, int oldinteriorid) { return true; }
		virtual bool OnPlayerKeyStateChange(int playerid, int newkeys, int oldkeys) { return true; }
		virtual bool OnRconLoginAttempt(const std::string ip, const std::string password, bool success) { return true; }
		virtual bool OnPlayerUpdate(int playerid) { return true; }
		virtual bool OnPlayerStreamIn(int playerid, int forplayerid) { return true; }
		virtual bool OnPlayerStreamOut(int playerid, int forplayerid) { return true; }
		virtual bool OnVehicleStreamIn(int vehicleid, int forplayerid) { return true; }
		virtual bool OnVehicleStreamOut(int vehicleid, int forplayerid) { return true; }
		virtual bool OnDialogResponse(int playerid, int dialogid, int response, int listitem, const std::string inputtext) { return true; }
		virtual bool OnPlayerTakeDamage(int playerid, int issuerid, float amount, int weaponid) { return true; }
		virtual bool OnPlayerGiveDamage(int playerid, int damagedid, float amount, int weaponid) { return true; }
		virtual bool OnPlayerClickMap(int playerid, float fX, float fY, float fZ) { return true; }
		virtual bool OnPlayerClickTextDraw(int playerid, int clickedid) { return true; }
		virtual bool OnPlayerClickPlayerTextDraw(int playerid, int playertextid) { return true; }
		virtual bool OnPlayerClickPlayer(int playerid, int clickedplayerid, int source) { return true; }
		virtual bool OnPlayerEditObject(int playerid, bool playerobject, int objectid, int response, float fX, float fY, float fZ, float fRotX, float fRotY, float fRotZ) { return true; }
		virtual bool OnPlayerEditAttachedObject(int playerid, int response, int index, int modelid, int boneid, float fOffsetX, float fOffsetY, float fOffsetZ, float fRotX, float fRotY, float fRotZ, float fScaleX, float fScaleY, float fScaleZ) { return true; }
		virtual bool OnPlayerSelectObject(int playerid, int type, int objectid, int modelid, float fX, float fY, float fZ) { return true; }
#ifdef STREAMER_TYPE_OBJECT
		virtual bool OnPlayerEnterArea(int playerid, int areaid) { return true; }
		virtual bool OnPlayerLeaveArea(int playerid, int areaid) { return true; }
		virtual bool OnPlayerEnterCheckpoint(int playerid, int checkpointid) { return true; }
		virtual bool OnPlayerLeaveCheckpoint(int playerid, int checkpointid) { return true; }
		virtual bool OnPlayerEnterRaceCheckpoint(int playerid, int checkpointid) { return true; }
		virtual bool OnPlayerLeaveRaceCheckpoint(int playerid, int checkpointid) { return true; }
#endif
		virtual bool OnPlayerEnterCheckpoint(int playerid) { return true; }
		virtual bool OnPlayerLeaveCheckpoint(int playerid) { return true; }
		virtual bool OnPlayerEnterRaceCheckpoint(int playerid) { return true; }
		virtual bool OnPlayerLeaveRaceCheckpoint(int playerid) { return true; }
		//sampgdk not initialized yet when load is being called
		virtual void Load() { return; }
		virtual void Unload() { return; }
		virtual ~Base() 
		{
			for(unsigned int i = 0, j = Extensions->size(); i < j; ++i)
			{
				if(Extensions->at(i).second == this)
				{
					Extensions->erase(Extensions->begin() + i);
					break;
				}
			}
		}
	};
};