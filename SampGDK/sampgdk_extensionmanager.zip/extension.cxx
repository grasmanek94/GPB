/*
		Copyright (c)  2013, Rafal "Gamer_Z" Grasman

		All rights reserved.

		Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

			-Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
			-Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
			-Neither the name of the organization nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

			Special Clause for SA-MP Servers:
			-The authors and or contributors must be credited in a visible and accessible area for the player, including but not limited to: about boxes, welcome messages on the server, commands displaying messages and/or message boxes

		THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
		AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
		IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
		ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
		LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR  CONSEQUENTIAL
		DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
		SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
		CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
		OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
		OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

		Extension source file
 */
#include "extension.hxx"

namespace Extension
{
	std::vector<extension_filler> * Extensions;
	bool Prioritizer (extension_filler &i,extension_filler &j)
	{ 
		return (i.first>j.first); 
	}
};

static ThisPlugin thisplugin;

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_PROCESS_TICK;
}

PLUGIN_EXPORT bool PLUGIN_CALL Load(void **ppData) 
{
	for(auto &i: *Extension::Extensions)
		i.second->Load();
	#ifdef STREAMER_TYPE_OBJECT
	StreamerCall::Load();
	#endif
	return thisplugin.Load(ppData) >= 0;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload() 
{
	for(auto &i: *Extension::Extensions)
		i.second->Unload();
#ifdef STREAMER_TYPE_OBJECT
	StreamerCall::Unload();
#endif
	thisplugin.Unload();
}

PLUGIN_EXPORT bool PLUGIN_CALL OnDialogResponse(int playerid, int dialogid, int response, int listitem, const char * inputtext)
{
	std::string input(inputtext);
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnDialogResponse(playerid,dialogid,response,listitem,input))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerEditObject(int playerid, bool playerobject, int objectid, int response, float fX, float fY, float fZ, float fRotX, float fRotY, float fRotZ)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerEditObject(playerid, playerobject, objectid, response, fX, fY, fZ, fRotX, fRotY, fRotZ);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerEditObject(playerid,playerobject,objectid,response,x,y,z,rx,ry,rz))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerSelectObject(int playerid, int type, int objectid, int modelid, float x, float y, float z)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerSelectObject(playerid, type, objectid, modelid, x, y, z);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerSelectObject(playerid,type,objectid,modelid,x,y,z))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerPickUpPickup(int playerid, int pickupid)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerPickUpPickup(playerid, pickupid);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerPickUpPickup(playerid,pickupid))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerEnterCheckpoint(int playerid)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerEnterCheckpoint(playerid);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerEnterCheckpoint(playerid))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerLeaveCheckpoint(int playerid)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerLeaveCheckpoint(playerid);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerLeaveCheckpoint(playerid))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerEnterRaceCheckpoint(int playerid)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerEnterRaceCheckpoint(playerid);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerEnterRaceCheckpoint(playerid))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerLeaveRaceCheckpoint(int playerid)
{
#ifdef STREAMER_TYPE_OBJECT
	return StreamerCall::Events::OnPlayerLeaveRaceCheckpoint(playerid);
#else
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerLeaveRaceCheckpoint(playerid))
			return false;
	return true;
#endif
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerSpawn(int playerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerSpawn(playerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerDeath(int playerid, int killerid, int reason)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerDeath(playerid,killerid,reason))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleSpawn(int vehicleid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleSpawn(vehicleid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleDeath(int vehicleid, int killerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleDeath(vehicleid,killerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerRequestClass(int playerid, int classid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerRequestClass(playerid,classid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerEnterVehicle(int playerid, int vehicleid, bool ispassenger)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerEnterVehicle(playerid,vehicleid,ispassenger))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerExitVehicle(int playerid, int vehicleid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerExitVehicle(playerid,vehicleid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerStateChange(int playerid, int newstate, int oldstate)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerStateChange(playerid,newstate,oldstate))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnRconCommand(const char * cmd)
{
	std::string command(cmd);
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnRconCommand(command))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerRequestSpawn(int playerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerRequestSpawn(playerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleMod(int playerid, int vehicleid, int componentid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleMod(playerid,vehicleid,componentid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnEnterExitModShop(int playerid, int enterexit, int interiorid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnEnterExitModShop(playerid,enterexit,interiorid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehiclePaintjob(int playerid, int vehicleid, int paintjobid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehiclePaintjob(playerid,vehicleid,paintjobid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleRespray(int playerid, int vehicleid, int color1, int color2)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleRespray(playerid,vehicleid,color1,color2))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleDamageStatusUpdate(int vehicleid, int playerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleDamageStatusUpdate(vehicleid,playerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnUnoccupiedVehicleUpdate(int vehicleid, int playerid, int passenger_seat)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnUnoccupiedVehicleUpdate(vehicleid,playerid,passenger_seat))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerSelectedMenuRow(int playerid, int row)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerSelectedMenuRow(playerid,row))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerExitedMenu(int playerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerExitedMenu(playerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerInteriorChange(int playerid, int newinteriorid, int oldinteriorid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerInteriorChange(playerid,newinteriorid,oldinteriorid))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerKeyStateChange(int playerid, int newkeys, int oldkeys)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerKeyStateChange(playerid,newkeys,oldkeys))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnRconLoginAttempt(const char * ip, const char * password, bool success)
{
	std::string ip_(ip), password_(password);
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnRconLoginAttempt(ip_,password_,success))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerStreamIn(int playerid, int forplayerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerStreamIn(playerid,forplayerid))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerStreamOut(int playerid, int forplayerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerStreamOut(playerid,forplayerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleStreamIn(int vehicleid, int forplayerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleStreamIn(vehicleid,forplayerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnVehicleStreamOut(int vehicleid, int forplayerid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnVehicleStreamOut(vehicleid,forplayerid))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerUpdate(int playerid)
{
	//if you really really need OnPlayerUpdate Support just implement it like above, how hard can it be to copy & paste?
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerTakeDamage(int playerid, int issuerid, float amount, int weaponid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerTakeDamage(playerid,issuerid,amount,weaponid))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerGiveDamage(int playerid, int damagedid, float amount, int weaponid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerGiveDamage(playerid,damagedid,amount,weaponid))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerClickMap(int playerid, float fX, float fY, float fZ)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerClickMap(playerid,fX,fY,fZ))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerClickTextDraw(int playerid, int clickedid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerClickTextDraw(playerid,clickedid))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerClickPlayerTextDraw(int playerid, int playertextid)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerClickTextDraw(playerid,playertextid))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerClickPlayer(int playerid, int clickedplayerid, int source)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerClickPlayer(playerid,clickedplayerid,source))
			return false;
	return true;
}
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerEditAttachedObject(int playerid, int response, int index, int modelid, int boneid, float fOffsetX, float fOffsetY, float fOffsetZ, float fRotX, float fRotY, float fRotZ, float fScaleX, float fScaleY, float fScaleZ)
{
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerEditAttachedObject(playerid,response,index,modelid,boneid,fOffsetX,fOffsetY,fOffsetZ,fRotX,fRotY,fRotZ,fScaleX,fScaleY,fScaleZ))
			return false;
	return true;
}

//
#ifdef STREAMER_TYPE_OBJECT
namespace StreamerCall
{
	bool OnPlayerEditDynamicObject(int playerid, int objectid, int response, float x, float y, float z, float rx, float ry, float rz)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerEditObject(playerid,false,objectid,response,x,y,z,rx,ry,rz))
				return false;
		return true;
	}
	bool OnPlayerSelectDynamicObject(int playerid,int objectid,int modelid, float x, float y, float z)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerSelectObject(playerid,0,objectid,modelid,x,y,z))
				return false;
		return true;
	}
	bool OnPlayerPickUpDynamicPickup(int playerid,int pickupid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerPickUpPickup(playerid,pickupid))
				return false;
		return true;
	}
	bool OnPlayerEnterDynamicCP(int playerid,int checkpointid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerEnterCheckpoint(playerid,checkpointid))
				return false;
		return true;
	}
	bool OnPlayerLeaveDynamicCP(int playerid,int checkpointid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerLeaveCheckpoint(playerid,checkpointid))
				return false;
		return true;
	}
	bool OnPlayerEnterDynamicRaceCP(int playerid,int checkpointid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerEnterRaceCheckpoint(playerid,checkpointid))
				return false;
		return true;
	}
	bool OnPlayerLeaveDynamicRaceCP(int playerid,int checkpointid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerLeaveRaceCheckpoint(playerid,checkpointid))
				return false;
		return true;
	}
	bool OnPlayerEnterDynamicArea(int playerid, int areaid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerEnterArea(playerid,areaid))
				return false;
		return true;
	}
	bool OnPlayerLeaveDynamicArea(int playerid, int areaid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnPlayerLeaveArea(playerid,areaid))
				return false;
		return true;
	}
	bool OnDynamicObjectMoved(int objectid)
	{
		for(auto &i: *Extension::Extensions)
			if(!i.second->OnObjectMoved(objectid))
				return false;
		return true;
	}
};
#endif
//return rules don't apply here (except in OnPlayerText)
PLUGIN_EXPORT bool PLUGIN_CALL OnGameModeExit()
{
	for(auto &i: *Extension::Extensions)
		i.second->OnGameModeExit();
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnGameModeInit()
{
	for(auto &i: *Extension::Extensions)
		i.second->OnGameModeInit();
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerText(int playerid, const char * text)
{
	std::string input(text);
	for(auto &i: *Extension::Extensions)
		if(!i.second->OnPlayerText(playerid,input))
			return false;
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerConnect(int playerid)
{
	StreamerCall::Events::OnPlayerConnect(playerid);
	for(auto &i: *Extension::Extensions)
		i.second->OnPlayerConnect(playerid);
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerDisconnect(int playerid, int reason)
{
	for(auto &i: *Extension::Extensions)
		i.second->OnPlayerDisconnect(playerid,reason);
	StreamerCall::Events::OnPlayerDisconnect(playerid,reason);
	return true;
}

PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerCommandText(int playerid, const char *cmdtext)
{
	std::string input(cmdtext);
	bool nounknowncommand = false;
	for(auto &i: *Extension::Extensions)
		//assumes commands don't return false (which may be safely assumes because commands returning zero or false will ignite the unknown command message anyway)
		nounknowncommand = (i.second->OnPlayerCommandText(playerid,input)) ? true : nounknowncommand;
	return nounknowncommand;
}