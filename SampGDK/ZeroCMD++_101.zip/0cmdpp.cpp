#include <sampgdk/plugin.h>

#include "0cmdpp.hpp"

#if defined USE_EXTENSIONMANAGER
class ZeroCommandRequester: public Extension::Base
{
public:
	bool OnPlayerCommandText(int playerid, std::string cmdtext);
};
ZeroCommandRequester _ZeroCommandRequester;
#endif

namespace SAMPGDK
{
	namespace ZeroCMD
	{
		namespace Internal
		{
			std::map<std::string, Command*> * command_map;
			void register_command(Command* cmd, std::string name)
			{ 
				if(command_map == NULL)
					command_map = new std::map<std::string, Command*>;
				std::string data(name);
				//transform command to lower case so even command names are case insensetive
				std::transform(data.begin(), data.end(), data.begin(), ::tolower);

				command_map->insert(std::pair<std::string, Command*>(data, cmd));
			}
		};
	};
};

#if defined USE_EXTENSIONMANAGER
bool ZeroCommandRequester::OnPlayerCommandText(int playerid, std::string cmdtext)
#else
PLUGIN_EXPORT bool PLUGIN_CALL OnPlayerCommandText(int playerid, const char *cmdtext)
#endif
{
	//declare strings we need
	std::string main(cmdtext);
	std::string command;
	std::string parameters;

	//find the space in the command
	size_t space = main.find(' ');

	if(space == std::string::npos)
	{
		//if there is no space treat the whole string as the command
		command.assign(main);
	}
	else
	{
		//else split the input into a command and parameters, with the first space being the place to split, don't include first space into the parameters string
		command.assign(main.begin(),main.begin()+space);
		parameters.assign(main.begin()+(space+1),main.end());
	}

	//make command call lowercase characters so the command call is case-insensetive
	std::transform(command.begin(), command.end(), command.begin(), ::tolower);

	//check if the user wants the issued command to proceed for the player with the parameters
	if(OnPlayerCommandReceived(playerid,command,parameters))
	{
		//try to find the command / check if the command exists
		auto cmd = SAMPGDK::ZeroCMD::Internal::command_map->find(command);
		if(cmd != SAMPGDK::ZeroCMD::Internal::command_map->end())
		{
			//execute the command and check if it succeeded or not by return value
			bool success = cmd->second->do_command(playerid,parameters);
			//notify callback
			OnPlayerCommandExecuted(playerid, command, parameters, success);
			//return to this callback
			return success;
		}
	}
	else
	{
		//end user doesn't want command to proceed
		return true;
	}
	//unknown command
	return OnUnknownCommand(playerid,command,parameters);
}