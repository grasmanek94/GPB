//-------------------------------------------//
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <queue>
#include <cstring>
#include <limits>
#include <fstream>
#include <stack>
#include <set>
#include <string>
#include <stdarg.h>
//-------------------------------------------//
#include "./amx/samp.h"
#include "./amx/vehicles.h"
#include "./amx/players.h" 
#include "./amx/wrapper.h" 
#include "./amx/eventhandler.h"
//-------------------------------------------//
#include "metakit/mk4.h"
//-------------------------------------------//
#include "cppINC/defines.h"
#include "main.h"
#include "cppINC/functions.cpp"
#include "cppINC/natives.cpp"
#include "cppINC/pluginexport.cpp"
//-------------------------------------------//

PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	Wrapper::GetInstance().Initialize(ppData);
	cout << "    Plugin 2011 by Gamer_Z loaded";
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL
	ProcessTick()
{

}

