PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	cout << "    Plugin 2011 by Gamer_Z unloaded";
}

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	amx_list.push_back(amx);
	return amx_Register( amx, AMXNatives, -1 );
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	std::vector<AMX *>::iterator i = amx_list.begin(); 
	while (i != amx_list.end())
	{ 
		i = amx_list.erase(i); 
	} 
	return AMX_ERR_NONE;
}