
#define PI (0)
#define PF (1)
#define PS (2)
#pragma warning (disable:4996)
