void InitializeDB(char * filename)
{
	database = c4_Storage(filename, true);
}

void AddProperty(int type, char name[64])
{
	dbprops.push_back(DB_Props(type,name));
}

void SaveDB()
{
	database.Commit();
}

c4_Row private_EmptyRow;
int AddEmptyEntry()
{
	return data_view.Add(private_EmptyRow);
}

void SetIntOnIndex(int index,char * item,int value)
{
	c4_IntProp Item(item);
	Item(data_view[index]) = value;
}

void SetFloatOnIndex(int index,char * item,float value)
{
	c4_FloatProp Item(item);
	Item(data_view[index]) = value;
}

void SetStringOnIndex(int index,char * item,char * value)
{
	c4_StringProp Item(item);
	Item(data_view[index]) = value;
}

int GetIntOnIndex(int index,char * item)
{
	c4_IntProp Item(item);
	return Item(data_view[index]);
}

float GetFloatOnIndex(int index,char * item)
{
	c4_FloatProp Item(item);
	return (float)Item(data_view[index]);
}

const char * GetStrOnIndex(int index,char * item)
{
	c4_StringProp Item(item);
	return Item(data_view[index]);
}

void BuildProperties()
{
	if(dbprops.size() > 0)
	{
		char builder[512];

		sprintf_s(builder,"data_view[");

		if(dbprops.at(0).type == 0)
		{
			sprintf_s(builder,"%s%s:I",builder,dbprops.at(0).name);
		}
		else
		if(dbprops.at(0).type == 1)
		{
			sprintf_s(builder,"%s%s:F",builder,dbprops.at(0).name);
		}
		else
		if(dbprops.at(0).type == 2)
		{
			sprintf_s(builder,"%s%s:S",builder,dbprops.at(0).name);
		}
		for(unsigned int i = 1; i < dbprops.size(); ++i)
		{
			if(dbprops.at(i).type == 0)
			{
				sprintf_s(builder,"%s,%s:I",builder,dbprops.at(i).name);
			}
			else
			if(dbprops.at(i).type == 1)
			{
				sprintf_s(builder,"%s,%s:F",builder,dbprops.at(i).name);
			}
			else
			if(dbprops.at(i).type == 2)
			{
				sprintf_s(builder,"%s,%s:S",builder,dbprops.at(i).name);
			}
		}
		sprintf_s(builder,"%s]",builder);
		data_view = database.GetAs(builder);
	}
}

c4_Row findrow;
int idxsearch=-1;
int ReturnUserIndex(char * user, char * field)
{
	c4_StringProp Property(field);
	Property(findrow) = user;
	idxsearch=data_view.Find(findrow,idxsearch+1);
	return idxsearch;
}

void MultiSet(int index, const char * format, ...)
{
    va_list ap;

    int j;
	int t = strlen(format);

    char * field = new char[128];

	int ivalue = 0;
	float fvalue = 0.0f;
	char * svalue = new char[8196];

    va_start(ap, format);

    for(j = 0; j < t; j++)
	{
		switch(format[j])
		{
			case 'i':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				ivalue = va_arg(ap, int);
				c4_IntProp Item(field);
				Item(data_view[index]) = ivalue;
				break;
			}
			case 'd':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				ivalue = va_arg(ap, int);
				c4_IntProp Item(field);
				Item(data_view[index]) = ivalue;
				break;
			}
			case 'f':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				fvalue = (float)va_arg(ap, double);
				c4_FloatProp Item(field);
				Item(data_view[index]) = fvalue;
				break;
			}
			case 's':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				svalue = va_arg(ap, char *);
				c4_StringProp Item(field);
				Item(data_view[index]) = svalue;
				break;
			}
		}
	}
    va_end(ap);
}

void MultiAddProperty(const char * format, ...)
{
    va_list ap;

    int j;
	int t = strlen(format);

    char * field = new char[128];

    va_start(ap, format);

    for(j = 0; j < t; j++)
	{
		switch(format[j])
		{
			case 'i':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				dbprops.push_back(DB_Props(PI,field));
				cout << (char)format[j] << " " << field << " " << PI << "\r\nMatches?: " << dbprops.back().name << " " << dbprops.back().type << "\r\n";
				break;
			}
			case 'd':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				dbprops.push_back(DB_Props(PI,field));
				cout << (char)format[j] << " " << field << " " << PI << "\r\nMatches?: " << dbprops.back().name << " " << dbprops.back().type << "\r\n";
				break;
			}
			case 'f':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				dbprops.push_back(DB_Props(PF,field));
				cout << (char)format[j] << " " << field << " " << PF << "\r\nMatches?: " << dbprops.back().name << " " << dbprops.back().type << "\r\n";
				break;
			}
			case 's':
			{
				sprintf(field,"%s",va_arg(ap, char *));
				dbprops.push_back(DB_Props(PS,field));
				cout << (char)format[j] << " " << field << " " << PS << "\r\nMatches?: " << dbprops.back().name << " " << dbprops.back().type << "\r\n";
				break;
			}
		}
	}
    va_end(ap);
}
