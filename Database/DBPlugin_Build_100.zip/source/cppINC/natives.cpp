
AMX_NATIVE_INFO AMXNatives[ ] =
{
	{"GDB_SetFloatData",n_SetFloatData},
	{"GDB_SetIntData",n_SetIntData},
	{"GDB_SetStrData",n_SetStrData},
	{"GDB_GetFloatData",n_GetFloatData},
	{"GDB_GetIntData",n_GetIntData},
	{"GDB_GetStrData",n_GetStrData},
	{"GDB_AddEmptyEntry",n_AddEmptyEntry},
	{"GDB_GetIDByName",n_GetIDByName},
	{"GDB_SaveDB",n_SaveDB},
	//{"GDB_MultiSet",n_MultiSet},
	{"GDB_InitializeDB",n_InitializeDB},
	{"GDB_AddProperty",n_AddProperty},
	{"GDB_PushProperties",n_PushProperties},
	{0,                0}
};

static cell AMX_NATIVE_CALL n_SetFloatData( AMX* amx, cell* params )
{
	char * itemname;
	amx_StrParam(amx,params[2],itemname);
	if(params[1] < 0 || params[1] >= data_view.GetSize())return 0;
	SetFloatOnIndex(params[1],itemname,amx_ctof(params[3]));
	return 1;
}

static cell AMX_NATIVE_CALL n_SetIntData( AMX* amx, cell* params )
{
	char * itemname;
	amx_StrParam(amx,params[2],itemname);
	if(params[1] < 0 || params[1] >= data_view.GetSize())return 0;
	SetIntOnIndex(params[1],itemname,params[3]);
	return 1;
}

static cell AMX_NATIVE_CALL n_SetStrData( AMX* amx, cell* params )
{
	char * itemname;
	char * data;
	amx_StrParam(amx,params[2],itemname);
	amx_StrParam(amx,params[3],data);
	if(params[1] < 0 || params[1] >= data_view.GetSize())return 0;
	SetStringOnIndex(params[1],itemname,data);
	return 1;
}

static cell AMX_NATIVE_CALL n_GetFloatData( AMX* amx, cell* params )
{
	char * itemname;
	amx_StrParam(amx,params[2],itemname);
	float C = 0.0f;
	if(params[1] < 0 || params[1] >= data_view.GetSize())return amx_ftoc(C);
	C = GetFloatOnIndex(params[1],itemname);
	return amx_ftoc(C);
}

static cell AMX_NATIVE_CALL n_GetIntData( AMX* amx, cell* params )
{
	char * itemname;
	amx_StrParam(amx,params[2],itemname);
	if(params[1] < 0 || params[1] >= data_view.GetSize())return 0;
	return GetIntOnIndex(params[1],itemname);
}

static cell AMX_NATIVE_CALL n_GetStrData( AMX* amx, cell* params )
{
	char * itemname;
	amx_StrParam(amx,params[2],itemname);
	if(params[1] < 0 || params[1] >= data_view.GetSize())return 0;
	char * ret = new char[8196];
	sprintf(ret,"%s",GetStrOnIndex(params[1],itemname));
	cell *dest = NULL;
    amx_GetAddr(amx,params[3],&dest);
    amx_SetString(dest,ret,0,0,params[4]);
	return 1;
}

static cell AMX_NATIVE_CALL n_AddEmptyEntry( AMX* amx, cell* params )
{
	return AddEmptyEntry();
}

static cell AMX_NATIVE_CALL n_GetIDByName( AMX* amx, cell* params )
{
	char * itemname;
	char * data;
	amx_StrParam(amx,params[1],data);
	amx_StrParam(amx,params[2],itemname);
	return ReturnUserIndex(data, itemname);
}

static cell AMX_NATIVE_CALL n_SaveDB( AMX* amx, cell* params )
{
	SaveDB();
	return 1;
}
/*
static cell AMX_NATIVE_CALL n_MultiSet( AMX* amx, cell* params )
{
	if(params[1] < 0 || params[1] >= data_view.GetSize())return 0;
	int index = params[1];
	char * data;
	amx_StrParam(amx,params[2],data);
	int len = strlen(data);
	if((params[0]/4) != ((len*2)+2))
	{
		std::cout << "n_MultiSet: wrong parameters\r\n";
		return 0;
	}

	char * field = new char[128];
	char * datax;

	for(int i = 0; i < len; ++i)
	{
		switch(data[i])
		{
			case 'i':
			{
				amx_StrParam(amx,params[(3+(i*2))],field);
				SetIntOnIndex(index,field,params[(4+(i*2))]);
				break;
			}
			case 'd':
			{
				amx_StrParam(amx,params[(3+(i*2))],field);
				SetIntOnIndex(index,field,params[(4+(i*2))]);
				break;
			}
			case 'f':
			{
				amx_StrParam(amx,params[(3+(i*2))],field);
				char * xx;
				amx_StrParam(amx,params[(4+(i*2))],xx);
				cout << amx_ctof(params[(4+(i*2))]) << " " << xx << "\r\n";
				SetFloatOnIndex(index,field,amx_ctof(params[(4+(i*2))]));
				break;
			}
			case 's':
			{	
				amx_StrParam(amx,params[(3+(i*2))],field);
				amx_StrParam(amx,params[(4+(i*2))],datax);
				SetStringOnIndex(index,field,datax);
				break;
			}
		}
	}
	return 1;
}
*/

bool initialised = false;
static cell AMX_NATIVE_CALL n_InitializeDB( AMX* amx, cell* params )
{
	if(initialised == true)return 0;
	initialised = true;
	char * filename;
	amx_StrParam(amx,params[1],filename);
	InitializeDB(filename);
	START_THREAD( Thread::BackgroundDataSaver, 0);
	return 1;
}

bool pushed = false;

static cell AMX_NATIVE_CALL n_AddProperty( AMX* amx, cell* params )
{
	if(pushed == true)return 0;
	char * name = new char[64];
	amx_StrParam(amx,params[2],name);
	AddProperty(params[1], name);
	return 1;
}

static cell AMX_NATIVE_CALL n_PushProperties( AMX* amx, cell* params )
{
	if(pushed == true)return 0;
	pushed = true;
	BuildProperties();
	return 1;
}