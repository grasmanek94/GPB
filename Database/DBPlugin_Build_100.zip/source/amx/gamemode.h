#ifndef SAMPGDK_GAMEMODE_H
#define SAMPGDK_GAMEMODE_H

#include "amxplugin.h"

AMX *GetGameMode();
void SetGameMode(AMX *amx);

#endif
