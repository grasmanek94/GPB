using namespace std;
using namespace sampgdk;

class GDB : public sampgdk::EventHandler 
{
public:
    GDB();
    virtual ~GDB();
};

static GDB theGameMode;

GDB::GDB()
{
    this->Register();
}

GDB::~GDB()
{

}

vector<AMX *>	amx_list;

extern void *	pAMXFunctions;

struct DB_Props
{
	int type;
	char name[64];
	DB_Props(int a, char *b)
	{
		type = a;
		for(int i = 0; i < 64; ++i)
			name[i] = 0;
		for(int i = 0, j = strlen(b); i < j; ++i)
		{
			name[i] = b[i];
		}
	}
};

c4_Storage		database;
c4_View			data_view;
vector			<DB_Props> dbprops;
//

void			InitializeDB(char * filename);
void			SaveDB();

void			AddProperty(int type, char * name);
void			BuildProperties();

int				AddEmptyEntry();
int				ReturnUserIndex(char * user, char * field);

void			SetIntOnIndex(int index,char * item,int value);
void			SetFloatOnIndex(int index,char * item,float value);
void			SetStringOnIndex(int index,char * item,char * value);

int				GetIntOnIndex(int index,char * item);
float			GetFloatOnIndex(int index,char * item);
const char *	GetStrOnIndex(int index,char * item);

void			MultiSet(int index, const char * format, ...);
void			MultiAddProperty(const char * format, ...);

//
static cell AMX_NATIVE_CALL n_SetFloatData( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_SetIntData( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_SetStrData( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetFloatData( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetIntData( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetStrData( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_AddEmptyEntry( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_GetIDByName( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_SaveDB( AMX* amx, cell* params );
//static cell AMX_NATIVE_CALL n_MultiSet( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_InitializeDB( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_AddProperty( AMX* amx, cell* params );
static cell AMX_NATIVE_CALL n_PushProperties( AMX* amx, cell* params );


//////////////////////////////////////////////////////////////////////
#ifndef __THREAD_H
#define __THREAD_H

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__)
#	include <process.h>
#	define OS_WINDOWS
#else
#	include <pthread.h>
#	define sscanf_s sscanf
#	define sprintf_s sprintf
#endif

class Thread
{
	public:
									Thread						( void );
								   ~Thread						( void );
#ifdef OS_WINDOWS
	static void						BackgroundDataSaver		( void *unused );
#else
	static void	*					BackgroundDataSaver		( void *unused );
#endif

};

#endif

Thread::Thread( void )
{
}

Thread::~Thread( void )
{
}

#ifdef OS_WINDOWS
#	define EXIT_THREAD() { _endthread(); }
#	define START_THREAD(a, b) { _beginthread( a, 0, (void *)( b ) ); }
#else
#	define EXIT_THREAD() { pthread_exit( NULL ); }
#	define START_THREAD(a, b) {	pthread_t thread;\
								pthread_create( &thread, NULL, a, (void *)( b ) ); }
#endif

#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
#include<windows.h>

#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#ifdef OS_WINDOWS
	void Thread::BackgroundDataSaver( void *unused )
#else
	void *Thread::BackgroundDataSaver( void *unused )
#endif
{
	while( true )
    {
		SLEEP(1000*90);
		SaveDB();
		//cout << "Database saved...\r\n";
    }

	EXIT_THREAD();//should be never reached..
}
//////////////////////////////////////////////////////////////////////
