/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the fixes 1.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2010
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *
 *  SA:MP team - plugin framework.
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 */

#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include <queue>
#include <deque>
#include <map>
#include <functional>

#include <iostream>
#include <fstream>
#include <stdarg.h>
#include <time.h>

#include "fixes.h"

#include "SDK/amx/amx.h"
#include "SDK/plugincommon.h"

#ifdef LINUX
	#include <sys/mman.h>
	#include <time.h>
	#include <alloca.h>
	#include <stdlib.h>
	#include <unistd.h>
	
	long long unsigned int
		MicrosecondTime()
	{
		struct timespec
			ts;
		clock_gettime(CLOCK_MONOTONIC, &ts);
		//return ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
		return ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
	}
#else
	#define VC_EXTRALEAN
	#define WIN32_LEAN_AND_MEAN
	
	#include <windows.h>

#endif

logprintf_t
	logprintf;

AMX_NATIVE
	pPrint,
	pPrintF;

extern void *
	pAMXFunctions;

int
	gAMXPtr[17];

AMX *
	gAMXFiles[17];

char
	gLogTimeFormat[32] = "[%H:%M:%S]",
	gLogprintfAssembly[5];

bool
	bDoLog,
	bInPrint;

void
	AssemblySwap(char * addr, char * dat, int len)
{
	char
		swp;
	while (len--)
	{
		swp = addr[len];
		addr[len] = dat[len];
		dat[len] = swp;
	}
}

void
	AssemblyRedirect(void * from, void * to, char * ret)
{
	#ifdef LINUX
		size_t
			iPageSize = getpagesize(),
			iAddr = ((reinterpret_cast <uint32_t>(from) / iPageSize) * iPageSize),
			iCount = (5 / iPageSize) * iPageSize + iPageSize * 2;
		mprotect(reinterpret_cast <void*>(iAddr), iCount, PROT_READ | PROT_WRITE | PROT_EXEC);
		//mprotect(from, 5, PROT_READ | PROT_WRITE | PROT_EXEC);
	#else
		DWORD
			old;
		VirtualProtect(from, 5, PAGE_EXECUTE_READWRITE, &old);
	#endif
	*((unsigned char *)ret) = 0xE9;
	*((char **)(ret + 1)) = (char *)((char *)to - (char *)from) - 5;
	//std::cout << "fixes.plugin: load: " << (sizeof (char *)) << *((int *)(ret + 1)) << std::endl;
	AssemblySwap((char *)from, ret, 5);
}

#include <sstream>
//__declspec(naked)
//__cdecl
int
	FIXES_logprintf(char * str, ...)
{
	va_list ap;
	char
		dst[1024];
	va_start(ap, str);
	vsnprintf(dst, 1024, str, ap);
	va_end(ap);
	printf("%s\n", dst);
	if (bDoLog)
	{
		// Re-enable logging.
		std::ofstream
			f("server_log.txt", std::fstream::app | std::fstream::out);
		if (f.is_open())
		{
			char
				ft[32];
			time_t
				t;
			time(&t);
			strftime(ft, sizeof (ft), gLogTimeFormat, localtime(&t));
			f << ft << ' ' << dst << std::endl;
			f.close();
		}
	}
	// So we can use "printf" without getting stuck in endless loops.
	if (!bInPrint)
	{
		std::string msg(str);
		if(msg.find("Packet was modified, sent by id: ") != std::string::npos)
		{
			std::stringstream stream;
			char found[4]= {str[33],str[34],str[35],0};
			stream << found;
			int playerid;
			if (!(stream >>playerid)){
				//could not convert
			}
			else
			{
				for (int i = 0; i != 17; ++i)
				{
					if (gAMXPtr[i] != -1)
					{
						cell
							ret = NULL,
							addr = NULL;
						amx_Push(gAMXFiles[i], static_cast<cell>(playerid));
						amx_Exec(gAMXFiles[i], &ret, gAMXPtr[i]);
						amx_Release(gAMXFiles[i], addr);
						if (ret == 1)
						{
							return 1;
						}
					}
				}
			}
		}
	}
	return 1;
}

// Intercept "print" and "printf" to just log them (relatively) normally.
static cell AMX_NATIVE_CALL
	n_print(AMX * amx, cell * params)
{
	bInPrint = true;
	cell
		ret = pPrint(amx, params);
	bInPrint = false;
	return ret;
}

static cell AMX_NATIVE_CALL
	n_printf(AMX * amx, cell * params)
{
	bInPrint = true;
	cell
		ret = pPrintF(amx, params);
	bInPrint = false;
	return ret;
}

// Load an entry from server.cfg.
int
	CFGLoad(char const * const name, char * const dest, size_t dlen)
{
	std::ifstream
		f("server.cfg");
	int
		ret = 1,
		len = strlen(name);
	if (f.is_open())
	{
		char
			line[256];
		f.clear();
		while (!f.eof())
		{
			f.getline(line, 256);
			if (f.fail())
			{
				goto CFGLoad_close;
			}
			// Does the line START with this text?  Anything other than the
			// first character fails.
			if (!strncmp(line, name, len) && line[len] <= ' ')
			{
				while (line[++len] <= ' ')
				{
					if (line[len] == '\0') goto CFGLoad_close;
				}
				// Skipped leading spaces, save the value.
				if (dest) strncpy(dest, line + len, dlen);
				ret = atoi(line + len);
				goto CFGLoad_close;
			}
		}
CFGLoad_close:
		// Yes, I used a label!  I needed to escape from a double loop.
		f.close();
	}
	return ret;
}

PLUGIN_EXPORT unsigned int PLUGIN_CALL
	Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES;
}

//----------------------------------------------------------
// The Load() function gets passed on exported functions from
// the SA-MP Server, like the AMX Functions and logprintf().
// Should return true if loading the plugin has succeeded.

PLUGIN_EXPORT bool PLUGIN_CALL
	Load(void ** ppData)
{
	setlocale(LC_CTYPE, "");
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	logprintf = (logprintf_t)ppData[PLUGIN_DATA_LOGPRINTF];
	for (int i = 0; i != 17; ++i)
	{
		gAMXFiles[i] = 0;
		gAMXPtr[i] = -1;
	}
	logprintf("\n");
	logprintf(" ===============================\n");
	logprintf("       fixes plugin loaded.     \n");
	logprintf("   (c) 2012 Alex \"Y_Less\" Cole\n");
	logprintf(" ===============================\n");
	
	AssemblyRedirect((void *)logprintf, (void *)FIXES_logprintf, gLogprintfAssembly);
	bInPrint = false;
	CFGLoad("logtimeformat", gLogTimeFormat, sizeof (gLogTimeFormat));
	bDoLog = !!CFGLoad("enablelog", 0, 0);

	return true;
}

//----------------------------------------------------------
// The Unload() function is called when the server shuts down,
// meaning this plugin gets shut down with it.

PLUGIN_EXPORT void PLUGIN_CALL
	Unload()
{

}

// From "amx.c", part of the PAWN language runtime:
// http://code.google.com/p/pawnscript/source/browse/trunk/amx/amx.c

#define USENAMETABLE(hdr) \
	((hdr)->defsize==sizeof(AMX_FUNCSTUBNT))

#define NUMENTRIES(hdr,field,nextfield) \
	(unsigned)(((hdr)->nextfield - (hdr)->field) / (hdr)->defsize)

#define GETENTRY(hdr,table,index) \
	(AMX_FUNCSTUB *)((unsigned char*)(hdr) + (unsigned)(hdr)->table + (unsigned)index*(hdr)->defsize)

#define GETENTRYNAME(hdr,entry) \
	(USENAMETABLE(hdr) ? \
		(char *)((unsigned char*)(hdr) + (unsigned)((AMX_FUNCSTUBNT*)(entry))->nameofs) : \
		((AMX_FUNCSTUB*)(entry))->name)

void
	Redirect(AMX * amx, char const * const from, ucell to, AMX_NATIVE * store)
{
	int
		num,
		idx;
	// Operate on the raw AMX file, don't use the amx_ functions to avoid issues
	// with the fact that we've not actually finished initialisation yet.  Based
	// VERY heavilly on code from "amx.c" in the PAWN runtime library.
	AMX_HEADER *
		hdr = (AMX_HEADER *)amx->base;
	AMX_FUNCSTUB *
		func;
	num = NUMENTRIES(hdr, natives, libraries);
	//logprintf("Redirect 1");
	for (idx = 0; idx != num; ++idx)
	{
		func = GETENTRY(hdr, natives, idx);
		//logprintf("Redirect 2 \"%s\" \"%s\"", from, GETENTRYNAME(hdr, func));
		if (!strcmp(from, GETENTRYNAME(hdr, func)))
		{
			//logprintf("Redirect 3");
			// Intercept the call!
			if (store)
			{
				*store = (AMX_NATIVE)func->address;
			}
			func->address = to;
			break;
		}
	}
}

PLUGIN_EXPORT int PLUGIN_CALL
	AmxLoad(AMX * amx) 
{
	Redirect(amx, "print", (ucell)n_print, &pPrint);
	Redirect(amx, "printf", (ucell)n_printf, &pPrintF);
	for (int i = 0; i != 17; ++i)
	{
		if (gAMXFiles[i] == 0)
		{
			gAMXFiles[i] = amx;
			int
				idx;
			if (amx_FindPublic(amx, "OnPacketModified", &idx))
			{
				//printf("NO CALLBACK\n");
				gAMXPtr[i] = -1;
			}
			else
			{
				//printf("GOT CALLBACK %d\n", idx);
				gAMXPtr[i] = idx;
			}
			break;
		}
	}
	return AMX_ERR_NONE;
}

//----------------------------------------------------------
// When a gamemode is over or a filterscript gets unloaded, this
// function gets called. No special actions needed in here.

PLUGIN_EXPORT int PLUGIN_CALL
	AmxUnload(AMX * amx) 
{
	for (int i = 0; i != 17; ++i)
	{
		if (gAMXFiles[i] == amx)
		{
			gAMXFiles[i] = 0;
			break;
		}
	}
	return AMX_ERR_NONE;
}
