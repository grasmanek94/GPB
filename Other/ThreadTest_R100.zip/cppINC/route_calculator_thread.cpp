#ifdef OS_WINDOWS
	#define SLEEP(x) { Sleep(x); }
#include<windows.h>

#else
	#define SLEEP(x) { usleep(x * 1000); }
#endif

#ifdef OS_WINDOWS
	void Thread::BackgroundCalculator( void *unused )
#else
	void *Thread::BackgroundCalculator( void *unused )
#endif
{
	float X;
	float Y;
	float Z;
	while( true )
    {
		if(ENABLED == false)
		{
			continue;
		}
		for(int i = 0; i < MAX_PLAYERS; ++i)
		{
			if(IsPlayerConnected(i) == false)
			{
				speed[i] = -1.0f;
				continue;
			}
			if(IsPlayerInAnyVehicle(i) == true)
			{
				GetVehicleVelocity(GetPlayerVehicleID(i),&X,&Y,&Z);
			}
			else
			{
				GetPlayerVelocity(i,&X,&Y,&Z);
			}
			speed[i] = sqrt(X*X+Y*Y+Z*Z);
		}
		SLEEP(30);
    }

	EXIT_THREAD();//should be never reached..
}