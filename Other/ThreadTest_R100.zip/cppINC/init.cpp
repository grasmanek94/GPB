/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/
PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{
	sampgdk_initialize_plugin(ppData);
	cout << "---Loading---\r\n\tGamer_Z's Project Bundle: \r\n\t\tThread Test R" << PLUGIN_VERSION << "\r\n---LOADED---";
	ENABLED = false;
	START_THREAD( Thread::BackgroundCalculator, 0);
	return true;
}
