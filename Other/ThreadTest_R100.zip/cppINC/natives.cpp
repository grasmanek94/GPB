AMX_NATIVE_INFO AMXNatives[ ] =
{
	{"GetSpeed",n_GetSpeed},
	{0,                0}
};

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	ENABLED = true;
	return amx_Register( amx, AMXNatives, -1 );
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	return AMX_ERR_NONE;
}

static cell AMX_NATIVE_CALL n_GetSpeed( AMX* amx, cell* params )
{
	return amx_ftoc(speed[params[1]]);
}