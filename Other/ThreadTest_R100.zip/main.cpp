#define PLUGIN_VERSION (100)
//-------------------------------------------//
#include "defines.h"
//-------------------------------------------//
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <queue>
#include <cstring>
#include <limits>
#include <fstream>
#include <stack>
#include <set>
#include <string>
//-------------------------------------------//
#include <sampgdk/core.h>
#include <sampgdk/players.h>
#include <sampgdk/plugin.h>
#include <sampgdk/vehicles.h>
#include <sampgdk/samp.h>
//-------------------------------------------//
#undef MAX_PLAYERS
#define MAX_PLAYERS (800)
//-------------------------------------------//
#include "Thread.h"
#include "main.h"
#include "./cppINC/natives.cpp"
#include "./cppINC/route_calculator_thread.cpp"
#include "./cppINC/init.cpp"
//-------------------------------------------//
//-------------------------------------------//
//----------------TESTING ZONE---------------//