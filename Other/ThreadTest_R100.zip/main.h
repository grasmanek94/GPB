using namespace std;
bool ENABLED = false;
float speed[MAX_PLAYERS];
static cell AMX_NATIVE_CALL n_GetSpeed( AMX* amx, cell* params );
Thread::Thread( void )
{
}

Thread::~Thread( void )
{
}

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	cout << "---Unloading---\r\n\tGamer_Z's Project Bundle: \r\n\t\tThread Test\r\n---UNLOADED---";
}
//-------------------------------------------//
//-------------------------------------------//
//----------------TESTING ZONE---------------//