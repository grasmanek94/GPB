/*
		ROUTER PLUGIN
		- GPS ADDITION TO SA-MP
		- Made By Gamer_Z a.k.a. grasmanek94 , Rafal Grasman

		October-2011


		contact: grasmanek94@live.nl

		http://gamer-gps.googlecode.com/
*/

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32__)
#	include <process.h>
#	define OS_WINDOWS
#else
#	include <pthread.h>
#	define sscanf_s sscanf
#	define sprintf_s sprintf
#endif

#ifdef OS_WINDOWS
#	define EXIT_THREAD() { _endthread(); }
#	define START_THREAD(a, b) { _beginthread( a, 0, (void *)( b ) ); }
#else
#	define EXIT_THREAD() { pthread_exit( NULL ); }
#	define START_THREAD(a, b) {	pthread_t thread;\
								pthread_create( &thread, NULL, a, (void *)( b ) ); }
#endif

#define PLUGIN_REVISION_R (1)