﻿Public Class Form3
    Public Labels(0 To 13)() As Label
    Private Sub NumericUpDown1_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        Dim Current As Integer = 0
        For Height As Integer = 0 To 8
            For index As Integer = 0 To 13
                Current = Current + 1
                Labels(index)(Height).Text = ChrW((NumericUpDown1.Value * 14 * 9) + Current)
            Next index
        Next Height
    End Sub

    Public Sub Label_Click(sender As System.Object, e As System.EventArgs)
        Form1.TextBox1.Text = DirectCast(sender, Control).Text
        Form1.AdTheChar()
        Close()
        If Form1.CheckBox1.Checked = True Then
            Clipboard.Clear()
            Clipboard.SetText(DirectCast(sender, Control).Text)
        End If
    End Sub
End Class