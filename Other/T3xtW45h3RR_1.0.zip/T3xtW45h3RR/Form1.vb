﻿Imports System
Imports System.IO

Public Class Form1
    Declare Function AddFontResource Lib "gdi32" Alias "AddFontResourceA" (ByVal lpFileName As String) As Long
    Declare Function RemoveFontResource Lib "gdi32" Alias "RemoveFontResourceA" (ByVal lpFileName As String) As Long
    Dim x(0 To 255) As List(Of String)
    Dim rand As New Random()
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        RichTextBox2.Text = ""
        For index As Integer = 0 To RichTextBox1.TextLength - 1
            RichTextBox2.Text = RichTextBox2.Text + Switch(RichTextBox1.Text(index))
        Next index
    End Sub

    Function Switch(ByVal Inpx As Char) As Char
        If AscW(Inpx) > 255 Or AscW(Inpx) < 0 Then
            Switch = Inpx
            Exit Function
        End If
        Dim max As Integer
        max = x(AscW(Inpx)).Count()
        Dim number = rand.Next(0, max)
        Switch = x(AscW(Inpx))(number)
        Exit Function
    End Function

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ''
        Dim lResult As Long

        lResult = AddFontResource(Application.StartupPath + "\CODE2002.TTF")

        ''
        Button2.Enabled = False
        Button3.Enabled = False
        For index As Integer = 0 To 255
            x(index) = New List(Of String)
            AddReplaceChar(Chr(index), Chr(index))
        Next index

        Try
            Dim fi As FileInfo = New FileInfo("Replacements.CRTBIN")
            Dim sw As StreamWriter
            If fi.Exists = False Then
                sw = fi.CreateText()
                sw.Flush()
                sw.Close()
            End If
            Dim sr As StreamReader = New StreamReader("Replacements.CRTBIN")
            Dim line As String
            Do
                line = sr.ReadLine()
                If Len(line) > 1 Then
                    For index As Integer = 1 To line.Length - 1
                        AddReplaceChar(line(0), line(index))
                    Next index
                End If
            Loop Until line Is Nothing
            sr.Close()
        Catch err As Exception
            MsgBox("Error Has occured:" + vbNewLine + err.ToString)
            Application.Exit()
        End Try
        ''
        For index As Integer = 0 To 13
            ReDim Preserve Form3.Labels(index)(0 To 8)
        Next index
        Try
            Dim Current As Integer = 0
            For Height As Integer = 0 To 8
                For index As Integer = 0 To 13
                    Current = Current + 1

                    Form3.Labels(index)(Height) = New Label
                    Form3.Labels(index)(Height).Visible = True
                    Form3.Labels(index)(Height).Size = New Point(56, 55)
                    Form3.Labels(index)(Height).TextAlign = ContentAlignment.TopLeft
                    Form3.Labels(index)(Height).UseCompatibleTextRendering = False
                    Form3.Labels(index)(Height).UseMnemonic = True
                    Form3.Labels(index)(Height).UseWaitCursor = False
                    Form3.Labels(index)(Height).Name = "Label(" + (Current).ToString + ")"
                    'Labels(index)(Height).Font = New System.Drawing.Font("Microsoft Sans Serif", 36,
                    Form3.Labels(index)(Height).Font = New System.Drawing.Font("Code2002", 34,
                        System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
                        CType(0, Byte))
                    'Labels(index)(Height).Location = New Point(12 + (72 * index), 30 + (55 * Height))
                    Form3.Labels(index)(Height).Location = New Point((index * 65) + 12, (Height * 55) + 30)
                    Form3.Labels(index)(Height).Text = ChrW((Form3.NumericUpDown1.Value * 14 * 9) + Current)
                    'Labels(index)(Height).
                    AddHandler Form3.Labels(index)(Height).Click, AddressOf Form3.Label_Click
                    Form3.Controls.Add(Form3.Labels(index)(Height))
                Next index
            Next Height
        Catch Ex As Exception
            MessageBox.Show("ERR: " & Ex.Message)
        End Try
    End Sub
    Function AddReplaceChar(ByVal Which As Char, ByVal Replacement As Char) As Boolean
        If AscW(Which) > 255 Or AscW(Which) < 0 Then
            Return (False)
        End If
        If Not (x(AscW(Which)).IndexOf(Replacement) = -1) Then
            Return (False)
        End If
        If x(AscW(Which)).IndexOf(Which) = 0 Then
            RemoveReplaceChar(Which, Which)
        End If

        x(AscW(Which)).Add(Replacement)
        Return (True)
    End Function
    Function RemoveReplaceChar(ByVal Which As Char, ByVal Replacement As Char) As Boolean
        If AscW(Which) > 255 Or AscW(Which) < 0 Then
            Return (False)
        End If
        If (x(AscW(Which)).IndexOf(Replacement) = -1) Then
            Return (False)
        End If
        x(AscW(Which)).Remove(Replacement)
        Return (True)
    End Function

    Private Sub ListBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Button2.Enabled = True
        Button3.Enabled = True
        ListBox2.Items.Clear()
        For index As Integer = 0 To x(ListBox1.SelectedIndex).Count - 1
            ListBox2.Items.Add(x(ListBox1.SelectedIndex)(index))
        Next index
    End Sub

    Private Sub TextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox1.TextChanged
        If Not (ListBox1.SelectedIndex = -1) Then
            If Len(TextBox1.Text) = 1 Then
                If AddReplaceChar(Chr(ListBox1.SelectedIndex), TextBox1.Text(0)) = True Then
                    ListBox2.Items.Clear()
                    For index As Integer = 0 To x(ListBox1.SelectedIndex).Count - 1
                        ListBox2.Items.Add(x(ListBox1.SelectedIndex)(index))
                    Next index
                End If
            End If
        End If
        TextBox1.Text = ""
    End Sub

    Public Function AdTheChar()
        If Not (ListBox1.SelectedIndex = -1) Then
            If Len(TextBox1.Text) = 1 Then
                If AddReplaceChar(Chr(ListBox1.SelectedIndex), TextBox1.Text(0)) = True Then
                    ListBox2.Items.Clear()
                    For index As Integer = 0 To x(ListBox1.SelectedIndex).Count - 1
                        ListBox2.Items.Add(x(ListBox1.SelectedIndex)(index))
                    Next index
                End If
            End If
        End If
        TextBox1.Text = ""
        Return True
    End Function
    Private Sub ListBox2_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ListBox2.SelectedIndexChanged
        If Not (ListBox1.SelectedIndex = -1) And Not (ListBox2.SelectedIndex = -1) And ListBox2.Items.Count > 1 Then
            If RemoveReplaceChar(Chr(ListBox1.SelectedIndex), ListBox2.SelectedItem.ToString) = True Then
                ListBox2.Items.Clear()
                For index As Integer = 0 To x(ListBox1.SelectedIndex).Count - 1
                    ListBox2.Items.Add(x(ListBox1.SelectedIndex)(index))
                Next index
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Form2.ShowInTaskbar = False
        Form2.ShowIcon = False
        Form2.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub LoadReplacementsToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles LoadReplacementsToolStripMenuItem.Click

        Dim openFileDialog1 As New OpenFileDialog()

        openFileDialog1.InitialDirectory = "./"
        openFileDialog1.Filter = "Character Replacement Table (*.CRTBIN)|*.CRTBIN"
        openFileDialog1.Title = "Select the file you want to open"
        openFileDialog1.FilterIndex = 0
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Try
                For index As Integer = 0 To 255
                    x(index).Clear()
                    AddReplaceChar(Chr(index), Chr(index))
                Next index
                Dim sr As StreamReader = New StreamReader(openFileDialog1.FileName())
                Dim line As String
                Do
                    line = sr.ReadLine()
                    If Len(line) > 1 Then
                        For index As Integer = 1 To line.Length - 1
                            AddReplaceChar(line(0), line(index))
                        Next index
                    End If
                Loop Until line Is Nothing
                sr.Close()
                If Not (ListBox1.SelectedIndex = -1) Then
                    ListBox2.Items.Clear()
                    For index As Integer = 0 To x(ListBox1.SelectedIndex).Count - 1
                        ListBox2.Items.Add(x(ListBox1.SelectedIndex)(index))
                    Next index
                End If
            Catch Ex As Exception
                MessageBox.Show("Cannot read file from disk. Original error: " & Ex.Message)
            End Try
        End If
    End Sub

    Private Sub SaveReplacementsAsToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SaveReplacementsAsToolStripMenuItem.Click
        Dim openFileDialog1 As New SaveFileDialog()

        openFileDialog1.InitialDirectory = "./"
        openFileDialog1.Filter = "Character Replacement Table (*.CRTBIN)|*.CRTBIN"
        openFileDialog1.FilterIndex = 0
        openFileDialog1.Title = "Select a location to save the table..."
        openFileDialog1.RestoreDirectory = True
        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Try
                Dim fi As FileInfo = New FileInfo(openFileDialog1.FileName())
                Dim sw As StreamWriter
                If fi.Exists = True Then
                    fi.Delete()
                End If
                sw = fi.CreateText()
                For index As Integer = 0 To 255
                    If Not (Chr(index) = vbNullChar) Then
                        sw.Write(Chr(index))
                        For curr As Integer = 0 To x(index).Count - 1
                            If Not (x(index)(curr) = vbNullChar) Then
                                sw.Write(x(index)(curr))
                            End If
                        Next
                        sw.Write(vbNewLine)
                    End If
                Next index

                sw.Flush()
                sw.Close()
            Catch Ex As Exception
                MessageBox.Show("Cannot write file to disk. Original error: " & Ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Form3.ShowDialog()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox1.CheckedChanged

    End Sub
End Class
