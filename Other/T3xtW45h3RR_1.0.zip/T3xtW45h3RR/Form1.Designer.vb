﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveReplacementsAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadReplacementsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 193)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(534, 26)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Convert"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.AcceptsTab = True
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 29)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(534, 158)
        Me.RichTextBox1.TabIndex = 1
        Me.RichTextBox1.Text = ""
        Me.RichTextBox1.WordWrap = False
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(12, 225)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.Size = New System.Drawing.Size(534, 158)
        Me.RichTextBox2.TabIndex = 2
        Me.RichTextBox2.Text = ""
        Me.RichTextBox2.WordWrap = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"0x00 NUL", "0x01 SOH", "0x02 STX", "0x03 ETX", "0x04 EOT", "0x05 ENQ", "0x06 ACK", "0x07 BEL", "0x08 BS", "0x09 TAB", "0x0A LF", "0x0B VT", "0x0C FF", "0x0D CR", "0x0E SO", "0x0F SI", "0x10 DLE", "0x11 DC1", "0x12 DC2", "0x13 DC3", "0x14 DC4", "0x15 NAK", "0x16 SYN", "0x17 ETB", "0x18 CAN", "0x19 EM", "0x1A SUB", "0x1B ESC", "0x1C FS", "0x1D GS", "0x1E RS", "0x1F US", "0x20 Space", "0x21 !", "0x22 """, "0x23 #", "0x24 $", "0x25 %", "0x26 &", "0x27 '", "0x28 (", "0x29 )", "0x2A *", "0x2B +", "0x2C ,", "0x2D -", "0x2E .", "0x2F /", "0x30 0", "0x31 1", "0x32 2", "0x33 3", "0x34 4", "0x35 5", "0x36 6", "0x37 7", "0x38 8", "0x39 9", "0x3A :", "0x3B ;", "0x3C <", "0x3D =", "0x3E >", "0x3F ?", "0x40 @", "0x41 A", "0x42 B", "0x43 C", "0x44 D", "0x45 E", "0x46 F", "0x47 G", "0x48 H", "0x49 I", "0x4A J", "0x4B K", "0x4C L", "0x4D M", "0x4E N", "0x4F O", "0x50 P", "0x51 Q", "0x52 R", "0x53 S", "0x54 T", "0x55 U", "0x56 V", "0x57 W", "0x58 X", "0x59 Y", "0x5A Z", "0x5B [", "0x5C \", "0x5D ]", "0x5E ^", "0x5F _", "0x60 `", "0x61 a", "0x62 b", "0x63 c", "0x64 d", "0x65 e", "0x66 f", "0x67 g", "0x68 h", "0x69 i", "0x6A j", "0x6B k", "0x6C l", "0x6D m", "0x6E n", "0x6F o", "0x70 p", "0x71 q", "0x72 r", "0x73 s", "0x74 t", "0x75 u", "0x76 v", "0x77 w", "0x78 x", "0x79 y", "0x7A z", "0x7B {", "0x7C |", "0x7D }", "0x7E ~", "0x7F DEL", "0x80 Ç", "0x81 ü", "0x82 é", "0x83 â", "0x84 ä", "0x85 ů", "0x86 ć", "0x87 ç", "0x88 ł", "0x89 ë", "0x8A Ő", "0x8B ő", "0x8C î", "0x8D Ź", "0x8E Ä", "0x8F Ć", "0x90 É", "0x91 Ĺ", "0x92 ĺ", "0x93 ô", "0x94 ö", "0x95 Ľ", "0x96 ľ", "0x97 Ś", "0x98 ś", "0x99 Ö", "0x9A Ü", "0x9B Ť", "0x9C ť", "0x9D Ł", "0x9E ×", "0x9F č", "0xA0 á", "0xA1 í", "0xA2 ó", "0xA3 ú", "0xA4 Ą", "0xA5 ą", "0xA6 Ž", "0xA7 ž", "0xA8 Ę", "0xA9 ę", "0xAA ¬", "0xAB ź", "0xAC Č", "0xAD ş", "0xAE «", "0xAF »", "0xB0 ░", "0xB1 ▒", "0xB2 ▓", "0xB3 │", "0xB4 ┤", "0xB5 Á", "0xB6 Â", "0xB7 Ě", "0xB8 Ş", "0xB9 ╣", "0xBA ║", "0xBB ╗", "0xBC ╝", "0xBD Ż", "0xBE ż", "0xBF ┐", "0xC0 └", "0xC1 ┴", "0xC2 ┬", "0xC3 ├", "0xC4 ─", "0xC5 ┼", "0xC6 Ă", "0xC7 ă", "0xC8 ╚", "0xC9 ╔", "0xCA ╩", "0xCB ╦", "0xCC ╠", "0xCD ═", "0xCE ╬", "0xCF ¤", "0xD0 đ", "0xD1 Đ", "0xD2 Ď", "0xD3 Ë", "0xD4 ď", "0xD5 Ň", "0xD6 Í", "0xD7 Î", "0xD8 ě", "0xD9 ┘", "0xDA ┌", "0xDB █", "0xDC ▄", "0xDD Ţ", "0xDE Ů", "0xDF ▀", "0xE0 Ó", "0xE1 ß", "0xE2 Ô", "0xE3 Ń", "0xE4 ń", "0xE5 ň", "0xE6 Š", "0xE7 š", "0xE8 Ŕ", "0xE9 Ú", "0xEA ŕ", "0xEB Ű", "0xEC ý", "0xED Ý", "0xEE ţ", "0xEF ´", "0xF0 ­", "0xF1 ˝", "0xF2 ˛", "0xF3 ˇ", "0xF4 ˘", "0xF5 §", "0xF6 ÷", "0xF7 ¸", "0xF8 °", "0xF9 ¨", "0xFA ˙", "0xFB ű", "0xFC Ř", "0xFD ř", "0xFE ■", "0xFF nbsp"})
        Me.ListBox1.Location = New System.Drawing.Point(552, 29)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(85, 355)
        Me.ListBox1.TabIndex = 3
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(705, 206)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(49, 20)
        Me.TextBox1.TabIndex = 4
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(643, 29)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(114, 173)
        Me.ListBox2.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(640, 209)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Custom Add:"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(643, 232)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 24)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Choose Character"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(771, 24)
        Me.MenuStrip1.TabIndex = 10
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveReplacementsAsToolStripMenuItem, Me.LoadReplacementsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'SaveReplacementsAsToolStripMenuItem
        '
        Me.SaveReplacementsAsToolStripMenuItem.Name = "SaveReplacementsAsToolStripMenuItem"
        Me.SaveReplacementsAsToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.SaveReplacementsAsToolStripMenuItem.Text = "Save replacements as..."
        '
        'LoadReplacementsToolStripMenuItem
        '
        Me.LoadReplacementsToolStripMenuItem.Name = "LoadReplacementsToolStripMenuItem"
        Me.LoadReplacementsToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.LoadReplacementsToolStripMenuItem.Text = "Load replacements"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(195, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(643, 262)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(114, 25)
        Me.Button3.TabIndex = 11
        Me.Button3.Text = "Paged View"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(643, 294)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(108, 17)
        Me.CheckBox1.TabIndex = 12
        Me.CheckBox1.Text = "Update Clipboard"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(771, 399)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "TҘxtCҐѦshҘҐ"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveReplacementsAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadReplacementsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox

End Class
