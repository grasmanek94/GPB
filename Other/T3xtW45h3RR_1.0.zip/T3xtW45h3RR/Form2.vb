﻿Public Class Form2
    Dim base As Integer = 0
    Dim index As Integer = 0

    Private Sub ListBox1_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If Not (ListBox1.SelectedIndex = -1) Then
            Dim data() As String
            data = Split(ListBox1.SelectedItem)
            ListBox2.Items.Clear()
            For index As Integer = 0 To Convert.ToInt32(data(1), 16) - Convert.ToInt32(data(0), 16)
                ListBox2.Items.Add(ChrW(Convert.ToInt32(data(0), 16) + index))
            Next index
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If Not (ListBox2.SelectedIndex = -1) Then
            If Not (Form1.ListBox1.SelectedIndex = -1) Then
                Form1.TextBox1.Text = ListBox2.SelectedItem
                Form1.AdTheChar()
                Close()
            End If
        End If
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ListBox2.SelectedIndexChanged
        Button2.Enabled = True
        Label3.Text = ListBox2.SelectedItem
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        If NumericUpDown1.Value < 1 Then
            NumericUpDown1.Value = 1
        End If
        Label3.Font = New System.Drawing.Font("Code2002", NumericUpDown1.Value,
 System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
 CType(0, Byte))

    End Sub

    Private Sub Form2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Button2.Enabled = False
    End Sub
End Class