﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(120, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Set:"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"0000 007F Basic Latin ", "0080 00FF C1 Controls and Latin-1 Supplement ", "0100 017F Latin Extended-A ", "0180 024F Latin Extended-B ", "0250 02AF IPA Extensions ", "02B0 02FF Spacing Modifier Letters ", "0300 036F Combining Diacritical Marks ", "0370 03FF Greek/Coptic ", "0400 04FF Cyrillic ", "0500 052F Cyrillic Supplement ", "0530 058F Armenian ", "0590 05FF Hebrew ", "0600 06FF Arabic ", "0700 074F Syriac ", "0750 077F Undefined ", "0780 07BF Thaana ", "07C0 08FF Undefined ", "0900 097F Devanagari ", "0980 09FF Bengali/Assamese ", "0A00 0A7F Gurmukhi ", "0A80 0AFF Gujarati ", "0B00 0B7F Oriya ", "0B80 0BFF Tamil ", "0C00 0C7F Telugu ", "0C80 0CFF Kannada ", "0D00 0DFF Malayalam ", "0D80 0DFF Sinhala ", "0E00 0E7F Thai ", "0E80 0EFF Lao ", "0F00 0FFF Tibetan ", "1000 109F Myanmar ", "10A0 10FF Georgian ", "1100 11FF Hangul Jamo ", "1200 137F Ethiopic ", "1380 139F Undefined ", "13A0 13FF Cherokee ", "1400 167F Unified Canadian Aboriginal Syllabics ", "1680 169F Ogham ", "16A0 16FF Runic ", "1700 171F Tagalog ", "1720 173F Hanunoo ", "1740 175F Buhid ", "1760 177F Tagbanwa ", "1780 17FF Khmer ", "1800 18AF Mongolian ", "18B0 18FF Undefined ", "1900 194F Limbu ", "1950 197F Tai Le ", "1980 19DF Undefined ", "19E0 19FF Khmer Symbols ", "1A00 1CFF Undefined ", "1D00 1D7F Phonetic Extensions ", "1D80 1DFF Undefined ", "1E00 1EFF Latin Extended Additional ", "1F00 1FFF Greek Extended ", "2000 206F General Punctuation ", "2070 209F Superscripts and Subscripts ", "20A0 20CF Currency Symbols ", "20D0 20FF Combining Diacritical Marks for Symbols ", "2100 214F Letterlike Symbols ", "2150 218F Number Forms ", "2190 21FF Arrows ", "2200 22FF Mathematical Operators ", "2300 23FF Miscellaneous Technical ", "2400 243F Control Pictures ", "2440 245F Optical Character Recognition ", "2460 24FF Enclosed Alphanumerics ", "2500 257F Box Drawing ", "2580 259F Block Elements ", "25A0 25FF Geometric Shapes ", "2600 26FF Miscellaneous Symbols ", "2700 27BF Dingbats ", "27C0 27EF Miscellaneous Mathematical Symbols-A ", "27F0 27FF Supplemental Arrows-A ", "2800 28FF Braille Patterns ", "2900 297F Supplemental Arrows-B ", "2980 29FF Miscellaneous Mathematical Symbols-B ", "2A00 2AFF Supplemental Mathematical Operators ", "2B00 2BFF Miscellaneous Symbols and Arrows ", "2C00 2E7F Undefined ", "2E80 2EFF CJK Radicals Supplement ", "2F00 2FDF Kangxi Radicals ", "2FE0 2FEF Undefined ", "2FF0 2FFF Ideographic Description Characters ", "3000 303F CJK Symbols and Punctuation ", "3040 309F Hiragana ", "30A0 30FF Katakana ", "3100 312F Bopomofo ", "3130 318F Hangul Compatibility Jamo ", "3190 319F Kanbun (Kunten) ", "31A0 31BF Bopomofo Extended ", "31C0 31EF Undefined ", "31F0 31FF Katakana Phonetic Extensions ", "3200 32FF Enclosed CJK Letters and Months ", "3300 33FF CJK Compatibility ", "3400 4DBF CJK Unified Ideographs Extension A ", "4DC0 4DFF Yijing Hexagram Symbols ", "4E00 9FAF CJK Unified Ideographs ", "9FB0 9FFF Undefined ", "A000 A48F Yi Syllables ", "A490 A4CF Yi Radicals ", "A4D0 ABFF Undefined ", "AC00 D7AF Hangul Syllables ", "D7B0 D7FF Undefined ", "D800 DBFF High Surrogate Area ", "DC00 DFFF Low Surrogate Area ", "E000 F8FF Private Use Area ", "F900 FAFF CJK Compatibility Ideographs ", "FB00 FB4F Alphabetic Presentation Forms ", "FB50 FDFF Arabic Presentation Forms-A ", "FE00 FE0F Variation Selectors ", "FE10 FE1F Undefined ", "FE20 FE2F Combining Half Marks ", "FE30 FE4F CJK Compatibility Forms ", "FE50 FE6F Small Form Variants ", "FE70 FEFF Arabic Presentation Forms-B ", "FF00 FFEF Halfwidth and Fullwidth Forms ", "FFF0 FFFE Specials "})
        Me.ListBox1.Location = New System.Drawing.Point(12, 25)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(304, 342)
        Me.ListBox1.TabIndex = 1
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(322, 25)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(163, 342)
        Me.ListBox2.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(661, 25)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Preview:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 189.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label3.Location = New System.Drawing.Point(558, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(187, 286)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = " "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(351, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Choose Character:"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(837, 342)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(59, 25)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(772, 342)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(59, 25)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Select"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(492, 25)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {250, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(40, 20)
        Me.NumericUpDown1.TabIndex = 9
        Me.NumericUpDown1.Value = New Decimal(New Integer() {190, 0, 0, 0})
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(908, 377)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form2"
        Me.Text = "Choose Character To Add"
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
End Class
