﻿Option Explicit On
Option Compare Text

Public Class Form1
    Dim DQ As New Queue
    Dim AQ As New Queue
    Dim TQ As New Queue

    Public Declare Function SendMessage Lib "user32.dll" Alias "SendMessageA" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Public Const EM_GETLINECOUNT = &HBA
    Public Const EM_LINESCROLL = &HB6
    Dim forpassword As Boolean = False
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        forpassword = False
        RichTextBox1.ScrollBars() = RichTextBoxScrollBars.None
        RichTextBox1.TabStop = True
        RichTextBox1.Text = ""
        ''''''
        AddTextE("Hello...", 1) 'text met enter, laat elke letter om de miliseconde zien
        Wait(1000) ' wacht 1000 ms = 1 seconde
        AddTextN("Do you know your name??", 100) ' text zonder enter, laat elke letter om de 100 miliseconde zien
        Wait(2000) ' wacht 2 seconden
        AddTextE("...", 500) ' laat elke letter om de halve seconde zien
        Wait(500) 'wacht een halve seconde
        AddTextE("C'mon BITCH I KNOW YOU DO KNOW!", 30) ' text met enter, laat elke letter om de 30 miliseconden zien
        AddTextE("...", 500)
        AddTextN("Type your name and press enter, bitch!::: ", 1)
        WaitForEnter() ' typ wilkeurige text en wacht op enter
        AddTextE("") 'standart laat elke letter zich om de 20 miliseconden zien, als je die niet opgeeft
        AddTextE("Aha so that's your name...")
        AddTextN("So now provide your password: ")
        WaitForPassword() ' verander getypte text naar * en wacht op enter
        AddTextE("")
        AddTextE("Thank you bitch, byeeee!")
        ''''''
        Timer1.Interval = 50
        Timer1.Enabled = True
    End Sub
    Private Sub AddTextE(ByVal text As String, Optional ByVal timing As Integer = 20)
        For i As Integer = 0 To text.Length - 1
            DQ.Enqueue(Asc(text(i)))
            AQ.Enqueue(0)
            TQ.Enqueue(timing)
        Next
        DQ.Enqueue(12)
        AQ.Enqueue(0)
        TQ.Enqueue(timing)
    End Sub
    Private Sub WaitForPassword()
        DQ.Enqueue(0)
        AQ.Enqueue(3)
        TQ.Enqueue(1)
    End Sub
    Private Sub WaitForEnter()
        DQ.Enqueue(0)
        AQ.Enqueue(2)
        TQ.Enqueue(1)
    End Sub
    Private Sub AddTextN(ByVal text As String, Optional ByVal timing As Integer = 20)
        For i As Integer = 0 To text.Length - 1
            DQ.Enqueue(Asc(text(i)))
            AQ.Enqueue(0)
            TQ.Enqueue(timing)
        Next
    End Sub
    Sub Wait(ByVal time As Integer)
        DQ.Enqueue(time)
        AQ.Enqueue(1)
        TQ.Enqueue(1)
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If AQ.Count > 0 Then
            If (AQ.Peek() = 1) Then
                AQ.Dequeue()
                TQ.Dequeue()
                System.Threading.Thread.Sleep(DQ.Dequeue())
            ElseIf (AQ.Peek() = 2) Then
                AQ.Dequeue()
                TQ.Dequeue()
                DQ.Dequeue()
                Timer1.Enabled = False
                RichTextBox1.ReadOnly = False
                RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
            ElseIf (AQ.Peek() = 3) Then
                forpassword = True
                AQ.Dequeue()
                TQ.Dequeue()
                DQ.Dequeue()
                Timer1.Enabled = False
                RichTextBox1.ReadOnly = False
                RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
            Else
                Dim intLines As Integer = SendMessage(RichTextBox1.Handle, EM_GETLINECOUNT, 0, 0)
                RichTextBox1.AppendText(Chr(DQ.Dequeue()))
                AQ.Dequeue()
                Timer1.Interval = TQ.Dequeue()
                Dim intLinesToAdd As Integer = (SendMessage(RichTextBox1.Handle, EM_GETLINECOUNT, 0, 0) - intLines)
                SendMessage(RichTextBox1.Handle, EM_LINESCROLL, 0, intLinesToAdd)
            End If
        End If
    End Sub
    Private Sub RichTextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) _
         Handles RichTextBox1.KeyDown
        If e.KeyCode = Keys.Escape Then
            Application.Exit()
        ElseIf e.KeyCode = Keys.Enter Then
            If Timer1.Enabled = False Then
                RichTextBox1.ReadOnly = True
                forpassword = False
                Timer1.Enabled = True
            End If
        End If
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles RichTextBox1.TextChanged
        If forpassword = True Then
            RichTextBox1.Text = RichTextBox1.Text.Remove(RichTextBox1.TextLength() - 1)
            RichTextBox1.AppendText("*")
            RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
        End If
    End Sub
End Class