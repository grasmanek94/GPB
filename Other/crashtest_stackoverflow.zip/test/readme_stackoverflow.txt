open server.cfg and change the line "gamemode0" to either test1 or test2. test2 uses more pushbacks (CreatePolygon = 1) and test1 not (CreatePolygon = 0)
The crashing code is in source\RouteConnector\main.cpp from line 87 to 158

In test one it hits 3466 and the data becomes probbly corrupt?
in test two it hits 1 or 2, max 4 and the application crashes.

A crashinfo.txt is generated on each crash.