﻿Option Explicit On
Option Compare Text
Public Class Form1
    Dim MyString As String
    Dim MyTypeString As String
    Dim Count As Int64
    Dim Ticking As Integer
    Dim StartUP As Integer = 0
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim Ping_runProcess As New Process()
        Dim Ping_runStartInfo As New ProcessStartInfo()
        Ping_runStartInfo.FileName = "cmd.exe "
        Ping_runStartInfo.UseShellExecute = False
        Ping_runStartInfo.CreateNoWindow = True
        Ping_runStartInfo.Arguments = "/D /c echo (Shift+)WASD to move window, R to rescan, C to clear screen, F1 to show info, ESC to exit && echo User running this machine: && whoami && echo Current time and date: && date /t && time /t"
        Ping_runStartInfo.RedirectStandardOutput = True
        Ping_runProcess.EnableRaisingEvents = True
        Ping_runProcess.StartInfo = Ping_runStartInfo
        Ping_runProcess.Start()
        Dim output As String = ""
        Dim readerStdOut As IO.StreamReader = Ping_runProcess.StandardOutput
        Do While readerStdOut.EndOfStream = False
            output = output + readerStdOut.ReadLine() + vbNewLine
        Loop
        output = output + "                               " + vbNewLine
        MyString = output + "Initializing network interface...          " + vbNewLine + "Please wait while analyzing..." + vbNewLine
        MyTypeString = ""
        RichTextBox1.ScrollBars() = RichTextBoxScrollBars.None
        RichTextBox1.Text = MyTypeString
        Timer1.Interval = 5
        Timer1.Enabled = True
        Timer2.Interval = 15
        Timer2.Enabled = True
        StartUP = 1
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Ticking = 1
        Count = Count + 1
        MyTypeString = Mid$(MyString, 1, Count)
        Dim temp As Integer
        temp = MyString.Length
        If temp = Count Then
            Timer1.Enabled = False
            Ticking = 0
            If StartUP = 1 Then
                StartUP = 0
                ResloveNetwork()
            End If
        End If

        RichTextBox1.Text = MyTypeString
    End Sub
    Private Direction As Integer = -1
    Private Sub RichTextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) _
         Handles RichTextBox1.KeyDown
        Direction = -1
        If e.KeyCode = Keys.A Then
            Direction = 0
            If (e.Shift) Then
                Direction = 1
            End If
        ElseIf e.KeyCode = Keys.D Then
            Direction = 2
            If (e.Shift) Then
                Direction = 3
            End If
        ElseIf e.KeyCode = Keys.W Then
            Direction = 4
            If (e.Shift) Then
                Direction = 5
            End If
        ElseIf e.KeyCode = Keys.S Then
            Direction = 6
            If (e.Shift) Then
                Direction = 7
            End If
        ElseIf e.KeyCode = Keys.Escape Then
            Application.Exit()
        ElseIf e.KeyCode = Keys.R Then
            If Ticking = 1 Then

            Else
                ResloveNetwork()
            End If
        ElseIf e.KeyCode = Keys.C Then
            If Ticking = 1 Then

            Else
                Count = 0
                MyString = ""
                MyTypeString = ""
                RichTextBox1.Text = ""
            End If
        ElseIf e.KeyCode = Keys.F1 Then
            If Ticking = 1 Then

            Else
                Dim Ping_runProcess As New Process()
                Dim Ping_runStartInfo As New ProcessStartInfo()
                Ping_runStartInfo.FileName = "cmd.exe "
                Ping_runStartInfo.UseShellExecute = False
                Ping_runStartInfo.CreateNoWindow = True
                Ping_runStartInfo.Arguments = "/D /c echo Press WASD to move window, R to rescan, C to clear screen, F1 to show info, ESC to exit && echo User running this machine: && whoami && echo Current time and date: && date /t && time /t"
                Ping_runStartInfo.RedirectStandardOutput = True
                Ping_runProcess.EnableRaisingEvents = True
                Ping_runProcess.StartInfo = Ping_runStartInfo
                Ping_runProcess.Start()
                Dim output As String = ""
                Dim readerStdOut As IO.StreamReader = Ping_runProcess.StandardOutput
                Do While readerStdOut.EndOfStream = False
                    output = output + readerStdOut.ReadLine() + vbNewLine
                Loop
                output = output + "Program Created by Gamer_Z a.k.a. grasmanek94" + vbNewLine + "Contact: zetpawn@hotmail.com" + vbNewLine + "                               " + vbNewLine
                MyString = MyString + output
                Timer1.Enabled = True
                Ticking = 1
            End If
        End If
    End Sub
    Private Sub ResloveNetwork()
        Dim stack(0 To 2) As String
        Dim CountFound As Integer = 0

        Dim Ping_runProcess As New Process()
        Dim Ping_runStartInfo As New ProcessStartInfo()
        Ping_runStartInfo.FileName = "cmd.exe "
        Ping_runStartInfo.UseShellExecute = False
        Ping_runStartInfo.CreateNoWindow = True
        Ping_runStartInfo.Arguments = "/D /c net view"
        Ping_runStartInfo.RedirectStandardOutput = True
        Ping_runProcess.EnableRaisingEvents = True
        Ping_runProcess.StartInfo = Ping_runStartInfo
        Ping_runProcess.Start()
        Dim output As String = "Looking up the network..." + vbNewLine + "Found computers:          " + vbNewLine + "--------------------" + vbNewLine
        Dim readerStdOut As IO.StreamReader = Ping_runProcess.StandardOutput
        Dim Temp As String = ""
        Dim Currline As String = ""

        Do While readerStdOut.EndOfStream = False
            Currline = readerStdOut.ReadLine()
            If Currline.IndexOf("\\") = -1 Then

            Else
                stack(CountFound) = Replace(Currline, "\\", "")
                stack(CountFound) = Replace(stack(CountFound), vbTab, "")
                stack(CountFound) = Replace(stack(CountFound), " ", "")
                If stack(CountFound).IndexOf("Thecommandcompletedsuccessfully.") = -1 Then
                    Dim Total As Integer = CountFound + 1
                    ReDim Preserve stack(0 To Total)
                    output = output + stack(CountFound) + vbNewLine

                    CountFound = Total
                End If

            End If
        Loop

        If CountFound = 0 Then
            output = output + vbNewLine + "No computers found in your network..." + vbNewLine
        Else
            output = output + vbNewLine + "--------------------" + vbNewLine + "Resloving name to ip..." + vbNewLine + vbNewLine + "Computer Name" + vbTab + vbTab + vbTab + vbTab + vbTab + vbTab + "IP Address" + vbNewLine
            Do While CountFound > 0
                CountFound = CountFound - 1
                Ping_runStartInfo.FileName = "cmd.exe "
                Ping_runStartInfo.UseShellExecute = False
                Ping_runStartInfo.CreateNoWindow = True
                Ping_runStartInfo.Arguments = "/D /c ping -4 -w 1000 -n 1 " + stack(CountFound)
                Ping_runStartInfo.RedirectStandardOutput = True
                Ping_runProcess.EnableRaisingEvents = True
                Ping_runProcess.StartInfo = Ping_runStartInfo
                Ping_runProcess.Start()
                readerStdOut = Ping_runProcess.StandardOutput
                Do While readerStdOut.EndOfStream = False
                    Dim Temporary As String = readerStdOut.ReadLine()
                    Dim str_begin As Integer = Temporary.IndexOf("Ping statistics for ")
                    Dim str_end As Integer = Temporary.IndexOf(":")
                    Dim failed As Integer = Temporary.IndexOf("Ping request could not find host ")
                    If failed = Not -1 Then
                        output = output + stack(CountFound) + vbTab + vbTab + vbTab + vbTab + "Cannot find host ip" + vbNewLine
                    Else
                        If str_begin = -1 Then

                        Else
                            If str_end = -1 Then

                            Else
                                Dim IP As String = Mid$(Temporary, str_begin + 21, str_end - 1)
                                IP = Replace(IP, ":", "")
                                IP = Replace(IP, " ", "")
                                output = output + stack(CountFound) + vbTab + vbTab + vbTab + vbTab + IP + vbNewLine
                            End If
                        End If
                    End If
                Loop
            Loop
        End If

        MyString = MyString + "--------------------" + vbNewLine + output
        Timer1.Enabled = True
    End Sub
    Private Sub RichTextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) _
         Handles RichTextBox1.KeyUp
        Direction = -1

    End Sub
    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If Direction = 0 Then
            Me.Left = Me.Left - 1
        ElseIf Direction = 2 Then
            Me.Left = Me.Left + 1
        ElseIf Direction = 4 Then
            Me.Top = Me.Top - 1
        ElseIf Direction = 6 Then
            Me.Top = Me.Top + 1

        ElseIf Direction = 1 Then
            Me.Left = Me.Left - 3
        ElseIf Direction = 3 Then
            Me.Left = Me.Left + 3
        ElseIf Direction = 5 Then
            Me.Top = Me.Top - 3
        ElseIf Direction = 7 Then
            Me.Top = Me.Top + 3
        End If
    End Sub

    Private Sub RichTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RichTextBox1.TextChanged
        RichTextBox1.Focus()
        RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
        RichTextBox1.ScrollToCaret()

    End Sub
End Class
