#include "cinder/app/AppBasic.h"
#include "cinder/Rand.h"
#include "cinder/Vector.h"
#include "cinder/Perlin.h"
#include "cinder/Color.h"
#include "cinder/gl/gl.h"
#include "cinder/gl/Texture.h"
#include "cinder/Text.h"
#include "cinder/ImageIo.h"
#include "cinder/Font.h"
#include "cinder/gl/TextureFont.h"

#include <list>
#include <array>

using namespace ci;
using namespace ci::app;

#pragma warning(disable: 4996)

std::string string_format(const std::string fmt, ...) 
{
	int size = 512;
	std::string str;
	va_list ap;
	while (1) {
		str.resize(size);
		va_start(ap, fmt);
		int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
		va_end(ap);
		if (n > -1 && n < size) {
			str.resize(n);
			return str;
		}
		if (n > -1)
			size = n + 1;
		else
			size *= 2;
	}
	return str;
}

class BasicParticleApp : public AppBasic {
 public:	
	void	setup();
	void	mouseDown( MouseEvent event );
	void	keyDown( KeyEvent event );
	
	bool	isOffscreen( const Vec2f &v );
	void	prepareSettings( Settings *settings );
	void	update();
	void	draw();	
	
	//Perlin			mPerlin;
	gl::TextureFontRef	mTextureFont;

};

std::vector<Vec2i> Snake;
Vec2i Velocity(0,0);
cinder::Rand random;
Vec2i Point;
//							Y	X
Vec2i GRID(200,200);
bool paused = false;

void BasicParticleApp::prepareSettings( Settings *settings )
{
	settings->setWindowSize( 800, 600 );
	settings->setFrameRate( 200.0f );
	gl::disableVerticalSync();
	Snake.push_back(Vec2i(GRID.x/2,GRID.y/2));
	Point = Vec2i(10,10);
	settings->setTitle("Simple Snake by Rafal \"Gamer_Z\" Grasman");
}

void BasicParticleApp::setup()
{
	gl::enableAlphaBlending();
	mTextureFont = gl::TextureFont::create( Font( "Consolas", 24 ) );
}

void BasicParticleApp::mouseDown( MouseEvent event )
{

}

bool MayChange = true;
void BasicParticleApp::keyDown( KeyEvent event )
{
	switch(event.getChar())
	{
	case 'f':
	case 'F':
		setFullScreen( ! isFullScreen() );
		break;
	case 'v':
	case 'V':
		gl::enableVerticalSync( ! gl::isVerticalSyncEnabled() );
		break;
	case 'p':
	case 'P':
		paused = paused ? false : true;
		break;
	case 'l':
	case 'L':
		for(int i = 0; i < 100; ++i)
			Snake.insert(Snake.begin(),Snake[0]);
		break;
	case 'w':
	case 'W':
		if(Velocity.y == 0 && MayChange)
			Velocity = Vec2i(0,-1), MayChange = false;
		break;
	case 'a':
	case 'A':
		if(Velocity.x == 0 && MayChange)
			Velocity = Vec2i(-1,0), MayChange = false;
		break;
	case 's':
	case 'S':
		if(Velocity.y == 0 && MayChange)
			Velocity = Vec2i(0,1), MayChange = false;
		break;
	case 'd':
	case 'D':
		if(Velocity.x == 0 && MayChange)
			Velocity = Vec2i(1,0), MayChange = false;
		break;
	}
}

// Returns whether a given point is visible onscreen or not
bool BasicParticleApp::isOffscreen( const Vec2f &v )
{
	return ( ( v.x < 0 ) || ( v.x > getWindowWidth() ) || ( v.y < 0 ) || ( v.y > getWindowHeight() ) );
}

void BasicParticleApp::update()
{

}

Vec2i RandomCoord()
{
	return 
		Vec2i(
			random.randInt(0,GRID.x),
			random.randInt(0,GRID.y)
		);
}

ULONGLONG LastMove = GetTickCount64();
unsigned long Score = 0;
unsigned long HScore = 0;

void BasicParticleApp::draw()
{
	gl::clear( Color(0.0,0.0,0.0) );
	glColor3f( Color(1.0,0.0,0.0) );
	ULONGLONG Tick = GetTickCount64();
	if((float)(Tick-LastMove) > (50.0f-50.0f*((float)Snake.size()/500.0))*(GetAsyncKeyState(VK_SHIFT) ? 0.5f : 1.0f) )
	{
		LastMove = Tick;

		if(!paused)
		{
			Vec2i newpos = Snake[Snake.size()-1]+Velocity;
			MayChange = true;

			if(newpos.x > GRID.x-1	) newpos.x = 0;
			if(newpos.x < 0			) newpos.x = GRID.x-1;
			if(newpos.y > GRID.y-1	) newpos.y = 0;
			if(newpos.y < 0			) newpos.y = GRID.y-1;

			bool hitting = false;
			for(auto i: Snake)
			{
				if(i == newpos)
				{
					hitting = true;
				}
			}
			if(!hitting)
			{
				Snake.push_back(newpos);
				if(Snake.back() == Point)
				{
					Point = RandomCoord();
					++Score;
					if(Score > HScore)
						HScore = Score;
				}
				else
				{
					Snake.erase(Snake.begin());
				}
			}
			else
			{
				Snake.clear();
				Velocity.x = 0;
				Velocity.y = 0;
				Snake.push_back(Vec2i(GRID.x/2,GRID.y/2));
				Point = Vec2i(10,10);
				Score = 0;
			}
		}
	}

	float Scalar = std::min(((float)getWindowWidth()/(float)GRID.x),((float)getWindowHeight()/(float)GRID.y));
	for(auto i: Snake)
		gl::drawSolidRect( Rectf( i.x*Scalar, i.y*Scalar, (i.x+1)*Scalar, (i.y+1)*Scalar ) );	
	glColor4f( ColorA(0.0,1.0,0.0, 0.5) );
	gl::drawSolidRect( Rectf( Point.x*Scalar, Point.y*Scalar, (Point.x+1)*Scalar, (Point.y+1)*Scalar ) );
	glColor3f( Color(0.0,0.0,1.0) );
	gl::drawSolidRect( Rectf( GRID.x*Scalar, 0.0, 256000.0, 256000.0 ) );
	gl::drawSolidRect( Rectf( 0.0, GRID.y*Scalar, 256000.0, 256000.0 ) );
	glColor3f( Color(0.0,1.0,0.0) );
	mTextureFont->drawString(string_format("Score:         %d\nHighest Score: %d\nSnake Lenght:  %d",Score,HScore,Snake.size()),Rectf(GRID.x*Scalar,30.0f,GRID.x*Scalar+800.0f,630.0f));
}


CINDER_APP_BASIC( BasicParticleApp, RendererGl )