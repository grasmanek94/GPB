/* =====================================================================================*//*
	TextDraw Plugin for SA-MP
    Copyright (C) 2011, iPLEOMAX

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*//* =====================================================================================*/

#include "REQ_Includes.txt"

using namespace std;
using namespace sampgdk;

static logprintf_t logprintf;

void **ppPluginData;
extern void *pAMXFunctions;

AMX *tdsAmx;

static tdstreamer theGameMode;

tdstreamer::tdstreamer() { this->Register(); }

tdstreamer::~tdstreamer() {}

/* =======================================================================================*/
/* Definitions */

#define MAX_PLAYERS			(500)
#define MAX_TEXTDRAWS		(2048)
#define MAX_TEXTDRAW_STRING (256)

/* End of definitions */
/* =======================================================================================*/

/* =======================================================================================*/
/* Variables: */

	bool ValidTD [MAX_TEXTDRAWS];
	float PositionX [MAX_TEXTDRAWS];
	float PositionY [MAX_TEXTDRAWS];
	float LetterSizeX [MAX_TEXTDRAWS];
	float LetterSizeY [MAX_TEXTDRAWS];
	float TextSizeX [MAX_TEXTDRAWS];
	float TextSizeY [MAX_TEXTDRAWS];
	int Alignment [MAX_TEXTDRAWS];
	int Color [MAX_TEXTDRAWS];
	int UseBox [MAX_TEXTDRAWS];
	int BoxColor [MAX_TEXTDRAWS];
	int ShadowSize [MAX_TEXTDRAWS];
	int OutlineSize [MAX_TEXTDRAWS];
	int BackgroundColor [MAX_TEXTDRAWS];
	int Font [MAX_TEXTDRAWS];
	bool Proportional [MAX_TEXTDRAWS];
	bool ShownForAll [MAX_TEXTDRAWS];
	bool ShownForPlayer [MAX_TEXTDRAWS] [MAX_PLAYERS];
	string StringTD[MAX_TEXTDRAWS];

	bool EnableLogs = false;

/* End of Variables */
/* =======================================================================================*/

/* Plugin Functions */

bool TD_Update( int textid )
{
	if(ShownForAll[textid]) { TextDrawShowForAll( textid ); }
	else
	{
		for ( int iPID=0; iPID<MAX_PLAYERS; iPID++ )
		{
			if(ShownForPlayer[textid][iPID])
			{
				TextDrawShowForPlayer(iPID, textid);
			}
		}
	}
	return true;
}

/* End of plugin Functions */
/* =======================================================================================*/

/* =======================================================================================*/
/* Plugin Natives */

static cell AMX_NATIVE_CALL TD_EnableLogs( AMX* amx, cell* params ) 
{ EnableLogs = true; return true; }

static cell AMX_NATIVE_CALL TD_DisableLogs( AMX* amx, cell* params ) 
{ EnableLogs = false; return true;}

static cell AMX_NATIVE_CALL TD_GetLetterSize( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	if( ValidTD[textid] )
	{
		cell* SizeX; cell* SizeY;

		amx_GetAddr(amx, params[2], &SizeX);
		amx_GetAddr(amx, params[3], &SizeY);

		*SizeX = amx_ftoc(LetterSizeX[textid]);
		*SizeY = amx_ftoc(LetterSizeY[textid]);
		return true;
	}
	return false;
}
static cell AMX_NATIVE_CALL TD_LetterSize( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	float sizeX = amx_ctof( params[2] );
	float sizeY = amx_ctof( params[3] );

	if (ValidTD[textid])
	{
		TextDrawLetterSize(textid, sizeX, sizeY);
		LetterSizeX[textid] = sizeX;
		LetterSizeY[textid] = sizeY;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Lettersize, X: %f, Y: %f", textid, sizeX, sizeY); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set Lettersize - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetTextSize( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	if( ValidTD[textid] )
	{
		cell* SizeX; cell* SizeY;

		amx_GetAddr(amx, params[2], &SizeX);
		amx_GetAddr(amx, params[3], &SizeY);

		*SizeX = amx_ftoc(TextSizeX[textid]);
		*SizeY = amx_ftoc(TextSizeY[textid]);
		return true;
	}
	return false;
}
static cell AMX_NATIVE_CALL TD_TextSize( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	float sizeX = amx_ctof( params[2] );
	float sizeY = amx_ctof( params[3] );

	if (ValidTD[textid])
	{
		TextDrawTextSize(textid, sizeX, sizeY);
		TextSizeX[textid] = sizeX;
		TextSizeY[textid] = sizeY;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Textsize, X: %f, Y: %f", textid, sizeX, sizeY); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set Textsize - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetAlignment( AMX* amx, cell* params ) 
{ return Alignment[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_Alignment( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int altype = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawAlignment(textid, altype);
		Alignment[textid] = altype;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Alignment type(%i)", textid, altype); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set Alignment - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetColor( AMX* amx, cell* params ) 
{ return Color[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_Color( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int colour = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawColor(textid, colour);
		Color[textid] = colour;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Color(%i)", textid, colour); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set Color - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_IsBox( AMX* amx, cell* params ) 
{ return UseBox[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_UseBox( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int option = ( params[2] );

	bool bOption;
	if(option == 0) { bOption = false; }
	else if(option == 1) { bOption = true; }

	if (ValidTD[textid])
	{
		TextDrawUseBox(textid, bOption);
		UseBox[textid] = bOption;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Use box: (%i)", textid, option); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set Box - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetBoxColor( AMX* amx, cell* params ) 
{ return BoxColor[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_BoxColor( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int colour = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawBoxColor(textid, colour);
		BoxColor[textid] = colour;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Use box: (%i)", textid, colour); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set BoxColor - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetShadow( AMX* amx, cell* params ) 
{ return ShadowSize[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_SetShadow( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int shadow = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawSetShadow(textid, shadow);
		ShadowSize[textid] = shadow;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Shadow size(%i)", textid, shadow); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set shadow size - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetOutline( AMX* amx, cell* params ) 
{ return OutlineSize[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_SetOutline( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int outline = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawSetOutline(textid, outline);
		OutlineSize[textid] = outline;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Outline size(%i)", textid, outline); }

		return true;
	}

	if (EnableLogs)
	{ logprintf("Error: Unable to set outline size - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetBackgroundColor( AMX* amx, cell* params ) 
{ return BackgroundColor[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_BackgroundColor( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int colour = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawBackgroundColor(textid, colour);
		BackgroundColor[textid] = colour;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Background color: (%i)", textid, colour); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set background color - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_GetFont( AMX* amx, cell* params ) 
{ return Font[ (params[1]) ]; }

static cell AMX_NATIVE_CALL TD_Font( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int font = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawFont(textid, font);
		Font[textid] = font;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Font type: (%i)", textid, font); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set font type - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_IsProportional( AMX* amx, cell* params ) 
{ 
	if(Proportional[ (params[1]) ])
	{ return 1; }
	else
	{ return 0; }
}
static cell AMX_NATIVE_CALL TD_SetProportional( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int option = ( params[2] );

	bool bOption;
	if(option == 0) { bOption = false; }
	else if(option == 1) { bOption = true; }

	if (ValidTD[textid])
	{
		TextDrawSetProportional(textid, bOption);
		Proportional[textid] = bOption;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i): Use box: (%i)", textid, option); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set Box - Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_Shown( AMX* amx, cell* params )
{
	int playerid = ( params[1] );
	int textid = ( params[2] );
	if (ShownForPlayer[textid][playerid]) return true;
	return false;
}
static cell AMX_NATIVE_CALL TD_Show( AMX* amx, cell* params )
{
	int playerid = ( params[1] );
	int textid = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawShowForPlayer( playerid, textid );
		ShownForPlayer[textid][playerid] = true;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i) visible to playerid(%i)", textid, playerid); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to show TD ID(%i) to playerid(%i)", textid, playerid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_Hide( AMX* amx, cell* params )
{
	int playerid = ( params[1] );
	int textid = ( params[2] );

	if (ValidTD[textid])
	{
		TextDrawHideForPlayer( playerid, textid );
		ShownForPlayer[textid][playerid] = false;

		TD_Update(textid);

		if (EnableLogs) 
		{ logprintf("Info: TD ID(%i) hidden for playerid(%i)", textid, playerid); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to hide TD ID(%i) for playerid(%i)", textid, playerid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_ShownForAll( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	if (ShownForAll[textid]) return true;
	return false;
}
static cell AMX_NATIVE_CALL TD_ShowForAll( AMX* amx, cell* params )
{
	int textid = ( params[1] );

	if (ValidTD[textid])
	{
		TextDrawShowForAll( textid );
		ShownForAll[textid] = true;

		TD_Update(textid);

		if (EnableLogs)
		{ logprintf("Info: TD ID(%i) visible to all players", textid); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to show TD ID(%i) to all players. Invalid TD", textid); }

	return false;
}

static cell AMX_NATIVE_CALL TD_HideForAll( AMX* amx, cell* params )
{
	int textid = ( params[1] );

	if (ValidTD[textid])
	{
		TextDrawHideForAll( textid );
		ShownForAll[textid] = false;

		TD_Update(textid);

		if (EnableLogs)
		{ logprintf("Info: TD ID(%i) hidden for all players", textid); }

		return true;
	}

	if (EnableLogs)
	{ logprintf("Error: Unable to hide TD ID(%i) for all players. Invalid TD", textid); }

	return false;
}

static cell AMX_NATIVE_CALL pTD_GetString( AMX* amx, cell* params )
{
	int textid = ( params[1] );

	if(ValidTD[textid])
	{
		const char * ret_str = StringTD[textid].c_str();

		cell* tdstr;
		amx_GetAddr(amx, params[2], &tdstr);
		amx_SetString ( tdstr, ret_str, 0, 0, 512);
		return true;
	}
	return false;
}

static cell AMX_NATIVE_CALL pTD_SetString( AMX* amx, cell* params )
{
	int textid = ( params[1] );

	if (ValidTD[textid])
	{
		char *textstring;
		amx_StrParam(amx, params[2], textstring);
		TextDrawSetString(textid, textstring);

		StringTD[textid] = textstring;

		TD_Update(textid);

		if (EnableLogs)
		{ logprintf("Info: TD ID(%i) set string: \"%s\"", textid, StringTD[textid]); }

		return true;
	}

	if (EnableLogs) 
	{ logprintf("Error: Unable to set string. Invalid TD ID(%i)", textid); }

	return false;
}

static cell AMX_NATIVE_CALL pTD_Create( AMX* amx, cell* params )
{
	float PosX = amx_ctof( params[1] );
	float PosY = amx_ctof( params[2] );

	char *textstring;
	amx_StrParam(amx, params[3], textstring);
	int TDID = TextDrawCreate(PosX, PosY, textstring);

	StringTD[TDID] = textstring;

	PositionX[TDID] = PosX; PositionY[TDID] = PosY;

	TextDrawLetterSize(TDID, 0.5, 1.0);
	LetterSizeX[TDID] = 0.5; LetterSizeY[TDID] = 1.0;

	TextDrawTextSize(TDID, 1.0, 1.0);
	TextSizeX[TDID] = 1.0; TextSizeY[TDID] = 1.0;

	TextDrawAlignment(TDID, 0);
	Alignment[TDID] = 0;

	TextDrawColor(TDID, 0xFFFFFFFF);
	Color[TDID] = 0xFFFFFFFF;

	TextDrawUseBox(TDID, false);
	UseBox[TDID] = false;

	TextDrawBoxColor(TDID, 0xFFFFFFAA);
	BoxColor[TDID] = 0xFFFFFFAA;

	TextDrawSetShadow(TDID, 1);
	ShadowSize[TDID] = 1;

	TextDrawSetOutline(TDID, 0);
	OutlineSize[TDID] = 0;

	TextDrawBackgroundColor(TDID, 0x000000FF);
	BackgroundColor[TDID] = 0x000000FF;

	TextDrawFont(TDID, 1);
	Font[TDID] = 1;

	TextDrawSetProportional(TDID, true);
	Proportional[TDID] = true;

	ValidTD[TDID] = true;

	if (EnableLogs) 
	{ logprintf("Info: TD (%i) created, X: %f Y: %f, S: \"%s\"", TDID, PosX, PosY, StringTD[TDID]); }

	return TDID;
}

static cell AMX_NATIVE_CALL TD_CopyAttributes( AMX* amx, cell* params )
{
	int textid = ( params[1] );
	int TDID = ( params[2] );

	if(!ValidTD[textid] || !ValidTD[TDID]) return false;

	TextDrawLetterSize(TDID, LetterSizeX[textid], LetterSizeY[textid]);
	TextDrawTextSize(TDID, TextSizeX[textid], TextSizeY[textid]);
	TextDrawAlignment(TDID, Alignment[textid]);
	TextDrawColor(TDID, Color[textid]);
	if (UseBox[textid] == 0) { TextDrawUseBox(TDID, false); }
	else if (UseBox[textid] == 1) { TextDrawUseBox(TDID, true); }
	TextDrawBoxColor(TDID, BoxColor[textid]);
	TextDrawSetShadow(TDID, ShadowSize[textid]);
	TextDrawSetOutline(TDID, OutlineSize[textid]);
	TextDrawBackgroundColor(TDID, BackgroundColor[textid]);
	TextDrawFont(TDID, Font[textid]);
	TextDrawSetProportional(TDID, Proportional[textid]);

	ShownForAll[TDID] = ShownForAll[textid];
	for ( int iPID = 0; iPID < MAX_PLAYERS; iPID++ )
	{
		ShownForPlayer[TDID][iPID] = ShownForPlayer[textid][iPID];
	}

	TD_Update(TDID);

	return true;
}

static cell AMX_NATIVE_CALL TD_SetPos( AMX* amx, cell* params )
{
	int textid = ( params[1] );

	if (ValidTD[textid] == false) { return false; }

	float PosX = amx_ctof( params[2] );
	float PosY = amx_ctof( params[3] );

	const char * ret_str = StringTD[textid].c_str();

	TextDrawDestroy(textid);
	int TDID = TextDrawCreate(PosX, PosY, ret_str);

	PositionX[TDID] = PosX; PositionY[TDID] = PosY;
	TextDrawLetterSize(TDID, LetterSizeX[textid], LetterSizeY[textid]);
	TextDrawTextSize(TDID, TextSizeX[textid], TextSizeY[textid]);
	TextDrawAlignment(TDID, Alignment[textid]);
	TextDrawColor(TDID, Color[textid]);
	if (UseBox[textid] == 0) { TextDrawUseBox(TDID, false); }
	else if (UseBox[textid] == 1) { TextDrawUseBox(TDID, true); }
	TextDrawBoxColor(TDID, BoxColor[textid]);
	TextDrawSetShadow(TDID, ShadowSize[textid]);
	TextDrawSetOutline(TDID, OutlineSize[textid]);
	TextDrawBackgroundColor(TDID, BackgroundColor[textid]);
	TextDrawFont(TDID, Font[textid]);
	TextDrawSetProportional(TDID, Proportional[textid]);

	ShownForAll[TDID] = ShownForAll[textid];
	for ( int iPID = 0; iPID < MAX_PLAYERS; iPID++ )
	{
		ShownForPlayer[TDID][iPID] = ShownForPlayer[textid][iPID];
	}

	TD_Update(TDID);

	return true;
}

static cell AMX_NATIVE_CALL TD_GetPos( AMX* amx, cell* params )
{
	int textid = ( params[1] );

	cell* PosX; cell* PosY;

	amx_GetAddr(amx, params[2], &PosX);
	amx_GetAddr(amx, params[3], &PosY);

	*PosX = amx_ftoc(PositionX[textid]);
	*PosY = amx_ftoc(PositionY[textid]);

	return true;
}

static cell AMX_NATIVE_CALL TD_Destroy( AMX* amx, cell* params )
{
	int TDID = ( params[1] );
	if(!ValidTD[TDID]) 
	{
		if (EnableLogs) 
		{ logprintf("Warning: Unable to destroy - Invalid TD ID(%i)", TDID); }
		return false;
	}

	StringTD[TDID] = "\0";

	PositionX[TDID] = 0.0; PositionY[TDID] = 0.0;

	LetterSizeX[TDID] = 0.0; LetterSizeY[TDID] = 0.0;
	TextSizeX[TDID] = 0.0; TextSizeY[TDID] = 0.0;
	Alignment[TDID] = 0;
	Color[TDID] = 0;
	UseBox[TDID] = false;
	BoxColor[TDID] = 0;
	ShadowSize[TDID] = 0;
	OutlineSize[TDID] = 0;
	BackgroundColor[TDID] = 0;
	Font[TDID] = 0;
	Proportional[TDID] = false;
	ShownForAll[TDID] = false;

	for ( int iPID = 0; iPID < MAX_PLAYERS; iPID++ )
	{
		ShownForPlayer[TDID][iPID] = false;
	}

	TextDrawDestroy(TDID);
	ValidTD[TDID] = false;

	if (EnableLogs) 
	{ logprintf("Info: TD ID(%i) Destroyed.", TDID); }

	return true;
}

static cell AMX_NATIVE_CALL TD_Valid( AMX* amx, cell* params ) { return ValidTD[ (params[1]) ]; }

/* End of plugin natives */
/* =======================================================================================*/

PLUGIN_EXPORT void PLUGIN_CALL ProcessTick() {}

AMX_NATIVE_INFO tdsNatives[] =
{
	{"TD_EnableLogs",			TD_EnableLogs}, //logs = true
	{"TD_DisableLogs",			TD_DisableLogs}, //logs = false

	{"pTD_Create",				pTD_Create}, //Params: fX, fY, sText
	{"TD_Destroy",				TD_Destroy}, //Params: textid

	{"TD_LetterSize",			TD_LetterSize}, //Params: textid, fSize
	{"TD_GetLetterSize",		TD_GetLetterSize}, //Params: textid, &fSize

	{"TD_TextSize",				TD_TextSize}, //Params: textid, fSize
	{"TD_GetTextSize",			TD_GetTextSize}, //Params: textid, &fSize

	{"TD_Alignment",			TD_Alignment}, //Params: textid, altype
	{"TD_GetAlignment",			TD_GetAlignment}, //Params: textid, return: altype

	{"TD_Color",				TD_Color}, //Params: textid, color
	{"TD_GetColor",				TD_GetColor}, //Params: textid, Return: color

	{"TD_UseBox",				TD_UseBox}, //Params: textid, Option
	{"TD_IsBox",				TD_UseBox}, //Params: textid, return: true/false

	{"TD_BoxColor",				TD_BoxColor}, //Params: textid, color
	{"TD_GetBoxColor",			TD_GetBoxColor}, //Params: textid, &color

	{"TD_SetShadow",			TD_SetShadow}, //Params: textid, Size
	{"TD_GetShadow",			TD_GetShadow}, //Params: textid, Return: Size

	{"TD_SetOutline",			TD_SetOutline}, //Params: textid, Size
	{"TD_SetOutline",			TD_GetOutline}, //Params: textid, Return: Size

	{"TD_BackgroundColor",		TD_BackgroundColor}, //Params: textid, color
	{"TD_GetBackgroundColor",	TD_GetBackgroundColor}, //Params: textid, color

	{"TD_Font",					TD_Font}, //Params: textid, fonttype
	{"TD_GetFont",				TD_GetFont}, //Params: textid, fonttype

	{"TD_SetProportional",		TD_SetProportional}, //Params: textid, Option
	{"TD_IsProportional",		TD_IsProportional}, //Params: textid, Option

	{"TD_Show",					TD_Show}, //Params: textid, playerid
	{"TD_Hide",					TD_Hide}, //Params: textid, playerid

	{"TD_ShowForAll",			TD_ShowForAll}, //Params: textid
	{"TD_HideForAll",			TD_HideForAll}, //Params: textid

	{"pTD_SetString",			pTD_SetString}, //Params: textid, sString
	{"pTD_GetString",			pTD_GetString}, //Params: textid, return: string

	{"TD_Shown",				TD_Shown}, //Params: playerid, textid
	{"TD_ShownForAll",			TD_ShownForAll}, //Params: textid

	{"TD_SetPos",				TD_SetPos}, //Params: textid, fX, fY, sNewstring
	{"TD_GetPos",				TD_GetPos}, //Params: textid, &fX, &fY

	{"TD_Valid",				TD_Valid}, //Params: textid return: true/false
	{"TD_CopyAttributes",		TD_CopyAttributes}, //Params: textid, targettextid, return: true/false

	{0, 0}
};

PLUGIN_EXPORT bool PLUGIN_CALL Load(void **ppData)
{
	Wrapper::GetInstance()->Initialize(ppData);
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	logprintf = (logprintf_t)ppData[PLUGIN_DATA_LOGPRINTF];
	logprintf("\n  * Textdraw plugin V0.1a Beta. (c) iPLEOMAX, 2011");
	return 1;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload()
{
	logprintf("\n  * Textdraw plugin unloaded.");
}

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad(AMX *amx)
{
	tdsAmx = amx;
	return amx_Register(amx, tdsNatives, -1);
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload(AMX *amx)
{
	return AMX_ERR_NONE;
}

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES | SUPPORTS_PROCESS_TICK;
}

/* End of Script */
/* =======================================================================================*/