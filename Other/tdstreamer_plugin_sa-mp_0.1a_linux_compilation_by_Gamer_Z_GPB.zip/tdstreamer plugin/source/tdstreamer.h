#ifndef tdstreamer_H
#define tdstreamer_H

#include "sampgdk/eventhandler.h"

class tdstreamer: 
public sampgdk::EventHandler 
{
		public:
		tdstreamer();
		virtual ~tdstreamer();
};

#endif