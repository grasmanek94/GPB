﻿Option Explicit On
Option Compare Text

Public Class Form1
    Dim DQ As New Queue
    Dim AQ As New Queue
    Dim TQ As New Queue

    Public Declare Function SendMessage Lib "user32.dll" Alias "SendMessageA" (ByVal hWnd As IntPtr, ByVal msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Public Const EM_GETLINECOUNT = &HBA
    Public Const EM_LINESCROLL = &HB6
    Dim forpassword As Boolean = False
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        forpassword = False
        RichTextBox1.ScrollBars() = RichTextBoxScrollBars.None
        RichTextBox1.TabStop = True
        RichTextBox1.Text = ""
        ''''''
        txt("Initializing interface...", 50)
        Download(2000)
        Endl()
        txt("Which IP Should I connect to?")
        Endl()
        WaitForEnter()
        Endl()
        txt("On Which port?")
        Endl()
        WaitForEnter()
        Endl()
        txt("Connecting... ")
        WaitCursor(4500)
        txt("Connection Ready, please input authorisation password:")
        Endl()
        WaitForPassword()
        Endl()
        txt("Welcome, guest")
        Endl()
        txt(">")
        WaitForEnter()
        Endl()
        txt("Downloading users.list...")
        Endl()
        Download(100)
        Endl()
        txt("Opening users.list in text editor... ")
        WaitCursor(1000)
        Endl()
        txt("-----------------------------users.list-----------------------------")
        Endl()
        txt("USER                                PASSWORD")
        Endl()
        Endl()
        txt("guest                               0baea2f0ae20150db78f58cddac442a9") 'superuser
        Endl()
        txt("root                                3495831d0367bceb79807c31c221fd50") 'TryToCatchMe!@#$%%%555
        Endl()
        txt("--------------------------------------------------------------------")
        Endl()
        txt(">")
        WaitForEnter()
        Endl()
        txt("Running... OPHCRACK /f users.list /u root")
        Endl()
        txt("Loading hash tables into memory: (preparing) ")
        WaitCursor(5500)
        Endl()
        txt("Loading: ")
        Download(17500)
        Endl()
        txt("Cracking password for user 'root':")
        Endl()
        Endl()
        CrackPassword("TryToCatchMe!@#$%%%555", 1250)
        Endl()
        Endl()

        ''''''
        Timer1.Interval = 1
        Timer1.Enabled = True
    End Sub
    Private Sub txt(ByVal text As String, Optional ByVal timing As Integer = 20)
        For i As Integer = 0 To text.Length - 1
            DQ.Enqueue(Asc(text(i)))
            AQ.Enqueue(0)
            TQ.Enqueue(timing)
        Next
    End Sub
    Private Sub WaitForPassword()
        DQ.Enqueue(0)
        AQ.Enqueue(3)
        TQ.Enqueue(1)
    End Sub
    Private Sub WaitForEnter()
        DQ.Enqueue(0)
        AQ.Enqueue(2)
        TQ.Enqueue(1)
    End Sub
    Private Sub Endl()
        DQ.Enqueue(12)
        AQ.Enqueue(0)
        TQ.Enqueue(1)
    End Sub
    Sub Wait(ByVal time As Integer)
        DQ.Enqueue(time)
        AQ.Enqueue(1)
        TQ.Enqueue(1)
    End Sub
    Sub WaitCursor(ByVal Steps As Integer)
        DQ.Enqueue(Steps)
        AQ.Enqueue(5)
        TQ.Enqueue(1)
    End Sub
    Sub CrackPassword(ByVal Password As String, Optional ByVal Time As Integer = 1000)
        DQ.Enqueue(Password)
        AQ.Enqueue(6)
        TQ.Enqueue(Time)
    End Sub
    Sub Download(ByVal time As Integer, Optional ByVal steps As Integer = 100)
        DQ.Enqueue(time)
        AQ.Enqueue(4)
        TQ.Enqueue(steps)
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If AQ.Count > 0 Then
            If (AQ.Peek() = 1) Then
                AQ.Dequeue()
                TQ.Dequeue()
                System.Threading.Thread.Sleep(DQ.Dequeue())
            ElseIf (AQ.Peek() = 2) Then
                AQ.Dequeue()
                TQ.Dequeue()
                DQ.Dequeue()
                Timer1.Enabled = False
                RichTextBox1.ReadOnly = False
                RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
            ElseIf (AQ.Peek() = 3) Then
                forpassword = True
                AQ.Dequeue()
                TQ.Dequeue()
                DQ.Dequeue()
                Timer1.Enabled = False
                RichTextBox1.ReadOnly = False
                RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
            ElseIf (AQ.Peek() = 4) Then
                AQ.Dequeue()
                Dim steps As Integer = TQ.Dequeue()
                RichTextBox1.Text += "|                                                                                                    |   0%" '107
                Dim Txt() As Char = "|                                                                                                    |   0%".ToCharArray()
                Dim EachWait As Integer = Integer.Parse(Math.Round((DQ.Dequeue() / 100) + 0.5, 0, MidpointRounding.ToEven))
                For i As Integer = 0 To steps
                    RichTextBox1.Text = RichTextBox1.Text.Remove(RichTextBox1.TextLength - 107, 107)
                    If i = 100 Then
                        RichTextBox1.AppendText("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||| 100%") '107
                    ElseIf i > 10 Then
                        Txt(i) = "|"
                        Txt(104) = (i).ToString()(0)
                        Txt(105) = (i).ToString()(1)
                        RichTextBox1.AppendText(New String(Txt)) '107
                    Else
                        Txt(i) = "|"
                        Txt(105) = (i).ToString()
                        RichTextBox1.AppendText(New String(Txt)) '107
                    End If
                    Me.Refresh()
                    RichTextBox1.Refresh()
                    System.Threading.Thread.Sleep(EachWait)
                Next
            ElseIf (AQ.Peek() = 5) Then
                AQ.Dequeue()
                TQ.Dequeue()
                Dim Txt() As Char = "|/-\".ToCharArray()
                Dim steps As Integer = Integer.Parse(Math.Round((DQ.Dequeue() / 75) + 0.5))
                For i As Integer = 0 To steps
                    Dim remainer As Integer
                    Math.DivRem(i, 4, remainer)
                    RichTextBox1.AppendText(Txt(remainer))
                    Me.Refresh()
                    RichTextBox1.Refresh()
                    System.Threading.Thread.Sleep(75)
                    RichTextBox1.Text = RichTextBox1.Text.Remove(RichTextBox1.TextLength - 1, 1)
                Next
            ElseIf (AQ.Peek() = 6) Then
                AQ.Dequeue()
                Dim Time As Integer = TQ.Dequeue()
                Dim Password As String = DQ.Dequeue()
                Dim len As Integer = Password.Length
                Dim CurrPW(len) As Char
                Dim Enabled(len) As Boolean
                For i As Integer = 0 To len - 1
                    CurrPW(i) = "-"
                    Enabled(i) = False
                Next
                Dim RandomClass As New Random()
                'Dim Charkey As Char = Chr((33 + ((RandomClass.Next()-1) Mod 93)))
                Dim Adone As Integer = 0
                Dim Counter As Integer = 0
                While Adone < len
                    Dim CurrToDo As Integer = (RandomClass.Next() - 1) Mod len
                    If Enabled(CurrToDo) = False Then
                        If Counter > (Adone + 1) * Time Then
                            Enabled(CurrToDo) = True
                            Adone += 1
                        End If
                    End If
                    For i As Integer = 0 To len - 1
                        If Enabled(i) = True Then
                            CurrPW(i) = Password(i)
                        Else
                            CurrPW(i) = Chr((33 + ((RandomClass.Next() - 1) Mod 93)))
                        End If
                    Next
                    RichTextBox1.AppendText(New String(CurrPW))
                    Me.Refresh()
                    RichTextBox1.Refresh()
                    Counter += 50
                    System.Threading.Thread.Sleep(50)
                    If Adone < len Then
                        RichTextBox1.Text = RichTextBox1.Text.Remove(RichTextBox1.TextLength - len, len)
                    End If
                End While
            Else
                    Dim intLines As Integer = SendMessage(RichTextBox1.Handle, EM_GETLINECOUNT, 0, 0)
                    RichTextBox1.AppendText(Chr(DQ.Dequeue()))
                    AQ.Dequeue()
                    Timer1.Interval = TQ.Dequeue()
                    Dim intLinesToAdd As Integer = (SendMessage(RichTextBox1.Handle, EM_GETLINECOUNT, 0, 0) - intLines)
                    SendMessage(RichTextBox1.Handle, EM_LINESCROLL, 0, intLinesToAdd)
            End If
        End If
    End Sub
    Private Sub RichTextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) _
         Handles RichTextBox1.KeyDown
        If e.KeyCode = Keys.Escape Then
            Application.Exit()
        ElseIf e.KeyCode = Keys.Enter Then
            If Timer1.Enabled = False Then
                RichTextBox1.ReadOnly = True
                forpassword = False
                Timer1.Enabled = True
            End If
        End If
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As System.Object, e As System.EventArgs) Handles RichTextBox1.TextChanged
        If forpassword = True Then
            RichTextBox1.Text = RichTextBox1.Text.Remove(RichTextBox1.TextLength() - 1)
            RichTextBox1.AppendText("*")
            RichTextBox1.SelectionStart = RichTextBox1.Text.Length()
        End If
    End Sub
End Class