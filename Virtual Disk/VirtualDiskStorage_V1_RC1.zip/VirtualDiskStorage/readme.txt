[CENTER][SIZE="7"]V[/SIZE][B][SIZE="5"]irtual [/SIZE][/B][SIZE="7"]F[/SIZE][B][SIZE="5"]ile [/SIZE][/B][SIZE="7"]S[/SIZE][B][SIZE="5"]ystem [/SIZE][/B]for [U]SA-MP[/U][/CENTER] 

[CENTER][U][I][B]Released by Xentiarox[/B][/I][/U] [xentiarox at gmail dot com] [U][I][B]with permission from Gamer_Z[/B][/I][/U] [rafal94 at live dot nl][/CENTER] (I talked with him on MSN about this, he agreed)

[U][SIZE="5"][I][COLOR="Blue"]Description[/COLOR][/I][/SIZE][/U]

[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]The [URL="http://en.wikipedia.org/wiki/Virtual_file_system#Single-file_virtual_file_systems"] Virtual File System[/URL] plugin is a SA-MP extension which provides functionality for storing data in a virtual disk.
Not only does it provide this functionality, it can also catch [B][I]all[/I][/B] sa-mp file traffic (created by scripts, not other plugins) and redirect it to the Virtual Disk.  This means that the plugin is able to hook all the file functions and with this you don't have to change your scripts, just load the plugin and all your data using file functions will be stored in the VFS!


[U][SIZE="5"][I][COLOR="Blue"]What are the benefits of using this plugin?[/COLOR][/I][/SIZE][/U]
[LIST=1]
[*]Fixes some SA-MP file bugs
[*]By keeping all files in one big file the FTP transfers will be very fast (compared to transfering many files)
[*]You can save alot of disk space by putting many files into one big file, this will avoid that small files take up too much space (eg 50 byte files taking up 1KB)
[*]no fopen/fclose I/O overhead
[*]compatible with all scripts
[*]you can choose to NOT hook the sa-mp functions and use the include for this plugin (so you can still write/read to/from scriptfiles folder)
[/LIST]

[U][SIZE="5"][I][COLOR="Blue"]How to use this plugin?[/COLOR][/I][/SIZE][/U]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]Go to [url=http://gpb.googlecode.com]GPB Googlecode Site[/url] then click on the Downloads tab and choose to download the Virtual File System Plugin.

[B][I][SIZE="4"]For Windows servers:[/SIZE][/I][/B]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]Place the plugin in the plugins directory, add the plugin to the plugins line in the server.cfg and make sure [URL="http://www.microsoft.com/en-us/download/details.aspx?id=5555"]Microsoft Visual C++ 2010 Redistributable [/URL]is installed. Voila! you don't even need to recompile your scripts. All file traffic will go to the virtual disk.

[B][I][SIZE="4"]For Linux Servers:[/SIZE][/I][/B]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]Place the plugin in the plugins directory, add the plugin to the plugins line in the server.cfg and make sure the [URL="http://www.eldos.com/solfs/download-release.php"]SolFS library [SolFS (Application edition) for Linux][/URL] is installed. Voila! you don't even need to recompile your scripts. All file traffic will go to the virtual disk.
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img][img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]NOTE: The linux version is not tested and is in beta stage! Any feedback to Gamer_Z is appreciated. In the future it may be possible that you don't need to install the library for the plugin to work.

[B][I][SIZE="4"]For Scripters:[/SIZE][/I][/B]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]If you do not want to use the Plugin File Function Hook, you can disable it by creating a file named "SCRIPTFILES-VFS-HOOK-DISABLED" in the root directory of your sa-mp server (no extensions, case sensetive on linux). If you cannot create the file then you can extract the file from the /extra/ subdirectory in the plugin package.
If this is the case, place the "vfile.inc" from the package into your pawn include directory. Then in your script include the library:
[pawn]
#include <vfile>
[/pawn]

After this you will be able to use the following functions, they work in the same way as the default SA-MP functions do (except they use a virtual storage):
[pawn]
native File:vopen(const name[], filemode: mode = io_readwrite);
native bool:vclose(File: handle);
native File:vtemp();
native bool:vremove(const name[]);

native vwrite(File: handle, const string[]);
native vread(File: handle, string[], size = sizeof string, bool: pack = false);
native bool:vputchar(File: handle, value, bool: utf8 = true);
native vgetchar(File: handle, value, bool: utf8 = true);//returns the character too!
native vblockwrite(File: handle, const buffer[], size = sizeof buffer);
native vblockread(File: handle, buffer[], size = sizeof buffer);

native vseek(File: handle, position = 0, seek_whence: whence = seek_start);
native vlength(File: handle);
native vexist(const pattern[]);
[/pawn]
[B][SIZE="1"]SIDE NOTE FOR PEOPLE WHO CAN'T READ: ONLY, AND ONLY use the include file if you disable the hooking system.[/SIZE][/B]

[U][SIZE="5"][I][COLOR="Blue"]I want to compile my own version of the plugin but I am getting SolFS errors when I load it, what is the problem?[/COLOR][/I][/SIZE][/U]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]You need to aquire your own [URL="http://www.eldos.com/solfs/order.php"]SolFS Developer License key[/URL] to create and redistribute your own copies of software which use SolFS. You are not allowed to make you License key publicicly available.

[U][SIZE="5"][I][COLOR="Blue"]Notes[/COLOR][/I][/SIZE][/U]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]The linux version is at beta stage and is untested. Any feedback to Gamer_Z himself will be appreciated.

[U][SIZE="5"][I][COLOR="Blue"]Can I Get any support?[/COLOR][/I][/SIZE][/U]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]I can only give you basic support, if you have more advanced question you should contact the author of the plugin (Gamer_Z) via email or msn: [rafal94 (at) live (dot) nl]

[U][SIZE="5"][I][COLOR="Blue"]What if my virtual disk gets corrupted due to a crash?[/COLOR][/I][/SIZE][/U]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]You can try repairing it with SolFS Explorer (included in the download package).

[U][SIZE="5"][I][COLOR="Blue"]Can I edit the virtual disk without the plugin?[/COLOR][/I][/SIZE][/U]
[img]http://img42.imageshack.us/img42/4286/tabfi.png[/img]There is a command line tool included in the package to manage your virtual disk.
