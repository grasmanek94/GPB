/*
* Default Includes
*/
#if defined LINUX
#include <stdio.h>
#include <stdlib.h> 
#include <iostream>
#include <assert.h>
#include <sstream>
#include <wchar.h>
#define wsprintf swprintf
#else
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <assert.h>
#include <sstream>
#include  <io.h>
#endif

/*
* AMX Includes
*/
#include "./SDK/amx/amx.h"
#include "./SDK/plugincommon.h"
#include "StoreDecl.h"

extern void * pAMXFunctions;

using namespace std;  

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES;
}

Error result;
Handle storage;
bool HOOK_IO_TRAFFIC = true;

PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	cout << "    SS (c) 2012 by Gamer_Z | Loading SolFS...\n";

	//Solid Filesystem Storage KEY | aquire your own key for custom builds
	result = StorageSetRegistrationKey((PSolFSChar)"Get Your Own License Key at eldos.com");
	//
	if (result != 0)
	{
		printf("SolFS Registration key error: %d\n", result);
		return false;
	}
	else
	{
		printf("SolFS Registration key is OK\n");
	}

	if( (access( "SCRIPTFILES-VFS-HOOK-DISABLED", 0 ) != -1) ) 
	{ 
		HOOK_IO_TRAFFIC = false;
	}
#if defined LINUX 
	SolFSWideChar storname[19] = {'S','C','R','I','P','T','F','I','L','E','S','-','V','F','S','.','S','T',0};
#endif
	if( !(access( "SCRIPTFILES-VFS.ST", 0 ) != -1) ) 
	{ 
#if defined LINUX
		result = StorageCreate(storname, False, 512, NULL, &storage, '/', False, False);
#else
		result = StorageCreate(L"SCRIPTFILES-VFS.ST", False, 512, NULL, &storage, '/', False, False);
#endif
		if (result != 0)
		{
			printf("SolFS StorageCreate error: %d\n", result);
			return false;
		}
		else
		{
			StorageClose(storage);
			printf("SolFS StorageCreate is OK\n");
#if defined LINUX
			result = StorageOpen(storname,&storage,'/',False,False);
#else
			result = StorageOpen(L"SCRIPTFILES-VFS.ST",&storage,'/',False,False);
#endif
			if(result != 0)
			{
				printf("SolFS StorageOpen error: %d\n", result);
				return false;
			}
			printf("SolFS StorageOpen is OK\n");
		}
	}
	else
	{
#if defined LINUX
		result = StorageOpen(storname,&storage,'/',False,False);
#else
		result = StorageOpen(L"SCRIPTFILES-VFS.ST",&storage,'/',False,False);
#endif
		if(result != 0)
		{
			printf("SolFS StorageOpen error: %d\n", result);
			return false;
		}
		printf("SolFS StorageOpen is OK\n");
	}
#if defined LINUX
	SolFSWideChar tempdir[6] = {'/','t','e','m','p',0};
	StorageCreateDirectory(storage, tempdir);
#else	
	StorageCreateDirectory(storage, L"/temp");
#endif
	cout << "Loaded!\n";
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	result = StorageClose(storage);
	if (result != 0)
		printf("SolFS error: %d\n", result);
	cout << "    SS (c) 2012 by Gamer_Z";
}

enum filemode {
  io_read,      /*  */
  io_write,     /* creates a new file */
  io_readwrite, /*  */
  io_append,    /* opened for writing only and seek to the end */
};

enum seek_whence {
  seek_start,
  seek_current,
  seek_end,
};

char * g_sz_tmp;
SolFSWideChar g_sz_wtmp[257];
SolFSLongWord g_amount_read = NULL;
static cell AMX_NATIVE_CALL n_FileOpen( AMX* amx, cell* params )
{
	Handle File = NULL;
	amx_StrParam(amx,params[1],g_sz_tmp);
	wstringstream xxx;
	xxx << g_sz_tmp;
#if defined LINUX
	wsprintf((wchar_t*)g_sz_wtmp,257,L"%ls",xxx.str().c_str());
#else
	wsprintf(g_sz_wtmp,xxx.str().c_str());
#endif
	switch (params[2] & 0x7fff) 
	{
		case io_read:
			result = StorageCreateFile(storage,g_sz_wtmp,True,False,True,True,NULL,NULL,NULL,&File,True,False);
			break;
		case io_write:
			result = StorageCreateFile(storage,g_sz_wtmp,False,True,True,True,NULL,NULL,NULL,&File,True,True);
			break;
		case io_readwrite:
			result = StorageCreateFile(storage,g_sz_wtmp,True,True,True,True,NULL,NULL,NULL,&File,True,False);
			break;
		case io_append:
			result = StorageCreateFile(storage,g_sz_wtmp,False,True,True,True,NULL,NULL,NULL,&File,True,False);
			StorageSeekFile(File,0,soFromEnd,&g_amount_read);
			break;
	} /* switch */
	if(result == 0)
	{
		return (cell)File;
	}
	return 0;
}

static cell AMX_NATIVE_CALL n_FileExists( AMX* amx, cell* params )
{
	amx_StrParam(amx,params[1],g_sz_tmp);
	wstringstream xxx;
	xxx << g_sz_tmp;
#if defined LINUX
	wsprintf((wchar_t*)g_sz_wtmp,257,L"%ls",xxx.str().c_str());
#else
	wsprintf(g_sz_wtmp,xxx.str().c_str());
#endif
	SolFSBool exist = false;
	StorageFileExists(storage,g_sz_wtmp,&exist);
	return exist;
}

static cell AMX_NATIVE_CALL n_FileClose( AMX* amx, cell* params )
{
	return StorageCloseFile((SolFSHandle)params[1]);
}

static cell AMX_NATIVE_CALL n_FileDelete( AMX* amx, cell* params )
{
	amx_StrParam(amx,params[1],g_sz_tmp);
	wstringstream xxx;
	xxx << g_sz_tmp;
#if defined LINUX
	wsprintf((wchar_t*)g_sz_wtmp,257,L"%ls",xxx.str().c_str());
#else
	wsprintf(g_sz_wtmp,xxx.str().c_str());
#endif
	result = StorageDeleteFile(storage,g_sz_wtmp);
	if(result == 0)return 1;
	return 0;
}

static cell AMX_NATIVE_CALL n_FileSeek( AMX* amx, cell* params )
{
  switch (params[3] & 0x7fff) {
  case seek_start:
		return StorageSeekFile((SolFSHandle)params[1],params[2],soFromBegin,&g_amount_read);
    break;
  case seek_current:
		return StorageSeekFile((SolFSHandle)params[1],params[2],soFromCurrent,&g_amount_read);
    break;
  case seek_end:
		return StorageSeekFile((SolFSHandle)params[1],params[2],soFromEnd,&g_amount_read);
    break;
  default:
    return 0;
  }
  return 1;
}

static cell AMX_NATIVE_CALL n_FileSize( AMX* amx, cell* params )
{
	StorageGetFileSize((SolFSHandle)params[1],&g_amount_read);
	return g_amount_read;
}

static cell AMX_NATIVE_CALL n_FileTemp( AMX* amx, cell* params )
{
	Handle File = NULL;
#if defined LINUX
	SolFSWideChar Name[257];
	wsprintf((wchar_t*)Name,257,L"temp/%s",tmpnam (NULL));
#else
	SolFSWideChar * Name = _wtmpnam (NULL);
	wsprintf(Name,L"temp/%s",Name);
#endif
	
	StorageCreateFile(storage,Name,True,True,True,True,NULL,NULL,NULL,&File,True,True);
	SolFSLongWord Attributes = NULL;
	StorageGetFileAttributes(storage,Name,&Attributes);
	Attributes |= 0x400;//temporary
	Attributes |= 0x800;//delete on close
	StorageSetFileAttributes(storage,Name,Attributes);
	return (cell)File;
}

static size_t fgets_cell(SolFSHandle fp,cell *string,size_t max,int utf8mode)
{
	size_t index;
	SolFSLongWord pos;
	cell c = 0;
	int follow,lastcr;
	cell lowmark;

	assert(sizeof(cell)>=4);
	assert(fp!=NULL);
	assert(string!=NULL);
	if (max<=0)
		return 0;

	/* get the position, in case we have to back up */
	StorageSeekFile(fp,0,soFromCurrent,&pos);

	index=0;
	follow=0;
	lowmark=0;
	lastcr=0;
	for ( ;; ) {
		assert(index<max);
		if (index==max-1)
			break;                    /* string fully filled */
		StorageReadFile(fp,&c,sizeof(char),&g_amount_read);
		if (/*c==EOF*/g_amount_read == 0) {
			if (!utf8mode || follow==0)
				break;                  /* no more characters */
			/* If an EOF happened halfway an UTF-8 code, the string cannot be
			* UTF-8 mode, and we must restart.
			*/
			index=0;
			StorageSeekFile(fp,pos,soFromBegin,&g_amount_read);
			continue;
		} /* if */

		/* 8-bit characters are unsigned */
		if (c<0)
			c=-c;

		if (utf8mode) {
			if (follow>0 && (c & 0xc0)==0x80) {
				/* leader code is active, combine with earlier code */
				string[index]=(string[index] << 6) | ((unsigned char)c & 0x3f);
				if (--follow==0) {
					/* encoding a character in more bytes than is strictly needed,
					* is not really valid UTF-8; we are strict here to increase
					* the chance of heuristic dectection of non-UTF-8 text
					* (JAVA writes zero bytes as a 2-byte code UTF-8, which is invalid)
					*/
					if (string[index]<lowmark)
						utf8mode=0;
					/* the code positions 0xd800--0xdfff and 0xfffe & 0xffff do not
					* exist in UCS-4 (and hence, they do not exist in Unicode)
					*/
					if (string[index]>=0xd800 && string[index]<=0xdfff
						|| string[index]==0xfffe || string[index]==0xffff)
						utf8mode=0;
					index++;
				} /* if */
			} else if (follow==0 && (c & 0x80)==0x80) {
				/* UTF-8 leader code */
				if ((c & 0xe0)==0xc0) {
					/* 110xxxxx 10xxxxxx */
					follow=1;
					lowmark=0x80;
					string[index]=c & 0x1f;
				} else if ((c & 0xf0)==0xe0) {
					/* 1110xxxx 10xxxxxx 10xxxxxx (16 bits, BMP plane) */
					follow=2;
					lowmark=0x800;
					string[index]=c & 0x0f;
				} else if ((c & 0xf8)==0xf0) {
					/* 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx */
					follow=3;
					lowmark=0x10000;
					string[index]=c & 0x07;
				} else if ((c & 0xfc)==0xf8) {
					/* 111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx */
					follow=4;
					lowmark=0x200000;
					string[index]=c & 0x03;
				} else if ((c & 0xfe)==0xfc) {
					/* 1111110x 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx (31 bits) */
					follow=5;
					lowmark=0x4000000;
					string[index]=c & 0x01;
				} else {
					/* this is invalid UTF-8 */
					utf8mode=0;
				} /* if */
			} else if (follow==0 && (c & 0x80)==0x00) {
				/* 0xxxxxxx (US-ASCII) */
				string[index++]=c;
				if (c=='\n')
					break;        /* read newline, done */
			} else {
				/* this is invalid UTF-8 */
				utf8mode=0;
			} /* if */
			if (!utf8mode) {
				/* UTF-8 mode was switched just off, which means that non-conforming
				* UTF-8 codes were found, which means in turn that the string is
				* probably not intended as UTF-8; start over again
				*/
				index=0;
				//readchrs=0;
				StorageSeekFile(fp,pos,soFromBegin,&g_amount_read);
			} /* if */
		} else {
			string[index++]=c;
			if (c=='\n') {
				break;                  /* read newline, done */
			} else if (lastcr) {
				StorageSeekFile(fp,-1,soFromCurrent,&g_amount_read); /* carriage return was read, no newline follows */        
				break;
			} /* if */
			lastcr=(c=='\r');
		} /* if */
	} /* for */
	assert(index<max);
	string[index]=0;
	return index;
}

static size_t fgets_char(SolFSHandle fp, char *string, size_t max)
{
	size_t index;
	int c = 0,lastcr;

	index=0;
	lastcr=0;
	for ( ;; ) {
		assert(index<max);
		if (index==max-1)
			break;                    /* string fully filled */
		StorageReadFile(fp,&c,sizeof(char),&g_amount_read);
		if (/*c==EOF*/g_amount_read==0)
			break;                    /* no more characters */
		string[index++]=(char)c;
		if (c==('\n')) {
			break;                    /* read newline, done */
		} else if (lastcr) {
			StorageSeekFile(fp,-1,soFromCurrent,&g_amount_read);
			//ungetc(c,(FILE*)fp);             /* carriage return was read, no newline follows */
			break;
		} /* if */
		lastcr=(c==('\r'));
	} /* for */
	assert(index<max);
	string[index]=0;

	return index;
}

static cell AMX_NATIVE_CALL n_FileWrite( AMX* amx, cell* params )
{
	amx_StrParam(amx,params[2],g_sz_tmp);
	StorageWriteFile((SolFSHandle)params[1],g_sz_tmp,strlen(g_sz_tmp)*sizeof(char),&g_amount_read);
	return 1;
}

static cell AMX_NATIVE_CALL n_FilePutChar( AMX* amx, cell* params )
{
	cell * cptr;
	cptr = &params[2];
	if(params[2] > 0xFF)
	{
		result = StorageWriteFile((SolFSHandle)params[1],cptr,2,&g_amount_read);
	}
	else
	{
		result = StorageWriteFile((SolFSHandle)params[1],cptr,1,&g_amount_read);
	}
	return result;
}

static cell AMX_NATIVE_CALL n_FileGetChar( AMX* amx, cell* params )
{
	cell str[2];
	char strx[2];
	if (params[3]) 
	{
		g_amount_read = fgets_cell((Handle)params[1], str, 2, 1);
	} else {
		g_amount_read = fgets_char((Handle)params[1], strx, 2);
		str[0]=strx[0];
	} /* if */
	if (g_amount_read==0)
		return EOF;
	cell *cptr;
	amx_GetAddr(amx,params[2],&cptr);
	*cptr = str[0];
	return str[0];
}

static cell AMX_NATIVE_CALL n_fread(AMX *amx, cell *params)
{
  int chars,max;
  char *str;
  cell *cptr;

  max=(int)params[3];
  if (max<=0)
    return 0;
  if (params[4])
    max*=sizeof(cell);

  amx_GetAddr(amx,params[2],&cptr);
  str=(char *)alloca(max);
  if (str==NULL || cptr==NULL) {
    amx_RaiseError(amx, AMX_ERR_NATIVE);
    return 0;
  } /* if */

  if (params[4]) {
    /* store as packed string, read an ASCII/ANSI string */
    chars=fgets_char((SolFSHandle)params[1],str,max);
    assert(chars<max);
	str[chars] = 0;
    amx_SetString(cptr,str,(int)params[4],0,max);
  } else {
    /* store and unpacked string, interpret UTF-8 */
    chars=fgets_cell((SolFSHandle)params[1],cptr,max,1);
  } /* if */

  assert(chars<max);
  return chars;
}

#if PAWN_CELL_SIZE==16
  #define aligncell amx_Align16
#elif PAWN_CELL_SIZE==32
  #define aligncell amx_Align32
#elif PAWN_CELL_SIZE==64 && (defined _I64_MAX || defined HAVE_I64)
  #define aligncell amx_Align64
#else
  #error Unsupported cell size
#endif
/* fblockwrite(File: handle, buffer[], size=sizeof buffer) */
static cell AMX_NATIVE_CALL n_fblockwrite(AMX *amx, cell *params)
{
  cell *cptr;
  cell count;
  amx_GetAddr(amx,params[2],&cptr);
  if (cptr!=NULL) {
    cell max=params[3];
	for (count=0; count<max; ++count) {
		if ((StorageWriteFile((SolFSHandle)params[1],cptr++,sizeof(cell),&g_amount_read),g_amount_read!=sizeof(cell)))
        break;/* write error */
    } /* for */
  } /* if */
  return count;
}

/* fblockread(File: handle, buffer[], size=sizeof buffer) */
static cell AMX_NATIVE_CALL n_fblockread(AMX *amx, cell *params)
{
  cell *cptr;
  cell count;

  amx_GetAddr(amx,params[2],&cptr);
  if (cptr!=NULL) {
    cell max=params[3];
    ucell v;
    for (count=0; count<max; count++) {
      if ((StorageReadFile((SolFSHandle)params[1],&v,sizeof(cell),&g_amount_read),g_amount_read!=sizeof(cell)))
        break;          /* write error */
      *cptr++=(cell)v;
    } /* for */
  } /* if */
  return count;
}

AMX_NATIVE_INFO AMXNatives[ ] =
{
	{"vopen",n_FileOpen},
	{"vclose",n_FileClose},
	{"vread",n_fread},
	{"vwrite",n_FileWrite},
	{"vlength",n_FileSize},
	{"vremove",n_FileDelete},
	{"vexist",n_FileExists},
	{"vtemp",n_FileTemp},
	{"vblockwrite",n_fblockwrite},
	{"vblockread",n_fblockread},
	{"vseek",n_FileSeek},
	{"vgetchar",n_FileGetChar},
	{"vputchar",n_FilePutChar},
	{0,                0}
};


// From "amx.c", part of the PAWN language runtime:
// http://code.google.com/p/pawnscript/source/browse/trunk/amx/amx.c

#define USENAMETABLE(hdr) \
	((hdr)->defsize==sizeof(AMX_FUNCSTUBNT))

#define NUMENTRIES(hdr,field,nextfield) \
	(unsigned)(((hdr)->nextfield - (hdr)->field) / (hdr)->defsize)

#define GETENTRY(hdr,table,index) \
	(AMX_FUNCSTUB *)((unsigned char*)(hdr) + (unsigned)(hdr)->table + (unsigned)index*(hdr)->defsize)

#define GETENTRYNAME(hdr,entry) \
	(USENAMETABLE(hdr) ? \
		(char *)((unsigned char*)(hdr) + (unsigned)((AMX_FUNCSTUBNT*)(entry))->nameofs) : \
		((AMX_FUNCSTUB*)(entry))->name)

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	if(HOOK_IO_TRAFFIC)
	{
		//Code from sscanf2.5, [PAWN]SSCANF Author: Y_Less
		int
			num,
			idx;
		// Operate on the raw AMX file, don't use the amx_ functions to avoid issues
		// with the fact that we've not actually finished initialisation yet.  Based
		// VERY heavilly on code from "amx.c" in the PAWN runtime library.
		AMX_HEADER *
			hdr = (AMX_HEADER *)amx->base;
		AMX_FUNCSTUB *
			func;
		num = NUMENTRIES(hdr, natives, libraries);
		for (idx = 0; idx != num; ++idx)//replace all file functions by our SolFS equivalents
		{
			func = GETENTRY(hdr, natives, idx);
			if (!strcmp("fopen", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileOpen;
			}
			if (!strcmp("fclose", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileClose;
			}
			if (!strcmp("ftemp", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileTemp;
			}
			if (!strcmp("fremove", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileDelete;
			}
			if (!strcmp("fwrite", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileWrite;
			}
			if (!strcmp("fread", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_fread;
			}
			if (!strcmp("fputchar", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FilePutChar;
			}
			if (!strcmp("fgetchar", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileGetChar;
			}
			if (!strcmp("fblockwrite", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_fblockwrite;
			}
			if (!strcmp("fblockread", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_fblockread;
			}
			if (!strcmp("fseek", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileSeek;
			}
			if (!strcmp("flength", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileSize;
			}
			if (!strcmp("fexist", GETENTRYNAME(hdr, func)))
			{
				func->address = (ucell)n_FileExists;
			}
		}
	}
	return amx_Register( amx, AMXNatives, -1 );
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	return AMX_ERR_NONE;
}


	//else
	//{
		// creating folder in storage
	//	result = StorageCreateDirectory(storage, L"/folder");
	//	if (result != 0)
	//		printf("SolFS error: %d\n", result);
	//	else
	//	{
			// creating subfolder in previously created folder
	//		result = StorageCreateDirectory(storage, L"/folder/subfolder");
	//		if (result != 0)
	//			printf("SolFS error: %d\n", result);			
	//	}
	//	if (result != 0)
	//		printf("SolFS error: %d\n", result);
	//	else
	//	{
			// deleting subfolder
	//		result = StorageDeleteDirectory(storage, L"/folder/subfolder");
	//		if (result != 0)
	//			printf("SolFS error: %d\n", result);
	//	}

	//}
