//====================================================
//
//  Solid File System
//
//  Copyright (c) 2003-2008, Softpanorama++ LLC
//  Exclusive rights granted to EldoS Corporation
//
//====================================================

#ifndef SolFSHPP
#define SolFSHPP

#include <stdlib.h>
#include "..\StoreDecl.h"

#ifdef WIN32
#include <tchar.h>
#elif _WIN32_WINCE
#include <tchar.h>
#else
#define TCHAR char
#define __T(x)      x
#define _T(x)       __T(x)
#define TEXT(x)    __T(x)
#define _TEXT(x)    __T(x)
#ifdef _UNICODE
#ifndef WCHAR
#define LPTSTR		unsigned short *
#define LPCTSTR		const unsigned short *
#else
#define LPTSTR		wchar_t *
#define LPCTSTR		const wchar_t *
#endif
#else
#define LPTSTR		char *
#define LPCTSTR		const char *
#endif
#endif

#ifdef USE_NAMESPACE
namespace SolFS 
{
#endif

#define WIDE(x)		L ## x

#undef CreateDirectory
#undef DeleteFile
#undef MoveFile
#undef GetFileAttributes
#undef SetFileAttributes

/*
#pragma push_macro("CreateDirectory")
#pragma push_macro("DeleteFile")
#pragma push_macro("MoveFile")
#pragma push_macro("GetFileAttributes")
#pragma push_macro("SetFileAttributes")

*/
#undef ecUnknown
#undef ecNoEncryption
#undef ecAES256_SHA256
#undef ecAES256_HMAC256
#undef ecCustom
#undef ecCustom256

#undef crUnknown
#undef crNoCompression
#undef crDefault
#undef crCustom
#undef crZLib
#undef crRLE

#undef tvtBoolean
#undef tvtString
#undef tvtDateTime
#undef tvtNumber
#undef tvtAnsiString

#undef errInvalidStorageFile
#undef errInvalidPageSize
#undef errStorageFileCorrupted
#undef errTooManyTransactionsCommiting
#undef errFileOrDirectoryAlreadyExists
#undef errExistsActiveTransactions
#undef errTagAlreadyExistInFile
#undef errFileNotFound
#undef errPathNotFound
#undef errSharingViolation
#undef errSeekBeyondEOF
#undef errNoMoreFiles
#undef errInvalidFileName
#undef errStorageActive
#undef errStorageNotActive
#undef errInvalidPassword
#undef errStorageReadOnly
#undef errNoEncryptionHandlers
#undef errOutOfMemory
#undef errLinkDestinationNotFound
#undef errFileIsNotSymLink
#undef errBufferTooSmall
#undef errBadCompressedData
#undef errInvalidParameter
#undef errStorageFull
#undef errInterruptedByUser
#undef errTagNotFound
#undef errDirectoryNotEmpty
#undef errHandleClosed
#undef errInvalidStreamHandle
#undef errFileAccessDenied
#undef errNoCompressionHandlers

#undef errInternalError

static const signed long errInvalidStorageFile = -1;
static const signed long errInvalidPageSize = -2;
static const signed long errStorageFileCorrupted = -3;
static const signed long errTooManyTransactionsCommiting = -4;
static const signed long errFileOrDirectoryAlreadyExists = -5;
static const signed long errExistsActiveTransactions = -6;
static const signed long errTagAlreadyExistInFile = -7;
static const signed long errFileNotFound = -8;
static const signed long errPathNotFound = -9;
static const signed long errSharingViolation = -10;
static const signed long errSeekBeyondEOF = -11;
static const signed long errNoMoreFiles = -12;
static const signed long errInvalidFileName = -13;
static const signed long errStorageActive = -14;
static const signed long errStorageNotActive = -15;
static const signed long errInvalidPassword = -16;
static const signed long errStorageReadOnly = -17;
static const signed long errNoEncryptionHandlers = -18;
static const signed long errOutOfMemory = -19;
static const signed long errLinkDestinationNotFound = -20;
static const signed long errFileIsNotSymLink = -21;
static const signed long errBufferTooSmall = -22;
static const signed long errBadCompressedData = -23;
static const signed long errInvalidParameter = -24;
static const signed long errStorageFull = -25;
static const signed long errInterruptedByUser = -26;
static const signed long errTagNotFound = -27;
static const signed long errDirectoryNotEmpty = -28;
static const signed long errHandleClosed = -29;
static const signed long errInvalidStreamHandle = -30;
static const signed long errFileAccessDenied = -31;
static const signed long errNoCompressionHandlers = -32;
static const signed long errInternalError = -200;

static LPCTSTR ErrorStrings[(-errNoCompressionHandlers)] =
{
	TEXT("Invalid storage file"),
	TEXT("Invalid page size"),
	TEXT("Storage file corrupted"),
	TEXT("Too many transactions commiting"),
	TEXT("File or directory already exists"),
	TEXT("Active transaction already exists"),
	TEXT("Tag already exists in the file"),
	TEXT("File not found"),
	TEXT("Path not found"),
	TEXT("Sharing violation"),
	TEXT("Seek beyond EOF"),
	TEXT("No more files"),
	TEXT("Invalid file name"),
	TEXT("Can not perform this opeartion on active storage"),
	TEXT("Can not perform this opeartion on not active storage"),
	TEXT("Invalid password"),
	TEXT("Can not perform this opeartion on read only storage"),
	TEXT("You can't use custom encryption because encryption handlers have not been set"),
	TEXT("Out of memory"),
	TEXT("Symbolic link destination file not found"),
	TEXT("File is not a symbolic link"),
	TEXT("Buffer is too small to contain the requested value"),
	TEXT("Corrupted compressed data"),
	TEXT("Invalid parameter"),
	TEXT("Storage full"),
	TEXT("Interrupted by user"),
	TEXT("Tag not found"),
	TEXT("Directory not empty"),
	TEXT("Handle already closed"),
	TEXT("Invalid file/stream handle"),
	TEXT("Access to file/stream is denied"),
	TEXT("You can't use custom encryption because encryption handlers have not been set")
};

static LPCTSTR strCallbacksNotSet = TEXT("Not all callback functions specified");
static LPCTSTR strCryptCallbackNotSet = TEXT("Not all encryption callback functions specified");
static LPCTSTR strCompressCallbackNotSet = TEXT("Not all compression callback functions specified");

static LPCTSTR strStorageFileDoesntExist = TEXT("Storage file does not exist.");
static LPCTSTR strStorageFileAlreadyExists = TEXT("Storage file already exists.");

typedef TSeekOrigin SeekOrigin;

typedef enum StorageOpenModeType {somCreateNew = 0, somCreateAlways = 1, somOpenExisting = 2, somOpenAlways = 3} StorageOpenMode;

typedef enum SolFSCompressionType {crNoCompression = 0, crDefault = 1, crCustom = 2, crZLib = 3, crRLE = 4, crUnknown = 0xFFFFFFFF} SolFSCompression;

typedef enum SolFSEncryptionType {ecNoEncryption = 0, ecAES256_SHA256 = 1, ecCustom256 = 2, ecAES256_HMAC256 = 3, ecUnknown = 0xFFFFFFFF} SolFSEncryption;

typedef enum SolFSTagValueType {tvtBoolean = 1, tvtString = 2, tvtDateTime = 3, tvtNumber = 4, tvtAnsiString = 100} SolFSTagValue;

Error CheckStorageResult(Error StorageResult);

class ESolFSSysError
{
protected: 
	LPCTSTR m_Message;
public:

	ESolFSSysError(LPCTSTR Message)
	{
		m_Message = Message;
	}

	LPCTSTR Message() { return m_Message;	};
};

class ESolFSError 
{
protected: 
	Error m_ErrorCode;
	LPCTSTR m_Message;
 public:

	ESolFSError(LPCTSTR Message)
	{
		m_Message = Message;
		m_ErrorCode = -1;
	}

	ESolFSError(LPCTSTR Message, Error ErrorCode)
	{
		m_Message = Message;
		m_ErrorCode = ErrorCode;
	}
	
	Error ErrorCode() { return m_ErrorCode;	};
	LPCTSTR Message() { return m_Message;	};
};

class SolFSStream;

class SolFSStorage
{
private:
	void* m_Storage;
	bool m_Active;
	bool m_FixedSize;
	bool m_ReadOnly;
	PWideChar m_FileName;
	bool m_UseTransactions;
	bool m_UseAccessTime;
	bool m_CaseSensitive;
	unsigned m_AutoCompact;
	unsigned m_PageSize;
	unsigned long m_MaxPageCount;
	unsigned long m_Buffering;
    unsigned long m_MaxTransactionSize;
	WideChar m_PathSeparator;
	PWideChar m_Logo;
	SolFSEncryption m_FilesEncryption;
	PWideChar m_FilesPassword;
	SolFSEncryption m_StorageEncryption;
	PWideChar m_StoragePassword;
	unsigned m_CompressionLevel;
	SolFSCompression m_Compression;
	
	CallbackDataType m_UserData;
	CallbackDataType m_CryptUserData;
	CallbackDataType m_CompressUserData;
	CallbackDataType m_ProgressUserData;

	SolFSCreateFileFunc m_OnCreateFile;
	SolFSOpenFileFunc m_OnOpenFile;
	SolFSCloseFileFunc m_OnCloseFile;
	SolFSFlushFileFunc m_OnFlushFile;
	SolFSDeleteFileFunc m_OnDeleteFile;
	SolFSGetFileSizeFunc m_OnGetFileSize;
	SolFSSetFileSizeFunc m_OnSetFileSize;
	SolFSSeekFileFunc m_OnSeekFile;
	SolFSReadFileFunc m_OnReadFile;
	SolFSWriteFileFunc m_OnWriteFile;
	SolFSCryptDataFunc m_OnEncryptData;
	SolFSCryptDataFunc m_OnDecryptData;
	SolFSCompressDataFunc m_OnCompressData;
	SolFSDecompressDataFunc m_OnDecompressData;
	SolFSCalculateHashFunc m_OnCalculateHash;
	SolFSValidateHashFunc m_OnValidateHash;
	SolFSProgressFunc m_OnProgress;
	//SolFSImportExportFunc m_OnImportExport;
	//SolFSPasswordFunc m_OnPasswordNeeded;
	
	void CheckActive(void);
	void CheckNotActive(void);
	bool IsCB(void);
	void CheckCB(void);
	bool IsEncryptionCB(void);
	void CheckEncryptionCB(void);
	bool IsCompressionCB(void);
	void CheckCompressionCB(void);
	void Opened(void);
	void Init(const PWideChar fileName);

	void Create(const PWideChar fileName, bool overwrite, long pageSize, const PWideChar logo);
	void CreateCB(const PWideChar fileName, bool overwrite, long pageSize, const PWideChar logo);
	void Open(const PWideChar fileName);
	void OpenReadOnly(const PWideChar fileName);
	void OpenCB(const PWideChar fileName);

	/*
	void SetOnCloseFile(const SolFSCloseFileEvent Value);
	void SetOnCreateFile(const SolFSCreateFileEvent Value);
	void SetOnDeleteFile(const SolFSDeleteFileEvent Value);
	void SetOnFlushFile(const SolFSFlushFileEvent Value);
	void SetOnGetFileSize(const SolFSGetFileSizeEvent Value);
	void SetOnOpenFile(const SolFSOpenFileEvent Value);
	void SetOnReadFile(const SolFSReadFileEvent Value);
	void SetOnSeekFile(const SolFSSeekFileEvent Value);
	void SetOnSetFileSize(const SolFSSetFileSizeEvent Value);
	void SetOnWriteFile(const SolFSWriteFileEvent Value);
	void SetOnCalculateHash(const SolFSCalculateHashEvent Value);
	void SetOnDecryptData(const SolFSCryptDataEvent Value);
	void SetOnEncryptData(const SolFSCryptDataEvent Value);
	void SetOnValidateHash(const SolFSValidateHashEvent Value);
	*/
	
public:
	SolFSStorage();

	SolFSStorage(const PWideChar fileName, bool useTransactions, bool useAccessTime, wchar_t pathSeparator);
	SolFSStorage(const PWideChar fileName, bool useTransactions, bool useAccessTime, wchar_t pathSeparator, bool openReadOnly);
	SolFSStorage(const PWideChar fileName, bool overwrite, long pageSize, bool useTransactions, bool useAccessTime, wchar_t pathSeparator, const PWideChar logo);
	
	SolFSStorage(const PWideChar fileName, bool useTransactions, bool useAccessTime, wchar_t pathSeparator, 
		CallbackDataType UserData,
		SolFSCreateFileFunc OnCreateFile, SolFSOpenFileFunc OnOpenFile,
		SolFSCloseFileFunc OnCloseFile, SolFSFlushFileFunc OnFlushFile, SolFSDeleteFileFunc OnDeleteFile,
		SolFSGetFileSizeFunc OnGetFileSize, SolFSSetFileSizeFunc OnSetFileSize, SolFSSeekFileFunc OnSeekFile,
		SolFSReadFileFunc OnReadFile, SolFSWriteFileFunc OnWriteFile);
	
	SolFSStorage(const PWideChar fileName, bool overwrite, long pageSize, bool useTransactions, bool useAccessTime, 
		wchar_t pathSeparator, const PWideChar logo, 
		CallbackDataType UserData,
		SolFSCreateFileFunc OnCreateFile, SolFSOpenFileFunc OnOpenFile,
		SolFSCloseFileFunc OnCloseFile, SolFSFlushFileFunc OnFlushFile, SolFSDeleteFileFunc OnDeleteFile,
		SolFSGetFileSizeFunc OnGetFileSize, SolFSSetFileSizeFunc OnSetFileSize, SolFSSeekFileFunc OnSeekFile,
		SolFSReadFileFunc OnReadFile, SolFSWriteFileFunc OnWriteFile);
	
	~SolFSStorage();
	
	static void				SetRegistrationKey(char* Key);
	static unsigned long	GetVersion();
	

	void				Open(StorageOpenMode OpenMode);
	void				Close(void);
	SolFSEncryption		GetEncryption(void);
	bool				CheckPassword(const PWideChar Password);
	void				SetPassword(const PWideChar Password);
	void				SetEncryption(SolFSEncryption Encryption, const PWideChar OldPassword, const PWideChar NewPassword);
	bool				IsSolFSStorage(void);
	void				CheckAndRepair(unsigned  long Flags);
	void				FormatFixedSize(__int64 FileSize, unsigned  long Flags);
	bool				Compact(void);

	SolFSStream*		OpenRootData(void);
	__int64				get_DiskSize(void);
	void				set_DiskSize(__int64 Value);
	__int64				DiskFree(void);
	
	bool				FileExists(const PWideChar FileName);
	void				DeleteFile(const PWideChar FileName);
	void				DeleteFileW(const PWideChar FileName);
	void				MoveFile(const PWideChar OldFileName, const PWideChar NewFileName);
	void				MoveFileW(const PWideChar OldFileName, const PWideChar NewFileName);
  void        DeleteAndRenameFile(const PWideChar OldFileName, const PWideChar NewFileName);
	
	bool				FindFirst(TStorageSearch &Search, const PWideChar Mask, unsigned long Attributes);
	bool				FindFirstEx(TStorageSearch &Search, const PWideChar Mask, unsigned long Attributes, unsigned long Flags);
	bool				FindNext(TStorageSearch &Search);
	void				FindClose(TStorageSearch &Search);
	
	void				CreateDirectory(const PWideChar Directory);
	void				CreateDirectoryW(const PWideChar Directory);
	void				ForceCreateDirectories(const PWideChar Path);
	bool 				IsDirectoryEmpty(const PWideChar Directory);
	void				DeleteDirectory(const PWideChar Directory);
	
	DateTime			GetFileCreationTime(const PWideChar FileName);
	void				SetFileCreationTime(const PWideChar FileName, DateTime Value);
	
	DateTime			GetFileModificationTime(const PWideChar FileName);
	void				SetFileModificationTime(const PWideChar FileName, DateTime Value);

	DateTime			GetFileLastAccessTime(const PWideChar FileName);
	void				SetFileLastAccessTime(const PWideChar FileName, DateTime Value);
	
	SolFSEncryption		GetFileEncryption(const PWideChar FileName);
	void 				SetFileEncryption(const PWideChar FileName, SolFSEncryption Encryption, const PWideChar 
							OldPassword, const PWideChar NewPassword);
	bool				CheckFilePassword(const PWideChar FileName, const PWideChar Password, bool EncryptionUnknown, 
							SolFSEncryption Encryption);

	void				GetFileCompression(const PWideChar FileName, SolFSCompression &Compression, unsigned long
							&CompressionLevel, unsigned long &PagesPerCluster);
	void				SetFileCompression(const PWideChar FileName, SolFSCompression Compression, unsigned long
							CompressionLevel, unsigned long PagesPerCluster, const PWideChar Password);
	
	void				GetFileAttributes(const PWideChar FileName, unsigned long &Attributes);
	void				GetFileAttributesW(const PWideChar FileName, unsigned long &Attributes);
	void				SetFileAttributes(const PWideChar FileName, unsigned long Attributes);
	void				SetFileAttributesW(const PWideChar FileName, unsigned long Attributes);
	
	void				Link(const PWideChar LinkName, const PWideChar DestinationName);
	void				GetLinkDestination(const PWideChar LinkName, PWideChar &DestinationName);

	unsigned long		GetFileTagInfo(const PWideChar FileName, unsigned short TagID, bool* TagExists);
	unsigned long		GetFileTag(const PWideChar FileName, unsigned short TagID, void* TagData, unsigned long TagDataSize);
	void				SetFileTag(const PWideChar FileName, unsigned short TagID, void* TagData, unsigned long TagDataSize);
	void				DeleteFileTag(const PWideChar FileName, unsigned short TagID);	

	// queries related

	void				AddTagName(unsigned short TagID, SolFSTagValueType TagValueType, const PWideChar TagName);
	void				DeleteTagName(unsigned short TagID);
	int					GetTagNamesCount();
	void				GetTagName(int Index, unsigned short &TagID, SolFSTagValueType &TagValueType, PWideChar &TagName);

	void				SetFileTagAsBool(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, bool Value);
	bool				GetFileTagAsBool(const PWideChar FileName, const PWideChar TagName, unsigned short TagID);

	void				SetFileTagAsString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PWideChar Value);
	void				GetFileTagAsString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PWideChar &Value);

	void				SetFileTagAsAnsiString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PChar Value);
	void				GetFileTagAsAnsiString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PChar &Value);

	void				SetFileTagAsDateTime(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, DateTime Value);
	DateTime			GetFileTagAsDateTime(const PWideChar FileName, const PWideChar TagName, unsigned short TagID);

	void				SetFileTagAsNumber(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, LongLongWord Value);
	LongLongInt			GetFileTagAsNumber(const PWideChar FileName, const PWideChar TagName, unsigned short TagID);

	void				DeleteFileTagByName(const PWideChar FileName, const PWideChar TagName);

	bool				FindByQueryFirst(TStorageSearch &Search, const PWideChar Directory, const PWideChar Query, long Flags);
	bool				FindByQueryNext(TStorageSearch &Search);
	void				FindByQueryClose(TStorageSearch &Search);

	// end of queries related

	CallbackDataType	get_UserData() { return m_UserData; };

	CallbackDataType	get_CryptUserData() { return m_CryptUserData; };
	void				set_CryptUserData(CallbackDataType Value) { m_CryptUserData = Value; };

	CallbackDataType	get_CompressUserData() { return m_CompressUserData; };
	void				set_CompressUserData(CallbackDataType Value) { m_CompressUserData = Value; };

// public properties
	bool				get_Active() { return m_Active; };
	bool				get_FixedSize() { return m_FixedSize; };
	void*				get_Storage() { return m_Storage; };

	bool				get_IsCorrupted();
	unsigned long		get_MaxPageCount();
	void				set_MaxPageCount(const unsigned long Value);

	DateTime			get_LastAccessTime();
	DateTime			get_LastWriteTime();

// published properties
	bool				get_ReadOnly() { return m_ReadOnly; };
	void				set_ReadOnly(const bool Value);

	bool				get_CaseSensitive() { return m_CaseSensitive; };
	void				set_CaseSensitive(const bool Value);

	unsigned long		get_PageSize() { return m_PageSize; };
	void				set_PageSize(const unsigned long Value);

	unsigned long		get_Buffering();
	void				set_Buffering(const unsigned long Value);

	unsigned long		get_MaxTransactionSize();
	void				set_MaxTransactionSize(const unsigned long Value);

	PWideChar			get_Logo()  { return m_Logo; };
	void				set_Logo(const PWideChar Value);

	PWideChar			get_FileName() { return m_FileName; };
	void				set_FileName(const PWideChar Value);
		
	WideChar			get_PathSeparator() { return m_PathSeparator; };
	void				set_PathSeparator(const WideChar Value);
	
	bool				get_UseTransactions() { return m_UseTransactions; };
	void				set_UseTransactions(const bool Value);

	bool				get_UseAccessTime() { return m_UseAccessTime; };
	void				set_UseAccessTime(const bool Value);

	unsigned long		get_AutoCompact() { return m_AutoCompact; };
	void				set_AutoCompact(const unsigned long Value);
		
	SolFSEncryption		get_FilesEncryption() { return m_FilesEncryption; };
	void				set_FilesEncryption(const SolFSEncryption Value);

	SolFSEncryption		get_StorageEncryption() { return m_StorageEncryption; };
	void				set_StorageEncryption(const SolFSEncryption Value);
	
	PWideChar			get_FilesPassword() { return m_FilesPassword; };
	void				set_FilesPassword(const PWideChar Value);

	PWideChar			get_StoragePassword() { return m_StoragePassword; };
	void				set_StoragePassword(const PWideChar Value);

	SolFSCompression	get_Compression() { return m_Compression; };
	void				set_Compression(const SolFSCompression Value);

	unsigned long		get_CompressionLevel() { return m_CompressionLevel; };
	void				set_CompressionLevel(const unsigned long Value);
	
	SolFSCryptDataFunc	get_OnDataEncrypt() { return m_OnEncryptData; };
	void				set_OnDataEncrypt(SolFSCryptDataFunc Value) { m_OnEncryptData = Value; };

	SolFSCryptDataFunc	get_OnDataDecrypt() { return m_OnDecryptData; };
	void				set_OnDataDecrypt(SolFSCryptDataFunc Value) { m_OnDecryptData = Value; };

	SolFSCompressDataFunc	get_OnDataCompress() { return m_OnCompressData; };
	void				set_OnDataCompress(SolFSCompressDataFunc Value) { m_OnCompressData = Value; };

	SolFSDecompressDataFunc	get_OnDataDecompress() { return m_OnDecompressData; };
	void				set_OnDataDecompress(SolFSDecompressDataFunc Value) { m_OnDecompressData = Value; };

	SolFSCalculateHashFunc	get_OnHashCalculate() { return m_OnCalculateHash; };
	void				set_OnHashCalculate(SolFSCalculateHashFunc Value) { m_OnCalculateHash = Value; };

	SolFSValidateHashFunc	get_OnHashValidate() { return m_OnValidateHash; };
	void				set_OnHashValidate(SolFSValidateHashFunc Value) { m_OnValidateHash = Value; };

	SolFSProgressFunc	get_OnProgress(CallbackDataType *UserData) { if (UserData) *UserData = m_ProgressUserData; return m_OnProgress; };
	void				set_OnProgress(SolFSProgressFunc Value, CallbackDataType UserData) { m_OnProgress = Value; m_ProgressUserData = UserData; };

	/*
	__property SolFSCreateFileEvent OnFileCreate = {read=FOnCreateFile, write=SetOnCreateFile};
	__property SolFSOpenFileEvent OnFileOpen = {read=FOnOpenFile, write=SetOnOpenFile};
	__property SolFSCloseFileEvent OnFileClose = {read=FOnCloseFile, write=SetOnCloseFile};
	__property SolFSFlushFileEvent OnFileFlush = {read=FOnFlushFile, write=SetOnFlushFile};
	__property SolFSDeleteFileEvent OnFileDelete = {read=FOnDeleteFile, write=SetOnDeleteFile};
	__property SolFSGetFileSizeEvent OnFileGetSize = {read=FOnGetFileSize, write=SetOnGetFileSize};
	__property SolFSSetFileSizeEvent OnFileSetSize = {read=FOnSetFileSize, write=SetOnSetFileSize};
	__property SolFSSeekFileEvent OnFileSeek = {read=FOnSeekFile, write=SetOnSeekFile};
	__property SolFSReadFileEvent OnFileRead = {read=FOnReadFile, write=SetOnReadFile};
	__property SolFSWriteFileEvent OnFileWrite = {read=FOnWriteFile, write=SetOnWriteFile};
	__property SolFSValidateHashEvent OnHashValidate = {read=FOnValidateHash, write=SetOnValidateHash};
	__property SolFSCalculateHashEvent OnHashCalculate = {read=FOnCalculateHash, write=SetOnCalculateHash};
	__property SolFSCryptDataEvent OnDataEncrypt = {read=FOnEncryptData, write=SetOnEncryptData};
	__property SolFSCryptDataEvent OnDataDecrypt = {read=FOnDecryptData, write=SetOnDecryptData};
	__property SolFSProgressEvent OnProgress = {read=FOnProgress, write=FOnProgress};
	__property SolFSImportExportEvent OnImportExport = {read=FOnImportExport, write=FOnImportExport};
	__property SolFSPasswordEvent OnPasswordNeeded = {read=FOnPasswordNeeded, write=FOnPasswordNeeded};
	*/
};

class SolFSStream 
{
private:
	bool m_CanRead;
	bool m_CanWrite;
	bool m_Closed;

	LongLongWord m_Position;
	Handle m_Stream;

	void CheckClosed();
	void InternalCreate(SolFSStorage *Storage, const PWideChar FileName, bool OpenExisting, bool TruncateExisting,
			bool ReadEnabled, bool WriteEnabled, bool ShareDenyRead, bool ShareDenyWrite,
			const PWideChar Password, unsigned long Encryption, long Reseved,
			SolFSCompression Compression, unsigned long CompressionLevel, unsigned short PagesPerCluster);

public:
	SolFSStream(Handle stream);
	~SolFSStream();

	SolFSStream(SolFSStorage *Storage, const PWideChar FileName, const PWideChar mode);
	SolFSStream(SolFSStorage *Storage, const PWideChar FileName, bool CreateNew, 
			bool ReadEnabled, bool WriteEnabled,
			bool ShareDenyRead, bool ShareDenyWrite,
			const PWideChar Password, SolFSEncryption Encryption, long Reseved,
			SolFSCompression Compression, unsigned long CompressionLevel,
			unsigned short PagesPerCluster);

	void			Close();
	void			Flush(void);
	LongWord		Read(void *Buffer, unsigned long Count);
	LongWord		Write(const void *Buffer, unsigned long Count);
	LongLongWord	Seek(LongLongWord Offset, SeekOrigin Origin);

	LongLongWord	get_Position() { CheckClosed(); return m_Position; }
	void			set_Position(LongLongWord Value);

	LongLongWord 	get_Length();
	void			set_Length(LongLongWord value);
	
};

void xtstrfree(LPTSTR *text);
void xwstrfree(PWideChar *text);
PWideChar xwstrdup(PWideChar text);
LPTSTR xtstrdup(LPTSTR text);
unsigned long xwcslen(PWideChar text);

/*
#pragma pop_macro("CreateDirectory")
#pragma pop_macro("DeleteFile")
#pragma pop_macro("MoveFile")
#pragma pop_macro("GetFileAttributes")
#pragma pop_macro("SetFileAttributes")
*/

#ifdef USE_NAMESPACE
}
#endif

#endif
