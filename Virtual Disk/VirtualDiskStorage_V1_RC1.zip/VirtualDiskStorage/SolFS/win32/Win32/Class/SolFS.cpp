//====================================================
//                                                    
//  Solid File System (SolFS)
//                                                    
//   Copyright (c) 2003-2008, EldoS Corporation
//                                                    
//==================================================== 

#include "SolFS.hpp"

#ifdef USE_NAMESPACE
namespace SolFS
{
#endif

/*
#pragma push_macro("CreateDirectory")
#pragma push_macro("DeleteFile")
#pragma push_macro("MoveFile")
#pragma push_macro("GetFileAttributes")
#pragma push_macro("SetFileAttributes")

#undef CreateDirectory
#undef DeleteFile
#undef MoveFile
#undef GetFileAttributes
#undef SetFileAttributes
*/
#define StoreWideStrNToStr(Src, Dst, MaxLen) \
	WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)Src, -1, (LPSTR)Dst, MaxLen, NULL, NULL)

typedef WINBASEAPI HANDLE (WINAPI *FindFirstFileWFunc)(
    LPCWSTR lpFileName,
    LPWIN32_FIND_DATAW lpFindFileData
);

FindFirstFileWFunc GetFindFirstFile()
{
	FindFirstFileWFunc W = NULL;
	
#ifdef SOLFS_WINCE
	HMODULE krnl = GetModuleHandle(TEXT("coredll.dll"));
	if (krnl != NULL)
		W = (FindFirstFileWFunc) GetProcAddress(krnl, TEXT("FindFirstFileW"));
#else
	HMODULE krnl = GetModuleHandle(TEXT("kernel32.dll"));
	if (krnl != NULL)
		W = (FindFirstFileWFunc) GetProcAddress(krnl, "FindFirstFileW");
#endif
	return W;
}

bool FileExists(const PWideChar FileName)
{
	HANDLE Result;
	FindFirstFileWFunc FFFunc = GetFindFirstFile();
	if (FFFunc != NULL)
	{	
		WIN32_FIND_DATAW SRec;
		Result = FFFunc((LPCWSTR) FileName, &SRec);
	}
	else
#ifndef SOLFS_WINCE
	{
		CHAR Buffer[MAX_PATH * 2 + 1];
		StoreWideStrNToStr(FileName, Buffer, MAX_PATH * 2);
		WIN32_FIND_DATAA SRec;
		Result = FindFirstFileA(Buffer, &SRec);
	}
#else
		Result = INVALID_HANDLE_VALUE;
#endif
	if (Result != INVALID_HANDLE_VALUE)
	{
		FindClose(Result);
		return true;
	}
	else
	{
		return false;
	}
}

DateTime DateTimeLocalToUTC(DateTime value)
{
	TIME_ZONE_INFORMATION tzi;
	memset(&tzi, 0, sizeof(tzi));
	if (GetTimeZoneInformation(&tzi) == TIME_ZONE_ID_DAYLIGHT)
		tzi.Bias += tzi.DaylightBias;
	return value + (((double) tzi.Bias) / (24 * 60));	
}

DateTime DateTimeUTCToLocal(DateTime value)
{
	TIME_ZONE_INFORMATION tzi;
	memset(&tzi, 0, sizeof(tzi));
	if (GetTimeZoneInformation(&tzi) == TIME_ZONE_ID_DAYLIGHT)
		tzi.Bias += tzi.DaylightBias;
	return value - (((double) tzi.Bias) / (24 * 60));	
}

Error CheckStorageResult(Error StorageResult)
{
	Error Result = StorageResult;
			
	if (Result < 0)
	{
		throw new ESolFSError((ErrorStrings)[(-Result) - 1], Result);
	}
	else 
    if (Result > 0)
	{
		throw new ESolFSError(TEXT(""), Result);
	}
	return Result;
}


Error __stdcall SolFSCalculateHash(CallbackDataType UserData, Pointer Buffer, LongWord Count, Pointer HashBuffer)
{
	Error Result;
	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		Result = (Storage->get_OnHashCalculate())(Storage->get_CryptUserData(), Buffer, Count, HashBuffer);		
	}
  	else
    	Result = -1;
	return Result;
}

Error __stdcall SolFSValidateHash(CallbackDataType UserData, Pointer Buffer, LongWord Count, Pointer HashBuffer, Bool *Valid)
{
	Error Result;
	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		Result = (Storage->get_OnHashValidate())(Storage->get_CryptUserData(), Buffer, Count, HashBuffer, Valid);		
	}
  	else
    	Result = -1;
	return Result;
}

Error __stdcall SolFSEncryptData(CallbackDataType UserData, PChar Key, LongWord KeyLength, PChar Data, LongWord DataSize, LongWord ObjectID, LongWord PageIndex)
{
	Error Result;
	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		Result = (Storage->get_OnDataEncrypt())(Storage->get_CryptUserData(), Key, KeyLength, Data, DataSize, ObjectID, PageIndex);
	}
  	else
    	Result = -1;
	return Result;
}

Error __stdcall SolFSDecryptData(CallbackDataType UserData, PChar Key, LongWord KeyLength, PChar Data, LongWord DataSize, LongWord ObjectID, LongWord PageIndex)
{
	Error Result;
	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		Result = (Storage->get_OnDataDecrypt())(Storage->get_CryptUserData(), Key, KeyLength, Data, DataSize, ObjectID, PageIndex);
	}
  	else
    	Result = -1;
	return Result;
}

Error __stdcall SolFSCompressData(CallbackDataType UserData, PChar InData, LongWord InDataSize, PChar OutData, LongWord *OutDataSize, LongWord CompressionLevel)
{
	Error Result;
	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		Result = (Storage->get_OnDataCompress())(Storage->get_CompressUserData(), InData, InDataSize, OutData, OutDataSize, CompressionLevel);
	}
  	else
    	Result = -1;
	return Result;
}

Error __stdcall SolFSDecompressData(CallbackDataType UserData, PChar InData, LongWord InDataSize, PChar OutData, LongWord *OutDataSize)
{
	Error Result;
	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		Result = (Storage->get_OnDataDecompress())(Storage->get_CompressUserData(), InData, InDataSize, OutData, OutDataSize);
	}
  	else
    	Result = -1;
	return Result;
}

void _stdcall SolFSProgress(CallbackDataType UserData, LongWord Operation, LongWord Progress, LongWord Total,
	Bool CanStop, Bool *Stop)
{
	if (Stop)
		*Stop = false;

	if (UserData != NULL)
	{
		SolFSStorage* Storage = (SolFSStorage*) UserData;
		CallbackDataType ProgressUserData = 0;
		if (Storage->get_OnProgress(NULL) != NULL)
			(Storage->get_OnProgress(&ProgressUserData))(ProgressUserData, Operation, Progress, Total, CanStop, Stop);
	}

	return;
}

unsigned long SolFSStorage::GetVersion()
{
  LongWord Result;
  CheckStorageResult(StorageGetVersion(&Result));
  return Result;
}

void SolFSStorage::SetRegistrationKey(char* Key)
{
	CheckStorageResult(StorageSetRegistrationKey((PChar)Key));
}

void SolFSStorage::CheckActive()
{
	if (m_Active == false)
	{
		CheckStorageResult(errStorageNotActive);
	}			
}

void SolFSStorage::CheckNotActive()
{
	if (m_Active == true)
	{
		CheckStorageResult(errStorageActive);
	}			
}

bool SolFSStorage::IsCB(void)
{
	return (m_OnCreateFile != NULL || 
			m_OnOpenFile != NULL ||
			m_OnDeleteFile != NULL || 
			m_OnCloseFile != NULL ||
			m_OnFlushFile != NULL ||
			m_OnSeekFile != NULL ||
			m_OnGetFileSize != NULL ||
			m_OnSetFileSize != NULL ||
			m_OnReadFile != NULL ||
			m_OnWriteFile != NULL
			);

}

void SolFSStorage::CheckCB(void)
{
	bool broken = false;
	if (m_OnCreateFile == NULL)
		broken = true;
	if (m_OnOpenFile == NULL)
		broken = true;
	if (m_OnCloseFile == NULL)
		broken = true;
	if (m_OnFlushFile == NULL)
		broken = true;
	if (m_OnGetFileSize == NULL)
		broken = true;
	if (m_OnSetFileSize == NULL)
		broken = true;
	if (m_OnSeekFile == NULL)
		broken = true;
	if (m_OnReadFile == NULL)
		broken = true;
	if (m_OnWriteFile == NULL)
		broken = true;
	if (broken)
		throw new ESolFSError(strCallbacksNotSet);

}

bool SolFSStorage::IsEncryptionCB(void)
{
	return (m_OnCalculateHash != NULL || 
			m_OnValidateHash != NULL ||
			m_OnEncryptData != NULL || 
			m_OnDecryptData != NULL);
}

void SolFSStorage::CheckEncryptionCB(void)
{
	bool broken = false;
	
	if (m_OnCalculateHash == NULL)
		broken = true;
	if (m_OnValidateHash == NULL)
		broken = true;
	if (m_OnEncryptData == NULL)
		broken = true;
	if (m_OnDecryptData == NULL)
		broken = true;
	if (broken)
		throw new ESolFSError(strCryptCallbackNotSet);
}

bool SolFSStorage::IsCompressionCB(void)
{
	return (m_OnCompressData != NULL || 
			m_OnDecompressData != NULL);
}

void SolFSStorage::CheckCompressionCB(void)
{
	bool broken = false;
	
	if (m_OnCompressData == NULL)
		broken = true;
	if (m_OnDecompressData == NULL)
		broken = true;
	if (broken)
		throw new ESolFSError(strCompressCallbackNotSet);
}

void SolFSStorage::Opened(void)
{
	Bool b;
	LongWord l;
	m_Active = true;
	
	CheckStorageResult(StorageSetAutoCompact(m_Storage, m_AutoCompact));
	CheckStorageResult(StorageSetCaseSensitive(m_Storage, m_CaseSensitive));
	CheckStorageResult(StorageSetBuffering(m_Storage, m_Buffering));

	CheckStorageResult(StorageIsReadOnly(m_Storage, &b));
	m_ReadOnly = b != 0;

	CheckStorageResult(StorageGetAutoCompact(m_Storage, &l));
	m_AutoCompact = l;
	
	PWideChar logo;			
	CheckStorageResult(StorageGetInfo(m_Storage, &l, &logo));
	m_PageSize = l;
	xwstrfree(&m_Logo);
	m_Logo = xwstrdup(logo);

	Bool fixedSize;
	unsigned __int64 totalSize, freeSpace;
	CheckStorageResult(StorageGetSizes(m_Storage, &fixedSize, &totalSize,
		&freeSpace));
	m_FixedSize = fixedSize != 0;
}

void SolFSStorage::Create(const PWideChar fileName, bool overwrite, long pageSize, const PWideChar logo)
{

	Handle storageHandle;
	if (m_Storage != 0)
		Close();
	
	if (IsCB())
    CheckStorageResult(StorageCreate(fileName,  overwrite, pageSize, logo, 
		  &storageHandle, m_PathSeparator, m_UseTransactions, m_UseAccessTime));
	
	CheckStorageResult(StorageSetCustomEncryptionHandlers(storageHandle, ((CallbackDataType) this), SolFSCalculateHash, SolFSValidateHash, SolFSEncryptData, SolFSDecryptData));
	CheckStorageResult(StorageSetCustomCompressionHandlers(storageHandle, ((CallbackDataType) this), SolFSCompressData, SolFSDecompressData));
	CheckStorageResult(StorageSetAutoCompact(storageHandle, m_AutoCompact));
	CheckStorageResult(StorageSetCaseSensitive(storageHandle, m_CaseSensitive));

	m_Storage = storageHandle;
	Opened();
}

void SolFSStorage::CreateCB(const PWideChar fileName, bool overwrite, long pageSize, const PWideChar logo)
{

	Handle storageHandle;
	if (m_Storage != 0)
		Close();
	
	CheckStorageResult(StorageCreateCB(
			fileName, 
			overwrite, pageSize,
			logo, 
			&storageHandle, m_PathSeparator,
			m_UseTransactions, m_UseAccessTime, m_ReadOnly,
			m_UserData, m_OnCreateFile, m_OnOpenFile, m_OnCloseFile, m_OnFlushFile, 
			m_OnDeleteFile, m_OnGetFileSize, m_OnSetFileSize, m_OnSeekFile, 
			m_OnReadFile, m_OnWriteFile));

		CheckStorageResult(StorageSetCustomEncryptionHandlers(storageHandle, ((CallbackDataType) this), SolFSCalculateHash, SolFSValidateHash, SolFSEncryptData, SolFSDecryptData));
		CheckStorageResult(StorageSetCustomCompressionHandlers(storageHandle, ((CallbackDataType) this), SolFSCompressData, SolFSDecompressData));
		CheckStorageResult(StorageSetAutoCompact(storageHandle, m_AutoCompact));
		CheckStorageResult(StorageSetCaseSensitive(storageHandle, m_CaseSensitive));

	m_Storage = storageHandle;
	Opened();
}

void SolFSStorage::Open(const PWideChar fileName)
{
	Handle storageHandle;
	if (m_Storage != 0)
		Close();

	CheckStorageResult(StorageOpen(fileName,  &storageHandle, m_PathSeparator, m_UseTransactions, m_UseAccessTime));

	CheckStorageResult(StorageSetCustomEncryptionHandlers(storageHandle, ((CallbackDataType) this), SolFSCalculateHash, SolFSValidateHash, SolFSEncryptData, SolFSDecryptData));
	CheckStorageResult(StorageSetCustomCompressionHandlers(storageHandle, ((CallbackDataType) this), SolFSCompressData, SolFSDecompressData));
	CheckStorageResult(StorageSetAutoCompact(storageHandle, m_AutoCompact));
	CheckStorageResult(StorageSetCaseSensitive(storageHandle, m_CaseSensitive));

	m_Storage = storageHandle;
	Opened();
}

void SolFSStorage::OpenReadOnly(const PWideChar fileName)
{
	Handle storageHandle;
	if (m_Storage != 0)
		Close();
	
	CheckStorageResult(StorageOpenReadOnly(fileName, &storageHandle, 
		m_PathSeparator, m_UseTransactions, m_UseAccessTime));

	CheckStorageResult(StorageSetCustomEncryptionHandlers(storageHandle, ((CallbackDataType) this), SolFSCalculateHash, SolFSValidateHash, SolFSEncryptData, SolFSDecryptData));
	CheckStorageResult(StorageSetCustomCompressionHandlers(storageHandle, ((CallbackDataType) this), SolFSCompressData, SolFSDecompressData));
	CheckStorageResult(StorageSetAutoCompact(storageHandle, m_AutoCompact));
	CheckStorageResult(StorageSetCaseSensitive(storageHandle, m_CaseSensitive));

	m_Storage = storageHandle;
	Opened();
}

void SolFSStorage::OpenCB(const PWideChar fileName)
{
	Handle storageHandle;
	if (m_Storage != 0)
		Close();

	CheckStorageResult(StorageOpenCB(
		fileName, &storageHandle, m_PathSeparator,
		m_UseTransactions, m_UseAccessTime, m_ReadOnly,
		m_UserData, m_OnCreateFile, m_OnOpenFile, m_OnCloseFile, m_OnFlushFile, 
			m_OnDeleteFile, m_OnGetFileSize, m_OnSetFileSize, m_OnSeekFile, 
			m_OnReadFile, m_OnWriteFile));

	CheckStorageResult(StorageSetCustomEncryptionHandlers(storageHandle, ((CallbackDataType) this), SolFSCalculateHash, SolFSValidateHash, SolFSEncryptData, SolFSDecryptData));
	CheckStorageResult(StorageSetCustomCompressionHandlers(storageHandle, ((CallbackDataType) this), SolFSCompressData, SolFSDecompressData));
	CheckStorageResult(StorageSetAutoCompact(storageHandle, m_AutoCompact));
	CheckStorageResult(StorageSetCaseSensitive(storageHandle, m_CaseSensitive));

	m_Storage = storageHandle;
	Opened();
}

void SolFSStorage::Init(const PWideChar fileName)
{		
	m_Active = false;
	m_ReadOnly = false;
	m_UseTransactions = false;
	m_UseAccessTime = false;
	m_PathSeparator = '\\';
	
	m_UserData = 0;
	m_CryptUserData = 0;
	m_CompressUserData = 0;
	m_ProgressUserData = 0;

	m_Logo = NULL;
  if (fileName != NULL)
	  m_FileName = xwstrdup(fileName);
  else
	  m_FileName = NULL;
	m_FilesPassword = NULL; 
	m_StoragePassword = NULL; 
	
	m_FilesEncryption = ecNoEncryption;
	m_StorageEncryption = ecNoEncryption;
	m_Compression = crNoCompression;
	
	m_AutoCompact = 25;			
	m_PageSize = 512;
	m_CompressionLevel = 0;
	m_FixedSize = false;
	m_CaseSensitive = true;
	m_MaxPageCount = 0;
	m_Buffering = 1;

	m_Storage = 0;

	m_OnCreateFile = NULL;
	m_OnOpenFile = NULL;
	m_OnCloseFile = NULL;
	m_OnFlushFile = NULL;
	m_OnDeleteFile = NULL;
	m_OnGetFileSize = NULL;
	m_OnSetFileSize = NULL;
	m_OnSeekFile = NULL;
	m_OnReadFile = NULL;
	m_OnWriteFile = NULL;

	m_OnEncryptData = NULL;
	m_OnDecryptData = NULL;
	m_OnCalculateHash = NULL;
	m_OnValidateHash = NULL;
	m_OnProgress = NULL;	
	m_OnCompressData = NULL;
	m_OnDecompressData = NULL;	
}

SolFSStorage::~SolFSStorage()
{
	Close();
	xwstrfree(&m_Logo);
	xwstrfree(&m_FileName);
	xwstrfree(&m_FilesPassword);
	xwstrfree(&m_StoragePassword);

}

SolFSStorage::SolFSStorage()
{
	Init(NULL);
}

SolFSStorage::SolFSStorage(const PWideChar fileName, bool useTransactions, bool useAccessTime, wchar_t pathSeparator)
{
	Init(fileName);
	m_UseTransactions = useTransactions;
	m_UseAccessTime = useAccessTime;
	m_PathSeparator = pathSeparator;
	
	Open(fileName);
}

SolFSStorage::SolFSStorage(const PWideChar fileName, bool useTransactions, bool useAccessTime, wchar_t pathSeparator, bool openReadOnly)
{
	Init(fileName);
	m_UseTransactions = useTransactions;
	m_UseAccessTime = useAccessTime;
	m_PathSeparator = pathSeparator;
	
	if (openReadOnly)
        OpenReadOnly(fileName);
	else
		Open(fileName);
}

/// <summary>
/// Creates new storage. fileName is the name of the storage file.
/// overwrite defines what to do if the file name exists.
/// Page size is a size in bytes (must be power of 2 with minimum size of 512 bytes). 
/// logo is a text string placed in the beginning of the file.
/// </summary>
SolFSStorage::SolFSStorage(const PWideChar fileName, bool overwrite,
	long pageSize, bool useTransactions, bool useAccessTime, wchar_t pathSeparator, const PWideChar logo)
{			
	Init(fileName);
	m_UseTransactions = useTransactions;
	m_UseAccessTime = useAccessTime;
	m_PathSeparator = pathSeparator;
	Create(fileName, overwrite, pageSize, logo);
}

/// <summary>
/// Opens existing storage. fileName is the name of the storage file
/// </summary>
SolFSStorage::SolFSStorage(const PWideChar fileName, bool useTransactions, bool useAccessTime, wchar_t pathSeparator, 
	CallbackDataType UserData,
	SolFSCreateFileFunc OnCreateFile, SolFSOpenFileFunc OnOpenFile,
	SolFSCloseFileFunc OnCloseFile, SolFSFlushFileFunc OnFlushFile, SolFSDeleteFileFunc OnDeleteFile,
	SolFSGetFileSizeFunc OnGetFileSize, SolFSSetFileSizeFunc OnSetFileSize, SolFSSeekFileFunc OnSeekFile,
	SolFSReadFileFunc OnReadFile, SolFSWriteFileFunc OnWriteFile)
{
	Init(fileName);
	m_UseTransactions = useTransactions;
	m_UseAccessTime = useAccessTime;
	m_PathSeparator = pathSeparator;
	
	m_UserData = UserData;
	m_OnCreateFile = OnCreateFile;
	m_OnOpenFile = OnOpenFile;
	m_OnCloseFile = OnCloseFile;
	m_OnFlushFile = OnFlushFile;
	m_OnDeleteFile = OnDeleteFile;
	m_OnGetFileSize = OnGetFileSize;
	m_OnSetFileSize = OnSetFileSize;
	m_OnSeekFile = OnSeekFile;
	m_OnReadFile = OnReadFile;
	m_OnWriteFile = OnWriteFile;

	CheckCB();
	
	OpenCB(fileName);			
}

SolFSStorage::SolFSStorage(const PWideChar fileName, bool overwrite, long pageSize, bool useTransactions, bool useAccessTime, 
	wchar_t pathSeparator, const PWideChar logo, 
	CallbackDataType UserData,
	SolFSCreateFileFunc OnCreateFile, SolFSOpenFileFunc OnOpenFile,
	SolFSCloseFileFunc OnCloseFile, SolFSFlushFileFunc OnFlushFile, SolFSDeleteFileFunc OnDeleteFile,
	SolFSGetFileSizeFunc OnGetFileSize, SolFSSetFileSizeFunc OnSetFileSize, SolFSSeekFileFunc OnSeekFile,
	SolFSReadFileFunc OnReadFile, SolFSWriteFileFunc OnWriteFile)
{
	Init(fileName);
	m_UseTransactions = useTransactions;
	m_UseAccessTime = useAccessTime;
	m_PathSeparator = pathSeparator;

	m_UserData = UserData;
	m_OnCreateFile = OnCreateFile;
	m_OnOpenFile = OnOpenFile;
	m_OnCloseFile = OnCloseFile;
	m_OnFlushFile = OnFlushFile;
	m_OnDeleteFile = OnDeleteFile;
	m_OnGetFileSize = OnGetFileSize;
	m_OnSetFileSize = OnSetFileSize;
	m_OnSeekFile = OnSeekFile;
	m_OnReadFile = OnReadFile;
	m_OnWriteFile = OnWriteFile;
	
	CheckCB();
	
	CreateCB(fileName, overwrite, pageSize, logo);
}

void SolFSStorage::Open(StorageOpenMode OpenMode)
{
	if (IsEncryptionCB())
		CheckEncryptionCB();

	bool Create, Overwrite;
	
	Overwrite = (OpenMode == somCreateAlways);

	if (IsCB())
	{
		Create = (OpenMode == somCreateAlways);
	}
	else if (::FileExists(m_FileName))
	{
		if (OpenMode == somCreateNew)
			throw new ESolFSSysError(strStorageFileDoesntExist);
		Create = (OpenMode == somCreateAlways);
	}
	else
	{
		if (OpenMode == somOpenExisting)
			throw new ESolFSSysError(strStorageFileAlreadyExists);
		Create = OpenMode != somOpenExisting;
	}
	if (IsCB())
	{
		CheckCB();
		if (Create)
			CreateCB(m_FileName, Overwrite, m_PageSize, m_Logo);
		else
			OpenCB(m_FileName);
	}
	else
	{
		if (Create)
			this->Create(m_FileName, Overwrite, m_PageSize, m_Logo);
		else
		if (m_ReadOnly)
			OpenReadOnly(m_FileName);
		else
			Open(m_FileName);
	}			
}

void SolFSStorage::Close()
{
	if (m_Storage != 0)
	{
		CheckStorageResult(StorageClose(m_Storage));
		m_Storage = 0;
		m_Active = false;
	}
}

SolFSEncryption	SolFSStorage::GetEncryption()
{
	LongWord Encryption;
	CheckActive();
	CheckStorageResult(StorageGetEncryption(m_Storage, &Encryption));
	return (SolFSEncryption) Encryption;
}

void SolFSStorage::SetPassword(const PWideChar Password)
{
	CheckActive();
	CheckStorageResult(StorageSetPassword(m_Storage, Password, xwcslen(Password)));
}

void SolFSStorage::SetEncryption(SolFSEncryption Encryption, const PWideChar OldPassword, const PWideChar NewPassword)
{
	CheckActive();
	CheckStorageResult(StorageSetEncryption(m_Storage, (LongWord) Encryption,
		OldPassword, xwcslen(OldPassword), NewPassword, xwcslen(NewPassword)));
	m_StorageEncryption = Encryption;
	m_StoragePassword = xwstrdup(NewPassword);
}
	
bool SolFSStorage::IsSolFSStorage(void)
{
	Error IOResult;
	CheckNotActive();
	if (IsCB())
	{
		CheckCB();
		IOResult = StorageIsValidStorageCB(m_FileName, 
			m_UserData, m_OnCreateFile, m_OnOpenFile, m_OnCloseFile, m_OnFlushFile, 
			m_OnDeleteFile, m_OnGetFileSize, m_OnSetFileSize, m_OnSeekFile, 
			m_OnReadFile, m_OnWriteFile);
	}
	else
	{
		IOResult = StorageIsValidStorage(m_FileName);
	}
	if (IOResult == 0)
		return true;
	else
	if (IOResult == errInvalidStorageFile)
		return false;
	else
	{
		CheckStorageResult(IOResult);
		// for stupid compilers
		return false;
	}
}

void SolFSStorage::CheckAndRepair(unsigned long Flags)
{
	CheckNotActive();
	if (IsCB())
	{
		CheckCB();
		CheckStorageResult(StorageCheckAndRepairCB(m_FileName,
			m_PageSize, Flags, m_StoragePassword, xwcslen(m_StoragePassword), 
			(CallbackDataType) this, SolFSProgress,
			m_UserData, m_OnCreateFile, m_OnOpenFile, m_OnCloseFile, m_OnFlushFile, 
			m_OnDeleteFile, m_OnGetFileSize, m_OnSetFileSize, m_OnSeekFile, 
			m_OnReadFile, m_OnWriteFile));
	}
	else
		CheckStorageResult(StorageCheckAndRepair(m_FileName,
			m_PageSize, Flags, m_StoragePassword, xwcslen(m_StoragePassword), (CallbackDataType) this, SolFSProgress));
}

void SolFSStorage::FormatFixedSize(__int64 FileSize, unsigned long Flags)
{
	CheckNotActive();
	if (IsCB())
	{
		CheckCB();
		CheckStorageResult(StorageFormatFixedSizeCB(m_FileName, FileSize, 
			m_PageSize, m_Logo, Flags, (CallbackDataType) this, SolFSProgress,
			m_UserData, m_OnCreateFile, m_OnOpenFile, m_OnCloseFile, m_OnFlushFile, 
			m_OnDeleteFile, m_OnGetFileSize, m_OnSetFileSize, m_OnSeekFile, 
			m_OnReadFile, m_OnWriteFile));
	}
	else
		CheckStorageResult(StorageFormatFixedSize(m_FileName,
			FileSize, m_PageSize, m_Logo, Flags, (CallbackDataType) this, SolFSProgress));
}

bool SolFSStorage::Compact(void)
{
	CheckActive();
	Bool Result;
	CheckStorageResult(StorageCompactEx(m_Storage, &Result, 0, this, SolFSProgress));
	return Result != 0;
}

SolFSStream* SolFSStorage::OpenRootData()
{
	CheckActive();

	Handle streamHandle;
	CheckStorageResult(StorageOpenRootData(m_Storage, &streamHandle));

	SolFSStream *Result = new SolFSStream(streamHandle);
	return Result;
}

__int64	SolFSStorage::get_DiskSize(void)
{
	CheckActive();

	Bool fixedSize;
	unsigned __int64 totalSize, freeSpace;
	CheckStorageResult(StorageGetSizes(m_Storage, &fixedSize, &totalSize, &freeSpace));
	
	return totalSize;	
}

void SolFSStorage::set_DiskSize(__int64 Value)
{
  CheckActive();

  CheckStorageResult(StorageSetStorageSize(m_Storage, Value, 
    this, SolFSProgress));
}

__int64 SolFSStorage::DiskFree(void)
{
	CheckActive();

	Bool fixedSize;
	unsigned __int64 totalSize, freeSpace;
	CheckStorageResult(StorageGetSizes(m_Storage, &fixedSize, &totalSize, &freeSpace));
	
	return freeSpace;
}
	
bool SolFSStorage::FileExists(const PWideChar FileName)
{
	Bool Result;

	CheckActive();
	
	CheckStorageResult(StorageFileExists(m_Storage, FileName, &Result));
	
	return Result != 0;
}

void SolFSStorage::DeleteFile(const PWideChar FileName)
{
	CheckActive();
	
	CheckStorageResult(StorageDeleteFile(m_Storage, FileName));
}

void SolFSStorage::DeleteFileW(const PWideChar FileName)
{
	CheckActive();
	
	CheckStorageResult(StorageDeleteFile(m_Storage, FileName));
}

void SolFSStorage::MoveFile(const PWideChar OldFileName, const PWideChar NewFileName)
{
	CheckActive();
	CheckStorageResult(StorageMoveFile(m_Storage, OldFileName, NewFileName));
}

void SolFSStorage::MoveFileW(const PWideChar OldFileName, const PWideChar NewFileName)
{
	CheckActive();
	CheckStorageResult(StorageMoveFile(m_Storage, OldFileName, NewFileName));
}

void SolFSStorage::DeleteAndRenameFile(const PWideChar OldFileName, const PWideChar NewFileName)
{
	CheckActive();
	CheckStorageResult(StorageDeleteAndRenameFile(m_Storage, OldFileName, NewFileName));
}

bool SolFSStorage::FindFirst(TStorageSearch &Search, const PWideChar Mask, unsigned long Attributes)
{
	return FindFirstEx(Search, Mask, Attributes,
		ffNeedFullName | ffNeedFileTimes | ffNeedFileSize);
}

bool SolFSStorage::FindFirstEx(TStorageSearch &Search, const PWideChar Mask, unsigned long Attributes, unsigned long Flags)
{
	CheckActive();
	int Result = StorageFindFirstEx(m_Storage, &Search, Mask, Attributes, Flags);

	if (Result != 0 && Result != errNoMoreFiles)
		CheckStorageResult(Result);

	if (Result == 0)
	{
		Search.Creation = DateTimeUTCToLocal(Search.Creation);
		Search.Modification = DateTimeUTCToLocal(Search.Modification);
		Search.LastAccess = DateTimeUTCToLocal(Search.LastAccess);
	}
	return Result == 0;
}

bool SolFSStorage::FindNext(TStorageSearch &Search)
{
	CheckActive();
	
	int Result = StorageFindNext(m_Storage, &Search);

	if (Result != 0 && Result != errNoMoreFiles)
		CheckStorageResult(Result);
	
	if (Result == 0)
	{
		Search.Creation = DateTimeUTCToLocal(Search.Creation);
		Search.Modification = DateTimeUTCToLocal(Search.Modification);
		Search.LastAccess = DateTimeUTCToLocal(Search.LastAccess);
	}
	return Result == 0;
}

void SolFSStorage::FindClose(TStorageSearch &Search)
{
	CheckActive();
	
	int Result = StorageFindClose(m_Storage, &Search);

	if (Result != 0)
		CheckStorageResult(Result);
}

void SolFSStorage::CreateDirectory(const PWideChar Directory)
{
	CheckActive();
	CheckStorageResult(StorageCreateDirectory(m_Storage, Directory));
}

void  SolFSStorage::CreateDirectoryW(const PWideChar Directory)
{
	CheckActive();
	CheckStorageResult(StorageCreateDirectory(m_Storage, Directory));
}

void SolFSStorage::ForceCreateDirectories(const PWideChar Path)
{
	CheckActive();
	CheckStorageResult(StorageForceCreateDirectories(m_Storage, Path));
}

bool SolFSStorage::IsDirectoryEmpty(const PWideChar Directory)
{
	Bool Value;
	CheckActive();
	CheckStorageResult(StorageIsDirectoryEmpty(m_Storage, Directory,
		&Value));
	return Value != 0;
}

void SolFSStorage::DeleteDirectory(const PWideChar Directory)
{
	CheckActive();
	CheckStorageResult(StorageDeleteDirectory(m_Storage, Directory));
}	

DateTime SolFSStorage::GetFileCreationTime(const PWideChar FileName)
{
	CheckActive();
	DateTime Result;
	CheckStorageResult(StorageGetFileCreationTime(m_Storage, FileName, &Result));
	return DateTimeUTCToLocal(Result);
}

void SolFSStorage::SetFileCreationTime(const PWideChar FileName, DateTime Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileCreationTime(m_Storage, FileName, DateTimeLocalToUTC(Value)));
}

DateTime SolFSStorage::GetFileModificationTime(const PWideChar FileName)
{
	CheckActive();
	DateTime Result;
	CheckStorageResult(StorageGetFileModificationTime(m_Storage, FileName, &Result));
	return DateTimeUTCToLocal(Result);
}

void SolFSStorage::SetFileModificationTime(const PWideChar FileName, DateTime Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileModificationTime(m_Storage, FileName, DateTimeLocalToUTC(Value)));
}
	
DateTime SolFSStorage::GetFileLastAccessTime(const PWideChar FileName)
{
	CheckActive();
	DateTime Result;
	CheckStorageResult(StorageGetFileLastAccessTime(m_Storage, FileName, &Result));
	return DateTimeUTCToLocal(Result);
}

void SolFSStorage::SetFileLastAccessTime(const PWideChar FileName, DateTime Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileLastAccessTime(m_Storage, FileName, DateTimeLocalToUTC(Value) ));
}

SolFSEncryption	SolFSStorage::GetFileEncryption(const PWideChar FileName)
{
	CheckActive();
	LongWord Result;
	CheckStorageResult(StorageGetFileEncryption(m_Storage, FileName, &Result));
	return (SolFSEncryption) Result;
}

void SolFSStorage::SetFileEncryption(const PWideChar FileName, SolFSEncryption Encryption, const PWideChar 
	OldPassword, const PWideChar NewPassword)
{
	CheckActive();
	CheckStorageResult(StorageSetFileEncryption(m_Storage, FileName, (unsigned long) Encryption, OldPassword, xwcslen(OldPassword), NewPassword, xwcslen(NewPassword)));
}

bool SolFSStorage::CheckFilePassword(const PWideChar FileName, const PWideChar Password, bool EncryptionUnknown, 
	SolFSEncryption Encryption)
{
	Bool Result;
	CheckActive();

	CheckStorageResult(StorageCheckFilePassword(m_Storage, FileName, (unsigned long) Encryption, EncryptionUnknown, 
					Password, xwcslen(Password), &Result));
	return Result != 0;
}

void SolFSStorage::GetFileCompression(const PWideChar FileName, SolFSCompression &Compression, unsigned long
							&CompressionLevel, unsigned long &PagesPerCluster)
{
	CheckActive();
	LongWord compr = 0;
	
	CheckStorageResult(StorageGetFileCompression(m_Storage, FileName, &compr, (PLongWord)&CompressionLevel, (PLongWord)&PagesPerCluster));
	Compression = (SolFSCompression) compr;
}

void SolFSStorage::SetFileCompression(const PWideChar FileName, SolFSCompression Compression, unsigned long 
							CompressionLevel, unsigned long PagesPerCluster, const PWideChar Password)
{
	CheckActive();
	CheckStorageResult(StorageSetFileCompression(m_Storage, FileName, Compression, CompressionLevel, PagesPerCluster, Password, xwcslen(Password)));
}

void SolFSStorage::GetFileAttributes(const PWideChar FileName, unsigned long &Attributes)
{
	CheckActive();
	CheckStorageResult(StorageGetFileAttributes(m_Storage, FileName, (PLongWord)&Attributes));
}

void SolFSStorage::GetFileAttributesW(const PWideChar FileName, unsigned long &Attributes)
{
	CheckActive();
	CheckStorageResult(StorageGetFileAttributes(m_Storage, FileName, (PLongWord)&Attributes));
}

void SolFSStorage::SetFileAttributes(const PWideChar FileName, unsigned long Attributes)
{
	CheckActive();
	CheckStorageResult(StorageSetFileAttributes(m_Storage, FileName, Attributes));
}

void SolFSStorage::SetFileAttributesW(const PWideChar FileName, unsigned long Attributes)
{
	CheckActive();
	CheckStorageResult(StorageSetFileAttributes(m_Storage, FileName, Attributes));
}

unsigned long SolFSStorage::GetFileTagInfo(const PWideChar FileName, unsigned short TagID, bool* TagExists)
{
	CheckActive();
	LongWord result = 0;
	Bool exists = false;
	Error SolFSResult = StorageGetFileTagInfo(m_Storage, FileName, TagID, &exists, &result);

	if (SolFSResult != 0) 
		CheckStorageResult(SolFSResult);
	*TagExists = exists != 0;

	return result;
}

unsigned long SolFSStorage::GetFileTag(const PWideChar FileName, unsigned short TagID, void* TagData, unsigned long TagDataSize)
{
	CheckActive();
	LongWord result = TagDataSize;
	Error SolFSResult = StorageGetFileTag(m_Storage, FileName, TagID, TagData, &result);

	if (SolFSResult != errBufferTooSmall && SolFSResult != 0) 
		CheckStorageResult(SolFSResult);

	return result;
}

void SolFSStorage::SetFileTag(const PWideChar FileName, unsigned short TagID, void* TagData, unsigned long TagDataSize)
{
	CheckActive();
	CheckStorageResult(StorageSetFileTag(m_Storage, FileName, TagID, TagData, TagDataSize));
}

void SolFSStorage::DeleteFileTag(const PWideChar FileName, unsigned short TagID)
{
	CheckActive();
	CheckStorageResult(StorageDeleteFileTag(m_Storage, FileName, TagID));
}

void SolFSStorage::Link(const PWideChar LinkName, const PWideChar DestinationName)
{
	CheckActive();
	CheckStorageResult(StorageLink(m_Storage, LinkName, DestinationName));
}

void SolFSStorage::GetLinkDestination(const PWideChar LinkName, PWideChar &DestinationName)
{
    Error StorageResult;
	LongWord BufferSize;

	CheckActive();

	BufferSize = 0;
	StorageResult = StorageGetLinkDestinationEx(m_Storage, LinkName,
		nil, &BufferSize);
	if (StorageResult == errBufferTooSmall)
	{
		DestinationName = new WideChar[BufferSize / sizeof(WideChar)];
		CheckStorageResult(StorageGetLinkDestinationEx(m_Storage, LinkName,
			DestinationName, &BufferSize));
	}
	else
		CheckStorageResult(StorageResult);
}

void SolFSStorage::AddTagName(unsigned short TagID, SolFSTagValueType TagValueType, const PWideChar TagName)
{
	CheckActive();
	CheckStorageResult(StorageAddTagName(m_Storage, TagID, TagValueType, TagName));
}

void SolFSStorage::DeleteTagName(unsigned short TagID)
{
	CheckActive();
	CheckStorageResult(StorageDeleteTagName(m_Storage, TagID));
}

int SolFSStorage::GetTagNamesCount()
{
	LongWord Count;
	CheckActive();
	CheckStorageResult(StorageGetTagNamesCount(m_Storage, &Count));
	return (int)Count;
}

void SolFSStorage::GetTagName(int Index, unsigned short &TagID, SolFSTagValueType &TagValueType, PWideChar &TagName)
{
    Error StorageResult;
	LongWord BufferSize;
	Word ValueType;

	CheckActive();

	BufferSize = 0;
	StorageResult = StorageGetTagName(m_Storage, 
		Index, &TagID, &ValueType, nil, &BufferSize);
	if (StorageResult == errBufferTooSmall)
	{
		TagName = new WideChar[BufferSize / sizeof(WideChar)];
		CheckStorageResult(StorageGetTagName(m_Storage, 
			Index, &TagID, &ValueType, TagName, &BufferSize));
	}
	else
		CheckStorageResult(StorageResult);

	TagValueType = (SolFSTagValueType)ValueType;
}

void SolFSStorage::SetFileTagAsBool(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, bool Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileTagAsBool(m_Storage, 
		FileName, TagName, TagID, (Bool)Value));
}

bool SolFSStorage::GetFileTagAsBool(const PWideChar FileName, const PWideChar TagName, unsigned short TagID)
{
	Bool Value;
	CheckActive();
	CheckStorageResult(StorageGetFileTagAsBool(m_Storage, 
		FileName, TagName, TagID, &Value));
	return (Value != False);
}

void SolFSStorage::SetFileTagAsString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PWideChar Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileTagAsString(m_Storage, 
		FileName, TagName, TagID, Value));
}

void SolFSStorage::GetFileTagAsString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PWideChar &Value)
{
    Error StorageResult;
	LongWord BufferSize;

	CheckActive();

	BufferSize = 0;
	StorageResult = StorageGetFileTagAsString(m_Storage, 
		FileName, TagName, TagID, nil, &BufferSize);
	if (StorageResult == errBufferTooSmall)
	{
		Value = new WideChar[BufferSize / sizeof(WideChar)];
		CheckStorageResult(StorageGetFileTagAsString(m_Storage, 
			FileName, TagName, TagID, Value, &BufferSize));
	}
	else
		CheckStorageResult(StorageResult);
}

void SolFSStorage::SetFileTagAsAnsiString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PChar Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileTagAsAnsiString(m_Storage, 
		FileName, TagName, TagID, Value));
}

void SolFSStorage::GetFileTagAsAnsiString(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, PChar &Value)
{
    Error StorageResult;
	LongWord BufferSize;

	CheckActive();

	BufferSize = 0;
	StorageResult = StorageGetFileTagAsAnsiString(m_Storage, 
		FileName, TagName, TagID, nil, &BufferSize);
	if (StorageResult == errBufferTooSmall)
	{
		Value = new Char[BufferSize];
		CheckStorageResult(StorageGetFileTagAsAnsiString(m_Storage, 
			FileName, TagName, TagID, Value, &BufferSize));
	}
	else
		CheckStorageResult(StorageResult);
}

void SolFSStorage::SetFileTagAsDateTime(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, DateTime Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileTagAsDateTime(m_Storage, 
		FileName, TagName, TagID, DateTimeLocalToUTC(Value)));
}

DateTime SolFSStorage::GetFileTagAsDateTime(const PWideChar FileName, const PWideChar TagName, unsigned short TagID)
{
	DateTime Value;
	CheckActive();
	CheckStorageResult(StorageGetFileTagAsDateTime(m_Storage, 
		FileName, TagName, TagID, &Value));
	return DateTimeUTCToLocal(Value);	
}

void SolFSStorage::SetFileTagAsNumber(const PWideChar FileName, const PWideChar TagName, unsigned short TagID, LongLongWord Value)
{
	CheckActive();
	CheckStorageResult(StorageSetFileTagAsNumber(m_Storage, 
		FileName, TagName, TagID, Value));
}

LongLongInt SolFSStorage::GetFileTagAsNumber(const PWideChar FileName, const PWideChar TagName, unsigned short TagID)
{
	LongLongInt Value;
	CheckActive();
	CheckStorageResult(StorageGetFileTagAsNumber(m_Storage, 
		FileName, TagName, TagID, &Value));
	return Value;
}

void SolFSStorage::DeleteFileTagByName(const PWideChar FileName, const PWideChar TagName)
{
	CheckActive();
	CheckStorageResult(StorageDeleteFileTagByName(m_Storage, 
		FileName, TagName));
}

bool SolFSStorage::FindByQueryFirst(TStorageSearch &Search, const PWideChar Directory, const PWideChar Query, long Flags)
{
	CheckActive();
	int Result = StorageFindByQueryFirst(m_Storage, Directory, &Search, Query, Flags);

	if (Result != 0 && Result != errNoMoreFiles)
		CheckStorageResult(Result);

	if (Result == 0)
	{
		Search.Creation = DateTimeUTCToLocal(Search.Creation);
		Search.Modification = DateTimeUTCToLocal(Search.Modification);
		Search.LastAccess = DateTimeUTCToLocal(Search.LastAccess);
	}
	return Result == 0;
}

bool SolFSStorage::FindByQueryNext(TStorageSearch &Search)
{
	CheckActive();
	int Result = StorageFindByQueryNext(m_Storage, &Search);

	if (Result != 0 && Result != errNoMoreFiles)
		CheckStorageResult(Result);

	if (Result == 0)
	{
		Search.Creation = DateTimeUTCToLocal(Search.Creation);
		Search.Modification = DateTimeUTCToLocal(Search.Modification);
		Search.LastAccess = DateTimeUTCToLocal(Search.LastAccess);
	}
	return Result == 0;
}

void SolFSStorage::FindByQueryClose(TStorageSearch &Search)
{
	CheckActive();
	CheckStorageResult(StorageFindByQueryClose(m_Storage, &Search));
}

bool SolFSStorage::get_IsCorrupted()
{
	Bool Value;
    CheckActive();
	CheckStorageResult(StorageIsCorrupted(m_Storage, &Value));
	return (Value != False);
}

unsigned long SolFSStorage::get_MaxPageCount()
{
	LongWord Value;

	if (m_Active)
	{
		CheckStorageResult(StorageGetMaxPageCount(m_Storage, &Value));
		m_MaxPageCount = Value;
	}
	return m_MaxPageCount;
}

void SolFSStorage::set_MaxPageCount(const unsigned long Value)
{
	if ((Value < 8) || (Value == 0))
    CheckStorageResult(errInvalidParameter);
	m_MaxPageCount = Value;
	if (m_Active)
		CheckStorageResult(StorageSetMaxPageCount(m_Storage, m_MaxPageCount));
}

DateTime SolFSStorage::get_LastAccessTime()
{
	DateTime Result;

	CheckActive();
	CheckStorageResult(StorageGetLastAccessTime(m_Storage, &Result));
	return DateTimeUTCToLocal(Result);
}

DateTime SolFSStorage::get_LastWriteTime()
{
	DateTime Result;

	CheckActive();
	CheckStorageResult(StorageGetLastWriteTime(m_Storage, &Result));
	return DateTimeUTCToLocal(Result);
}

void SolFSStorage::set_ReadOnly(const bool Value)
{
	CheckNotActive();
	m_ReadOnly = Value;
}
		
void SolFSStorage::set_PageSize(const unsigned long Value)
{
	CheckNotActive();
	m_PageSize = Value;
}

unsigned long SolFSStorage::get_Buffering()
{
	LongWord Value;

	CheckActive();
	CheckStorageResult(StorageGetBuffering(m_Storage, &Value));
	return Value;
}

void SolFSStorage::set_Buffering(const unsigned long Value)
{
	CheckActive();
	CheckStorageResult(StorageSetBuffering(m_Storage, Value));
}

unsigned long SolFSStorage::get_MaxTransactionSize()
{
	LongWord Value;

	CheckActive();
	CheckStorageResult(StorageGetBuffering(m_Storage, &Value));
	return Value;
}

void SolFSStorage::set_MaxTransactionSize(const unsigned long Value)
{
	CheckActive();
	CheckStorageResult(StorageSetBuffering(m_Storage, Value));
}

void SolFSStorage::set_Logo(const PWideChar Value)
{
	m_Logo = xwstrdup(Value);
	if (get_Active())
		CheckStorageResult(StorageSetLogo(m_Storage, Value));
}

void SolFSStorage::set_FileName(const PWideChar Value)
{
	CheckNotActive();
			
	xwstrfree(&m_FileName);

	m_FileName = xwstrdup(Value);
}
	
void SolFSStorage::set_PathSeparator(const WideChar Value)
{
	CheckNotActive();

	m_PathSeparator = Value;
}

void SolFSStorage::set_UseTransactions(const bool Value)
{
	CheckNotActive();

	m_UseTransactions = Value;
}

void SolFSStorage::set_UseAccessTime(const bool Value)
{
	CheckNotActive();

	m_UseAccessTime = Value;
}

void SolFSStorage::set_AutoCompact(const unsigned long Value)
{
	if (m_Active)
		CheckStorageResult(StorageSetAutoCompact(m_Storage, Value));
	m_AutoCompact = Value;
}

void SolFSStorage::set_CaseSensitive(const bool Value)
{
	CheckNotActive();

	m_CaseSensitive = Value;
}

	
void SolFSStorage::set_FilesEncryption(const SolFSEncryption Value)
{
	m_FilesEncryption = Value;
}

void SolFSStorage::set_StorageEncryption(const SolFSEncryption Value)
{
	CheckNotActive();
	
	m_StorageEncryption = Value;
}

void SolFSStorage::set_FilesPassword(const PWideChar Value)
{
	xwstrfree(&m_FilesPassword);

	m_FilesPassword = xwstrdup(Value);
}

void SolFSStorage::set_StoragePassword(const PWideChar Value)
{
	//CheckNotActive();
	xwstrfree(&m_StoragePassword);
	m_StoragePassword = xwstrdup(Value);
  if (m_Active)
    SetPassword(m_StoragePassword);
}


void SolFSStorage::set_Compression(const SolFSCompression Value)
{
	m_Compression = Value;
}

void SolFSStorage::set_CompressionLevel(const unsigned long Value)
{
	m_CompressionLevel = Value;
}
	
// ========================== SolFSStream ========================== 

void SolFSStream::InternalCreate(SolFSStorage *Storage, const PWideChar FileName, bool OpenExisting, bool TruncateExisting,
			bool ReadEnabled, bool WriteEnabled, bool ShareDenyRead, bool ShareDenyWrite,
			const PWideChar Password, unsigned long Encryption, long Reseved,
			SolFSCompression Compression, unsigned long CompressionLevel, unsigned short PagesPerCluster)
{
	//Bool fileExist;
	Handle streamHandle;

	//inherited Create;
	m_Closed = false;
	m_Stream = 0;
	m_Position = 0;
	m_CanRead = ReadEnabled;
	m_CanWrite = WriteEnabled;

	unsigned long pwdlen;
	
	if (!Password)
		pwdlen = 0;
	else
		pwdlen = wcslen((wchar_t*)Password) * sizeof(WideChar);

	if (Compression == crNoCompression)
		CheckStorageResult(StorageCreateFile(Storage->get_Storage(),  FileName,
			ReadEnabled, WriteEnabled, ShareDenyRead, ShareDenyWrite,
			Encryption, Password, pwdlen, &streamHandle, 
			OpenExisting, TruncateExisting));
	else
		CheckStorageResult(StorageCreateFileCompressed(
			Storage->get_Storage(),  FileName,
			ReadEnabled, WriteEnabled, ShareDenyRead, ShareDenyWrite,
			Encryption, Password, pwdlen, 
			Compression, CompressionLevel, PagesPerCluster, &streamHandle, 
			OpenExisting, TruncateExisting));
	
	m_Stream = streamHandle;
}

SolFSStream::SolFSStream(Handle stream)
{
	m_Closed = false;
	m_Stream = 0;
	m_Position = 0;
	m_CanRead = true;
	m_CanWrite = true;	
	m_Stream = stream;
}

SolFSStream::SolFSStream(SolFSStorage *Storage, const PWideChar FileName, const PWideChar mode)
{
	bool OpenExisting = false;
	bool TruncateExisting = false;
	bool ReadEnabled = false;
	bool WriteEnabled = false;
	bool ShareDenyRead = false;
	bool ShareDenyWrite = false;
	bool append = false;

	if (wcscmp((wchar_t*)mode, WIDE("r")) == 0)
	{
		ReadEnabled = true;
		OpenExisting = true;
	}
	else
	if (wcscmp((wchar_t*)mode, WIDE("w")) == 0)
	{
		WriteEnabled =true;
		OpenExisting = false;
		TruncateExisting = true;
	}
	else
	if (wcscmp((wchar_t*)mode, WIDE("a")) == 0)
	{
		WriteEnabled = true;
		OpenExisting = false;
		TruncateExisting = false;
		append = true;
	}
	else
	if (wcscmp((wchar_t*)mode, WIDE("a+")) == 0)
	{
		ReadEnabled = true;
		WriteEnabled = true;
		OpenExisting = false;
		TruncateExisting = false;
		append = true;
	}
	else
	if (wcscmp((wchar_t*)mode, WIDE("r+")) == 0)
	{
		ReadEnabled = true;
		WriteEnabled = true;
		OpenExisting = true;
		TruncateExisting = false;

	}
	else
	if (wcscmp((wchar_t*)mode, WIDE("w+")) == 0)
	{
		ReadEnabled = true;
		WriteEnabled = true;
		OpenExisting = true;
		TruncateExisting = true;
	}

	InternalCreate(Storage, FileName, OpenExisting, TruncateExisting,
		ReadEnabled, WriteEnabled, ShareDenyRead, ShareDenyWrite,
		Storage->get_FilesPassword(), Storage->get_FilesEncryption(), 0,
		Storage->get_Compression(), Storage->get_CompressionLevel(), 16);

	if (append)
		Seek(0, soFromEnd);
}

SolFSStream::SolFSStream(SolFSStorage *Storage, const PWideChar FileName, bool CreateNew, 
			bool ReadEnabled, bool WriteEnabled,
			bool ShareDenyRead, bool ShareDenyWrite,
			const PWideChar Password, SolFSEncryption Encryption, long Reseved,
			SolFSCompression Compression, unsigned long CompressionLevel,
			unsigned short PagesPerCluster)
{
	InternalCreate(Storage, FileName, !CreateNew, CreateNew,
		ReadEnabled, WriteEnabled, ShareDenyRead, ShareDenyWrite,
		Password, Encryption, Reseved, 
		Compression, CompressionLevel, PagesPerCluster);
}


SolFSStream::~SolFSStream()
{
	if (m_Stream != 0)
		Close();
}

void SolFSStream::CheckClosed()
{
	if (m_Closed)
	{
		CheckStorageResult(errInvalidStreamHandle);
	}
}

void SolFSStream::Close()
{
	CheckClosed();
	CheckStorageResult(StorageCloseFile(m_Stream));
	m_Stream = 0;
	m_Closed = true;
}

void SolFSStream::Flush(void)
{
	CheckClosed();
	CheckStorageResult(StorageFlushFile(m_Stream));
}

LongWord SolFSStream::Read(void *Buffer, unsigned long Count)
{
	if (!m_CanRead)
		return 0;
	Error ioResult;
	LongWord filePosition, Result;
	CheckClosed();

	CheckStorageResult(StorageTellFile(m_Stream, &filePosition));
	if (m_Position != filePosition)
	{
		filePosition = (LongInt)m_Position;
		CheckStorageResult(StorageSeekFile(m_Stream, filePosition, soFromBegin, &filePosition));
		m_Position = filePosition;
	}
	Result = 0;
	ioResult = StorageReadFile(m_Stream, (void*)Buffer, Count, &Result);
	if (Result == 0)
		CheckStorageResult(ioResult);

	m_Position += Result;
	return Result;
}

LongWord SolFSStream::Write(const void *Buffer, unsigned long Count)
{
	if (!m_CanWrite)
		return 0;
	Error ioResult;
	LongWord filePosition, Result;
	CheckClosed();
	
	CheckStorageResult(StorageTellFile(m_Stream, &filePosition));
	if (m_Position != filePosition)
	{
		filePosition = (LongInt)m_Position;
		CheckStorageResult(StorageSeekFile(m_Stream, filePosition, soFromBegin, &filePosition));
		m_Position = filePosition;
	}
	Result = 0;
	ioResult = StorageWriteFile(m_Stream, (void*)Buffer, Count, &Result);
	if (Result == 0)
		CheckStorageResult(ioResult);

	m_Position += Result;
	return Result;
}

LongLongWord SolFSStream::Seek(LongLongWord Offset, SeekOrigin Origin)
{
	CheckClosed();

	switch (Origin)
	{

	case soFromBegin: 
		{
			set_Position(Offset);
			break;
		}
	case soFromCurrent:  
		{
			set_Position(m_Position + Offset);
			break;
		}
	case soFromEnd:
		{
			LongLongWord fileSize;
			CheckStorageResult(StorageGetFileDataSizeLong(m_Stream, &fileSize));
			set_Position(fileSize + Offset);
			break;
		}
	}
	return m_Position;
}

LongLongWord SolFSStream::get_Length()
{
	CheckClosed(); 
	LongLongWord Result;
	CheckStorageResult(StorageGetFileDataSizeLong(m_Stream, &Result));
	return Result;
}

void SolFSStream::set_Position(LongLongWord Value) 
{ 
	CheckClosed(); 
	LongLongWord FileSize;
	CheckStorageResult(StorageGetFileDataSizeLong(m_Stream, &FileSize));
	if (m_Position <= FileSize)
		m_Position = Value; 
	else
	{
		CheckStorageResult(StorageSetFileDataSizeLong(m_Stream, Value));
		m_Position = Value; 
	}
}

void SolFSStream::set_Length(LongLongWord value)
{
	CheckClosed();
	CheckStorageResult(StorageSetFileDataSizeLong(m_Stream, value));
}


void xtstrfree(LPTSTR *text)
{
	if (*text)
		free(*text);
	*text = NULL;
}

void xwstrfree(PWideChar *text)
{
	if (*text)
		free(*text);
	*text = NULL;
}

PWideChar xwstrdup(PWideChar text)
{
	PWideChar result;
	if (!text)
	{
		result = (PWideChar) malloc(sizeof(WideChar));
		*result = 0;
		return result;
	}
	else
	{
		result = (PWideChar) malloc((wcslen((wchar_t*)text) + 1) * sizeof(WideChar));
		wcscpy((wchar_t*)result, (wchar_t*)text);
		return result;
	}
};

/*
LPTSTR xtstrdup(LPTSTR text)
{
	LPTSTR result;
	if (!text)
	{
		result = (LPTSTR) malloc(sizeof(TCHAR));
		*result = 0;
		return result;
	}
	else
	{
		result = (LPTSTR) malloc((_tcslen(text) + 1) * sizeof(TCHAR));
		_tcscpy(result, text);
		return result;
	}
};
*/
unsigned long xwcslen(PWideChar text)
{
	if (text)
		return wcslen((wchar_t*)text) * sizeof(WideChar);
	else
		return 0;
};

/*
#pragma pop_macro("CreateDirectory")
#pragma pop_macro("DeleteFile")
#pragma pop_macro("MoveFile")
#pragma pop_macro("GetFileAttributes")
#pragma pop_macro("SetFileAttributes")
*/

#ifdef USE_NAMESPACE
}
#endif
