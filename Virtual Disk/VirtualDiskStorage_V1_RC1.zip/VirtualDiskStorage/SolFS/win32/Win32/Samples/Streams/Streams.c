
#include <stdio.h>
#include "../../../StoreDecl.h"

int main(int argc, char* argv[])
{
	Error result;
	Handle storage, file;
	char buffer[1000];
	int i;
	unsigned long done;

	printf("SolFS streams example\n");

	// Creting storage in file test.st
	result = StorageCreate(L"test.st", True, 512, NULL, &storage, '/', 
		False, False);
	if (result != 0)
		printf("SolFS error: %d\n", result);
	else
	{
		// filling buffer 
		for (i = 0; i < 1000; i++)
			buffer[i] = '0' + i % 10;

		// creating and opening file /file.txt		
		result = StorageCreateFile(storage, L"/file.txt", True, True, True, True, 
			ecNoEncryption,	NULL, 0, &file, False, False);
		if (result != 0)
			printf("SolFS error: %d\n", result);
		else
		{
			// writing buffer in the file 10 times
			for (i = 0; i < 10; i++)
			{
				result = StorageWriteFile(file, buffer, 1000, &done);
				if (result != 0)
				{
					printf("SolFS error: %d\n", result);
					break;
				}
			}
			// reading in buffer all zeros from file
			for (i = 0; i < 1000; i++)
			{
				// moving file pointer to next zero in the file
				result = StorageSeekFile(file, i * 10, soFromBegin, &done);
				if (result != 0)
				{
					printf("SolFS error: %d\n", result);
					break;
				}
				// reading one byte
				result = StorageReadFile(file, buffer + i, 1, &done);
				if (result != 0)
				{
					printf("SolFS error: %d\n", result);
					break;
				}
			}

			result = StorageCloseFile(file);
			if (result != 0)
				printf("SolFS error: %d\n", result);
		}
		
		result = StorageClose(storage);
		if (result != 0)
			printf("SolFS error: %d\n", result);
	}

	return 0;
}

