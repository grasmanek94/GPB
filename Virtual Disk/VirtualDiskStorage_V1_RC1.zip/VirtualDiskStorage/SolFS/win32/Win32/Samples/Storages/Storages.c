
#include <stdio.h>
#include "../../../StoreDecl.h"

int main(int argc, char* argv[])
{
	Error result;
	Handle storage;

	printf("SolFS storages test\n");

	// Creting storage in file test.st
	result = StorageCreate(L"test.st", True, 512, NULL, &storage, '/', 
		False, False);
	if (result != 0)
		printf("SolFS error: %d\n", result);
	else
	{
		// creating folder in storage
		result = StorageCreateDirectory(storage, L"/folder");
		if (result != 0)
			printf("SolFS error: %d\n", result);
		else
		{
			// creating subfolder in previously created folder
			result = StorageCreateDirectory(storage, L"/folder/subfolder");
			if (result != 0)
				printf("SolFS error: %d\n", result);			
		}
		if (result != 0)
			printf("SolFS error: %d\n", result);
		else
		{
			// deleting subfolder
			result = StorageDeleteDirectory(storage, L"/folder/subfolder");
			if (result != 0)
				printf("SolFS error: %d\n", result);
		}
		result = StorageClose(storage);
		if (result != 0)
			printf("SolFS error: %d\n", result);
	}

	return 0;
}

