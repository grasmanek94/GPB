#include "../StoreDecl.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#ifdef _WINDOWS
#include <windows.h>
#else
#ifdef _MACOS
#define Handle void*
#define WideChar unsigned short
#endif // _MACOS
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#endif

char* stmask = "*";
#ifdef _WINDOWS
const char slash = '\\';
char* dmask = "*";
#else
const char slash = '/';
char* dmask = "*";
#endif

char* archive = NULL;
char* files = NULL;
char* extrpath = ".";
char* passwd = NULL;
char* exclf = NULL;
char* basepath = NULL;
long compressLevel = 0;
LongWord pageSize = 4096;
LongLongWord fixedSize = 0;
long maxBufSize = 1024 * 1024;

Bool lower = False;
Bool upper = False;
Bool delfl = False;
Bool nopth = False;
Bool overw = False;
Bool sbdir = False;
Bool date1 = False;
Bool date2 = False;
Bool alwaysyes = False;
Bool compr = False;
Bool pgsize = False;
Bool fxdsize = False;
Bool recreate = False;

Bool keyOverwriteSet = False;

#define strSuccess "Success"

#define strInvalidStorageFile "Invalid storage file"
#define strInvalidPageSize "Invalid page size"
#define strStorageFileCorrupted "Storage file corrupted"
#define strTooManyTransactionsCommiting "Too many transactions commiting"
#define strFileOrDirectoryAlreadyExists "File or directory already exists"
#define strExistsActiveTransactions "Active transactions already exists"
#define strTagAlreadyExistInFile "Tag already exists in the file"
#define strFileNotFound "File not found in storage"
#define strPathNotFound "Path not found in storage"
#define strSharingViolation "Sharing violation"
#define strSeekBeyondEOF "Seek beyond EOF"
#define strNoMoreFiles "No more files"
#define strInvalidFileName "Invalid file name"
#define strStorageActive "Can not perform this opeartion on active storage"
#define strStorageNotActive "Can not perform this opeartion on not active storage"
#define strInvalidPassword "Invalid password"
#define strStorageReadOnly "Can not perform this opeartion on read only storage"
#define strNoEncryptionHandlers "Can''t set custom encryption because no encryption handlers have not been set"
#define strOutOfMemory "Out of memory"
#define strLinkDestinationNotFound "Symbolic link destination file not found"
#define strFileIsNotSymLink "File is not Symbolic link"
#define strBufferTooSmall "Buffer is too small to contain the requested value"
#define strBadCompressedData "Compressed file is corrupted"
#define strInvalidParameters "Invalid parameter in function call"
#define strStorageFull "Storage is full and can''t be resized"
#define strInterruptedByUser "Operation interrupted by user"
#define strTagNotFound "Tag not found"
#define strDirectoryNotEmpty  "Directory not empty"
#define strHandleClosed "File is unexpected closed and handle no longer valid"
#define strInvalidStreamHandle "Invalid file/stream handle"
#define strFileAccessDenied "Access to file is denied"
#define strNoCompressionHandlers ""
#define strNotImplemented "Fuction is not implemented in this version of "
#define strLicenseKeyNotSet "Valid license key is not provided"
#define strDriverNotInstalled "Driver is not installed"
#define strLicenseKeyExpired "License key expired"
#define strNewStorageVersion "Storage was created by new version of "





const char* ErrorStrings[] = 
{
	strSuccess,
    strInvalidStorageFile,
    strInvalidPageSize,
    strStorageFileCorrupted,
    strTooManyTransactionsCommiting,
    strFileOrDirectoryAlreadyExists,
    strExistsActiveTransactions,
    strTagAlreadyExistInFile,
    strFileNotFound,
    strPathNotFound,
    strSharingViolation,
    strSeekBeyondEOF,
    strNoMoreFiles,
    strInvalidFileName,
    strStorageActive,
    strStorageNotActive,
    strInvalidPassword,
    strStorageReadOnly,
    strNoEncryptionHandlers,
    strOutOfMemory,
    strLinkDestinationNotFound,
    strFileIsNotSymLink,
    strBufferTooSmall,
    strBadCompressedData,
    strInvalidParameters,
    strStorageFull,
    strInterruptedByUser,
    strTagNotFound,
    strDirectoryNotEmpty,
    strHandleClosed,
	strInvalidStreamHandle,
	strFileAccessDenied,
	strNoCompressionHandlers,
	strNotImplemented,
	strLicenseKeyNotSet,
	strDriverNotInstalled,
	strLicenseKeyExpired,
	strNewStorageVersion
};

void closearc();

const char* err2str(Error e)
{
	if (e == 0)
		return "Success";

	else if (e > -(int)(sizeof(ErrorStrings)/sizeof(const char*)) && e < 0)
		return ErrorStrings[abs((int)e)];
	else
		return strerror((int)e);
}

void banner(void)
{
	printf("SolFS Manager, Copyright (c) 2011 EldoS Corp.\n\n");
}

void usage(void)
{
	printf("Usage:      <command> [-<switch 1> ... -<switch N>] <archive> [<files>...]\n\n");
	printf("<Commands>\n");
	printf("  a             Add files to archive\n");
	printf("  d             Delete files from archive\n");
	printf("  e             Extract files from archive\n");
	printf("  l             List contents of archive\n");
	printf("  t             Test integrity of archive\n");
	printf("  x             eXtract files with full pathname\n");

	printf("\n<Switches>\n");
	printf("  -             Stop switches scanning\n");

//	printf("  l             Convert names to lower case\n");
//	printf("  u             Convert names to upper case\n");
//!	printf("  d             Delete files after archiving\n");
	printf("  c<0-9>        set Compression level (0 - default)\n");
	printf("  e             Exclude paths from names\n");
	printf("  f<size>       set size of the Fixed size storage\n");
	printf("  g<page size>  set size of the paGe for new storage (4096 - default)\n");
	printf("  p<password>   set Password\n");
	printf("  o<path>       set Output directory\n");
	printf("  r             Recurse subdirectories\n");
	printf("  s+            overwrite existing Storage\n");
	printf("  s-            do not overwrite Storage (default)\n");
	printf("  y             Assume Yes on all queries\n");
	printf("  w+            overWrite existing files\n");
	printf("  w-            do not overWrite existing files (default)\n");

}

/*void error(char* s, char* e)
{
	closearc();
	
	if(s)
		if(e)
			printf("%s: %s\n\n", s, e);
	else
		printf("%s\n\n", s);
	
	// usage();
	
	exit(1);
}*/

int cmd = -1;
int res_code = 0;
Handle st = 0;
Handle fl;

Bool askif(char* question)
{
	int r;
	printf("%s? (y/n/a) ", question);
	if(alwaysyes)
	{

		printf(" yes\n");
		return True;
	}
	fflush(stdout);
	for (r=0;!r;) {
		switch (r=getchar()) {
			case 'A' :
			case 'a' :
				alwaysyes=True;
			case 'Y' :
			case 'y' :
				r=2;
				break;
			case 'N' :
			case 'n' :
				r=1;
				break;
			default :
				r=0;
				break;
		}
	}
	return (--r != 0) ? True : False;
}

Bool namecmp(const char* mask, const char* cmp)
{
	int maskLen;
	int cmpLen;
	Bool multEnable;
	int cmpPos;
	int maskPos;
	int maskLastPos;

	if (!mask || !cmp)
		return 0;
	
	maskLen = strlen(mask);
	cmpLen = strlen(cmp);

	while (maskLen)
	{
		if (mask[maskLen - 1] == '?')
		{
			if (cmpLen > 0)
			{
				cmpLen--;
				maskLen--;
			}
			else
				return False;
		}
		else
			break;
	}

	multEnable = False;
	cmpPos = 0;
	maskPos = 0;
	while (maskPos < maskLen && cmpPos < cmpLen)
	{
		char ch = mask[maskPos];
		if (ch == '*')
		{
			multEnable = True;
			maskLastPos = ++maskPos;
		}
		else if (ch == '?')
		{
			cmpPos++;
			maskPos++;
			if (multEnable)
				maskLastPos++;
		}
		else
		{
			Bool bcmp;
#ifndef _WINDOWS
				bcmp = *(cmp + cmpPos) == ch;
#else
				bcmp = strnicmp(cmp + cmpPos, &ch, 1) == 0;
#endif
			if (!bcmp)
			{
				if (multEnable)
				{
					cmpPos++;
					maskPos = maskLastPos;
				}
				else
					return False;
			}
			else
			{
				cmpPos++;
				maskPos++;
			}
		}
	}

	if (cmpPos < cmpLen)
	{
		if (mask[maskLen - 1] == '*')
			return True;
		else
			return False;
	}
	else if (maskPos < maskLen)
		return False;
	else
		return True;
}

/*int namecmp(char *pat, char *cmp) {

	for (;*pat;++pat) {
		switch(*pat) {
			case '?' :
				if (*cmp!='.' && *cmp) ++cmp;
				break;
			case '*' :
				while (*cmp!='.' && *cmp) ++cmp;
				break;
			case '.' :
				if (*cmp=='.') {
					cmp=strrchr(cmp,'.');
					++cmp;
				}
				else if (*cmp) return 0;
				else {
					do ++pat; while (*pat=='?');
					if (*pat==0 || *pat=='*') {
						while (*pat) ++pat;
					}
					--pat;
				}
				break;
			default :
				if (*cmp!=*pat) return 0;
				++cmp;
				break;
		}
	}
	if (*cmp==0) return 1;
	else return 0;
}*/

// ----------------------------------------------------------------------------------

PWideChar str2wstr(char* s)
{
	int i; 
	PWideChar t;
	if(!s)
		return(NULL);
	i = strlen(s) + 1;
	t = (PWideChar)malloc(i * sizeof(WideChar));
	for(i--;i >= 0;i--)
	t[i] = s[i];
	return(t);
}

char* wstr2str(PWideChar s)
{
	int i = 0;
	PWideChar s1;
	char* t;
	char* t1;
	if(!s)
		return(NULL);
	s1 = s;
	while(*(s1++)) i++;
	i++;
	t = (char*)malloc(i * sizeof(char));
	t1 = t;
	while(s && *s)
		*(t++) = (char)*(s++);
	*t = 0;
	return(t1);
}

Error openarc(int i)
{
	Error e = 0;
	PWideChar t = str2wstr(archive);
	if(i)
	{
		if(recreate)
		{
		  if(fxdsize)
		  {
  			  e = StorageFormatFixedSize(t, fixedSize, pageSize, NULL, 0, NULL, NULL);
	  		  e = StorageOpen(t, &st, slash, False, False);
		  }
		  else
				e = StorageCreate(t, True, pageSize, NULL, &st, slash, False, False);
		}
		else
		{
  			e = StorageCreate(t, False, pageSize, NULL, &st, slash, False, False);
			if (e)
	  		  e = StorageOpen(t, &st, slash, False, False);
		}
	}
	if(!i || e)
		e = StorageOpenReadOnly(t, &st, slash, False, False);

	free(t);


	return e;
}

void closearc(void)
{
	if (st != 0)
		StorageClose(st);
	st = 0;
}

char* appendExtrPath(const char* path)
{
	int tmplen = strlen(extrpath);
	char* fullpath = (char*)malloc(tmplen + strlen(path) + 2);
	if (!fullpath)				
	{
		perror("Error");
		return NULL;
	}
	
	if (path[0] == slash)
		path++;

	strncpy(fullpath, extrpath, tmplen);

	if (fullpath[tmplen-1] != slash)
	{
		fullpath[tmplen] = slash;
		fullpath[tmplen+1] = 0;
	}
	else
		fullpath[tmplen] = 0;
	strcat(fullpath, path);
	return fullpath;
}

typedef Bool (*enumfnc)(TStorageSearch sr, long userdata);

Bool enumstor(char* path, char* mask, enumfnc fnc, long userdata)
{
	TStorageSearch sr;
	char* t;
	PWideChar t2;
	Error e = 0;
	char z[2];

	z[0] = slash;
	z[1] = 0;

	if(path && (!*path || *path == slash))
	{
		t = (char*)malloc(strlen(path) + 1 + 2);
		*t = 0;
	}
	else
	{
		t = (char*)malloc(strlen(path) + 1 + 3);
		strcpy(t, z);
	}
	strcat(t, path);
	strcat(t, z);

	strcat(t, "*");
	t2 = str2wstr(t);

	e = StorageFindFirst(st, &sr, t2, attrAnyFile);
	if(e == 0)
	{
		while(1)
		{
			Bool r = True;
			char* t3 = wstr2str(sr.FileName);

			if (t3 && namecmp(mask, t3))
				r = fnc(sr, userdata);
			free(t3);


			//if(!r)
			//	break;

			if(sr.Attributes == attrDirectory && sbdir) //if recursively
			{
				t3 = wstr2str(sr.FullName);
				r = enumstor(t3, mask, fnc, userdata);
				free(t3);
				//if(!r)
				//	break;
			}
			e = StorageFindNext(st, &sr);
			if(e != 0)
				break;
		}
		StorageFindClose(st, &sr);
	}
	free(t);
	free(t2);
	return (e == 0);
}

Bool file_exists(char* filename)
{
#ifndef _WINDOWS
	FILE* fl = fopen(filename, "r");
	if(fl)
	{
		fclose(fl);
		return True;
	}
    else
	{
		DIR* dir = opendir(filename);
		if(dir == 0)
			return False;
		else
		{
			closedir(dir);
			return True;
		}
	} 
#else
	Bool res; 
	WIN32_FIND_DATA find_data;
	HANDLE dir;
	dir = FindFirstFile(filename, &find_data);
	res  = dir != INVALID_HANDLE_VALUE;
	if (res)
	{

		res = (FindNextFile(dir, &find_data) == 0);
		FindClose(dir);
	}
	return res;
#endif
}

Bool is_dir(char* filename)
{
#ifndef _WINDOWS
	DIR* dir = opendir(filename);
	if(dir)
	{
		closedir(dir);
		return True;
	}
	else
		return False;
#else
	WIN32_FIND_DATA find_data;
	HANDLE dir = FindFirstFile(filename, &find_data);
	Bool res;
	if (dir != INVALID_HANDLE_VALUE)
	{
		res = (find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY;
		if (res)
			res = (FindNextFile(dir, &find_data) == 0);
		
		FindClose(dir);
	}
	else
		res = False;
	return res;
#endif
}

Bool addfile(char* fileName, 
			 char* srcPath, 
			 char* dstPath)
{
	Error e, er;
	int fileNameLen;
	int dstPathLen;
	char* dstFullName;
	PWideChar wDstFullName;
	PWideChar pwd;
	char* srcFullName;
	char defDstPath[2];
	LongWord r;
	long len, bufSize;
	FILE* f;

	defDstPath[0] = slash;
	defDstPath[1] = 0;

	if (!dstPath)
		dstPath = defDstPath;

	fileNameLen = strlen(fileName);
	dstPathLen = strlen(dstPath);
	dstFullName = (char*)malloc(dstPathLen + 1 + fileNameLen + 1);
	if (!dstFullName)
	{
		perror("Error");
		return False;
	}
	strcpy(dstFullName, dstPath);
	if (dstPathLen != 1)
	{
		dstFullName[dstPathLen] = slash;
		dstFullName[dstPathLen+1] = 0;
	}
	strcat(dstFullName, fileName);

	wDstFullName = str2wstr(dstFullName);
	if (!wDstFullName)
	{
		perror("Error");
		free(dstFullName);
		return False;
	}

	if (!overw) 
	{
		Bool exists;
		e = StorageFileExists(st, wDstFullName, &exists);

		if (e != 0)
		{
			fprintf(stderr, "Error \"%s\"\n", err2str(e));
			free(dstFullName);
			free(wDstFullName); 
			return False;
		}
		if (exists)
		{
			char* buf;
			if (keyOverwriteSet)
			{
				free(dstFullName);
				free(wDstFullName);
				return False;
			}

      buf = (char*)malloc(strlen(dstFullName) + 300);
			if (buf)
			{
				sprintf(buf, "File \"%s\" already exists, overwrite", dstFullName);
				if (!alwaysyes && !askif(buf))
				{				
					free(buf);
					free(dstFullName);
					free(wDstFullName);
					return False;
				}
				free(buf);
			}
		}
	}

	printf("adding file: %s - ", dstFullName);
	free(dstFullName);

	pwd = NULL;
	if (passwd != NULL)
	{
		pwd = str2wstr(passwd);
		if (!pwd)
		{
			e = errno;
			printf("failed (\"%s\")\n", err2str(e));
			free(wDstFullName);
			return False;
		}
	}

	srcFullName = (char*)malloc(strlen(srcPath) + 1 + fileNameLen + 1);
	if (!srcFullName)
	{
		e = errno;
		printf("failed (\"%s\")\n", err2str(e));
		return False;
	}
	strcpy(srcFullName, srcPath);
	strncat(srcFullName, &slash, 1);
	strcat(srcFullName, fileName);

	if (compr)
	{
		e = StorageCreateFileCompressed(st, wDstFullName, True, True,
			True, True, pwd != NULL ? 1 : 0, pwd,
			pwd != NULL ? strlen(passwd) : 0,
			1, compressLevel, 16, &fl, True, True);
	}
	else
	{
		e = StorageCreateFile(st, wDstFullName, True, True, True, True, pwd != NULL ? 1 : 0, pwd,
			pwd != NULL ? strlen(passwd) : 0, &fl, True, True);
	}
	free(wDstFullName);
	free(pwd);
	if(e != 0)
	{
		free(srcFullName);
		printf("failed (\"%s\")\n", err2str(e));
		return False;
	}

	f = fopen(srcFullName, "rb");
	if(f != NULL)
	{
		char* buf;
    long bufRead;
		fseek(f, 0, SEEK_END);
		len = ftell(f);
		fseek(f, 0, SEEK_SET);
		
    bufSize = pageSize * 1024;
    if (bufSize > maxBufSize)
      bufSize = maxBufSize;
		buf = (char*)malloc(bufSize);
		if (buf)
		{
			while(len >= bufSize)
			{
				bufRead = fread(buf, 1, bufSize, f);
				e = StorageWriteFile(fl, buf, bufRead, &r);
				if(e != 0)
					break;
				len -= bufRead;
			}

			if((len > 0) && (len <= bufSize))
			{
				bufRead = fread(buf, 1, len, f);
				e = StorageWriteFile(fl, buf, bufRead, &r);
			}
	
			free(buf);
		}
		else		
			e = errno;

		fclose(f);
	}
	else
	{
		e = errno;
	}

	free(srcFullName);

	er = StorageCloseFile(fl);
	if (e == 0)
		e = er;

	if (e != 0)
	{
		printf("failed (\"%s\")\n", err2str(e));
		return False;
	}
	else
	{
		printf("ok\n");
		return True;
	}
}

typedef struct _StrItem
{
	struct _StrItem* next;
	char* str;	
} StrItem, *PStrItem;

Bool addfiles(char* mask, char* dstPath)
{
#ifdef _WINDOWS
	WIN32_FIND_DATA find_data;
	int findPathLen;
	char* tmpFindAll;
#endif
	char findPath[1023];
	char fullName[1023];
	char* fileMask = NULL;
	char* tmpPath = NULL;
    char* currPath = NULL;
	PStrItem dirList = NULL;
	Bool dirProcessing = False;
	char *fn = NULL;
	void* dir;

	findPath[0] = 0;

	if (!mask)
		return False;

	fileMask = strrchr(mask, slash);
	if (fileMask != NULL)
	{ 
		int l1 = strlen(mask);
		int l2 = strlen(fileMask);	
		int findPathLen = l1 - l2;
		if (findPathLen > 0 && findPathLen < sizeof(findPath)-1)
		{
			strncpy(findPath, mask, findPathLen); 
			findPath[findPathLen] = 0;
			fileMask++;
		}
	}
	else
		fileMask = mask;

	if (findPath[0] == 0)
	{
#ifndef _WINDOWS
		getcwd(findPath, sizeof(findPath));
#else
		GetCurrentDirectory(sizeof(findPath), findPath);
#endif
	}

#ifndef _WINDOWS
	if (!dstPath && !nopth)
	{
		char* tmpbuf = (char*)malloc(1024);
		if (!tmpbuf)
		{
			perror("Error");
			return False;
		}
		getcwd(tmpbuf, 1024);	   
		chdir(findPath);
		tmpPath = (char*)malloc(1024);
		if (!tmpPath)
		{
			perror("Error");
			chdir(tmpbuf);	
			free(tmpbuf);
			return False;
		}
		getcwd(tmpPath, 1024);	
		chdir(tmpbuf);	
		free(tmpbuf);
		dstPath = strchr(tmpPath, slash);
	}

	dir = opendir(findPath);
	if(dir == 0)
#else
	if (!dstPath && !nopth)
	{
		char* pFilePart;
		
		DWORD dw = GetFullPathName(findPath, 0, tmpPath, &pFilePart);
		if (dw > 0)
		{
			tmpPath = (char*)malloc(dw);
			if (!tmpPath)
			{
				perror("Error");
				return False;
			}
			GetFullPathName(findPath, dw, tmpPath, &pFilePart);
		}
		dw = GetCurrentDirectory(0, currPath);
		if (dw > 0)
		{
			currPath = (char*)malloc(dw);
			if (!currPath)
			{
				perror("Error");
				return False;
			}
			GetCurrentDirectory(dw, currPath);
		}
		if (strncmp(currPath, tmpPath, strlen(currPath) - 1) == 0)
		{
			if (strlen(currPath) == strlen(tmpPath))
				dstPath = "";
			else
				dstPath = strchr(tmpPath + strlen(currPath) - 1, slash);
		}
		else
			dstPath = strchr(tmpPath, slash);
	}

	dir = INVALID_HANDLE_VALUE;

	findPathLen = strlen(findPath);
	tmpFindAll = (char*)malloc(findPathLen + 1 + 1 + 1);
	if (tmpFindAll)
	{
		strncpy(tmpFindAll, findPath, findPathLen);
		tmpFindAll[findPathLen] = slash;

		tmpFindAll[findPathLen+1] = '*';
		tmpFindAll[findPathLen+2] = 0;
		dir = FindFirstFile(tmpFindAll, &find_data);
		free(tmpFindAll);
	}

	if(dir == INVALID_HANDLE_VALUE)
#endif
	{
		fprintf(stderr, "Unable to handle input path \"%s\"\n", findPath);
		free(tmpPath);
		return False;
	}

  while(1)
	{
#ifndef _WINDOWS		
		struct dirent* de = readdir(dir);
		if(!de)
		{
			PStrItem tmp;
			if (!dirList)
				break;
			dirProcessing = True;
			fn = dirList->str;
			tmp = dirList;
			dirList = dirList->next;
			free(tmp);
		}
		else
			fn = de->d_name;
#else
		if (!dirProcessing)
			fn = &(find_data.cFileName[0]);
#endif
	
		if (strcmp(fn, ".") == 0)
		{
			PWideChar wpath = str2wstr(dstPath);
			if (!wpath)
			{
				perror("Error");
			}
			else
			{
				Error e = StorageForceCreateDirectories(st, wpath);
				free(wpath);
				if (e != 0)
				{
					fprintf(stderr, "Error \"%s\"\n", err2str(e));
				}				
			}			
		}
		else if(strcmp(fn, "..") != 0)
		{
			Bool isdir;
			if (dirProcessing)
				isdir = True;
			else
			{
#ifndef _WINDOWS
              char* fullname;
              int findPathLen = strlen(findPath); 
              int tmp = strlen(fn);
              fullname = (char*)malloc(findPathLen + tmp + 2);
              if (!fullname)
              {
                  perror("Error");
                  break;
              }
              strncpy(fullname, findPath, findPathLen);
              fullname[findPathLen] = slash;
              strncpy(fullname + findPathLen + 1, fn, tmp);
              fullname[findPathLen + 1 + tmp] = 0;              
				isdir = is_dir(fullname);
              free(fullname);
#else
				isdir = (find_data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY;
#endif
			}

			if (isdir)
			{
				if (sbdir) //if recurse
				{
					if (!dirProcessing) //save directory name
					{
						PStrItem item = (PStrItem)malloc(sizeof(StrItem));
						if (item)
						{
							item->next = NULL;
							item->str = strdup(fn);
							if (!item->str)
								free(item);
							else
							{
								item->next = dirList;
								dirList = item;
							}
						}
					}
					else
					{
						int findPathLen = strlen(findPath);
						char* tmpMask = (char*)malloc(findPathLen + 1 + 
							strlen(fn) + 1 + strlen(fileMask) + 1);

						int dstPathLen = dstPath ? strlen(dstPath) : 0;
						char* tmpDstPath = (char*)malloc(dstPathLen + 1 + strlen(fn) + 1);

						if (tmpMask && tmpDstPath)
						{
							strncpy(tmpMask, findPath, findPathLen);
							tmpMask[findPathLen] = slash;
							tmpMask[findPathLen+1] = 0;
							strcat(tmpMask, fn);
							strncat(tmpMask, &slash, 1);
							strcat(tmpMask, fileMask);

							if (dstPathLen == 0)
							{
								tmpDstPath[0] = slash;
								tmpDstPath[1] = 0;
							}
							else
							{
								strncpy(tmpDstPath, dstPath, dstPathLen);
								tmpDstPath[dstPathLen] = slash;
								tmpDstPath[dstPathLen+1] = 0;
							}
							strcat(tmpDstPath, fn);

							addfiles(tmpMask, tmpDstPath);
						}
						free(tmpMask);
						free(tmpDstPath);
						free(fn);

					}
				}
			}
			else
			{
				strcpy(fullName, findPath);
				strncat(fullName, &slash, 1);
				strcat(fullName, fn);
				if (namecmp(fileMask, fn) && (strcmp(fullName, archive) != 0))
					addfile(fn, findPath, dstPath);
			}
		}

#ifdef _WINDOWS	
		if (!FindNextFile(dir, &find_data))
		{
			PStrItem tmp;
			if (!dirList)
				break;
			dirProcessing = True;
			fn = dirList->str;
			tmp = dirList;
			dirList = dirList->next;
			free(tmp);
		}
#endif
	}

#ifndef _WINDOWS	
	closedir(dir);
#else
	FindClose(dir);
#endif


	if (currPath != NULL)
		free(currPath);
	if (tmpPath != NULL)
		free(tmpPath);
	return True;
}

#define BUFSZ 4096

int mkstdir(long l, char* s)
{
	PWideChar t = str2wstr(s);
	Error e = StorageCreateDirectory(st, t);
	if (e != errFileOrDirectoryAlreadyExists)
		printf("adding dir: %s\n", s);
	free(t);
	return(e == 0 || e == errFileOrDirectoryAlreadyExists);
}

Bool makedir(char* s)
{
	char cdr[1024];
	Bool r;

#ifdef _WINDOWS
	GetCurrentDirectory(MAX_PATH, cdr);
	r = SetCurrentDirectory(s) != 0;
	SetCurrentDirectory(cdr);
#else
	getcwd(cdr, 1023);
	r = chdir(s) == 0;
	chdir(cdr);
#endif
	
	if(!r)
	{
		//printf("creating dir: %s ", s);
		
		char* t = strchr(s, slash);
		if (!t)
			return False;
		t++;
		while (1)
		{
			t = strchr(t, slash);
			if(t)
				*t = 0;
#ifdef _WINDOWS
			r = CreateDirectory(s, NULL) != 0 ? True : False;
#else
			r = mkdir(s, 0600) == -1 ? False : True;
#endif
			if (t)
			{
				*t = slash;
				t++;
			}
			else
				break;
		}

		/*if(r)
			printf(" - ok\n");
		else
			printf(" - failed (\"%s\")\n", err2str(errno));*/
		if (!r)
		{
			fprintf(stderr, "Failed directory creation \"%s\", error \"%s\"", s, err2str(errno));
		}
	}
	return r;
}

FILE* openDestinationFile(char* s, long userdata)
{
	FILE* ret = NULL;
	char* fullpath;
	Bool r; 


	//get file name
	char* dir;
	char* filename = strrchr(s, slash);
	dir = s;
	filename[0] = 0; 
	filename++;

	if (userdata == 0)
		fullpath = appendExtrPath("");
	else
		fullpath = appendExtrPath(dir);
	filename[-1] = slash;

	if (!fullpath)				
	{
		perror("Error");
		return NULL;
	}

	r = makedir(fullpath);
	if (r)
	{

		int len = strlen(fullpath);
		char* tmp = (char*)realloc(fullpath, len + 1 + strlen(filename) + 1);	
		if (!tmp)
		{
			free(fullpath);
			perror("Error");
			return NULL;
		}
		fullpath = tmp;
		if (fullpath[len-1] != slash)
		{
			fullpath[len] = slash;
			fullpath[len+1] = 0;
		}
		strcat(fullpath, filename);
	
		if (file_exists(fullpath) && !overw)
		{
			char* buf;
			if (keyOverwriteSet)
			{
				free(fullpath);
				return NULL;
			}
				
			buf = (char*)malloc(strlen(fullpath) + 300);
			if (buf)
			{
				sprintf(buf, "File \"%s\" already exists, overwrite", fullpath);
				if (alwaysyes || askif(buf))
				{				
					ret = fopen(fullpath, "wb");
					if (ret == NULL)
						perror("Error");
				}
				free(buf);
			}
		}
		else
		{
			ret = fopen(fullpath, "wb");
			if (ret == NULL)
				perror("Error");
		}
	}
	else
		perror("Error");

	free(fullpath);
	return ret;
}

//if userdata == 1 then do extracting with full pathname
Bool exffile(TStorageSearch sr, long userdata)
{
	Handle fl;
	Error e;
	FILE* f;
	PWideChar pwd = NULL;
	char* sFullName = wstr2str(sr.FullName);
	if (!sFullName)
	{
		perror("Error");
		return False;
	}
		
	if (sr.Attributes == attrDirectory)
	{
		if (nopth)
			return True;
		if (userdata != 0)
		{
			Bool r;
			char* fullpath = appendExtrPath(sFullName);
			free(sFullName);
			if (!fullpath)				
			{
				perror("Error");
				return False;
			}

			r = makedir(fullpath);
			free(fullpath);
			return r;
		}
		free(sFullName);
		return True;
	}

	printf("extracting file: %s ", sFullName);

	if (passwd)
		pwd = str2wstr(passwd);

	e = StorageOpenFile(st, sr.FullName, True, False, False, False, pwd,
		pwd != NULL ? strlen(passwd) : 0, &fl);
	
	free(pwd);
	
	if(e == 0)
	{
		LongWord r;

		//make destination directory and open the destination file
		f = openDestinationFile(sFullName, userdata);
		if (f)
		{
			char* buf = (char*)malloc(BUFSZ);
			while(1)
			{
				e = StorageReadFile(fl, buf, BUFSZ, &r);
				if(e != 0 || r == 0)
					break;
				fwrite(buf, r, 1, f);
			}
			free(buf);
			fclose(f);
		}
		else
		{
			e = errno;
		}
		StorageCloseFile(fl);
	}
	free(sFullName);

	if(e == 0 || e == errSeekBeyondEOF)
		printf(" - ok\n");
	else
		printf(" - failed (\"%s\")\n", err2str(e));
	return e == 0;
}

Bool testfile(TStorageSearch sr, long l)
{
	Handle fl;
	LongWord ln;
	Error e;
	PWideChar pwd = NULL;

	char* sFullName = wstr2str(sr.FullName);
	if (!sFullName)
	{
		perror("Error");
		return False;
	}

	printf("testing file: %s - ", sFullName);
	free(sFullName);

	if (pwd != NULL)
		pwd = str2wstr(passwd);

	e = StorageOpenFile(st, sr.FullName, True, False, False, False, pwd,
		pwd != NULL ? strlen(passwd) : 0, &fl);
	
	if (pwd)
		free(pwd);

	if(e == 0)
	{
		e = StorageGetFileSize(fl, &ln);
	}
	if(e == 0)
	{
		LongWord r;
		char* buf = (char*)malloc(BUFSZ);
		while(ln > BUFSZ)
		{
			e = StorageReadFile(fl, buf, BUFSZ, &r);
			if(e > 0)
				break;
			ln -= BUFSZ;
		}
		if(ln > 0)
		{
			e = StorageReadFile(fl, buf, ln, &r);
		}
		free(buf);
	}
	StorageCloseFile(fl);
	if(e == 0)
		printf("ok\n");
	else
		printf("failed (\"%s\")\n", err2str(e));
	return e == 0;
}

Bool listfile(TStorageSearch sr, long l)
{
	//if (sr.Attributes == attrDirectory)
	//	return True;
	Error e = 0;
	char* sFullName = wstr2str(sr.FullName);
	if (!sFullName)
	{
		perror("Error");
		return False;
	}

	if (sr.Attributes == attrDirectory)
	{
		printf("%-66s\n", sFullName);
	}
	else
	{
		TStorageSearch Search;
		e = StorageFindFirst(st, &Search, sr.FullName, attrAnyFile);
		if(e == 0)
		{
			StorageFindClose(st, &Search);
			printf("%-66s %12d\n", sFullName, (int)Search.FileSize);
		}
	}
	free(sFullName);
	return e == 0 ? True : False;
}

Bool delfile(TStorageSearch sr, long userdata)
{
	Error e;

	char* sFullName = wstr2str(sr.FullName);
	if (!sFullName)
	{
		perror("Error");
		return False;
	}

	printf("deleting file: %s ", sFullName);
	free(sFullName);
	e = StorageDeleteFile(st, sr.FullName);
	if(e == 0)
		printf(" - ok\n");
	else
		printf(" - failed (\"%s\")\n", err2str(e));
	return e == 0;
}

// -----------------------------------------------------------------------------

void fncAdd(void)
{
	char* nm;
	char* t;
	Bool r = True;
	Error e = openarc(1);
	if (e != 0)
	{
		fprintf(stderr, "Can't open storage %s. Error: \"%s\"\n", archive, err2str(e));
		return;
	}
	
	if(!files)
	{
		files = strdup(dmask);
		if (!files)
		{
			perror("Error");
			closearc();
			return;
		}
	}

	nm = files;
	t = nm;
	while(r)
	{
		if(!nm)
			break;
		nm = strchr(nm, ' ');
		if(nm)
		{
			*nm = 0;
			nm++;
		}

		if(t)

			r = addfiles(t, NULL);
		t = nm;
	}
	closearc();
	//if(!r)
	//	error("Error reading storage", archive);
	printf("\ndone\n");
}

void fncDel(void)
{
	Error e;
	char* nm;
	Bool r;

	e = openarc(0);
	if (e != 0)
	{
		fprintf(stderr, "Can't open storage %s. Error: \"%s\"\n", archive, err2str(e));
		return;
	}

	if(!files)
	{
		files = strdup(stmask);
		if (!files)
		{
			perror("Error");
			closearc();
			return;
		}
	}

	//sbdir = true;
	nm = files;
	r = True;
	while(r)

	{
		char* t = nm;
		char* t2;
		if(!nm)
			break;
		nm = strchr(nm, ' ');
		if(nm)
			*(nm++) = 0;
		t2 = strrchr(t, slash);
		if(t2)
		{
			*(t2++) = 0;
			r = enumstor(t, t2, delfile, 0);
		}
		else
			r = enumstor("", t, delfile, 0);
	}
	closearc();
	//if(!r)
	//	error("Error reading storage", archive);
	printf("\ndone\n");
}

void fncExtr(void)
{
	char* nm;
	Bool r;
	Error e = openarc(0);
	if (e != 0)
	{
		fprintf(stderr, "Can't open storage %s. Error: \"%s\"\n", archive, err2str(e));
		return;
	}

	if(!files)
	{
		files = strdup(stmask);
		if (!files)
		{
			perror("Error");
			closearc();
			return;
		}
	}

	//sbdir = true;
	nm = files;
	r = True;
	while(r)
	{
		char *t, *t2;
		if(!nm)
			break;
		t = nm;
		nm = strchr(nm, ' ');
		if(nm)
			*(nm++) = 0;
		t2 = strrchr(t, slash);
		if(t2)
		{
			*(t2++) = 0;
			r = enumstor(t, t2, exffile, 0);
		}
		else
			r = enumstor("", t, exffile, 0);
	}
	closearc();
	//if(!r)
	//	error("Error reading storage", archive);
	printf("\ndone\n");
}

void fncList(void)
{
	Bool r;
	Error e = openarc(0);
	if (e != 0)
	{
		fprintf(stderr, "Can't open storage %s. Error: \"%s\"\n", archive, err2str(e));
		return;
	}
	
	printf("%-66s %12s\n\n", "file name", "size");
	sbdir = True;
	r = enumstor("", stmask, listfile, 0);

	//if (!r)		
	//	error("Error reading storage", archive);
	closearc();
}

void fncTest(void)
{
	Bool r;
	Error e = openarc(0);
	if (e != 0)
	{
		fprintf(stderr, "Can't open storage %s. Error: \"%s\"\n", archive, err2str(e));
		return;
	}
	
	sbdir = True;
	r = enumstor("", stmask, testfile, 0);
	//if (!r)		
	//	error("Error reading storage", archive);
	closearc();
	printf("\ndone\n");
}

void fncUpd(void)
{

}

void fncXtr(void)
{
	char* nm;
	Bool r;
	Error e = openarc(0);
	if (e != 0)
	{
		fprintf(stderr, "Can't open storage %s. Error: \"%s\"\n", archive, err2str(e));
		return;
	}
	
	if(!files)
	{
		files = strdup(stmask);
		if (!files)
		{
			perror("Error");
			closearc();
			return;
		}
	}

	sbdir = True;
	nm = files;
	r = True;
	while(r)
	{
		char *t, *t2;
		if(!nm)
			break;
		t = nm;
		nm = strchr(nm, ' ');
		if(nm)
			*(nm++) = 0;
		t2 = strrchr(t, slash);
		if(t2)

		{
			*(t2++) = 0;
			r = enumstor(t, t2, exffile, 1);
		}
		else
			r = enumstor("", t, exffile, 1);
	}
	closearc();
	//if(!r)
	//	error("Error reading storage", archive);
	printf("\ndone\n");
}

// ----------------------------------------------------------------------------------

Bool foOver(char* d)
{
	if(strlen(d) == 1 && d[0] == '+')
		overw = True;
	else
	if(strlen(d) == 1 && d[0] == '-')
		overw = False;
	else
		return False;
	return True;
}

Bool foOverStorage(char* d)
{
	if(strlen(d) == 1 && d[0] == '+')
    recreate = True;
	else
	if(strlen(d) == 1 && d[0] == '-')
		recreate = False;
	else
		return False;
	return True;
}

Bool foPassw(char* d)
{
	if (d && *d == 0)
		return False;
	passwd = d;
	return True;
}

Bool foDate1(char* d)
{
	return True;
}

Bool foDate2(char* d)
{
	return True;
}

Bool foExcl(char* d)
{
	if(!exclf)
		exclf = strdup(d);
	else
	{
		int n = strlen(exclf) + strlen(d) + 2;
		char* tmp = exclf;
		exclf = (char*)malloc(n);
		strcpy(exclf, tmp);
		strcat(exclf, " ");
		strcat(exclf, d);
		free(tmp);
	}
	return True;
}

Bool foPath(char* d)
{
	int len = strlen(d);
	if (len > 0)
		extrpath = d;
	return True;
}

Bool foComprLvl(char* d)
{
	if (*d != 0 && *(d+1) == 0)
	{
		compressLevel = *d - 0x30;
		if (compressLevel >= 0 && compressLevel <= 9)	
			return True;
	}
	return False;
}

Bool foPageSize(char* d)
{
  long value;
  if (*d != 0)
	{
    value = atol(d);
    if (value != 0)
    {
      pageSize = value;
			return True;
    }
	}
	return False;
}

Bool foFixedSize(char* d)
{
  long value;
  if (*d != 0)
	{
    value = atol(d);
    if (value != 0)
    {
      fixedSize = value;
			return True;
    }
	}
	return False;
}

// ----------------------------------------------------------------------------------

//enum {cmAdd, cmDel, cmExtr, cmFresh, cmList, cmPrn, cmTest, cmUpd, cmXtr};

typedef void (*cfunc)(void);
typedef Bool (*ofunc)(char*);

typedef struct {
	char cmd;
	cfunc fnc;
} command;

typedef struct {
	char opt;
	Bool* var;
	ofunc fnc;
} option;

command commands[] = {
	{'a',   fncAdd},
	{'d',   fncDel},
	{'e',  fncExtr},
	{'l',  fncList},
	{'t',  fncTest},
	{'u',   fncUpd},
	{'x',   fncXtr}
};

option options[] = {
	{'l',  &lower, NULL},
	{'u',  &upper, NULL},
	{'d',  &delfl, NULL},
	{'e',  &nopth, NULL},
	{'w',  &keyOverwriteSet, foOver},
	{'p',  NULL, foPassw},
	{'r',  &sbdir, NULL},
	{'b',  NULL, foDate1},
	{'a',  NULL, foDate2},
	{'x',  NULL, foExcl},
	{'y',  &alwaysyes, NULL},
	{'o',  NULL, foPath},
	{'c',  &compr, foComprLvl},
	{'g',  &pgsize, foPageSize},
	{'f',  &fxdsize, foFixedSize},
	{'s',  &recreate, foOverStorage}
};

// ----------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
	int x, ar;
	int res_code = 0;

	#ifndef SOLFS_NO_TRIAL
	char *sRegKey = "";
	//#error request the trial key from EldoS Corporation, comment this line and assign the key as a constant to sRegKey. Visit http://www.eldos.com/solfs/keyreq/ to request the key
	if (StorageSetRegistrationKey(sRegKey) != 0)
		fprintf(stderr, "Invalid registration key\n");
	#endif // SOLFS_NO_TRIAL
	banner();
	if(argc<2)
	{
		usage();
		return 0;
	}
	if(strlen(argv[1]) != 1)
	{
		fprintf(stderr, "Invalid command \"%s\"\n", argv[1]);
		return 1;
	}

	x = sizeof(commands)/sizeof(command) - 1;
	for(;x >= 0;x--)
	{
		if(argv[1][0] == commands[x].cmd)
		{
			cmd = x;

			break;
		}
	}
	
	if(cmd < 0)
	{
		fprintf(stderr, "Invalid command \"%s\"\n", argv[1]);
		return 1;
	}

	ar = 2;
	while(argc > ar)
	{
		int opt;
		if(strlen(argv[ar]) < 1)
		{
			fprintf(stderr, "Invalid option \"%s\"\n", argv[ar]);
			return 1;
		}
		if(strlen(argv[ar]) == 1 && argv[ar][0] == '-')
			break;
		if(argv[ar][0] != '-')
			break;
		x = sizeof(options)/sizeof(option) - 1;
		opt = -1;
		for(;x >= 0;x--)
		if(argv[ar][1] == options[x].opt)
		{
			opt = x;
			break;
		}
		if(opt < 0)
		{
			fprintf(stderr, "Invalid option \"%s\"\n", argv[ar]);
			return 1;
		}
		if(options[opt].var)
			*(options[opt].var) = True;
		if(options[opt].fnc)
		{
			if(!options[opt].fnc(&argv[ar][2]))
			{
				fprintf(stderr, "Invalid option \"%s\"\n", argv[ar]);
				return 1;
			}
		}
		else
		if(strlen(argv[ar]) > 2)
		{
			fprintf(stderr, "Invalid option \"%s\"\n", argv[ar]);
			return 1;
		}
		ar++;
	}

	if(argc > ar)
	{
		archive = argv[ar];
		//int arl = strlen(archive);
		//if (arl > 0 && archive[arl - 1] != '.')
		ar++;
	}

	while(argc > ar)
	{
		if(!files)
			files = strdup(argv[ar]);
		else
		{
			int n = strlen(files) + strlen(argv[ar]) + 2;
			char* tmp = files;
			files = (char*)malloc(n);
			strcpy(files, tmp);
			strcat(files, " ");
			strcat(files, argv[ar]);
			free(tmp);
		}
		ar++;
	}
	printf("Archive: %s\n\n", archive);
	commands[cmd].fnc();
	free(files);
	free(exclf);
	return(res_code);         
}
