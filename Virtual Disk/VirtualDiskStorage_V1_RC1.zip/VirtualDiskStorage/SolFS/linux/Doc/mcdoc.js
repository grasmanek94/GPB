function getAttribute(node, attrName)
{
   	/*
    if (is.nav && node.attributes)
    {
    	return node.getAttribute(attrName);
    	var i;
    	for (i = 0; i < node.attributes.length; i++)
    	{
	    	if (node.attributes[i].name.toLowerCase() == attrName.toLowerCase())
    		{
    			return node.attributes[i].value;
	    	}
		}
    }
	else
	if (is.ie || is.opera)
	*/
	return node.getAttribute(attrName);
}

function hideLayer(l)
{
	l.cbe.hide();
}

function getAbsX(node)
{
	var rv = 0;
	if (node.offsetParent != null)
	{
		rv = node.offsetLeft + getAbsX(node.offsetParent);
	}
	if (rv >= 0)
		return rv;
    else
    	return 0;
}

function getAbsY(node)
{
	var rv = 0;
	if (node.offsetParent != null)
	{
	    rv = node.offsetTop;
		rv += getAbsY(node.offsetParent);
	}
	if (rv >= 0)
		return rv;
    else
    	return 0;
}

function linkClick(l)
{
    var blockName;

  	blockName = getAttribute(l, "BlockName");

	var CurElem = cbeGetElementById(blockName);
	if (CurElem)
	{
    	var DivValue = CurElem.innerHTML;
		var TargetBlock = cbeGetElementById("div_popup");
				var leftdiv = cbeGetElementById("left");
		var rightdiv = cbeGetElementById("right");
		var contentdiv = cbeGetElementById("content");
		if (TargetBlock)
		{
	 		TargetBlock.innerHTML = DivValue;
	 		TargetBlock.cbe.show();
	 		if (is.ie)
	 		{
		 		var xx = getAbsX(l);
		 		var yy = getAbsY(l) - TargetBlock.clientHeight - 4;
	
				//if (leftdiv != null)
				//	xx -= leftdiv.clientWidth;
					
				//if (contentdiv != null)
				//	yy -= getAbsY(contentdiv) + contentdiv.offsetTop;
			}
			else
			{
		 		var xx = getAbsX(l);
		 		var yy = getAbsY(l) - TargetBlock.clientHeight - 4;
	
				//if (contentdiv != null)
				//	yy -= contentdiv.offsetTop;
			}
			TargetBlock.cbe.moveTo(xx, yy);
		}
		else
	    	alert("div_popup not found");		
	}
	else
    	alert("Element " + blockName + " not found");
	return true;
}

function doSetVis(node, group, value)
{
    var groupValue;

    groupValue = getAttribute(node, "group");
	
	if (groupValue == group)
	{
		if (value == "off")
 		{
	 		//node.hide();
	 		node.style.display="none";
 		}
		else
		{
			//node.show();
            node.style.display="";
		}
	}
}

function setVis(blockName, value)
{
	var ele, i;
    var spanArray = cbeGetElementsByTagName("SPAN");
    for (i = 0; i < spanArray.length; i++)
    {
    	ele = spanArray[i];
        doSetVis(ele, blockName, value);
    }
    spanArray = cbeGetElementsByTagName("P");
    for (i = 0; i < spanArray.length; i++)
    {
    	ele = spanArray[i];
        doSetVis(ele, blockName, value);
    }
}

function doToggle(node, group)
{
    var groupValue;

    groupValue = getAttribute(node, "group");
	
	if (groupValue == group)
	{
        if (node.style.display != "none")
 		{
	 		//node.hide();
	 		node.style.display = "none";
	 		return "off";
 		}
		else
		{
			//node.show();
	 		node.style.display = "";
	 		return "on";
		}
	}
}

function toggle(l)
{
    var blockName;

   	blockName = getAttribute(l, "groupRef");
    var ele, i, cookieVal;
    var spanArray = cbeGetElementsByTagName("SPAN");
    var cookieVal, v1;
    for (i = 0; i < spanArray.length; i++)
    {
    	ele = spanArray[i];
        v1 = doToggle(ele, blockName);
        if (v1)
	        cookieVal = v1;
    }

    spanArray = cbeGetElementsByTagName("P");
    for (i = 0; i < spanArray.length; i++)
    {
    	ele = spanArray[i];
        doToggle(ele, blockName);
    }
    var today = new Date();
    today.setDate(1); today.setMonth(1); today.setYear(2100);
    cbeSetCookie(blockName, cookieVal, today, "");
}

function setFilters()
{
	cbeInitialize();
	setVis("groupCPPLIB", cbeGetCookie("groupCPPLIB"));
	setVis("groupCPPVCL", cbeGetCookie("groupCPPVCL"));
	setVis("groupCPPNET", cbeGetCookie("groupCPPNET"));
	setVis("groupPascal", cbeGetCookie("groupPascal"));
	setVis("groupCSharp", cbeGetCookie("groupCSharp"));
	setVis("groupDLL", cbeGetCookie("groupDLL"));
	setVis("groupVBNet", cbeGetCookie("groupVBNet"));
	setVis("groupJava", cbeGetCookie("groupJava"));
//	setVis("groupActiveX", cbeGetCookie("groupActiveX"));
}
