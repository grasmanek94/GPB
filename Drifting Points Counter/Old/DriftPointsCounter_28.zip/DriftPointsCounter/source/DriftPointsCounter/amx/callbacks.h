// Copyright (c) 2011 SA:MP GDK Project
// See file LICENSE for license details.

#ifndef SAMP_CALLBACKS_H
#define SAMP_CALLBACKS_H

namespace sampgdk { 

void SetupSampCallbackHooks();

} 

#endif

