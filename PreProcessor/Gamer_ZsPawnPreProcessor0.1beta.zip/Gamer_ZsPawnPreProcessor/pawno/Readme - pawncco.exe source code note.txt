This is the standart pawncc.exe from the windows server package.
I do not have the source code for this application so use at your own risk.
the application is provided by the Sa-MP team. It can be obtained from the sa-mp.com download section too.