﻿/*
* RA3INFO | 'Red Alert 3' By Gamer_Z/Grasmanek94 | http://gpb.googlecode.com/
*/
#include <main.h>

bool Displaying = false;

inline bool IsPlayerInGame()
{
	return (POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+0xD8) != NULL);
	//return (PlayerSlot != (-1));
}

namespace Drawer
{
	struct TextInfo
	{
		std::string text;
		float x,y;
		DWORD start,end;
		DWORD color;
		bool textcoloring;
		TextInfo(float _x, float _y, std::string _text, DWORD _start, DWORD _end, DWORD _color, bool _tc = false)
		{
			x = _x;
			y = _y;
			text.assign(_text.c_str());
			start = _start;
			end = _end;
			color = _color;
			textcoloring = _tc;
		}
	};

	std::vector<TextInfo> data;
	TextInfo DisplayNow(0.0f,10.0f,"",0,0,0xFFFFFFFF,true);

	void Add(float x, float y, std::string text, DWORD time, DWORD delay, DWORD color, bool TextColoring)
	{
		DWORD PUT = GetTickCount()+delay;
		data.push_back(TextInfo(x,y,text,PUT,PUT+time,color,TextColoring));
	}
	void AddQueue(std::string text, DWORD time = 1000)
	{
		DisplayNow.text.assign(text);
		DWORD PUT = GetTickCount();
		DisplayNow.start = PUT;
		DisplayNow.end = PUT+time;
	}
	void Display()
	{
		Displaying = false;
		DWORD now = GetTickCount();
		for(unsigned int i = 0, j = data.size(); i < j; ++i)
			if(data.at(i).end > now)
				data.erase(data.begin()+i);
		for(unsigned int i = 0, j = data.size(); i < j; ++i)
			if(data.at(i).start >= now)
			{
				Displaying = true;
				DirectXFont::Access(0)->Print(data.at(i).x,data.at(i).y,data.at(i).color,data.at(i).text.c_str(),data.at(i).textcoloring);
			}
			if(DisplayNow.end > now)
			{
				Displaying = true;
				//render->D3DBox(0.0,10.0f,DirectXFont::Access(0)->DrawLength(DisplayNow.text.c_str()),DirectXFont::Access(0)->DrawHeight(),0x77000000);
				DirectXFont::Access(0)->Print(0.0f,10.0f,0xFFFFFFFF,DisplayNow.text.c_str(),true);
			}
	}
};

namespace User
{
	struct Options
	{
		bool Cheat;
		bool Buildtest;
		unsigned int Transparency;
		Options() : 
			Cheat(true),Transparency(0x8F000000), Buildtest(true)
		{

		}
	};

	namespace Settings
	{
		Options Data;

		void CheckChange()
		{
			if(Keys(VK_APPS).Down)
			{
				if(Keys(VK_F9).ConsumePressed())
				{
					Data.Cheat ^= 1;
					if(!Data.Cheat)
						Drawer::AddQueue("Cheats {FFFF0000}Disabled");
					else
						Drawer::AddQueue("Cheats {FF00FF00}Enabled");
				}
				if(Keys(VK_F10).ConsumePressed())
				{
					Data.Buildtest ^= 1;
					if(!Data.Buildtest)
						Drawer::AddQueue("Buildtest {FFFF0000}Disabled");
					else
						Drawer::AddQueue("Buildtest {FF00FF00}Enabled");
				}
				if(Keys(VK_F12).ConsumePressed())
				{
					Data.Transparency += 0x10000000;
					if(Data.Transparency > 0xFF000000)
						Data.Transparency = 0xFF000000;
				}
				if(Keys(VK_F11).ConsumePressed())
				{
					Data.Transparency -= 0x10000000;
					if(Data.Transparency < 0x00000000)
						Data.Transparency = 0x00000000;
				}
			}//ConsumeDown(VK_APPS)
		}
	};
};

struct RA3{
	static std::map<int,int> create_map()
	{
		std::map<int,int> m;
		m[-1]= 0xFFFFFFFF;
		m[0] = 0xFF324BC8;
		m[1] = 0xFFF0D719;
		m[2] = 0xFF14693C;
		m[3] = 0xFFE17314;
		m[4] = 0xFF7D19C8;
		m[5] = 0xFFE61414;
		m[6] = 0xFF66CFF8;
		return m;
	}
	static const std::map<int,int> PlayerColors;
};
const std::map<int,int> RA3:: PlayerColors =  RA3::create_map();

unsigned int max_sessions = 1;

#define MAX_PLAYERS (6)

int ScreenY = 0;
int ScreenX = 0;
int MouseX  = 0;
int MouseY  = 0;

struct UnitsInfo
{
	//pointers to UnitsInfo structures, null when no structure available at that location
	DWORD * nodes[3];//0x00

	//data
	int unkown_1;		//0x0C
	unsigned int Type;	//0x10
	unsigned int Amount;//0x14
};

struct pinfo
{
	bool			in;
	enum Controller	{Ctrl_UNKNOWN,	Ctrl_HUMAN,	Ctrl_AI				};
	enum Nation		{N_UNKNOWN,		N_ALLIES,	N_SOVIET,	N_JAPAN	};
	std::string		Name;
	Nation			Side;
	short			Team;
	Controller		Who;
	int				*Money;
	int				*Power;
	int				*Usage;
	unsigned int	*Color;

	bool			GotUnits;
	DWORD			*unit_start_node;
};

std::map<DWORD*,UnitsInfo*> UnitList[MAX_PLAYERS];
std::map<unsigned int,std::string> UnitNames;
std::map<std::string,unsigned int> Units[MAX_PLAYERS];

void GenerateUnitList(unsigned short slot)
{
	std::set<DWORD*> todo;
	unsigned int inserted = 1;
	while(inserted)
	{
		inserted = 0;
		for(auto it = UnitList[slot].begin(); it != UnitList[slot].end(); ++it)
		{
			for(short i = 0; i < 3; ++i)
			{
				if(it->second->nodes[i] != NULL)
				{
					if(UnitList[slot].find(&POINTER(DWORD,it->second->nodes[i])) == UnitList[slot].end())
					{
						todo.insert(it->second->nodes[i]);
						++inserted;
					}
				}
			}
		}
		while(!todo.empty())
		{
			UnitList[slot][*todo.begin()] = &POINTER(UnitsInfo,*todo.begin());
			todo.erase(todo.begin());
		}
	}
	for(auto it = UnitList[slot].begin(); it != UnitList[slot].end(); ++it)
		Units[slot][UnitNames[it->second->Type]] = it->second->Amount;
}

pinfo Player[MAX_PLAYERS];
bool GameInternsInited = false;
void OnGameLaunch();


void FrameTick(myIDirect3DDevice9 * device, HWND wnd)
{
	if(!GameInternsInited)
		OnGameLaunch();
	PROTECT;
	KeyManagerRun();//key press/release detection
	if(Keys(VK_MENU).Down && Keys(VK_F4).Pressed)
		::ExitProcess(0);

	MouseX = POINTER(int,POINTER(DWORD,0x00CDAEFC)+0x3C);
	MouseY = POINTER(int,POINTER(DWORD,0x00CDAEFC)+0x40);
	ScreenX = POINTER(int, 0x00400000+0x008E9EBC);
	ScreenY = POINTER(int, 0x00400000+0x008E9EC0);

	User::Settings::CheckChange();
	Drawer::Display();

	static bool got_session = false;

	if(!User::Settings::Data.Cheat || !IsPlayerInGame())
	{
		if(!IsPlayerInGame())
		{
			if(got_session)
			{
				++max_sessions;
				got_session = false;
				for(short i = 0; i < MAX_PLAYERS; ++i)
				{
					Player[i].in = false;
					Player[i].GotUnits = false;
					Player[i].Money = NULL;
					Player[i].Power = NULL;
					Player[i].Color = NULL;
					Player[i].Usage = NULL;
					Player[i].unit_start_node = NULL;
					UnitList[i].clear();
					Units[i].clear();
				}
			}
			if(!Displaying)
			{
				DirectXFont::Access(0)->Print(0.0,0.0,0xFFFF0000, "RA3{FFFFFF00}INFO {FF00FFFF}MOD {FFFFFFFF}By Gamer_Z a.k.a Grasmanek94",true);
				DirectXFont::Access(0)->Print(0.0,11.0,0xFFFFFF00,"Website: {FF00FFFF}http://gpb.googlecode.com/",true);
				//DirectXFont::Access(0)->Print(0.0,33.0,0xFFFFFF00,string_format("Screensize: %dx%d",ScreenX,ScreenY).c_str(),true);
				//DirectXFont::Access(0)->Print(0.0,44.0,0xFFFFFF00,string_format("Mouse: {%d,%d}",MouseX,MouseY).c_str(),false);
			}
		}
		return;
	}

	if(!got_session)
	{
		for(unsigned int i = max_sessions; ; ++i)
		{
			PROTECT;
			unsigned int adder = (0x4 * (i - 1));
			auto& Tester = POINTER(char,POINTER(DWORD,POINTER(DWORD,0x00CE3358)+adder)+0xF);
			if(Tester == '#')
			{
				char * GameSessionInfo = (POINTER(char*,POINTER(DWORD,0x00CE3358)+adder)+0x10);
				std::stringstream infoconvert(GameSessionInfo);
				std::string process;
				short mainslotsmin = 0;
				while(std::getline(infoconvert,process))
				{
					//MessageBox(NULL,GameSessionInfo,"char",0);
					unsigned int WhatSlot = process.find("Slot ");
					if (WhatSlot != std::string::npos)
					{
						short slot = (process[WhatSlot+5]-48)-mainslotsmin;
						pinfo::Nation tempNation;
						unsigned int Nation = process.find("(Rising Sun),");
						if(Nation != std::string::npos)
						{
							tempNation = pinfo::Nation::N_JAPAN;
						}
						else
						{
							Nation = process.find("(Allies),"); 
							if(Nation != std::string::npos)
							{
								tempNation = pinfo::Nation::N_ALLIES;
							}
							else 
							{
								Nation = process.find("(Soviets),"); 
								if(Nation != std::string::npos)
								{
									tempNation = pinfo::Nation::N_SOVIET;
								}
								else
								{
									tempNation = pinfo::Nation::N_UNKNOWN;
									++mainslotsmin;
								}
							}
						}
						if(tempNation != pinfo::Nation::N_UNKNOWN)
						{
							unsigned int WhatController = process.find("Human",Nation);
							pinfo::Controller tempCtrl = pinfo::Controller::Ctrl_UNKNOWN;
							if (WhatController != std::string::npos)
								tempCtrl = pinfo::Controller::Ctrl_HUMAN;
							else
								tempCtrl = pinfo::Controller::Ctrl_AI;
							Player[slot].in = true;
							Player[slot].Side = tempNation;
							Player[slot].Who = tempCtrl;
							unsigned int start = WhatSlot+8;
							unsigned int amount = Nation - start;
							Player[slot].Name.assign(process.substr(start,amount));
							unsigned int TeamPos = process.find("Team:",Nation);
							if(process[TeamPos+5] == '-')
							{
								Player[slot].Team = -1;
							}
							else
							{
								Player[slot].Team = process[TeamPos+5]-48;
							}
							unsigned int CurrentSlot = (0xD8+(0x4*slot));
							if(POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot) != NULL)
							{
								Player[slot].Color = &POINTER(unsigned int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0x40)+0x0)+0x40);
								Player[slot].Money = &POINTER(int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0xE4)+0x0)+0x4);
								Player[slot].Power = &POINTER(int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0x8)+0x6C)+0x4);
								Player[slot].Usage = &POINTER(int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0x8)+0x6C)+0x8);
								Player[slot].unit_start_node = &POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot) + 0x38) + 0x0C);
							}
						}
					}
				}
				max_sessions = i;
				got_session = true;
			}
			else
			{
				break;
			}
			UNPROTECT;
		}
	}
	if(!Displaying)
	{
		float CurrDrawHeight = 10.0f;
		float StartWidth = 0.0f;
		short SelectSlot = -1;
		for(int i = 0; i < 6; ++i)
		{
			if(!Player[i].in)	
				break;
			std::stringstream display("");
			switch(Player[i].Side)
			{
				case pinfo::Nation::N_ALLIES:{display << "A ";break;}
				case pinfo::Nation::N_JAPAN: {display << "J ";break;}
				case pinfo::Nation::N_SOVIET:{display << "S ";break;}
				default:					 {display << "U ";break;}
			}
			if(!Player[i].GotUnits)
			{
				if(POINTER(DWORD,*Player[i].unit_start_node+0x10) > 256)
				{
					Player[i].GotUnits = true;
					UnitList[i][(&POINTER(UnitsInfo,*Player[i].unit_start_node))->nodes[2]] = &POINTER(UnitsInfo,*Player[i].unit_start_node);
					GenerateUnitList(i);
				}
			}
			else
				GenerateUnitList(i);
			StartWidth = DirectXFont::Access(0)->DrawLength("0 000000000000000000000000 0000000 0000/0000")+10.0f;
			render->D3DBox(5.0f,CurrDrawHeight-1.0f,DirectXFont::Access(0)->DrawLength("0 000000000000000000000000 0000000 0000/0000")+10.0f,15.0f,(User::Settings::Data.Transparency + (*Player[i].Color & 0x00FFFFFF)));
			if(MouseX >= 5 && MouseX <= (int)(DirectXFont::Access(0)->DrawLength("0 000000000000000000000000 0000000 0000/0000")+10.0f) && MouseY >= (int)(CurrDrawHeight-1.0f) && MouseY <= (int)((CurrDrawHeight-1.0f)+15.0f))
				SelectSlot = i;
			display << std::setw(24) << Player[i].Name.c_str() << " " << std::setw(7) << *Player[i].Money << "{FF" << ((*Player[i].Usage > *Player[i].Power) ? ("FF00") : ((*Player[i].Usage >= (*Player[i].Power-25)) ? ("FF7F") : ("00FF"))) << "00} " << std::setw(4) << *Player[i].Usage << "/" << std::setw(4) << *Player[i].Power << "\0";
			DirectXFont::Access(0)->Print(10.0,CurrDrawHeight,0xFFFFFFFF,display.str().c_str(),true);
			CurrDrawHeight += 15.0f;
		}
		if(SelectSlot != -1)
		{
			//DirectXFont::Access(0)->Print(MouseX,MouseY+5,0xFFFFFFFF,string_format("Current Selected player: %s",Player[SelectSlot].Name.c_str()).c_str(),true);
			if(User::Settings::Data.Buildtest)
			{
				if(Keys(VK_MENU).Down)
				{
					CurrDrawHeight = 10.0f;
					StartWidth += 10.0f;
					for(auto it = Units[SelectSlot].begin(); it != Units[SelectSlot].end(); ++it)
					{
						if(it->second > 0)
						{
							std::stringstream display("");
							display << std::setw(4) << it->second << " " << std::setw(24) << it->first.c_str() << "\0";
							render->D3DBox(StartWidth,CurrDrawHeight-1.0f,DirectXFont::Access(0)->DrawLength(display.str().c_str())+10.0f,15.0f,0xAA000000);
							DirectXFont::Access(0)->Print(StartWidth+5.0f,CurrDrawHeight,0xFFFFFFFF,display.str().c_str(),true);
							CurrDrawHeight += 15.0f;
						}
					}
				}
			}
		}
	}
	UNPROTECT;
}


void InitializeDX(myIDirect3DDevice9 * device)
{
	DirectXFont::Add("Lucida Console",10.0f,FW_BOLD);
	DirectXFont::InitializeAll();
}

void UninitializeDX(myIDirect3DDevice9 * device)
{
	DirectXFont::InvalidateAll();
}

void OnGameLaunch()
{
	if(GameInternsInited)
		return;

	GameInternsInited = true;


	//Japan
	UnitNames[472840039]  = "Japan MCV";
	UnitNames[3333683370] = "Generator Core";
	UnitNames[1475377722] = "Dojo Core";
	UnitNames[4283075424] = "Refinery Core";
	UnitNames[2462967055] = "Japan Ore Collector";
	UnitNames[317183908]  = "Burst Drone";
	UnitNames[263203925]  = "Imperal Warrior";
	UnitNames[2097498589] = "Tankbuster";
	UnitNames[551280588]  = "Japan Engineer";
	UnitNames[2687381971] = "Mecha Bay Core";
	UnitNames[2027152172] = "Mainframe Core";
	UnitNames[4031077785] = "Docks Core";
	UnitNames[2808668694] = "Shinobi";
	UnitNames[395436146]  = "Sudden Transport";
	UnitNames[524905323]  = "Defender Core";
	UnitNames[1703323040] = "Yuriko Omega";
	UnitNames[3625717778] = "Rocket Angle";
	UnitNames[3281546964] = "Mecha Tengu";
	UnitNames[3468155423] = "Tsunami Tank";
	UnitNames[1854693375] = "Striker-VX";
	UnitNames[1502645858] = "King Oni";
	UnitNames[2427985212] = "Wave-Force Artillery";
	UnitNames[3470418429] = "Yar Mini-Sub";
	UnitNames[2973949638] = "Sea-Wing";
	UnitNames[439134635]  = "Naginata Cruiser";
	UnitNames[4234031892] = "Shogun Battleship";
	UnitNames[605223810]  = "Tower Core";
	UnitNames[1607020577] = "Nanoswarm Core";
	UnitNames[1545342735] = "Decimator Core";

	//Allies
	UnitNames[685397838]  = "Allied MCV";
	UnitNames[1015200016] = "Apollo Fighter";
	UnitNames[3075441480] = "Vindicator";
	UnitNames[706309745]  = "Prospector";
	UnitNames[1352487169] = "Cryocopter";
	UnitNames[3724290270] = "Attack Dog";
	UnitNames[329038999]  = "Peacekeeper";
	UnitNames[2211817579] = "Century Bomber";
	UnitNames[2623355832] = "Javelin Soldier";
	UnitNames[3790149531] = "Allied Engineer";
	UnitNames[1252381973] = "Spy";
	UnitNames[1407249170] = "Tanya";
	UnitNames[1080603607] = "Ripitide ACV";
	UnitNames[3137747290] = "Multigunner IFV";
	UnitNames[129570087]  = "Guardian Tank";
	UnitNames[3566131256] = "Athena Cannon";
	UnitNames[1388308933] = "Mirage Tank";
	UnitNames[2328510325] = "Dolphin";
	UnitNames[773921433]  = "Hydrofoil";
	UnitNames[1524970748] = "Assault Destroyer";
	UnitNames[158358912]  = "Aircraft Carrier";

	//Soviet
	UnitNames[4141531812] = "Soviet Ore Collector";
	UnitNames[855797665]  = "War Bear";
	UnitNames[430641583]  = "Conscript";
	UnitNames[741706849]  = "Flak Trooper";
	UnitNames[2693442515] = "Soviet Engineer";
	UnitNames[1041335901] = "Tesla Trooper";
	UnitNames[391087951]  = "Natasha";
	UnitNames[3144182497] = "Sputnik";
	UnitNames[3611415335] = "Terror Drone";
	UnitNames[1626387689] = "Sickle";
	UnitNames[1378601825] = "Bullfrog";
	UnitNames[2494781707] = "Hammer Tank";
	UnitNames[2182316510] = "V4 Rocket Launcher";
	UnitNames[2655336508] = "Apocalypse Tank";
	UnitNames[2940997029] = "Soviet MCV";
	UnitNames[2136264401] = "MiG Fighter";
	UnitNames[1085058413] = "Twinblade";
	UnitNames[4289204654] = "Kirov Airship";
	UnitNames[2952146552] = "Stingray";
	UnitNames[2366257226] = "Akula Sub";
	UnitNames[3169800633] = "Dreadnought";
	/*if(User::Settings::Load())
		Drawer::AddQueue("Settings {FF00FF00}loaded");
	else
		Drawer::AddQueue("Settings {FFFF0000}cannot be loaded");
	*/
	Drawer::AddQueue(" ",0);
}