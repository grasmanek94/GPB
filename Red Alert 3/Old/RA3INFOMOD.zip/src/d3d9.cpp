﻿/*
* RA3INFO | 'Red Alert 3' By Gamer_Z/Grasmanek94 | http://gpb.googlecode.com/
*/
#include <main.h>

bool Displaying = false;

inline bool IsPlayerInGame()
{
	return (POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+0xD8) != NULL);
	//return (PlayerSlot != (-1));
}

namespace Drawer
{
	struct TextInfo
	{
		std::string text;
		float x,y;
		DWORD start,end;
		DWORD color;
		bool textcoloring;
		TextInfo(float _x, float _y, std::string _text, DWORD _start, DWORD _end, DWORD _color, bool _tc = false)
		{
			x = _x;
			y = _y;
			text.assign(_text.c_str());
			start = _start;
			end = _end;
			color = _color;
			textcoloring = _tc;
		}
	};

	std::vector<TextInfo> data;
	TextInfo DisplayNow(0.0f,10.0f,"",0,0,0xFFFFFFFF,true);

	void Add(float x, float y, std::string text, DWORD time, DWORD delay, DWORD color, bool TextColoring)
	{
		DWORD PUT = GetTickCount()+delay;
		data.push_back(TextInfo(x,y,text,PUT,PUT+time,color,TextColoring));
	}
	void AddQueue(std::string text, DWORD time = 1000)
	{
		DisplayNow.text.assign(text);
		DWORD PUT = GetTickCount();
		DisplayNow.start = PUT;
		DisplayNow.end = PUT+time;
	}
	void Display()
	{
		Displaying = false;
		DWORD now = GetTickCount();
		for(unsigned int i = 0, j = data.size(); i < j; ++i)
			if(data.at(i).end > now)
				data.erase(data.begin()+i);
		for(unsigned int i = 0, j = data.size(); i < j; ++i)
			if(data.at(i).start >= now)
			{
				Displaying = true;
				DirectXFont::Access(0)->Print(data.at(i).x,data.at(i).y,data.at(i).color,data.at(i).text.c_str(),data.at(i).textcoloring);
			}
			if(DisplayNow.end > now)
			{
				Displaying = true;
				//render->D3DBox(0.0,10.0f,DirectXFont::Access(0)->DrawLength(DisplayNow.text.c_str()),DirectXFont::Access(0)->DrawHeight(),0x77000000);
				DirectXFont::Access(0)->Print(0.0f,10.0f,0xFFFFFFFF,DisplayNow.text.c_str(),true);
			}
	}
};

namespace User
{
	struct Options
	{
		bool Cheat;
		//bool Colors;
		unsigned int Transparency;
		Options() : 
			Cheat(true),Transparency(0x8F000000)/*, Colors(false)*/
		{

		}
	};

	namespace Settings
	{
		Options Data;
		/*std::ofstream& operator<<(std::ofstream& stream, Options &info)
		{
			stream.write(reinterpret_cast<char*>(&info.Cheat), sizeof(bool));
			stream.write(reinterpret_cast<char*>(&info.Colors), sizeof(bool));
			stream.write(reinterpret_cast<char*>(&info.Transparency), sizeof(unsigned int));
			return stream;
		}

		std::ifstream& operator>>(std::ifstream& stream, Options &info)
		{
			stream.read(reinterpret_cast<char*>(&info.Cheat), sizeof(bool));
			stream.read(reinterpret_cast<char*>(&info.Colors), sizeof(bool));
			stream.read(reinterpret_cast<char*>(&info.Transparency), sizeof(unsigned int));
			return stream;
		}

		bool Save()
		{
			std::ofstream myfile(".\\RA3INFO.settings.dat",std::ios::binary);
			if(myfile.good())
			{
				myfile << Data;
				myfile.close();
				return true;
			}
			return false;
		}

		bool Load()
		{
			std::ifstream myfile(".\\RA3INFO.settings.dat",std::ios::binary);	
			if(myfile.good())
			{
				myfile >> Data;
				myfile.close();
				return true;
			}
			return false;
		}*/

		void CheckChange()
		{
			if(Keys(VK_APPS).Down)
			{
				/*if(Keys(VK_F7).ConsumePressed())
				{
					if(User::Settings::Load())
						Drawer::AddQueue("Settings {FFFF0000}Loaded");
					else
						Drawer::AddQueue("Settings {FF00FF00}cannot be loaded");					
				}
				if(Keys(VK_F8).ConsumePressed())
				{
					if(User::Settings::Save())
						Drawer::AddQueue("Settings {FFFF0000}Saved");
					else
						Drawer::AddQueue("Settings {FF00FF00}cannot be saved");
				}*/
				if(Keys(VK_F9).ConsumePressed())
				{
					Data.Cheat ^= 1;
					if(!Data.Cheat)
						Drawer::AddQueue("Cheats {FFFF0000}Disabled");
					else
						Drawer::AddQueue("Cheats {FF00FF00}Enabled");
				}

				/*if(Keys(VK_F10).ConsumePressed())
				{
					if(!IsPlayerInGame())
					{
						Data.Colors ^= 1;
						if(!Data.Colors)
							Drawer::AddQueue("Ally Colors {FFFF0000}Disabled");
						else
							Drawer::AddQueue("Ally Colors {FF00FF00}Enabled");
					}
					else
						Drawer::AddQueue("Cannot Change Ally Colors option In-Game!");
				}*/
				if(Keys(VK_F12).ConsumePressed())
				{
					Data.Transparency += 0x10000000;
					if(Data.Transparency > 0xFF000000)
						Data.Transparency = 0xFF000000;
				}
				if(Keys(VK_F11).ConsumePressed())
				{
					Data.Transparency -= 0x10000000;
					if(Data.Transparency < 0x00000000)
						Data.Transparency = 0x00000000;
				}
			}//ConsumeDown(VK_APPS)
		}
	};
};

struct RA3{
	static std::map<int,int> create_map()
	{
		std::map<int,int> m;
		m[-1]= 0xFFFFFFFF;
		m[0] = 0xFF324BC8;
		m[1] = 0xFFF0D719;
		m[2] = 0xFF14693C;
		m[3] = 0xFFE17314;
		m[4] = 0xFF7D19C8;
		m[5] = 0xFFE61414;
		m[6] = 0xFF66CFF8;
		return m;
	}
	static const std::map<int,int> PlayerColors;
};
const std::map<int,int> RA3:: PlayerColors =  RA3::create_map();

unsigned int max_sessions = 1;

#define MAX_PLAYERS (6)

struct pinfo
{
	bool			in;
	enum Controller	{Ctrl_UNKNOWN,	Ctrl_HUMAN,	Ctrl_AI				};
	enum Nation		{N_UNKNOWN,		N_ALLIES,	N_SOVIET,	N_JAPAN	};
	std::string		Name;
	Nation			Side;
	short			Team;
	Controller		Who;
	int				*Money;
	int				*Power;
	int				*Usage;
	unsigned int	*Color;
};

pinfo Player[MAX_PLAYERS];

void FrameTick(myIDirect3DDevice9 * device, HWND wnd)
{
	PROTECT;
	KeyManagerRun();//key press/release detection

	User::Settings::CheckChange();
	Drawer::Display();

	static bool got_session = false;

	if(!User::Settings::Data.Cheat || !IsPlayerInGame())
	{
		if(!IsPlayerInGame())
		{
			if(got_session)
			{
				++max_sessions;
				got_session = false;
				for(short i = 0; i < MAX_PLAYERS; ++i)
				{
					Player[i].in = false;
					Player[i].Money = NULL;
					Player[i].Power = NULL;
					Player[i].Color = NULL;
					Player[i].Usage = NULL;
				}
			}
			if(!Displaying)
			{
				DirectXFont::Access(0)->Print(0.0,0.0,0xFFFF0000, "RA3{FFFFFF00}INFO {FF00FFFF}MOD",true);
				DirectXFont::Access(0)->Print(0.0,11.0,0xFFFFFFFF,"By Gamer_Z a.k.a Grasmanek94",true);
				DirectXFont::Access(0)->Print(0.0,22.0,0xFFFFFF00,"Website: {FF00FFFF}http://gpb.googlecode.com/",true);
			}
		}
		return;
	}

	if(!got_session)
	{
		for(unsigned int i = max_sessions; ; ++i)
		{
			PROTECT;
			unsigned int adder = (0x4 * (i - 1));
			auto& Tester = POINTER(char,POINTER(DWORD,POINTER(DWORD,0x00CE3358)+adder)+0xF);
			if(Tester == '#')
			{
				char * GameSessionInfo = (POINTER(char*,POINTER(DWORD,0x00CE3358)+adder)+0x10);
				std::stringstream infoconvert(GameSessionInfo);
				std::string process;
				short mainslotsmin = 0;
				while(std::getline(infoconvert,process))
				{
					//MessageBox(NULL,GameSessionInfo,"char",0);
					unsigned int WhatSlot = process.find("Slot ");
					if (WhatSlot != std::string::npos)
					{
						short slot = (process[WhatSlot+5]-48)-mainslotsmin;
						pinfo::Nation tempNation;
						unsigned int Nation = process.find("(Rising Sun),");
						if(Nation != std::string::npos)
						{
							tempNation = pinfo::Nation::N_JAPAN;
						}
						else
						{
							Nation = process.find("(Allies),"); 
							if(Nation != std::string::npos)
							{
								tempNation = pinfo::Nation::N_ALLIES;
							}
							else 
							{
								Nation = process.find("(Soviets),"); 
								if(Nation != std::string::npos)
								{
									tempNation = pinfo::Nation::N_SOVIET;
								}
								else
								{
									tempNation = pinfo::Nation::N_UNKNOWN;
									++mainslotsmin;
								}
							}
						}
						if(tempNation != pinfo::Nation::N_UNKNOWN)
						{
							unsigned int WhatController = process.find("Human",Nation);
							pinfo::Controller tempCtrl = pinfo::Controller::Ctrl_UNKNOWN;
							if (WhatController != std::string::npos)
								tempCtrl = pinfo::Controller::Ctrl_HUMAN;
							else
								tempCtrl = pinfo::Controller::Ctrl_AI;
							Player[slot].in = true;
							Player[slot].Side = tempNation;
							Player[slot].Who = tempCtrl;
							unsigned int start = WhatSlot+8;
							unsigned int amount = Nation - start;
							Player[slot].Name.assign(process.substr(start,amount));
							unsigned int TeamPos = process.find("Team:",Nation);
							if(process[TeamPos+5] == '-')
							{
								Player[slot].Team = -1;
							}
							else
							{
								Player[slot].Team = process[TeamPos+5]-48;
							}
							unsigned int CurrentSlot = (0xD8+(0x4*slot));
							if(POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot) != NULL)
							{
								Player[slot].Color = &POINTER(unsigned int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0x40)+0x0)+0x40);
								Player[slot].Money = &POINTER(int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0xE4)+0x0)+0x4);
								Player[slot].Power = &POINTER(int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0x8)+0x6C)+0x4);
								Player[slot].Usage = &POINTER(int,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,POINTER(DWORD,0x00400000+0x008E98EC)+CurrentSlot)+0x8)+0x6C)+0x8);
							}
						}
					}
				}
				max_sessions = i;
				got_session = true;
			}
			else
			{
				break;
			}
			UNPROTECT;
		}
	}

	float CurrDrawHeight = 10.0f;
	for(int i = 0; i < 6; ++i)
	{
		if(!Displaying)
		{
			
			std::stringstream display("");
			switch(Player[i].Side)
			{
				case pinfo::Nation::N_ALLIES:{display << "A ";break;}
				case pinfo::Nation::N_JAPAN: {display << "J ";break;}
				case pinfo::Nation::N_SOVIET:{display << "S ";break;}
				default:					 {display << "U ";break;}
			}
			render->D3DBox(5.0f,CurrDrawHeight-1.0,DirectXFont::Access(0)->DrawLength("0 000000000000000000000000 0000000 0000/0000")+10.0f,15.0f,(User::Settings::Data.Transparency + (*Player[i].Color & 0x00FFFFFF)));
			display << std::setw(24) << Player[i].Name.c_str() << " " << std::setw(7) << *Player[i].Money << "{FF" << ((*Player[i].Usage > *Player[i].Power) ? ("FF00") : ((*Player[i].Usage >= (*Player[i].Power-25)) ? ("FF7F") : ("00FF"))) << "00} " << std::setw(4) << *Player[i].Usage << "/" << std::setw(4) << *Player[i].Power << "\0";
			DirectXFont::Access(0)->Print(10.0,CurrDrawHeight,0xFFFFFFFF,display.str().c_str(),true);
			CurrDrawHeight += 15.0f;
		}
	}
	UNPROTECT;
}


void InitializeDX(myIDirect3DDevice9 * device)
{
	DirectXFont::Add("Lucida Console",10.0f,FW_BOLD);
	DirectXFont::InitializeAll();
}

void UninitializeDX(myIDirect3DDevice9 * device)
{
	DirectXFont::InvalidateAll();
}

bool GameInternsInited = false;
void OnGameLaunch()
{
	if(GameInternsInited)
		return;

	GameInternsInited = true;

	/*if(User::Settings::Load())
		Drawer::AddQueue("Settings {FF00FF00}loaded");
	else
		Drawer::AddQueue("Settings {FFFF0000}cannot be loaded");
	*/
	Drawer::AddQueue(" ",0);
}