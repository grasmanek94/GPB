/*****************************************************************************
*
*  PROJECT:     Multi Theft Auto v1.0
*  LICENSE:     See LICENSE in the top level directory
*  FILE:        sdk/game/CAnimBlendSequence.h
*  PURPOSE:     Animation blend sequence interface
*
*  Multi Theft Auto is available from http://www.multitheftauto.com/
*
*****************************************************************************/

#ifndef __CAnimBlendSequence_H
#define __CAnimBlendSequence_H

class CAnimBlendSequence
{
public:
};

#endif
