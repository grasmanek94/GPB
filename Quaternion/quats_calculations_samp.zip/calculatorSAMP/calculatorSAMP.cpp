/*
* Default Includes
*/
#include <stdio.h>
#include <stdlib.h>
#include <iostream>

/*
* AMX Includes
*/
#include "./SDK/amx/amx.h"
#include "./SDK/plugincommon.h"

/*
* Converter Includes
*/

#include "EulerAngles.c"

extern void * pAMXFunctions;

using namespace std;  

PLUGIN_EXPORT unsigned int PLUGIN_CALL Supports() 
{
	return SUPPORTS_VERSION | SUPPORTS_AMX_NATIVES;
}

PLUGIN_EXPORT bool PLUGIN_CALL Load( void **ppData ) 
{
	pAMXFunctions = ppData[PLUGIN_DATA_AMX_EXPORTS];
	cout << "    Euler (c) 2012 by Gamer_Z";
	return true;
}

PLUGIN_EXPORT void PLUGIN_CALL Unload( )
{
	cout << "    Euler (c) 2012 by Gamer_Z";
}

//native QuatToEuler(Float:qX,Float:qY,Float:qZ,Float:qW,&Float:eX,&Float:eY,&Float:eZ,&Float:eW,order=0);

static cell AMX_NATIVE_CALL n_QuatToEuler( AMX* amx, cell* params )
{
	Quat q;
	q.x = amx_ctof(params[1]);
	q.y = amx_ctof(params[2]);
	q.z = amx_ctof(params[3]);
	q.w = amx_ctof(params[4]);
	EulerAngles EU = Eul_FromQuat(q,params[9]);
	cell* cptr;
	amx_GetAddr(amx, params[5], &cptr);
	*cptr = amx_ftoc(EU.x);
	amx_GetAddr(amx, params[6], &cptr);
	*cptr = amx_ftoc(EU.y);
	amx_GetAddr(amx, params[7], &cptr);
	*cptr = amx_ftoc(EU.z);
	amx_GetAddr(amx, params[8], &cptr);
	*cptr = amx_ftoc(EU.w);
	return 1;
}

AMX_NATIVE_INFO AMXNatives[ ] =
{
	{"QuatToEuler", n_QuatToEuler},
	{0,                0}
};

PLUGIN_EXPORT int PLUGIN_CALL AmxLoad( AMX *amx ) 
{
	return amx_Register( amx, AMXNatives, -1 );
}

PLUGIN_EXPORT int PLUGIN_CALL AmxUnload( AMX *amx ) 
{
	return AMX_ERR_NONE;
}
